/**
 * NetSuite Order Sync Service
 *
 * Three-phase sync that keeps WMS picking/packing queues in sync with NetSuite:
 *   Phase 1: Fetch all Sales Orders + Item Fulfillments from NetSuite
 *   Phase 2: Upsert — create new WMS orders or update existing ones
 *   Phase 3: Cleanup — cancel stale orders no longer in NetSuite
 *
 * Sales Orders (pending fulfillment) → PENDING (picking queue)
 * Item Fulfillments (picked/packed)  → PICKED  (packing queue)
 * Item Fulfillments (shipped)        → SHIPPED (done)
 *
 * @domain integrations
 * @dependencies NetSuiteClient, OrderRepository
 */

import {
  NetSuiteClient,
  NetSuiteCredentials,
  NetSuiteSalesOrder,
  NetSuiteSalesOrderLine,
} from './NetSuiteClient';
import { logger } from '../config/logger';
import { query as sharedQuery } from '../db/client';
import { tenantPoolManager } from '../db/tenantContext';
import { OrderPriority, generateOrderId } from '@opsui/shared';
import { Pool } from 'pg';

// ============================================================================
// TYPES
// ============================================================================

export interface NetSuiteSyncResult {
  totalProcessed: number;
  succeeded: number;
  failed: number;
  skipped: number;
  updated: number;
  cleaned: number;
  details: {
    imported: string[];
    updated: string[];
    failed: Array<{ tranId: string; error: string }>;
    skipped: Array<{ tranId: string; reason: string }>;
    cleaned: string[];
  };
}

export interface NetSuiteSyncOptions {
  /** Sync only orders modified after this date */
  lastSyncAt?: Date;
  /** Maximum number of orders to pull */
  limit?: number;
  /** NetSuite sales order status filter */
  status?: string;
  /** Create orders even if SKUs don't exist (will fail) */
  createMissingSkus?: boolean;
  /** Sync start timestamp (for stale cleanup) */
  syncStartTime?: Date;
}

export interface NetSuiteOrderPreview {
  tranId: string;
  customerName: string;
  orderDate: string;
  shipDate?: string;
  lineCount: number;
  status: string;
  canImport: boolean;
  issues: string[];
}

// ============================================================================
// HELPERS
// ============================================================================

/**
 * Decode HTML entities from NetSuite SOAP responses
 */
function decodeHtmlEntities(text: string): string {
  if (!text) return text;
  return text
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&#(\d+);/g, (_match, dec) => String.fromCharCode(parseInt(dec, 10)));
}

// ============================================================================
// SERVICE
// ============================================================================

interface NetSuiteItemDetails {
  itemId: string;
  displayName: string;
  upcCode: string;
  binNumber: string;
}

interface ExistingOrder {
  orderId: string;
  status: string;
  netsuiteIfInternalId: string | null;
}

export class NetSuiteOrderSyncService {
  private client: NetSuiteClient;
  private organizationId: string | null = null;
  private tenantPool: Pool | null = null;
  private itemCache: Map<string, NetSuiteItemDetails> = new Map();

  /**
   * Execute a query against the correct database (tenant or shared).
   * Uses tenant pool if the integration's org has a dedicated database.
   */
  private async query<T extends Record<string, any> = Record<string, any>>(
    text: string,
    params?: any[]
  ) {
    if (this.tenantPool) {
      const start = Date.now();
      const result = await this.tenantPool.query<any>(text, params);
      logger.debug('Tenant query executed', {
        duration: `${Date.now() - start}ms`,
        rows: result.rowCount,
        sql: text.substring(0, 100),
      });
      return { ...result, rows: result.rows || [] };
    }
    return sharedQuery<T>(text, params);
  }

  constructor(credentialsOrClient?: NetSuiteCredentials | NetSuiteClient) {
    if (credentialsOrClient instanceof NetSuiteClient) {
      this.client = credentialsOrClient;
    } else {
      this.client = new NetSuiteClient(credentialsOrClient);
    }
  }

  // ========================================================================
  // SCHEMA MIGRATION (idempotent)
  // ========================================================================

  /**
   * Ensure NetSuite tracking columns exist on the orders table.
   * Runs on every sync — all statements are idempotent (IF NOT EXISTS / safe).
   */
  private async ensureSchemaColumns(): Promise<void> {
    const columns = [
      { name: 'netsuite_so_internal_id', type: 'VARCHAR(50)' },
      { name: 'netsuite_so_tran_id', type: 'VARCHAR(50)' },
      { name: 'netsuite_if_internal_id', type: 'VARCHAR(50)' },
      { name: 'netsuite_if_tran_id', type: 'VARCHAR(50)' },
      { name: 'netsuite_last_synced_at', type: 'TIMESTAMP WITH TIME ZONE' },
      { name: 'netsuite_source', type: 'VARCHAR(20)' },
    ];

    for (const col of columns) {
      try {
        await this.query(`ALTER TABLE orders ADD COLUMN IF NOT EXISTS ${col.name} ${col.type}`);
      } catch {
        // Column may already exist — safe to ignore
      }
    }

    // Create indexes for fast lookups
    try {
      await this.query(
        `CREATE INDEX IF NOT EXISTS idx_orders_ns_so_id ON orders(netsuite_so_internal_id) WHERE netsuite_so_internal_id IS NOT NULL`
      );
      await this.query(
        `CREATE INDEX IF NOT EXISTS idx_orders_ns_if_id ON orders(netsuite_if_internal_id) WHERE netsuite_if_internal_id IS NOT NULL`
      );
      await this.query(
        `CREATE INDEX IF NOT EXISTS idx_orders_ns_so_tran ON orders(netsuite_so_tran_id) WHERE netsuite_so_tran_id IS NOT NULL`
      );
    } catch {
      // Indexes may already exist
    }

    // Backfill existing orders that were created with old approach
    try {
      await this.query(
        `UPDATE orders
         SET netsuite_so_tran_id = SUBSTRING(customer_email FROM 10),
             netsuite_source = 'NETSUITE'
         WHERE customer_email LIKE 'netsuite:SO%'
           AND netsuite_so_tran_id IS NULL`
      );
      await this.query(
        `UPDATE orders
         SET netsuite_if_tran_id = SUBSTRING(customer_email FROM 10),
             netsuite_source = 'NETSUITE'
         WHERE customer_email LIKE 'netsuite:IF%'
           AND netsuite_if_tran_id IS NULL`
      );
      // Also mark any other netsuite: prefixed orders
      await this.query(
        `UPDATE orders
         SET netsuite_source = 'NETSUITE'
         WHERE customer_email LIKE 'netsuite:%'
           AND netsuite_source IS NULL`
      );
    } catch {
      // Backfill may fail on first run if columns don't exist yet — safe
    }
  }

  // ========================================================================
  // MAIN SYNC METHOD — THREE-PHASE
  // ========================================================================

  /**
   * Sync orders from NetSuite to WMS using three-phase approach:
   * 1. Fetch all SOs + IFs from NetSuite
   * 2. Upsert: create new or update existing WMS orders
   * 3. Cleanup: cancel stale PENDING orders not seen in NetSuite
   */
  async syncOrders(
    _integrationId: string,
    _options: NetSuiteSyncOptions = {}
  ): Promise<NetSuiteSyncResult> {
    // Look up the organization this integration belongs to (always from shared DB)
    const orgResult = await sharedQuery(
      `SELECT io.organization_id, o.database_name
       FROM integration_organizations io
       JOIN organizations o ON o.organization_id = io.organization_id
       WHERE io.integration_id = $1 LIMIT 1`,
      [_integrationId]
    );
    this.organizationId = orgResult.rows[0]?.organizationId || null;
    const databaseName = orgResult.rows[0]?.databaseName || null;

    if (!this.organizationId) {
      logger.warn('No organization mapping found for integration, orders will have no org scope', {
        integrationId: _integrationId,
      });
    }

    // If the org has a dedicated tenant database, use that pool for all writes
    if (databaseName) {
      this.tenantPool = tenantPoolManager.getPool(databaseName);
      logger.info('NetSuite sync using tenant database', {
        integrationId: _integrationId,
        organizationId: this.organizationId,
        database: databaseName,
      });
    } else {
      this.tenantPool = null;
    }

    // Ensure schema columns exist (idempotent)
    await this.ensureSchemaColumns();

    // Clear item cache for fresh sync
    this.itemCache.clear();

    const syncStartTime = _options.syncStartTime || new Date();

    const result: NetSuiteSyncResult = {
      totalProcessed: 0,
      succeeded: 0,
      failed: 0,
      skipped: 0,
      updated: 0,
      cleaned: 0,
      details: {
        imported: [],
        updated: [],
        failed: [],
        skipped: [],
        cleaned: [],
      },
    };

    try {
      logger.info('Starting NetSuite three-phase order sync');

      // ====================================================================
      // PHASE 1: Fetch pending fulfillment Sales Orders from NetSuite
      // Search returns full data with line items (bodyFieldsOnly=false)
      // ====================================================================

      let allSalesOrders: NetSuiteSalesOrder[] = [];
      try {
        const soResponse = await this.client.getSalesOrders({
          limit: 200,
          status: '_pendingFulfillment',
        });
        allSalesOrders = (soResponse.items || []) as NetSuiteSalesOrder[];
        logger.info('Phase 1: Fetched pending sales orders from NetSuite', {
          count: allSalesOrders.length,
        });
      } catch (error: any) {
        logger.warn('Phase 1: Failed to fetch sales orders', { error: error.message });
      }

      // Build set of SO internal IDs currently pending fulfillment in NetSuite
      const currentPendingSoIds = new Set<string>();
      for (const so of allSalesOrders) {
        if (so.readyToShip) currentPendingSoIds.add(so.id);
      }

      result.totalProcessed = allSalesOrders.length;

      // ====================================================================
      // PHASE 2: Upsert Sales Orders into WMS (picking queue)
      // ====================================================================

      for (const salesOrder of allSalesOrders) {
        try {
          const syncResult = await this.upsertFromSalesOrder(
            salesOrder,
            new Map(), // No fulfillment map needed — Phase 3 handles status transitions
            syncStartTime,
            _options
          );

          if (syncResult.created) {
            result.succeeded++;
            result.details.imported.push(syncResult.tranId);
          } else if (syncResult.updated) {
            result.updated++;
            result.details.updated.push(syncResult.tranId);
          } else if (syncResult.skipped) {
            result.skipped++;
            result.details.skipped.push({
              tranId: syncResult.tranId,
              reason: syncResult.reason || 'Unknown',
            });
          }
        } catch (error: any) {
          result.failed++;
          result.details.failed.push({
            tranId: salesOrder.tranId || salesOrder.id,
            error: error.message || 'Unknown error',
          });
          logger.error('Failed to sync sales order', {
            orderId: salesOrder.id,
            error: error.message,
          });
        }
      }

      // ====================================================================
      // PHASE 3: Check PENDING WMS orders no longer in NetSuite results
      // These were either fulfilled (→ PICKED) or cancelled
      // Only fetch fulfillment details for these few orders (not ALL 300+)
      // ====================================================================

      try {
        const pendingWmsOrders = await this.query(
          `SELECT order_id, netsuite_so_internal_id, netsuite_so_tran_id
           FROM orders
           WHERE netsuite_source = 'NETSUITE'
             AND status = 'PENDING'
             AND netsuite_so_internal_id IS NOT NULL`
        );

        logger.info('Phase 3: Checking WMS PENDING orders against NetSuite', {
          wmsPendingCount: pendingWmsOrders.rows.length,
          netSuitePendingCount: currentPendingSoIds.size,
        });

        // If Phase 1 succeeded, we have a reliable pending set
        // If Phase 1 failed (timeout), currentPendingSoIds will be empty
        const phase1Succeeded = currentPendingSoIds.size > 0;

        for (const row of pendingWmsOrders.rows) {
          const soId = row.netsuite_so_internal_id;
          
          // If Phase 1 succeeded and this SO is still pending, just mark synced
          if (phase1Succeeded && currentPendingSoIds.has(soId)) {
            await this.markOrderSynced(row.order_id, syncStartTime);
            continue;
          }

          // SO is not in pending set — either:
          // 1. Phase 1 failed (timeout) — need to check individually
          // 2. SO was fulfilled/cancelled on NetSuite
          try {
            const soDetail = await this.client.getSalesOrder(soId);
            const soStatus = (soDetail.status?.refName || '').toLowerCase();

            if (soStatus.includes('pending fulfillment')) {
              // Still pending — mark synced and keep in queue
              await this.markOrderSynced(row.order_id, syncStartTime);
              logger.debug('Order still pending fulfillment in NetSuite', {
                orderId: row.order_id,
                soTranId: row.netsuite_so_tran_id,
              });
            } else if (
              soStatus.includes('billed') ||
              soStatus.includes('closed') ||
              soStatus.includes('pending billing') ||
              soStatus.includes('fulfilled')
            ) {
              // SO was fulfilled/completed — mark as PICKED (it went through picking)
              await this.updateOrderStatus(row.order_id, 'PICKED');
              await this.markOrderSynced(row.order_id, syncStartTime);
              result.updated++;
              result.details.updated.push(row.netsuite_so_tran_id || soId);
              logger.info('Updated order to PICKED (SO no longer pending fulfillment)', {
                orderId: row.order_id,
                soTranId: row.netsuite_so_tran_id,
                newSoStatus: soStatus,
              });
            } else if (soStatus.includes('cancelled')) {
              // SO was cancelled
              await this.query(
                `UPDATE orders SET status = 'CANCELLED'::order_status, cancelled_at = NOW(), updated_at = NOW()
                 WHERE order_id = $1 AND status = 'PENDING'`,
                [row.order_id]
              );
              await this.markOrderSynced(row.order_id, syncStartTime);
              result.cleaned++;
              result.details.cleaned.push(row.netsuite_so_tran_id || soId);
              logger.info('Cancelled order (SO cancelled on NetSuite)', {
                orderId: row.order_id,
                soTranId: row.netsuite_so_tran_id,
              });
            } else {
              // Unknown status — keep in queue and mark synced
              await this.markOrderSynced(row.order_id, syncStartTime);
              logger.debug('Order has unknown NetSuite status, keeping in queue', {
                orderId: row.order_id,
                soTranId: row.netsuite_so_tran_id,
                soStatus,
              });
            }
          } catch (error: any) {
            // Individual SO lookup failed (likely timeout)
            // If Phase 1 also failed, this is expected — keep order for next cycle
            // If Phase 1 succeeded but this individual lookup failed, still retry next cycle
            logger.warn('Failed to check SO status for pending WMS order', {
              orderId: row.order_id,
              soId,
              soTranId: row.netsuite_so_tran_id,
              error: error.message,
              willRetry: true,
            });
            // Don't mark synced — will retry next cycle
          }
        }
      } catch (error: any) {
        logger.error('Phase 3: Status transition check failed', { error: error.message });
      }

      // ====================================================================
      // PHASE 4: Cleanup truly stale orders (safety net)
      // ====================================================================

      try {
        const cleanedCount = await this.cleanupStaleOrders(syncStartTime);
        result.cleaned += cleanedCount;
      } catch (error: any) {
        logger.error('Phase 4: Cleanup failed', { error: error.message });
      }

      logger.info('NetSuite three-phase sync completed', {
        totalProcessed: result.totalProcessed,
        succeeded: result.succeeded,
        updated: result.updated,
        failed: result.failed,
        skipped: result.skipped,
        cleaned: result.cleaned,
      });

      return result;
    } catch (error: any) {
      logger.error('NetSuite order sync failed', { error: error.message });
      throw error;
    }
  }

  // ========================================================================
  // PHASE 2: UPSERT METHODS
  // ========================================================================

  /**
   * Process a Sales Order: create if new, update status if existing.
   * If a fulfillment exists for this SO, transition to PICKED/SHIPPED.
   */
  private async upsertFromSalesOrder(
    salesOrder: NetSuiteSalesOrder,
    fulfillmentMap: Map<string, any[]>,
    syncStartTime: Date,
    _options: NetSuiteSyncOptions
  ): Promise<{
    created: boolean;
    updated: boolean;
    skipped: boolean;
    reason?: string;
    tranId: string;
  }> {
    const tranId = salesOrder.tranId;
    const soInternalId = salesOrder.id;

    // Check line items
    const lineItems = salesOrder.item?.items || [];
    if (lineItems.length === 0) {
      return { created: false, updated: false, skipped: true, reason: 'No line items', tranId };
    }

    // Only import orders marked "Ready To Ship" (custbody8) — matches NetSuite "Orders to Fulfill" page
    if (!salesOrder.readyToShip) {
      logger.debug('Sales order skipped — readyToShip is false', { tranId });
      return { created: false, updated: false, skipped: true, reason: 'Not ready to ship', tranId };
    }

    // Check if fulfillment exists for this SO
    const fulfillments = fulfillmentMap.get(soInternalId) || [];
    const hasFulfillment = fulfillments.length > 0;
    const latestFulfillment = fulfillments[fulfillments.length - 1];
    const isShipped =
      hasFulfillment && (latestFulfillment.shipStatus || '').toLowerCase().includes('shipped');

    logger.info('Processing sales order', {
      tranId,
      soInternalId,
      readyToShip: salesOrder.readyToShip,
      lineCount: lineItems.length,
      hasFulfillment: (fulfillmentMap.get(soInternalId) || []).length > 0,
    });

    // Look up existing WMS order
    const existing =
      (await this.findOrderByNetSuiteSoId(soInternalId)) ||
      (await this.findOrderByExternalIdFull(tranId));

    if (existing) {
      // UPDATE existing order
      let updated = false;

      if (isShipped && !['SHIPPED', 'CANCELLED'].includes(existing.status)) {
        // Fulfillment is shipped — mark as SHIPPED (skip if worker is active)
        if (!['PICKING', 'PACKING'].includes(existing.status)) {
          await this.updateOrderStatus(existing.orderId, 'SHIPPED', {
            ifInternalId: latestFulfillment.id,
            ifTranId: latestFulfillment.tranId,
          });
          updated = true;
          logger.info('Updated order to SHIPPED (fulfillment shipped on NetSuite)', {
            orderId: existing.orderId,
            tranId,
          });
        }
      } else if (hasFulfillment && existing.status === 'PENDING') {
        // Fulfillment exists but not shipped — order was picked on NetSuite
        await this.updateOrderStatus(existing.orderId, 'PICKED', {
          ifInternalId: latestFulfillment.id,
          ifTranId: latestFulfillment.tranId,
        });
        updated = true;
        logger.info('Updated order to PICKED (fulfillment created on NetSuite)', {
          orderId: existing.orderId,
          tranId,
        });
      }

      // Always mark as synced
      await this.markOrderSynced(existing.orderId, syncStartTime);

      // Ensure tracking columns are populated (backfill for old orders)
      // Also backfill total_amount from line items if missing
      try {
        await this.query(
          `UPDATE orders SET netsuite_so_internal_id = COALESCE(netsuite_so_internal_id, $1),
                             netsuite_so_tran_id = COALESCE(netsuite_so_tran_id, $2),
                             netsuite_source = 'NETSUITE',
                             subtotal = COALESCE(subtotal, (SELECT COALESCE(SUM(line_total), 0) FROM order_items WHERE order_id = $3)),
                             total_amount = COALESCE(total_amount, (SELECT COALESCE(SUM(line_total), 0) FROM order_items WHERE order_id = $3))
           WHERE order_id = $3`,
          [soInternalId, tranId, existing.orderId]
        );
      } catch {
        /* safe to ignore */
      }

      return {
        created: false,
        updated,
        skipped: !updated,
        reason: updated ? undefined : 'No status change needed',
        tranId,
      };
    }

    // CREATE new WMS order
    const targetStatus = isShipped ? 'SHIPPED' : hasFulfillment ? 'PICKED' : 'PENDING';
    const order = await this.createWMSOrder(
      salesOrder,
      soInternalId,
      targetStatus,
      syncStartTime,
      hasFulfillment ? latestFulfillment : null
    );

    logger.info('Created WMS order from NetSuite SO', {
      orderId: order.orderId,
      tranId,
      status: targetStatus,
      hasFulfillment,
    });

    return { created: true, updated: false, skipped: false, tranId };
  }

  /**
   * Process an Item Fulfillment that was NOT matched to a current SO.
   * This handles fulfillments whose SO is no longer _pendingFulfillment.
   */
  private async upsertFromFulfillment(
    fulfillment: any,
    syncStartTime: Date,
    _options: NetSuiteSyncOptions
  ): Promise<{
    created: boolean;
    updated: boolean;
    skipped: boolean;
    reason?: string;
    tranId: string;
  }> {
    const tranId = fulfillment.tranId || fulfillment.id;
    const ifInternalId = fulfillment.id;
    const soInternalId = fulfillment.createdFrom?.id;
    const shipStatus = (fulfillment.shipStatus || '').toLowerCase();
    const isShipped = shipStatus.includes('shipped');

    // Fetch the parent Sales Order to get the SO tran ID
    let soTranId: string | null = null;
    if (soInternalId) {
      try {
        const salesOrder = await this.client.getSalesOrder(soInternalId);
        soTranId = salesOrder.tranId;
        logger.debug('Fetched parent Sales Order for IF', {
          ifTranId: tranId,
          soInternalId,
          soTranId,
        });
      } catch (error: any) {
        logger.warn('Failed to fetch parent Sales Order for IF', {
          ifTranId: tranId,
          soInternalId,
          error: error.message,
        });
      }
    }

    // Try to find existing WMS order by the parent SO
    let existing: ExistingOrder | null = null;
    if (soInternalId) {
      existing = await this.findOrderByNetSuiteSoId(soInternalId);
    }
    if (!existing) {
      existing = await this.findOrderByNetSuiteIfId(ifInternalId);
    }
    if (!existing) {
      existing = await this.findOrderByExternalIdFull(tranId);
    }
    // Also try SO tranId from createdFrom.refName
    if (!existing && fulfillment.createdFrom?.refName) {
      const soTranId = fulfillment.createdFrom.refName.replace(/^.*#/, '').trim();
      if (soTranId) {
        existing = await this.findOrderByExternalIdFull(soTranId);
      }
    }

    if (existing) {
      // UPDATE existing order
      let updated = false;

      if (isShipped && !['SHIPPED', 'CANCELLED'].includes(existing.status)) {
        if (!['PICKING', 'PACKING'].includes(existing.status)) {
          await this.updateOrderStatus(existing.orderId, 'SHIPPED', {
            ifInternalId,
            ifTranId: tranId,
          });
          updated = true;
          logger.info('Updated order to SHIPPED via fulfillment', {
            orderId: existing.orderId,
            tranId,
          });
        }
      } else if (!isShipped && existing.status === 'PENDING') {
        await this.updateOrderStatus(existing.orderId, 'PICKED', {
          ifInternalId,
          ifTranId: tranId,
        });
        updated = true;
        logger.info('Updated order to PICKED via fulfillment', {
          orderId: existing.orderId,
          tranId,
        });
      }

      await this.markOrderSynced(existing.orderId, syncStartTime);

      return {
        created: false,
        updated,
        skipped: !updated,
        reason: updated ? undefined : 'No status change needed',
        tranId,
      };
    }

    // CREATE new WMS order from fulfillment (no matching SO found)
    if (isShipped) {
      // Don't create new orders for already-shipped fulfillments
      return {
        created: false,
        updated: false,
        skipped: true,
        reason: 'Already shipped, no existing order',
        tranId,
      };
    }

    const lineItems = fulfillment.item?.items || fulfillment.item || [];
    if (!Array.isArray(lineItems) || lineItems.length === 0) {
      return { created: false, updated: false, skipped: true, reason: 'No line items', tranId };
    }

    const order = await this.createWMSOrderFromFulfillment(fulfillment, syncStartTime, soTranId);
    logger.info('Created WMS order from NetSuite fulfillment (no matching SO)', {
      orderId: order.orderId,
      tranId,
      soTranId,
    });

    return { created: true, updated: false, skipped: false, tranId };
  }

  // ========================================================================
  // PHASE 3: CLEANUP
  // ========================================================================

  /**
   * Cancel stale PENDING orders that are no longer in NetSuite's pending fulfillment queue.
   * Only affects NetSuite-sourced orders, never manual orders.
   * Safety: requires at least 2 minutes since last sync to avoid race conditions.
   */
  private async cleanupStaleOrders(syncStartTime: Date): Promise<number> {
    try {
      // Find NetSuite-sourced PENDING orders not touched in this sync cycle
      // Safety: must be at least 2 minutes old (2 sync cycles)
      const twoMinutesAgo = new Date(syncStartTime.getTime() - 2 * 60 * 1000);

      const staleResult = await this.query(
        `SELECT order_id, netsuite_so_tran_id, netsuite_last_synced_at
         FROM orders
         WHERE netsuite_source = 'NETSUITE'
           AND status = 'PENDING'
           AND netsuite_last_synced_at IS NOT NULL
           AND netsuite_last_synced_at < $1
           AND netsuite_last_synced_at < $2`,
        [syncStartTime, twoMinutesAgo]
      );

      const staleOrders = staleResult.rows || [];
      if (staleOrders.length === 0) return 0;

      logger.info('Phase 3: Found stale PENDING orders to clean up', {
        count: staleOrders.length,
        orderIds: staleOrders.map((o: any) => o.order_id).slice(0, 10),
      });

      let cleaned = 0;
      for (const order of staleOrders) {
        try {
          await this.query(
            `UPDATE orders
             SET status = 'CANCELLED'::order_status,
                 cancelled_at = NOW(),
                 updated_at = NOW()
             WHERE order_id = $1 AND status = 'PENDING'`,
            [order.order_id]
          );
          cleaned++;
          logger.info('Cleaned up stale order', {
            orderId: order.order_id,
            soTranId: order.netsuite_so_tran_id,
            lastSynced: order.netsuite_last_synced_at,
          });
        } catch (error: any) {
          logger.warn('Failed to clean up stale order', {
            orderId: order.order_id,
            error: error.message,
          });
        }
      }

      return cleaned;
    } catch (error: any) {
      logger.error('Stale order cleanup failed', { error: error.message });
      return 0;
    }
  }

  // ========================================================================
  // ORDER LOOKUP (NEW — by NetSuite tracking columns)
  // ========================================================================

  /**
   * Find WMS order by NetSuite Sales Order internal ID
   */
  private async findOrderByNetSuiteSoId(soInternalId: string): Promise<ExistingOrder | null> {
    try {
      const result = await this.query(
        `SELECT order_id, status, netsuite_if_internal_id
         FROM orders WHERE netsuite_so_internal_id = $1`,
        [soInternalId]
      );
      if (result.rows.length > 0) {
        const row = result.rows[0];
        return {
          orderId: row.order_id,
          status: row.status,
          netsuiteIfInternalId: row.netsuite_if_internal_id,
        };
      }
    } catch {
      /* column may not exist yet */
    }
    return null;
  }

  /**
   * Find WMS order by NetSuite Item Fulfillment internal ID
   */
  private async findOrderByNetSuiteIfId(ifInternalId: string): Promise<ExistingOrder | null> {
    try {
      const result = await this.query(
        `SELECT order_id, status, netsuite_if_internal_id
         FROM orders WHERE netsuite_if_internal_id = $1`,
        [ifInternalId]
      );
      if (result.rows.length > 0) {
        const row = result.rows[0];
        return {
          orderId: row.order_id,
          status: row.status,
          netsuiteIfInternalId: row.netsuite_if_internal_id,
        };
      }
    } catch {
      /* column may not exist yet */
    }
    return null;
  }

  /**
   * Find WMS order by external ID (customer_email, customer_reference, order_external_refs)
   * Returns full order info including status.
   */
  private async findOrderByExternalIdFull(externalOrderId: string): Promise<ExistingOrder | null> {
    // Check customer_email field
    const result = await this.query(
      `SELECT order_id, status, netsuite_if_internal_id
       FROM orders WHERE customer_email = $1`,
      [`netsuite:${externalOrderId}`]
    );
    if (result.rows.length > 0) {
      const row = result.rows[0];
      return {
        orderId: row.order_id,
        status: row.status,
        netsuiteIfInternalId: row.netsuite_if_internal_id || null,
      };
    }

    // Check customer_reference
    try {
      const refResult = await this.query(
        `SELECT order_id, status, netsuite_if_internal_id
         FROM orders WHERE customer_reference = $1`,
        [externalOrderId]
      );
      if (refResult.rows.length > 0) {
        const row = refResult.rows[0];
        return {
          orderId: row.order_id,
          status: row.status,
          netsuiteIfInternalId: row.netsuite_if_internal_id || null,
        };
      }
    } catch {
      /* column may not exist */
    }

    // Check order_external_refs
    try {
      const extResult = await this.query(
        `SELECT o.order_id, o.status, o.netsuite_if_internal_id
         FROM order_external_refs r
         JOIN orders o ON o.order_id = r.order_id
         WHERE r.external_order_id = $1`,
        [externalOrderId]
      );
      if (extResult.rows.length > 0) {
        const row = extResult.rows[0];
        return {
          orderId: row.order_id,
          status: row.status,
          netsuiteIfInternalId: row.netsuite_if_internal_id || null,
        };
      }
    } catch {
      /* table may not exist */
    }

    return null;
  }

  // ========================================================================
  // STATUS UPDATE HELPERS
  // ========================================================================

  /**
   * Update WMS order status from NetSuite sync.
   * Bypasses OrderRepository.updateStatus validation intentionally —
   * NetSuite is the source of truth and may skip intermediate states.
   */
  private async updateOrderStatus(
    orderId: string,
    newStatus: string,
    ifData?: { ifInternalId: string; ifTranId: string }
  ): Promise<void> {
    const updates: string[] = [`status = '${newStatus}'::order_status`, 'updated_at = NOW()'];

    if (newStatus === 'PICKED') {
      updates.push('picked_at = COALESCE(picked_at, NOW())');
      updates.push('progress = 100');
    } else if (newStatus === 'SHIPPED') {
      updates.push('shipped_at = COALESCE(shipped_at, NOW())');
      updates.push('picked_at = COALESCE(picked_at, NOW())');
      updates.push('packed_at = COALESCE(packed_at, NOW())');
      updates.push('progress = 100');
    }

    if (ifData) {
      updates.push(`netsuite_if_internal_id = '${ifData.ifInternalId}'`);
      updates.push(`netsuite_if_tran_id = '${ifData.ifTranId}'`);
    }

    await this.query(`UPDATE orders SET ${updates.join(', ')} WHERE order_id = $1`, [orderId]);
  }

  /**
   * Mark an order as synced in this cycle
   */
  private async markOrderSynced(orderId: string, syncStartTime: Date): Promise<void> {
    try {
      await this.query(`UPDATE orders SET netsuite_last_synced_at = $1 WHERE order_id = $2`, [
        syncStartTime,
        orderId,
      ]);
    } catch {
      /* safe to ignore */
    }
  }

  /**
   * Build a map of SO internal ID → fulfillment details
   */
  private buildFulfillmentMap(fulfillments: any[]): Map<string, any[]> {
    const map = new Map<string, any[]>();
    for (const f of fulfillments) {
      const soId = f.createdFrom?.id;
      if (!soId) continue;
      const existing = map.get(soId) || [];
      existing.push(f);
      map.set(soId, existing);
    }
    return map;
  }

  // ========================================================================
  // ORDER CREATION (updated with tracking columns)
  // ========================================================================

  /**
   * Create a WMS order from a NetSuite sales order.
   * Sets NetSuite tracking columns for future sync updates.
   */
  private async createWMSOrder(
    salesOrder: NetSuiteSalesOrder,
    soInternalId: string,
    targetStatus: string,
    syncStartTime: Date,
    fulfillment?: any
  ) {
    const lineItems = salesOrder.item?.items || [];
    const orderId = generateOrderId();
    const priority = this.calculatePriority(salesOrder.shipDate);

    // Calculate order total from line items
    const subtotal = lineItems.reduce((sum, line) => {
      return sum + (line.amount || (line.rate || 0) * (line.quantity || 1));
    }, 0);

    const shippingAddress = salesOrder.shippingAddress
      ? {
          street1: salesOrder.shippingAddress.addr1 || '',
          street2: salesOrder.shippingAddress.addr2 || '',
          city: salesOrder.shippingAddress.city || '',
          state: salesOrder.shippingAddress.state || '',
          postalCode: salesOrder.shippingAddress.zip || '',
          country: salesOrder.shippingAddress.country?.refName || '',
        }
      : null;

    await this.query(
      `INSERT INTO orders (
        order_id, customer_id, customer_name, priority, status, progress,
        shipping_address, customer_email, organization_id,
        subtotal, total_amount,
        netsuite_so_internal_id, netsuite_so_tran_id,
        netsuite_if_internal_id, netsuite_if_tran_id,
        netsuite_source, netsuite_last_synced_at,
        picked_at, shipped_at, packed_at,
        created_at, updated_at
      ) VALUES (
        $1, $2, $3, $4, $5::order_status, $6, $7, $8, $9,
        $10, $11,
        $12, $13, $14, $15,
        'NETSUITE', $16,
        $17, $18, $19,
        NOW(), NOW()
      )`,
      [
        orderId,
        salesOrder.entity?.id || 'NETSUITE',
        salesOrder.entity?.refName || 'Unknown Customer',
        priority,
        targetStatus,
        targetStatus === 'PENDING' ? 0 : 100,
        shippingAddress ? JSON.stringify(shippingAddress) : null,
        `netsuite:${salesOrder.tranId}`,
        this.organizationId,
        subtotal,
        subtotal,
        soInternalId,
        salesOrder.tranId,
        fulfillment?.id || null,
        fulfillment?.tranId || null,
        syncStartTime,
        targetStatus !== 'PENDING' ? new Date() : null, // picked_at
        targetStatus === 'SHIPPED' ? new Date() : null, // shipped_at
        targetStatus === 'SHIPPED' ? new Date() : null, // packed_at
      ]
    );

    // Insert line items
    for (let i = 0; i < lineItems.length; i++) {
      const line = lineItems[i];
      const sku = await this.findSkuByNetSuiteItem(line.item?.id, line.item?.refName);
      const skuCode = sku || line.item?.refName || line.item?.id || `NS-${i}`;

      const itemDetails = await this.getItemDetails(line.item?.id);
      const rawName = itemDetails?.displayName || line.item?.refName || skuCode;
      const itemName = decodeHtmlEntities(rawName);
      const barcode = itemDetails?.upcCode || undefined;
      const nsBin = itemDetails?.binNumber || undefined;

      await this.ensureSku(skuCode, itemName, barcode, nsBin);

      const skuResult = await this.query(
        `SELECT bin_locations[1] as bin_location FROM skus WHERE sku = $1 AND active = true`,
        [skuCode]
      );
      const binLocation = skuResult.rows[0]?.bin_location || 'UNASSIGNED';

      await this.query(
        `INSERT INTO order_items (
          order_item_id, order_id, sku, name, quantity, bin_location, status,
          unit_price, line_total, currency
        ) VALUES ($1, $2, $3, $4, $5, $6, 'PENDING', $7, $8, 'NZD')`,
        [
          `OI-${orderId}-${i}`,
          orderId,
          skuCode,
          itemName,
          line.quantity || 1,
          binLocation,
          line.rate || 0,
          line.amount || (line.rate || 0) * (line.quantity || 1),
        ]
      );
    }

    // Store external reference (legacy compat)
    await this.storeExternalOrderId(orderId, salesOrder.tranId, salesOrder.id);

    return { orderId };
  }

  /**
   * Create a WMS order from a NetSuite item fulfillment (when no SO match found).
   * Sets tracking columns so future syncs can link it.
   */
  private async createWMSOrderFromFulfillment(
    fulfillment: any,
    syncStartTime: Date,
    soTranId?: string | null
  ) {
    const lineItems = fulfillment.item?.items || fulfillment.item || [];
    const tranId = fulfillment.tranId || fulfillment.id;
    const orderId = generateOrderId();
    const priority = this.calculatePriority(fulfillment.shipDate);

    const shipStatus = (fulfillment.shipStatus || '').toLowerCase();
    let wmsStatus = 'PICKED';
    if (shipStatus.includes('shipped')) {
      wmsStatus = 'SHIPPED';
    } else if (shipStatus.includes('packed')) {
      wmsStatus = 'PACKED';
    }

    const shippingAddr = fulfillment.shippingAddress || {};
    const shippingAddress =
      shippingAddr.addr1 || shippingAddr.city
        ? {
            street1: shippingAddr.addr1 || '',
            street2: shippingAddr.addr2 || '',
            city: shippingAddr.city || '',
            state: shippingAddr.state || '',
            postalCode: shippingAddr.zip || '',
            country: shippingAddr.country?.refName || '',
          }
        : null;

    await this.query(
      `INSERT INTO orders (
        order_id, customer_id, customer_name, priority, status, progress,
        shipping_address, customer_email, organization_id,
        netsuite_so_internal_id, netsuite_so_tran_id, netsuite_if_internal_id, netsuite_if_tran_id,
        netsuite_source, netsuite_last_synced_at,
        picked_at, shipped_at, packed_at,
        created_at, updated_at
      ) VALUES (
        $1, $2, $3, $4, $5::order_status, 0, $6, $7, $8,
        $9, $10, $11, $12,
        'NETSUITE', $13,
        $14, $15, $16,
        NOW(), NOW()
      )`,
      [
        orderId,
        fulfillment.entity?.id || fulfillment.createdFrom?.id || 'NETSUITE',
        fulfillment.entity?.refName || fulfillment.createdFrom?.refName || 'NetSuite Order',
        priority,
        wmsStatus,
        shippingAddress ? JSON.stringify(shippingAddress) : null,
        `netsuite:${tranId}`,
        this.organizationId,
        fulfillment.createdFrom?.id || null, // SO internal ID
        soTranId || null, // SO tran ID (fetched from parent SO)
        fulfillment.id, // IF internal ID
        tranId, // IF tranId
        syncStartTime,
        new Date(), // picked_at (fulfillments are picked)
        wmsStatus === 'SHIPPED' ? new Date() : null,
        wmsStatus === 'PACKED' || wmsStatus === 'SHIPPED' ? new Date() : null,
      ]
    );

    for (let i = 0; i < lineItems.length; i++) {
      const line = lineItems[i];
      const sku = await this.findSkuByNetSuiteItem(
        line.item?.id,
        line.item?.refName || line.itemName
      );
      const skuCode = sku || line.item?.refName || line.itemName || `NS-${i}`;

      const itemDetails = await this.getItemDetails(line.item?.id);
      const rawName = itemDetails?.displayName || line.item?.refName || line.itemName || skuCode;
      const itemName = decodeHtmlEntities(rawName);
      const barcode = itemDetails?.upcCode || undefined;
      const nsBin = itemDetails?.binNumber || undefined;

      await this.ensureSku(skuCode, itemName, barcode, nsBin);

      const skuResult = await this.query(
        `SELECT bin_locations[1] as bin_location FROM skus WHERE sku = $1 AND active = true`,
        [skuCode]
      );
      const binLocation = skuResult.rows[0]?.bin_location || 'UNASSIGNED';

      await this.query(
        `INSERT INTO order_items (
          order_item_id, order_id, sku, name, quantity, bin_location, status,
          unit_price, line_total, currency
        ) VALUES ($1, $2, $3, $4, $5, $6, 'PENDING', $7, $8, 'NZD')`,
        [
          `OI-${orderId}-${i}`,
          orderId,
          skuCode,
          itemName,
          line.quantity || 1,
          binLocation,
          line.rate || 0,
          line.amount || (line.rate || 0) * (line.quantity || 1),
        ]
      );
    }

    await this.storeExternalOrderId(orderId, tranId, fulfillment.id);
    return { orderId };
  }

  /**
   * Calculate order priority based on ship date
   */
  private calculatePriority(shipDate?: string): OrderPriority {
    if (!shipDate) {
      return OrderPriority.NORMAL;
    }

    const ship = new Date(shipDate);
    const now = new Date();
    const daysUntilShip = Math.ceil((ship.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));

    if (daysUntilShip <= 1) {
      return OrderPriority.URGENT;
    } else if (daysUntilShip <= 3) {
      return OrderPriority.HIGH;
    } else if (daysUntilShip <= 7) {
      return OrderPriority.NORMAL;
    }
    return OrderPriority.LOW;
  }

  // ========================================================================
  // SKU MAPPING
  // ========================================================================

  /**
   * Fetch item details (barcode, bin, display name) from NetSuite with caching
   */
  private async getItemDetails(itemId: string): Promise<NetSuiteItemDetails | null> {
    if (!itemId) return null;
    if (this.itemCache.has(itemId)) return this.itemCache.get(itemId)!;

    try {
      const item = await this.client.getInventoryItem(itemId);
      const details: NetSuiteItemDetails = {
        itemId: item.itemId,
        displayName: item.displayName,
        upcCode: item.upcCode,
        binNumber: item.binNumber,
      };
      this.itemCache.set(itemId, details);
      return details;
    } catch (error: any) {
      logger.warn('Failed to fetch NetSuite item details', { itemId, error: error.message });
      return null;
    }
  }

  /**
   * Find WMS SKU by NetSuite item ID or name
   */
  private async findSkuByNetSuiteItem(
    netSuiteItemId?: string,
    netSuiteItemName?: string
  ): Promise<string | null> {
    if (netSuiteItemId) {
      const result = await this.query(
        `SELECT sku FROM skus WHERE (sku = $1 OR barcode = $1) AND active = true`,
        [netSuiteItemId]
      );
      if (result.rows.length > 0) {
        return result.rows[0].sku;
      }
    }

    if (netSuiteItemName) {
      const result = await this.query(
        `SELECT sku FROM skus WHERE (name ILIKE $1 OR sku ILIKE $1) AND active = true`,
        [netSuiteItemName]
      );
      if (result.rows.length > 0) {
        return result.rows[0].sku;
      }
    }

    return netSuiteItemName || netSuiteItemId || null;
  }

  /**
   * Ensure a SKU exists in the WMS catalog. Creates it if missing.
   */
  private async ensureSku(
    skuCode: string,
    itemName: string,
    barcode?: string,
    binLocation?: string
  ): Promise<void> {
    const cleanName = decodeHtmlEntities(itemName);
    const bin = binLocation || 'UNASSIGNED';
    const result = await this.query(`SELECT sku FROM skus WHERE sku = $1`, [skuCode]);

    if (result.rows.length > 0) {
      if (barcode || binLocation) {
        const updates: string[] = [];
        const params: any[] = [];
        let idx = 1;

        if (barcode) {
          updates.push(`barcode = COALESCE(NULLIF(barcode, ''), $${idx})`);
          params.push(barcode);
          idx++;
        }
        if (binLocation) {
          updates.push(
            `bin_locations = CASE WHEN bin_locations = ARRAY['UNASSIGNED']::varchar[] THEN ARRAY[$${idx}]::varchar[] ELSE bin_locations END`
          );
          params.push(binLocation);
          idx++;
        }

        if (updates.length > 0) {
          params.push(skuCode);
          await this.query(
            `UPDATE skus SET ${updates.join(', ')}, updated_at = NOW() WHERE sku = $${idx}`,
            params
          );
        }
      }
      return;
    }

    await this.query(
      `INSERT INTO skus (sku, name, barcode, category, active, bin_locations, organization_id, created_at, updated_at)
       VALUES ($1, $2, $3, 'NETSUITE', true, ARRAY[$4]::varchar[], $5, NOW(), NOW())
       ON CONFLICT (sku) DO NOTHING`,
      [skuCode, cleanName, barcode || null, bin, this.organizationId]
    );
    logger.info('Auto-created SKU from NetSuite item', {
      sku: skuCode,
      name: cleanName,
      barcode,
      bin,
    });
  }

  /**
   * Validate that all SKUs exist in WMS
   */
  private async validateSkus(
    lineItems: NetSuiteSalesOrderLine[]
  ): Promise<{ valid: boolean; missingSkus: string[] }> {
    const missingSkus: string[] = [];

    for (const line of lineItems) {
      const sku = await this.findSkuByNetSuiteItem(line.item?.id, line.item?.refName);
      if (!sku) {
        const identifier = line.item?.refName || line.item?.id || `Line ${line.line}`;
        missingSkus.push(identifier);
      }
    }

    return {
      valid: missingSkus.length === 0,
      missingSkus,
    };
  }

  // ========================================================================
  // ORDER LOOKUP (LEGACY)
  // ========================================================================

  /**
   * Find an existing order by external (NetSuite) order ID — returns order_id only.
   * Kept for backward compatibility with preview/other consumers.
   */
  private async findOrderByExternalId(externalOrderId: string): Promise<string | null> {
    const existing = await this.findOrderByExternalIdFull(externalOrderId);
    return existing?.orderId || null;
  }

  /**
   * Store external order ID reference
   */
  private async storeExternalOrderId(
    orderId: string,
    tranId: string,
    netSuiteId: string
  ): Promise<void> {
    try {
      await this.query(`UPDATE orders SET customer_reference = $1 WHERE order_id = $2`, [
        tranId,
        orderId,
      ]);
    } catch {
      // Column might not exist in tenant DB
    }

    try {
      await this.query(
        `INSERT INTO order_external_refs (order_id, external_order_id, external_system, external_data)
         VALUES ($1, $2, 'NETSUITE', $3)
         ON CONFLICT (order_id, external_system) DO UPDATE SET external_order_id = $2, external_data = $3`,
        [orderId, tranId, JSON.stringify({ netSuiteId, tranId })]
      );
    } catch {
      // Table might not exist in tenant DB
    }
  }

  // ========================================================================
  // PREVIEW ORDERS
  // ========================================================================

  /**
   * Preview NetSuite orders without importing them
   */
  async previewOrders(options: { limit?: number; status?: string } = {}): Promise<{
    orders: NetSuiteOrderPreview[];
    total: number;
  }> {
    const status = options.status || '_pendingFulfillment';
    const limit = options.limit || 20;

    const response = await this.client.getSalesOrders({
      limit,
      status,
    });

    const orders: NetSuiteOrderPreview[] = [];

    for (const item of response.items || []) {
      try {
        const salesOrder = await this.client.getSalesOrder(item.id);
        const preview = await this.previewSingleOrder(salesOrder);
        orders.push(preview);
      } catch (error: any) {
        logger.warn('Failed to preview NetSuite order', { orderId: item.id, error: error.message });
      }
    }

    return {
      orders,
      total: response.totalResults || orders.length,
    };
  }

  /**
   * Preview a single NetSuite order
   */
  private async previewSingleOrder(salesOrder: NetSuiteSalesOrder): Promise<NetSuiteOrderPreview> {
    const issues: string[] = [];
    let canImport = true;

    const existingOrder = await this.findOrderByExternalId(salesOrder.tranId);
    if (existingOrder) {
      issues.push('Order already imported');
      canImport = false;
    }

    const lineItems = salesOrder.item?.items || [];
    if (lineItems.length === 0) {
      issues.push('No line items');
      canImport = false;
    }

    const skuValidation = await this.validateSkus(lineItems);
    if (!skuValidation.valid) {
      issues.push(
        `Missing SKUs: ${skuValidation.missingSkus.slice(0, 3).join(', ')}${skuValidation.missingSkus.length > 3 ? '...' : ''}`
      );
      canImport = false;
    }

    return {
      tranId: salesOrder.tranId,
      customerName: salesOrder.entity?.refName || 'Unknown',
      orderDate: salesOrder.tranDate,
      shipDate: salesOrder.shipDate,
      lineCount: lineItems.length,
      status: salesOrder.status?.refName || 'Unknown',
      canImport,
      issues,
    };
  }

  // ========================================================================
  // CONNECTION TEST
  // ========================================================================

  /**
   * Test NetSuite connection
   */
  async testConnection(): Promise<{
    success: boolean;
    message: string;
    latency?: number;
    details?: any;
  }> {
    return this.client.testConnection();
  }

  // ========================================================================
  // SYNC RECONCILIATION
  // ========================================================================

  /**
   * Reconcile WMS orders with NetSuite to clean up stale data.
   * This method performs a full check of all PENDING orders against NetSuite.
   */
  async reconcileOrders(_integrationId: string): Promise<{
    checked: number;
    cancelled: number;
    updated: number;
    errors: Array<{ orderId: string; error: string }>;
  }> {
    // Look up the organization this integration belongs to
    const orgResult = await sharedQuery(
      `SELECT io.organization_id, o.database_name
       FROM integration_organizations io
       JOIN organizations o ON o.organization_id = io.organization_id
       WHERE io.integration_id = $1 LIMIT 1`,
      [_integrationId]
    );
    this.organizationId = orgResult.rows[0]?.organizationId || null;
    const databaseName = orgResult.rows[0]?.databaseName || null;

    if (databaseName) {
      this.tenantPool = tenantPoolManager.getPool(databaseName);
    } else {
      this.tenantPool = null;
    }

    await this.ensureSchemaColumns();

    const result = {
      checked: 0,
      cancelled: 0,
      updated: 0,
      errors: [] as Array<{ orderId: string; error: string }>,
    };

    try {
      // Get all PENDING orders sourced from NetSuite
      const pendingOrders = await this.query(
        `SELECT order_id, netsuite_so_internal_id, netsuite_so_tran_id, netsuite_last_synced_at
         FROM orders
         WHERE netsuite_source = 'NETSUITE'
           AND status = 'PENDING'
           AND netsuite_so_internal_id IS NOT NULL`
      );

      logger.info('Starting order reconciliation', {
        integrationId: _integrationId,
        pendingCount: pendingOrders.rows.length,
      });

      // Fetch current pending fulfillment orders from NetSuite
      const soResponse = await this.client.getSalesOrders({
        limit: 500,
        status: '_pendingFulfillment',
      });

      const netSuitePendingIds = new Set<string>();
      for (const so of soResponse.items || []) {
        if ((so as any).readyToShip) {
          netSuitePendingIds.add((so as any).id);
        }
      }

      logger.info('Fetched NetSuite pending orders for reconciliation', {
        netSuiteCount: netSuitePendingIds.size,
      });

      // Check each PENDING WMS order
      for (const order of pendingOrders.rows) {
        result.checked++;
        const soId = order.netsuite_so_internal_id;

        try {
          if (netSuitePendingIds.has(soId)) {
            // Order is still pending in NetSuite - mark as synced
            await this.markOrderSynced(order.order_id, new Date());
          } else {
            // Order not in NetSuite pending queue - check actual status
            const soDetail = await this.client.getSalesOrder(soId);
            const nsStatus = (soDetail.status?.refName || '').toLowerCase();

            if (nsStatus.includes('cancelled')) {
              await this.query(
                `UPDATE orders SET status = 'CANCELLED'::order_status, cancelled_at = NOW(), updated_at = NOW() WHERE order_id = $1`,
                [order.order_id]
              );
              result.cancelled++;
              logger.info('Reconciled: cancelled order', {
                orderId: order.order_id,
                soTranId: order.netsuite_so_tran_id,
                nsStatus,
              });
            } else if (
              nsStatus.includes('billed') ||
              nsStatus.includes('fulfilled') ||
              nsStatus.includes('pending billing')
            ) {
              await this.query(
                `UPDATE orders SET status = 'PICKED'::order_status, picked_at = COALESCE(picked_at, NOW()), progress = 100, updated_at = NOW() WHERE order_id = $1`,
                [order.order_id]
              );
              result.updated++;
              logger.info('Reconciled: updated order to PICKED', {
                orderId: order.order_id,
                soTranId: order.netsuite_so_tran_id,
                nsStatus,
              });
            } else {
              // Unknown status - keep and mark synced
              await this.markOrderSynced(order.order_id, new Date());
              logger.debug('Reconciled: keeping order (unknown NetSuite status)', {
                orderId: order.order_id,
                soTranId: order.netsuite_so_tran_id,
                nsStatus,
              });
            }
          }
        } catch (error: any) {
          result.errors.push({
            orderId: order.order_id,
            error: error.message,
          });
          logger.warn('Reconciliation failed for order', {
            orderId: order.order_id,
            soId,
            error: error.message,
          });
        }
      }

      logger.info('Order reconciliation complete', {
        integrationId: _integrationId,
        checked: result.checked,
        cancelled: result.cancelled,
        updated: result.updated,
        errors: result.errors.length,
      });

      return result;
    } catch (error: any) {
      logger.error('Order reconciliation failed', {
        integrationId: _integrationId,
        error: error.message,
      });
      throw error;
    }
  }

  /**
   * Get sync status report for all NetSuite-sourced orders
   */
  async getSyncReport(): Promise<{
    totalOrders: number;
    byStatus: Record<string, number>;
    staleOrders: number;
    neverSynced: number;
    recentlySynced: number;
  }> {
    await this.ensureSchemaColumns();

    const fiveMinutesAgo = new Date(Date.now() - 5 * 60 * 1000);

    const stats = await this.query(`
      SELECT 
        status,
        COUNT(*) as count,
        COUNT(*) FILTER (WHERE netsuite_last_synced_at IS NULL) as never_synced,
        COUNT(*) FILTER (WHERE netsuite_last_synced_at < $1) as stale,
        COUNT(*) FILTER (WHERE netsuite_last_synced_at >= $1) as recent
      FROM orders
      WHERE netsuite_source = 'NETSUITE' OR customer_email LIKE 'netsuite:%'
      GROUP BY status
    `, [fiveMinutesAgo]);

    const report = {
      totalOrders: 0,
      byStatus: {} as Record<string, number>,
      staleOrders: 0,
      neverSynced: 0,
      recentlySynced: 0,
    };

    for (const row of stats.rows) {
      report.totalOrders += parseInt(row.count, 10);
      report.byStatus[row.status] = parseInt(row.count, 10);
      report.neverSynced += parseInt(row.neverSynced, 10);
      report.staleOrders += parseInt(row.stale, 10);
      report.recentlySynced += parseInt(row.recent, 10);
    }

    return report;
  }
}
