"use strict";
/**
 * Run order_exceptions table migration
 *
 * Creates the order_exceptions table for tracking exceptions during fulfillment.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.runOrderExceptionsMigration = runOrderExceptionsMigration;
const fs_1 = require("fs");
const path_1 = require("path");
const client_1 = require("./client");
async function runOrderExceptionsMigration() {
    console.log('Running order_exceptions migration...');
    const pool = await (0, client_1.getPool)();
    try {
        // Read the migration file
        const migrationPath = (0, path_1.join)(__dirname, 'migrations', '035_fix_order_exceptions_foreign_key.sql');
        const sql = (0, fs_1.readFileSync)(migrationPath, 'utf-8');
        console.log('Executing order_exceptions migration SQL...');
        await pool.query(sql);
        console.log('✓ order_exceptions table created successfully');
    }
    catch (error) {
        console.error('Error running order_exceptions migration:', error);
        throw error;
    }
    finally {
        await (0, client_1.closePool)();
    }
}
// Run if called directly
if (require.main === module) {
    runOrderExceptionsMigration()
        .then(() => {
        console.log('Migration completed successfully');
        process.exit(0);
    })
        .catch(error => {
        console.error('Migration failed:', error);
        process.exit(1);
    });
}
//# sourceMappingURL=run-order-exceptions-migration.js.map