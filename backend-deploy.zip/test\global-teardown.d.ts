/**
 * Jest Global Teardown
 *
 * Runs once after all test suites.
 * Cleans up test database and connections.
 */
export default function globalTeardown(): Promise<void>;
//# sourceMappingURL=global-teardown.d.ts.map