/**
 * Accounting & Financial API Routes
 *
 * REST API for financial metrics, inventory valuation, profit/loss reporting,
 * vendor performance, and transaction management
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=accounting.d.ts.map