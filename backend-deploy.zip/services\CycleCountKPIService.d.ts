/**
 * Cycle Count KPI Service
 *
 * Aggregates cycle count data for dashboards and analytics
 */
export interface CycleCountKPI {
    totalCounts: number;
    completedCounts: number;
    inProgressCounts: number;
    scheduledCounts: number;
    completionRate: number;
    averageAccuracy: number;
    totalItemsCounted: number;
    totalVariances: number;
    pendingVariances: number;
    highValueVarianceCount: number;
}
export interface AccuracyTrend {
    period: string;
    accuracy: number;
    totalCounts: number;
}
export interface TopDiscrepancySKU {
    sku: string;
    name: string;
    varianceCount: number;
    totalVariance: number;
    averageVariancePercent: number;
}
export interface CountByUser {
    userId: string;
    name: string;
    countsCompleted: number;
    itemsCounted: number;
    averageAccuracy: number;
}
export interface ZonePerformance {
    zone: string;
    countsCompleted: number;
    itemsCounted: number;
    averageAccuracy: number;
    totalVariance: number;
}
export interface CountTypeEffectiveness {
    countType: string;
    countsCompleted: number;
    averageAccuracy: number;
    averageDuration: number;
    varianceDetectionRate: number;
}
export interface DailyStats {
    date: string;
    countsCompleted: number;
    itemsCounted: number;
    variancesFound: number;
    accuracyRate: number;
}
export declare class CycleCountKPIService {
    /**
     * Get overall KPIs for cycle counting
     */
    getOverallKPIs(filters?: {
        startDate?: Date;
        endDate?: Date;
        location?: string;
        countType?: string;
    }): Promise<CycleCountKPI>;
    /**
     * Get accuracy trends over time
     */
    getAccuracyTrend(days?: number): Promise<AccuracyTrend[]>;
    /**
     * Get SKUs with most discrepancies
     */
    getTopDiscrepancySKUs(limit?: number, days?: number): Promise<TopDiscrepancySKU[]>;
    /**
     * Get performance by user
     */
    getCountByUser(days?: number): Promise<CountByUser[]>;
    /**
     * Get performance by zone
     */
    getZonePerformance(days?: number): Promise<ZonePerformance[]>;
    /**
     * Get effectiveness by count type
     */
    getCountTypeEffectiveness(days?: number): Promise<CountTypeEffectiveness[]>;
    /**
     * Get daily statistics for charts
     */
    getDailyStats(days?: number): Promise<DailyStats[]>;
    /**
     * Get real-time dashboard data (aggregates all KPIs)
     */
    getRealTimeDashboard(filters?: {
        startDate?: Date;
        endDate?: Date;
        location?: string;
        countType?: string;
    }): Promise<{
        overallKPIs: CycleCountKPI;
        accuracyTrend: AccuracyTrend[];
        topDiscrepancies: TopDiscrepancySKU[];
        userPerformance: CountByUser[];
        zonePerformance: ZonePerformance[];
        countTypeEffectiveness: CountTypeEffectiveness[];
        dailyStats: DailyStats[];
    }>;
}
export declare const cycleCountKPIService: CycleCountKPIService;
//# sourceMappingURL=CycleCountKPIService.d.ts.map