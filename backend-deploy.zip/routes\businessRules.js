"use strict";
/**
 * Business Rules API Routes
 *
 * REST API for managing business rules, viewing execution logs,
 * and testing rule conditions.
 */
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const BusinessRulesRepository_1 = require("../repositories/BusinessRulesRepository");
const BusinessRulesService_1 = require("../services/BusinessRulesService");
const middleware_1 = require("../middleware");
const shared_1 = require("@opsui/shared");
const router = (0, express_1.Router)();
// All business rules routes require authentication
router.use(middleware_1.authenticate);
// ============================================================================
// CRUD ROUTES
// ============================================================================
/**
 * GET /api/business-rules
 * Get all business rules with optional filtering
 */
router.get('/', (0, middleware_1.asyncHandler)(async (req, res) => {
    const { status, ruleType, includeInactive } = req.query;
    const rules = await BusinessRulesRepository_1.businessRulesRepository.findAll({
        status: status,
        ruleType: ruleType,
        includeInactive: includeInactive === 'true',
    });
    res.json({
        success: true,
        data: {
            rules,
            count: rules.length,
        },
    });
}));
/**
 * GET /api/business-rules/:ruleId
 * Get a specific business rule by ID
 */
router.get('/:ruleId', (0, middleware_1.asyncHandler)(async (req, res) => {
    const { ruleId } = req.params;
    const rule = await BusinessRulesRepository_1.businessRulesRepository.findById(ruleId);
    if (!rule) {
        res.status(404).json({
            success: false,
            error: 'Rule not found',
        });
        return;
    }
    res.json({
        success: true,
        data: { rule },
    });
}));
/**
 * POST /api/business-rules
 * Create a new business rule (ADMIN/SUPERVISOR only)
 */
router.post('/', (0, middleware_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR), (0, middleware_1.asyncHandler)(async (req, res) => {
    const ruleData = req.body;
    // Validate required fields
    if (!ruleData.name || !ruleData.ruleType || !ruleData.createdBy) {
        res.status(400).json({
            success: false,
            error: 'Missing required fields: name, ruleType, createdBy',
        });
        return;
    }
    const rule = await BusinessRulesRepository_1.businessRulesRepository.create(ruleData);
    res.status(201).json({
        success: true,
        data: { rule },
    });
}));
/**
 * PUT /api/business-rules/:ruleId
 * Update an existing business rule (ADMIN/SUPERVISOR only)
 */
router.put('/:ruleId', (0, middleware_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { ruleId } = req.params;
    const updates = req.body;
    const rule = await BusinessRulesRepository_1.businessRulesRepository.update(ruleId, updates);
    if (!rule) {
        res.status(404).json({
            success: false,
            error: 'Rule not found',
        });
        return;
    }
    res.json({
        success: true,
        data: { rule },
    });
}));
/**
 * DELETE /api/business-rules/:ruleId
 * Delete a business rule (ADMIN only)
 */
router.delete('/:ruleId', (0, middleware_1.authorize)(shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { ruleId } = req.params;
    const deleted = await BusinessRulesRepository_1.businessRulesRepository.delete(ruleId);
    if (!deleted) {
        res.status(404).json({
            success: false,
            error: 'Rule not found',
        });
        return;
    }
    res.json({
        success: true,
        message: 'Rule deleted successfully',
    });
}));
// ============================================================================
// EXECUTION LOGS
// ============================================================================
/**
 * GET /api/business-rules/:ruleId/execution-logs
 * Get execution logs for a specific rule
 */
router.get('/:ruleId/execution-logs', (0, middleware_1.asyncHandler)(async (req, res) => {
    const { ruleId } = req.params;
    const limit = parseInt(req.query.limit) || 100;
    const logs = await BusinessRulesRepository_1.businessRulesRepository.findExecutionLogs(ruleId, limit);
    res.json({
        success: true,
        data: {
            logs,
            count: logs.length,
        },
    });
}));
// ============================================================================
// RULE TESTING
// ============================================================================
/**
 * POST /api/business-rules/test
 * Test rule conditions against sample data
 */
router.post('/test', (0, middleware_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { rule, entity, entityType, entityId } = req.body;
    if (!rule || !entity) {
        res.status(400).json({
            success: false,
            error: 'Missing required fields: rule, entity',
        });
        return;
    }
    const context = {
        eventType: rule.triggerEvents[0] || shared_1.RuleEventType.ORDER_CREATED,
        entity,
        entityType: entityType || 'test',
        entityId: entityId || 'test-entity',
        userId: 'test-user',
    };
    const evaluationResult = BusinessRulesService_1.businessRulesService.evaluateRuleConditions(rule, context);
    res.json({
        success: true,
        data: {
            shouldExecute: evaluationResult.shouldExecute,
            conditionsMet: evaluationResult.conditionsMet,
            conditionResults: evaluationResult.conditionResults,
        },
    });
}));
/**
 * POST /api/business-rules/:ruleId/activate
 * Activate a rule (ADMIN/SUPERVISOR only)
 */
router.post('/:ruleId/activate', (0, middleware_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { ruleId } = req.params;
    const rule = await BusinessRulesRepository_1.businessRulesRepository.update(ruleId, {
        status: shared_1.RuleStatus.ACTIVE,
        updatedBy: req.user?.userId || 'system',
    });
    if (!rule) {
        res.status(404).json({
            success: false,
            error: 'Rule not found',
        });
        return;
    }
    res.json({
        success: true,
        data: { rule },
    });
}));
/**
 * POST /api/business-rules/:ruleId/deactivate
 * Deactivate a rule (ADMIN/SUPERVISOR only)
 */
router.post('/:ruleId/deactivate', (0, middleware_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { ruleId } = req.params;
    const rule = await BusinessRulesRepository_1.businessRulesRepository.update(ruleId, {
        status: shared_1.RuleStatus.INACTIVE,
        updatedBy: req.user?.userId || 'system',
    });
    if (!rule) {
        res.status(404).json({
            success: false,
            error: 'Rule not found',
        });
        return;
    }
    res.json({
        success: true,
        data: { rule },
    });
}));
/**
 * GET /api/business-rules/stats/summary
 * Get summary statistics for business rules
 */
router.get('/stats/summary', (0, middleware_1.asyncHandler)(async (_req, res) => {
    const allRules = await BusinessRulesRepository_1.businessRulesRepository.findAll({ includeInactive: true });
    const stats = {
        total: allRules.length,
        active: allRules.filter((r) => r.status === shared_1.RuleStatus.ACTIVE).length,
        inactive: allRules.filter((r) => r.status === shared_1.RuleStatus.INACTIVE).length,
        draft: allRules.filter((r) => r.status === shared_1.RuleStatus.DRAFT).length,
        byType: {
            ALLOCATION: allRules.filter((r) => r.ruleType === 'ALLOCATION').length,
            PICKING: allRules.filter((r) => r.ruleType === 'PICKING').length,
            SHIPPING: allRules.filter((r) => r.ruleType === 'SHIPPING').length,
            INVENTORY: allRules.filter((r) => r.ruleType === 'INVENTORY').length,
            VALIDATION: allRules.filter((r) => r.ruleType === 'VALIDATION').length,
            NOTIFICATION: allRules.filter((r) => r.ruleType === 'NOTIFICATION').length,
        },
        totalExecutions: allRules.reduce((sum, r) => sum + r.executionCount, 0),
    };
    res.json({
        success: true,
        data: stats,
    });
}));
exports.default = router;
//# sourceMappingURL=businessRules.js.map