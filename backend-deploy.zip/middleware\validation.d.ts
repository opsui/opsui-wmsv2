/**
 * Request validation middleware using Joi
 *
 * Validates request bodies, query parameters, and route parameters
 */
import { Request, Response, NextFunction } from 'express';
import Joi from 'joi';
/**
 * Validate request body against a Joi schema
 */
export declare function validateBody(schema: Joi.ObjectSchema): (req: Request, _res: Response, next: NextFunction) => void;
/**
 * Validate request query parameters against a Joi schema
 */
export declare function validateQuery(schema: Joi.ObjectSchema): (req: Request, _res: Response, next: NextFunction) => void;
/**
 * Validate request route parameters against a Joi schema
 */
export declare function validateParams(schema: Joi.ObjectSchema): (req: Request, _res: Response, next: NextFunction) => void;
export declare const commonSchemas: {
    id: Joi.StringSchema<string>;
    orderId: Joi.StringSchema<string>;
    sku: Joi.StringSchema<string>;
    binLocation: Joi.StringSchema<string>;
    email: Joi.StringSchema<string>;
    quantity: Joi.NumberSchema<number>;
    priority: Joi.StringSchema<string>;
    status: Joi.StringSchema<string>;
    pagination: {
        page: Joi.NumberSchema<number>;
        limit: Joi.NumberSchema<number>;
        sortBy: Joi.StringSchema<string>;
        sortOrder: Joi.StringSchema<string>;
    };
};
export declare const schemas: {
    createOrder: Joi.ObjectSchema<any>;
    claimOrder: Joi.ObjectSchema<any>;
    pickItem: Joi.ObjectSchema<any>;
    completeOrder: Joi.ObjectSchema<any>;
    cancelOrder: Joi.ObjectSchema<any>;
    createUser: Joi.ObjectSchema<any>;
    updateUser: Joi.ObjectSchema<any>;
    login: Joi.ObjectSchema<any>;
    orderQuery: Joi.ObjectSchema<any>;
    skuQuery: Joi.ObjectSchema<any>;
};
export declare const validate: {
    createOrder: (req: Request, _res: Response, next: NextFunction) => void;
    claimOrder: (req: Request, _res: Response, next: NextFunction) => void;
    pickItem: (req: Request, _res: Response, next: NextFunction) => void;
    completeOrder: (req: Request, _res: Response, next: NextFunction) => void;
    cancelOrder: (req: Request, _res: Response, next: NextFunction) => void;
    createUser: (req: Request, _res: Response, next: NextFunction) => void;
    updateUser: (req: Request, _res: Response, next: NextFunction) => void;
    login: (req: Request, _res: Response, next: NextFunction) => void;
    orderQuery: (req: Request, _res: Response, next: NextFunction) => void;
    skuQuery: (req: Request, _res: Response, next: NextFunction) => void;
    orderId: (req: Request, _res: Response, next: NextFunction) => void;
    sku: (req: Request, _res: Response, next: NextFunction) => void;
    userId: (req: Request, _res: Response, next: NextFunction) => void;
};
//# sourceMappingURL=validation.d.ts.map