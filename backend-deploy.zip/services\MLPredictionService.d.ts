/**
 * ML Prediction Service
 * Integrates with ML models for order duration, demand forecasting, and route optimization
 * Uses both local heuristic models and external ML API when available
 */
export interface OrderFeatures {
    order_id?: string;
    order_item_count: number;
    order_total_value?: number;
    hour_of_day: number;
    day_of_week: number;
    sku_count: number;
    zone_diversity: number;
    priority_level: number;
    picker_count?: number;
}
interface DurationPrediction {
    prediction_id: string;
    model_version: string;
    prediction: {
        duration_minutes: number;
        duration_hours: number;
        breakdown?: {
            picking: number;
            packing: number;
            travel: number;
            overhead: number;
        };
    };
    confidence: number;
    metadata: {
        model_type: string;
        predicted_at: string;
    };
}
interface DemandForecast {
    sku_id: string;
    forecast_horizon_days: number;
    forecasts: Array<{
        day: number;
        forecast_date: string;
        forecast_quantity: number;
    }>;
}
interface RouteOptimization {
    locations: string[];
    optimized_path: string[];
    total_distance_meters: number;
    estimated_time_minutes: number;
}
/**
 * ML Prediction Service
 * Provides ML predictions using local fallback when external API unavailable
 */
export declare class MLPredictionService {
    private mlApiUrl;
    private useLocalOnly;
    private cache;
    private readonly CACHE_TTL;
    constructor();
    /**
     * Predict order fulfillment duration
     */
    predictOrderDuration(features: OrderFeatures): Promise<DurationPrediction>;
    /**
     * Forecast SKU demand
     */
    forecastDemand(skuId: string, historicalData: number[], forecastHorizonDays?: number): Promise<DemandForecast>;
    /**
     * Optimize pick route
     */
    optimizeRoute(locations: string[], startPoint?: string): Promise<RouteOptimization>;
    /**
     * Local duration prediction using heuristic model
     */
    private predictDurationLocal;
    /**
     * Local demand forecast
     */
    private forecastDemandLocal;
    /**
     * Local route optimization
     */
    private optimizeRouteLocal;
    /**
     * API-based prediction
     */
    private predictDurationAPI;
    /**
     * API-based demand forecast
     */
    private forecastDemandAPI;
    /**
     * API-based route optimization
     */
    private optimizeRouteAPI;
    /**
     * Calculate moving average
     */
    private movingAverage;
    /**
     * Cache helpers
     */
    private getFromCache;
    private setCache;
    /**
     * Clear cache
     */
    clearCache(): void;
}
export declare const mlPredictionService: MLPredictionService;
export {};
//# sourceMappingURL=MLPredictionService.d.ts.map