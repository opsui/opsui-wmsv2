/**
 * Organization Routes
 *
 * API endpoints for multi-tenant organization management.
 * Handles organization CRUD, memberships, invitations, and settings.
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=organizations.d.ts.map