/**
 * Route Optimization API Routes
 *
 * Exposes route optimization algorithms via REST API
 * Provides endpoints for calculating optimal pick routes
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=routeOptimization.d.ts.map