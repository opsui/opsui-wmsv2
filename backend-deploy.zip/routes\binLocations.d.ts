/**
 * Bin Location routes
 *
 * Endpoints for managing warehouse bin locations
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=binLocations.d.ts.map