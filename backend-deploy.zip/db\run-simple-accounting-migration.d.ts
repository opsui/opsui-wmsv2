/**
 * Run simple accounting tables migration
 * Creates minimal tables needed for accounting functionality
 */
export {};
//# sourceMappingURL=run-simple-accounting-migration.d.ts.map