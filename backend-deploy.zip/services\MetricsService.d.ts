/**
 * Metrics service
 *
 * Provides dashboard metrics and real-time statistics
 *
 * FIXED: Now properly fetches current_view from database
 */
import { DashboardMetricsResponse } from '@opsui/shared';
export declare class MetricsService {
    getDashboardMetrics(): Promise<DashboardMetricsResponse>;
    getPickerPerformance(pickerId: string, startDate: Date, endDate: Date): Promise<{
        tasksCompleted: number;
        tasksTotal: number;
        averageTimePerTask: number;
        totalItemsPicked: number;
        ordersCompleted: number;
    }>;
    getAllPickersPerformance(startDate: Date, endDate: Date): Promise<Array<{
        pickerId: string;
        pickerName: string;
        tasksCompleted: number;
        ordersCompleted: number;
        totalItemsPicked: number;
        averageTimePerTask: number;
    }>>;
    getAllPackersPerformance(startDate: Date, endDate: Date): Promise<Array<{
        packerId: string;
        packerName: string;
        tasksCompleted: number;
        ordersCompleted: number;
        totalItemsProcessed: number;
        averageTimePerTask: number;
    }>>;
    getAllStockControllersPerformance(startDate: Date, endDate: Date): Promise<Array<{
        controllerId: string;
        controllerName: string;
        tasksCompleted: number;
        transactionsCompleted: number;
        totalItemsProcessed: number;
        averageTimePerTask: number;
    }>>;
    getPickerActivity(): Promise<Array<{
        pickerId: string;
        pickerName: string;
        currentOrderId: string | null;
        orderProgress: number;
        currentTask: string | null;
        lastViewedAt: Date | null;
        status: 'ACTIVE' | 'IDLE' | 'PICKING' | 'INACTIVE';
        currentView: string | null;
    }>>;
    getOrderStatusBreakdown(): Promise<Array<{
        status: string;
        count: number;
    }>>;
    getHourlyThroughput(): Promise<Array<{
        hour: string;
        picked: number;
        shipped: number;
    }>>;
    getThroughputByRange(range: 'daily' | 'weekly' | 'monthly' | 'quarterly' | 'yearly'): Promise<Array<{
        period: string;
        picked: number;
        shipped: number;
    }>>;
    getTopSKUsByPickFrequency(limit?: number): Promise<Array<{
        sku: string;
        name: string;
        picks: number;
    }>>;
    /**
     * Get the interval string for the given time period
     */
    private getTimePeriodInterval;
    getTopSKUsByScanType(scanType: 'pick' | 'pack' | 'verify' | 'all', limit?: number, timePeriod?: 'daily' | 'weekly' | 'monthly' | 'yearly'): Promise<Array<{
        sku: string;
        name: string;
        picks: number;
        scans?: number;
        packVerifies?: number;
    }>>;
    getPickerOrders(pickerId: string): Promise<Array<{
        orderId: string;
        status: string;
        progress: number;
        customerName: string;
        priority: string;
        itemCount: number;
        items: Array<{
            sku: string;
            name: string;
            quantity: number;
            pickedQuantity: number;
            binLocation: string;
            status: string;
        }>;
    }>>;
    getPackerActivity(): Promise<Array<{
        packerId: string;
        packerName: string;
        currentOrderId: string | null;
        orderProgress: number;
        currentTask: string | null;
        lastViewedAt: Date | null;
        status: 'ACTIVE' | 'IDLE' | 'PACKING' | 'INACTIVE';
        currentView: string | null;
    }>>;
    getPackerOrders(packerId: string): Promise<Array<{
        orderId: string;
        status: string;
        progress: number;
        customerName: string;
        priority: string;
        itemCount: number;
    }>>;
    getStockControllerActivity(): Promise<Array<{
        controllerId: string;
        controllerName: string;
        lastViewedAt: Date | null;
        status: 'ACTIVE' | 'IDLE' | 'INACTIVE';
        currentView: string | null;
    }>>;
    getStockControllerTransactions(controllerId: string, limit?: number): Promise<Array<{
        transactionId: string;
        sku: string;
        binLocation: string;
        type: string;
        quantityChange: number;
        reason: string;
        createdAt: Date;
    }>>;
}
export declare const metricsService: MetricsService;
//# sourceMappingURL=MetricsService.d.ts.map