"use strict";
/**
 * Organization Context Middleware
 *
 * Handles organization context for multi-tenant requests.
 * Extracts organization from header, token, or user's default.
 * Validates user has access to the organization.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.organizationContext = organizationContext;
exports.requireOrganization = requireOrganization;
exports.validateOrganizationAccess = validateOrganizationAccess;
exports.requireOrganizationAccess = requireOrganizationAccess;
exports.requireOrganizationRole = requireOrganizationRole;
exports.requireOrganizationPermission = requireOrganizationPermission;
exports.getOrganizationId = getOrganizationId;
exports.getOrganizationIdOrThrow = getOrganizationIdOrThrow;
const shared_1 = require("@opsui/shared");
const logger_1 = require("../config/logger");
const OrganizationRepository_1 = require("../repositories/OrganizationRepository");
// ============================================================================
// ORGANIZATION CONTEXT MIDDLEWARE
// ============================================================================
/**
 * Extract and validate organization context
 *
 * Organization can be specified via:
 * 1. X-Organization-ID header (explicit)
 * 2. JWT token organizationId field
 * 3. User's default organization (from database)
 *
 * Sets req.organizationId for use in downstream handlers
 */
async function organizationContext(req, _res, next) {
    try {
        if (!req.user) {
            return next(); // No user, skip organization context
        }
        let organizationId = null;
        // 1. Check explicit header
        const headerOrgId = req.headers['x-organization-id'];
        if (headerOrgId) {
            organizationId = headerOrgId;
        }
        // 2. Check JWT token
        if (!organizationId && req.user.organizationId) {
            organizationId = req.user.organizationId;
        }
        // 3. Get user's default organization from database
        if (!organizationId) {
            const memberships = await OrganizationRepository_1.organizationUserRepository.findUserOrganizations(req.user.userId);
            const primary = memberships.find(m => m.isPrimary);
            organizationId = primary?.organizationId || memberships[0]?.organizationId || null;
        }
        // Set organization context
        req.organizationId = organizationId;
        // Log for debugging
        if (organizationId) {
            logger_1.logger.debug('Organization context set', {
                userId: req.user.userId,
                organizationId,
                source: headerOrgId ? 'header' : req.user.organizationId ? 'token' : 'default',
            });
        }
        next();
    }
    catch (error) {
        next(error);
    }
}
/**
 * Require organization context
 * Returns 400 if no organization is set
 */
function requireOrganization(req, res, next) {
    if (!req.organizationId) {
        res.status(400).json({
            error: 'Organization context required',
            code: 'ORGANIZATION_REQUIRED',
            message: 'Please specify an organization via X-Organization-ID header or set a default organization',
        });
        return;
    }
    next();
}
/**
 * Validate user has access to the organization
 * Must be used after organizationContext
 */
async function validateOrganizationAccess(req, _res, next) {
    try {
        if (!req.user) {
            return next(new shared_1.ForbiddenError('Not authenticated'));
        }
        if (!req.organizationId) {
            return next(); // No organization set, skip validation
        }
        // Check access
        const hasAccess = await OrganizationRepository_1.organizationUserRepository.checkUserAccess(req.user.userId, req.organizationId);
        if (!hasAccess) {
            return next(new shared_1.ForbiddenError('You do not have access to this organization'));
        }
        next();
    }
    catch (error) {
        next(error);
    }
}
/**
 * Require organization and validate access
 * Combines requireOrganization and validateOrganizationAccess
 */
async function requireOrganizationAccess(req, _res, next) {
    try {
        // First set context
        await organizationContext(req, _res, async (err) => {
            if (err)
                return next(err);
            // Check organization is set
            if (!req.organizationId) {
                return next(new Error('Organization context required'));
            }
            // Validate access
            if (!req.user) {
                return next(new shared_1.ForbiddenError('Not authenticated'));
            }
            const hasAccess = await OrganizationRepository_1.organizationUserRepository.checkUserAccess(req.user.userId, req.organizationId);
            if (!hasAccess) {
                return next(new shared_1.ForbiddenError('You do not have access to this organization'));
            }
            next();
        });
    }
    catch (error) {
        next(error);
    }
}
/**
 * Organization role check middleware factory
 */
function requireOrganizationRole(...allowedRoles) {
    return async (req, res, next) => {
        try {
            if (!req.user) {
                return next(new shared_1.ForbiddenError('Not authenticated'));
            }
            if (!req.organizationId) {
                res.status(400).json({
                    error: 'Organization context required',
                    code: 'ORGANIZATION_REQUIRED',
                });
                return;
            }
            const membership = await OrganizationRepository_1.organizationUserRepository.findByOrganizationAndUser(req.organizationId, req.user.userId);
            if (!membership || !membership.isActive) {
                return next(new shared_1.ForbiddenError('You do not have access to this organization'));
            }
            if (!allowedRoles.includes(membership.role)) {
                return next(new shared_1.ForbiddenError(`Organization role ${allowedRoles.join(' or ')} required`));
            }
            next();
        }
        catch (error) {
            next(error);
        }
    };
}
/**
 * Organization permission check middleware factory
 */
function requireOrganizationPermission(permission) {
    return async (req, res, next) => {
        try {
            if (!req.user) {
                return next(new shared_1.ForbiddenError('Not authenticated'));
            }
            if (!req.organizationId) {
                res.status(400).json({
                    error: 'Organization context required',
                    code: 'ORGANIZATION_REQUIRED',
                });
                return;
            }
            const membership = await OrganizationRepository_1.organizationUserRepository.findByOrganizationAndUser(req.organizationId, req.user.userId);
            if (!membership || !membership.isActive) {
                return next(new shared_1.ForbiddenError('You do not have access to this organization'));
            }
            // Owners and admins have all permissions
            if (membership.role === 'ORG_OWNER' || membership.role === 'ORG_ADMIN') {
                return next();
            }
            // Check specific permission
            if (!membership[permission]) {
                return next(new shared_1.ForbiddenError(`You do not have permission: ${permission}`));
            }
            next();
        }
        catch (error) {
            next(error);
        }
    };
}
// ============================================================================
// HELPER FUNCTIONS
// ============================================================================
/**
 * Get organization ID from request
 * Utility for use in route handlers
 */
function getOrganizationId(req) {
    return req.organizationId || null;
}
/**
 * Get organization ID or throw
 * Use when organization is required
 */
function getOrganizationIdOrThrow(req) {
    if (!req.organizationId) {
        throw new Error('Organization context not set');
    }
    return req.organizationId;
}
//# sourceMappingURL=organizationContext.js.map