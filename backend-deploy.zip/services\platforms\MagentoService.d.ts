/**
 * Magento Platform Service
 *
 * Handles integration with Magento's REST API
 * Supports webhook processing, inventory sync, order import, and product sync
 */
import { EcommerceConnection, EcommerceProductMapping, TestConnectionResult, PlatformProductData, PlatformOrderData } from '@opsui/shared';
export declare class MagentoService {
    private readonly DEFAULT_API_VERSION;
    /**
     * Build Magento API URL
     */
    private buildApiUrl;
    /**
     * Make authenticated request to Magento API
     */
    private apiRequest;
    /**
     * Test connection to Magento
     */
    testConnection(connection: EcommerceConnection): Promise<TestConnectionResult>;
    /**
     * Fetch products from Magento
     */
    fetchProducts(connection: EcommerceConnection, skus?: string[]): Promise<PlatformProductData[]>;
    /**
     * Fetch a single product by SKU
     */
    private fetchProductBySku;
    /**
     * Normalize Magento product to standard format
     */
    private normalizeProduct;
    /**
     * Update inventory in Magento
     */
    updateInventory(connection: EcommerceConnection, mapping: EcommerceProductMapping, quantity: number): Promise<void>;
    /**
     * Get inventory from Magento
     */
    getInventory(connection: EcommerceConnection, mapping: EcommerceProductMapping): Promise<number | undefined>;
    /**
     * Fetch orders from Magento
     */
    fetchOrders(connection: EcommerceConnection, orderIds?: string[], daysToLookBack?: number): Promise<PlatformOrderData[]>;
    /**
     * Fetch a single order by ID
     */
    private fetchOrderById;
    /**
     * Normalize Magento order to standard format
     */
    private normalizeOrder;
    /**
     * Verify Magento webhook signature
     */
    verifyWebhook(connection: EcommerceConnection, payload: any): Promise<boolean>;
    /**
     * Handle order webhook from Magento
     */
    handleOrderWebhook(connection: EcommerceConnection, payload: any): Promise<void>;
    /**
     * Handle product webhook from Magento
     */
    handleProductWebhook(connection: EcommerceConnection, payload: any): Promise<void>;
    /**
     * Handle inventory webhook from Magento
     */
    handleInventoryWebhook(connection: EcommerceConnection, payload: any): Promise<void>;
}
//# sourceMappingURL=MagentoService.d.ts.map