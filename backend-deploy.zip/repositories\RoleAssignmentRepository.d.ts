/**
 * Role Assignment Repository
 *
 * Manages additional role assignments for users
 */
import { Pool } from 'pg';
import { RoleAssignment, GrantRoleDTO, RevokeRoleDTO, UserRole } from '@opsui/shared';
export declare class RoleAssignmentRepository {
    private pool;
    constructor(pool: Pool);
    /**
     * Get all active role assignments for a user
     */
    getUserRoleAssignments(userId: string): Promise<UserRole[]>;
    /**
     * Get all role assignments with details
     */
    getAllRoleAssignments(): Promise<RoleAssignment[]>;
    /**
     * Get role assignments for a specific user
     */
    getRoleAssignmentsForUser(userId: string): Promise<RoleAssignment[]>;
    /**
     * Grant a role to a user
     */
    grantRole(dto: GrantRoleDTO, grantedBy: string): Promise<RoleAssignment>;
    /**
     * Revoke a role from a user (soft delete)
     */
    revokeRole(dto: RevokeRoleDTO): Promise<void>;
    /**
     * Check if a user has a specific role (including base role)
     */
    userHasRole(userId: string, role: UserRole): Promise<boolean>;
}
//# sourceMappingURL=RoleAssignmentRepository.d.ts.map