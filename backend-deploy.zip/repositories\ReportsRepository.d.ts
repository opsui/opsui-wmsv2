/**
 * Reports Repository
 *
 * Handles database operations for reports, executions,
 * schedules, and dashboards.
 */
import { Report, ReportExecution, Dashboard, ExportJob, ReportType, ReportStatus } from '@opsui/shared';
export declare class ReportsRepository {
    /**
     * Get all reports with optional filtering
     */
    findAll(filters?: {
        reportType?: ReportType;
        status?: ReportStatus;
        isPublic?: boolean;
        createdBy?: string;
        includeAll?: boolean;
    }): Promise<Report[]>;
    /**
     * Find a report by ID
     */
    findById(reportId: string): Promise<Report | null>;
    /**
     * Create a new report
     */
    create(report: Omit<Report, 'reportId' | 'createdAt'>): Promise<Report>;
    /**
     * Update an existing report
     */
    update(reportId: string, updates: Partial<Report>): Promise<Report | null>;
    /**
     * Delete a report
     */
    delete(reportId: string): Promise<boolean>;
    /**
     * Create a report execution
     */
    createExecution(execution: Omit<ReportExecution, 'executionId'>): Promise<ReportExecution>;
    /**
     * Get execution history for a report
     */
    findExecutionsByReportId(reportId: string, limit?: number): Promise<ReportExecution[]>;
    /**
     * Get all dashboards
     */
    findDashboards(filters?: {
        owner?: string;
        isPublic?: boolean;
    }): Promise<Dashboard[]>;
    /**
     * Find a dashboard by ID
     */
    findDashboardById(dashboardId: string): Promise<Dashboard | null>;
    /**
     * Create a dashboard
     */
    createDashboard(dashboard: Omit<Dashboard, 'dashboardId' | 'createdAt'>): Promise<Dashboard>;
    /**
     * Create an export job
     */
    createExportJob(job: Omit<ExportJob, 'jobId' | 'createdAt'>): Promise<ExportJob>;
    /**
     * Update export job
     */
    updateExportJob(jobId: string, updates: Partial<ExportJob>): Promise<ExportJob | null>;
    /**
     * Get an export job by ID
     */
    getExportJob(jobId: string): Promise<ExportJob | null>;
    /**
     * Get all export jobs (alias for findExportJobs)
     */
    findAllExportJobs(createdBy?: string): Promise<ExportJob[]>;
    /**
     * Get all export jobs with optional filtering
     */
    findExportJobs(filters?: {
        status?: ReportStatus;
        entityType?: string;
        createdBy?: string;
    }): Promise<ExportJob[]>;
}
export declare const reportsRepository: ReportsRepository;
//# sourceMappingURL=ReportsRepository.d.ts.map