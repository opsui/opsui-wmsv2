"use strict";
/**
 * Custom Role repository
 *
 * Handles database operations for custom roles and permissions
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.customRoleRepository = exports.CustomRoleRepository = void 0;
const BaseRepository_1 = require("./BaseRepository");
const client_1 = require("../db/client");
const shared_1 = require("@opsui/shared");
class CustomRoleRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super('custom_roles', 'role_id');
    }
    // --------------------------------------------------------------------------
    // GET ALL ROLES (including system roles from UserRole enum)
    // --------------------------------------------------------------------------
    async getAllRolesWithPermissions() {
        // Get custom roles with their permissions
        const customRolesResult = await (0, client_1.query)(`
      SELECT cr.role_id, cr.name, cr.description, cr.is_system,
             COALESCE(json_agg(rp.permission ORDER BY rp.permission) FILTER (WHERE rp.permission IS NOT NULL), '[]') as permissions
      FROM custom_roles cr
      LEFT JOIN role_permissions rp ON cr.role_id = rp.role_id
      GROUP BY cr.role_id, cr.name, cr.description, cr.is_system
      ORDER BY cr.name
    `);
        const roles = customRolesResult.rows.map(row => ({
            roleId: row.role_id,
            name: row.name,
            permissions: row.permissions || [],
        }));
        return roles;
    }
    // --------------------------------------------------------------------------
    // GET CUSTOM ROLE BY ID
    // --------------------------------------------------------------------------
    async getCustomRoleById(roleId) {
        const result = await (0, client_1.query)(`SELECT cr.role_id, cr.name, cr.description, cr.is_system,
              json_agg(rp.permission ORDER BY rp.permission) FILTER (WHERE rp.permission IS NOT NULL) as permissions
       FROM custom_roles cr
       LEFT JOIN role_permissions rp ON cr.role_id = rp.role_id
       WHERE cr.role_id = $1
       GROUP BY cr.role_id, cr.name, cr.description, cr.is_system`, [roleId]);
        if (result.rows.length === 0) {
            return null;
        }
        return result.rows[0];
    }
    // --------------------------------------------------------------------------
    // GET CUSTOM ROLE BY ID OR THROW
    // --------------------------------------------------------------------------
    async getCustomRoleByIdOrThrow(roleId) {
        const role = await this.getCustomRoleById(roleId);
        if (!role) {
            throw new shared_1.NotFoundError('CustomRole', roleId);
        }
        return role;
    }
    // --------------------------------------------------------------------------
    // CREATE CUSTOM ROLE
    // --------------------------------------------------------------------------
    async createCustomRole(data) {
        // Check if role ID already exists
        const existing = await this.findById(data.roleId);
        if (existing) {
            throw new shared_1.ConflictError(`Role with ID ${data.roleId} already exists`);
        }
        // Check if name already exists
        const existingName = await (0, client_1.query)(`SELECT * FROM custom_roles WHERE name = $1`, [data.name]);
        if (existingName.rows.length > 0) {
            throw new shared_1.ConflictError(`Role with name ${data.name} already exists`);
        }
        // Create the role
        await this.insert({
            roleId: data.roleId,
            name: data.name,
            description: data.description,
            isSystem: false,
        });
        // Grant permissions
        if (data.permissions && data.permissions.length > 0) {
            for (const permission of data.permissions) {
                await (0, client_1.query)(`INSERT INTO role_permissions (role_id, permission, granted_by)
           VALUES ($1, $2, $3)`, [data.roleId, permission, data.grantedBy]);
            }
        }
        // Return the role with permissions
        return (await this.getCustomRoleById(data.roleId));
    }
    // --------------------------------------------------------------------------
    // UPDATE CUSTOM ROLE
    // --------------------------------------------------------------------------
    async updateCustomRole(roleId, data) {
        const existing = await this.getCustomRoleByIdOrThrow(roleId);
        // Don't allow updating system roles
        if (existing.isSystem) {
            throw new Error('Cannot update system roles');
        }
        // Update name and description if provided
        const updates = [];
        const values = [];
        let paramIndex = 1;
        if (data.name !== undefined && data.name !== existing.name) {
            // Check if name already exists
            const existingName = await (0, client_1.query)(`SELECT * FROM custom_roles WHERE name = $1 AND role_id != $2`, [data.name, roleId]);
            if (existingName.rows.length > 0) {
                throw new shared_1.ConflictError(`Role with name ${data.name} already exists`);
            }
            updates.push(`name = $${paramIndex++}`);
            values.push(data.name);
        }
        if (data.description !== undefined) {
            updates.push(`description = $${paramIndex++}`);
            values.push(data.description);
        }
        if (updates.length > 0) {
            values.push(roleId);
            await (0, client_1.query)(`UPDATE custom_roles SET ${updates.join(', ')}, updated_at = NOW() WHERE role_id = $${paramIndex}`, values);
        }
        // Update permissions if provided
        if (data.permissions !== undefined) {
            // Remove all existing permissions
            await (0, client_1.query)(`DELETE FROM role_permissions WHERE role_id = $1`, [roleId]);
            // Add new permissions
            for (const permission of data.permissions) {
                await (0, client_1.query)(`INSERT INTO role_permissions (role_id, permission, granted_by)
           VALUES ($1, $2, $3)`, [roleId, permission, data.grantedBy]);
            }
        }
        // Return the updated role
        return (await this.getCustomRoleById(roleId));
    }
    // --------------------------------------------------------------------------
    // DELETE CUSTOM ROLE
    // --------------------------------------------------------------------------
    async deleteCustomRole(roleId) {
        const existing = await this.getCustomRoleByIdOrThrow(roleId);
        // Don't allow deleting system roles
        if (existing.isSystem) {
            throw new Error('Cannot delete system roles');
        }
        // Delete role permissions (cascade will handle this, but being explicit)
        await (0, client_1.query)(`DELETE FROM role_permissions WHERE role_id = $1`, [roleId]);
        // Delete the role
        await (0, client_1.query)(`DELETE FROM custom_roles WHERE role_id = $1`, [roleId]);
    }
    // --------------------------------------------------------------------------
    // GET PERMISSIONS FOR A ROLE
    // --------------------------------------------------------------------------
    async getRolePermissions(roleId) {
        const result = await (0, client_1.query)(`SELECT permission FROM role_permissions WHERE role_id = $1 ORDER BY permission`, [roleId]);
        return result.rows.map(row => row.permission);
    }
    // --------------------------------------------------------------------------
    // CHECK IF ROLE HAS PERMISSION
    // --------------------------------------------------------------------------
    async roleHasPermission(roleId, permission) {
        const result = await (0, client_1.query)(`SELECT 1 FROM role_permissions WHERE role_id = $1 AND permission = $2`, [roleId, permission]);
        return result.rows.length > 0;
    }
    // --------------------------------------------------------------------------
    // GET PERMISSIONS FOR USER (including from their base role and custom roles)
    // --------------------------------------------------------------------------
    async getUserPermissions(userId, userRole) {
        // Get permissions from default role permissions
        const { DEFAULT_ROLE_PERMISSIONS, Permission } = await Promise.resolve().then(() => __importStar(require('@opsui/shared')));
        // Debug logging - check available roles
        console.log('[getUserPermissions] Available role keys:', Object.keys(DEFAULT_ROLE_PERMISSIONS));
        console.log('[getUserPermissions] userId:', userId, 'userRole:', userRole, 'userRole type:', typeof userRole);
        const defaultPermissions = DEFAULT_ROLE_PERMISSIONS[userRole] || [];
        console.log('[getUserPermissions] defaultPermissions count:', defaultPermissions.length);
        if (defaultPermissions.length > 0) {
            console.log('[getUserPermissions] First few permissions:', defaultPermissions.slice(0, 5));
            console.log('[getUserPermissions] PERFORM_CYCLE_COUNTS:', Permission.PERFORM_CYCLE_COUNTS);
            console.log('[getUserPermissions] Has PERFORM_CYCLE_COUNTS:', defaultPermissions.includes(Permission.PERFORM_CYCLE_COUNTS));
            console.log('[getUserPermissions] Has ADMIN_FULL_ACCESS:', defaultPermissions.includes(Permission.ADMIN_FULL_ACCESS));
        }
        else {
            console.log('[getUserPermissions] WARNING: No default permissions found for role:', userRole);
        }
        // Get custom role permissions that have been granted to this user
        // Cast both sides to text for proper type comparison
        const result = await (0, client_1.query)(`SELECT DISTINCT rp.permission
       FROM role_permissions rp
       INNER JOIN user_role_assignments ura ON rp.role_id::text = ura.role::text
       WHERE ura.user_id = $1 AND ura.active = true
       ORDER BY rp.permission`, [userId]);
        const customPermissions = result.rows.map(row => row.permission);
        // Combine and deduplicate
        const allPermissions = [...new Set([...defaultPermissions, ...customPermissions])];
        return allPermissions;
    }
    // --------------------------------------------------------------------------
    // GET SYSTEM ROLES (predefined UserRole enum)
    // --------------------------------------------------------------------------
    async getSystemRoles() {
        const { UserRole, DEFAULT_ROLE_PERMISSIONS } = await Promise.resolve().then(() => __importStar(require('@opsui/shared')));
        return Object.values(UserRole).map(role => ({
            roleId: role,
            name: role
                .replace(/_/g, ' ')
                .toLowerCase()
                .replace(/\b\w/g, l => l.toUpperCase()),
            permissions: DEFAULT_ROLE_PERMISSIONS[role] || [],
            isSystem: true,
        }));
    }
}
exports.CustomRoleRepository = CustomRoleRepository;
// Singleton instance
exports.customRoleRepository = new CustomRoleRepository();
//# sourceMappingURL=CustomRoleRepository.js.map