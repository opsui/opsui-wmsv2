"use strict";
/**
 * Activate all users
 */
Object.defineProperty(exports, "__esModule", { value: true });
const client_1 = require("./client");
const logger_1 = require("../config/logger");
async function activateUsers() {
    try {
        logger_1.logger.info('Activating users...');
        const result = await (0, client_1.query)(`UPDATE users SET active = true`);
        logger_1.logger.info(`Updated ${result.rowCount} users`);
        await (0, client_1.closePool)();
        process.exit(0);
    }
    catch (error) {
        logger_1.logger.error('Failed to activate users', {
            error: error instanceof Error ? error.message : String(error),
        });
        await (0, client_1.closePool)();
        process.exit(1);
    }
}
activateUsers().catch(error => {
    logger_1.logger.error('Unhandled error in activateUsers', {
        error: error instanceof Error ? error.message : String(error),
    });
    process.exit(1);
});
//# sourceMappingURL=activate-users.js.map