/**
 * Jest Global Setup
 *
 * Runs once before all test suites.
 * Sets up the test database and global test fixtures.
 */
export default function globalSetup(): Promise<void>;
//# sourceMappingURL=global-setup.d.ts.map