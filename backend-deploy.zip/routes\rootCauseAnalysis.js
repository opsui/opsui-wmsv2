"use strict";
/**
 * Root Cause Analysis Routes
 *
 * API endpoints for variance root cause categorization and analysis
 */
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const RootCauseAnalysisService_1 = require("../services/RootCauseAnalysisService");
const middleware_1 = require("../middleware");
const permissions_1 = require("../middleware/permissions");
const shared_1 = require("@opsui/shared");
const router = (0, express_1.Router)();
// All routes require authentication
router.use(middleware_1.authenticate);
// ============================================================================
// ROOT CAUSE CATEGORIES
// ============================================================================
/**
 * GET /api/cycle-count/root-causes/categories
 * Get all root cause categories
 */
router.get('/categories', (0, middleware_1.asyncHandler)(async (_req, res) => {
    const categories = await RootCauseAnalysisService_1.rootCauseAnalysisService.getAllCategories();
    res.json(categories);
}));
/**
 * GET /api/cycle-count/root-causes/categories/:categoryId
 * Get a specific root cause category
 */
router.get('/categories/:categoryId', (0, middleware_1.asyncHandler)(async (req, res) => {
    const { categoryId } = req.params;
    const category = await RootCauseAnalysisService_1.rootCauseAnalysisService.getCategory(categoryId);
    res.json(category);
}));
// ============================================================================
// ROOT CAUSE RECORDING
// ============================================================================
/**
 * POST /api/cycle-count/root-causes
 * Record root cause for a variance entry
 * Requires PERFORM_CYCLE_COUNTS permission
 */
router.post('/', (0, permissions_1.requirePermission)(shared_1.Permission.PERFORM_CYCLE_COUNTS), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { entryId, categoryId, additionalNotes } = req.body;
    // Validate required fields
    if (!entryId || !categoryId) {
        res.status(400).json({
            error: 'Missing required fields',
            code: 'MISSING_FIELDS',
        });
        return;
    }
    const rootCause = await RootCauseAnalysisService_1.rootCauseAnalysisService.recordRootCause({
        entryId,
        categoryId,
        additionalNotes,
        createdBy: req.user.userId,
    });
    res.status(201).json(rootCause);
}));
/**
 * GET /api/cycle-count/root-causes/entry/:entryId
 * Get root cause for a specific entry
 */
router.get('/entry/:entryId', (0, middleware_1.asyncHandler)(async (req, res) => {
    const { entryId } = req.params;
    const rootCause = await RootCauseAnalysisService_1.rootCauseAnalysisService.getRootCauseForEntry(entryId);
    res.json(rootCause);
}));
// ============================================================================
// ANALYTICS ENDPOINTS
// ============================================================================
/**
 * GET /api/cycle-count/root-causes/pareto
 * Get Pareto analysis of root causes (80/20 rule)
 */
router.get('/pareto', (0, middleware_1.authorize)(shared_1.UserRole.STOCK_CONTROLLER, shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (req, res) => {
    const days = req.query.days ? parseInt(req.query.days) : 30;
    const paretoData = await RootCauseAnalysisService_1.rootCauseAnalysisService.getRootCausePareto(days);
    res.json(paretoData);
}));
/**
 * GET /api/cycle-count/root-causes/breakdown
 * Get category breakdown with trend analysis
 */
router.get('/breakdown', (0, middleware_1.authorize)(shared_1.UserRole.STOCK_CONTROLLER, shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (req, res) => {
    const days = req.query.days ? parseInt(req.query.days) : 30;
    const breakdown = await RootCauseAnalysisService_1.rootCauseAnalysisService.getCategoryBreakdown(days);
    res.json(breakdown);
}));
/**
 * GET /api/cycle-count/root-causes/trending
 * Get trending root causes (increasing problems)
 */
router.get('/trending', (0, middleware_1.authorize)(shared_1.UserRole.STOCK_CONTROLLER, shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (req, res) => {
    const days = req.query.days ? parseInt(req.query.days) : 30;
    const trending = await RootCauseAnalysisService_1.rootCauseAnalysisService.getTrendingRootCauses(days);
    res.json(trending);
}));
/**
 * GET /api/cycle-count/root-causes/sku/:sku
 * Get root cause analysis for a specific SKU
 */
router.get('/sku/:sku', (0, middleware_1.authorize)(shared_1.UserRole.STOCK_CONTROLLER, shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { sku } = req.params;
    const days = req.query.days ? parseInt(req.query.days) : 30;
    const skuAnalysis = await RootCauseAnalysisService_1.rootCauseAnalysisService.getRootCauseBySKU(sku, days);
    res.json(skuAnalysis);
}));
/**
 * GET /api/cycle-count/root-causes/zone/:zone
 * Get root cause analysis for a specific zone
 */
router.get('/zone/:zone', (0, middleware_1.authorize)(shared_1.UserRole.STOCK_CONTROLLER, shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { zone } = req.params;
    const days = req.query.days ? parseInt(req.query.days) : 30;
    const zoneAnalysis = await RootCauseAnalysisService_1.rootCauseAnalysisService.getRootCauseByZone(zone, days);
    res.json(zoneAnalysis);
}));
exports.default = router;
//# sourceMappingURL=rootCauseAnalysis.js.map