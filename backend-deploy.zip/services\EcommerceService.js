"use strict";
/**
 * E-commerce Integration Service
 *
 * Business logic for e-commerce platform integration
 * Supports Shopify, WooCommerce, Magento, and custom platforms
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.ecommerceService = exports.EcommerceService = void 0;
const client_1 = require("../db/client");
const EcommerceRepository_1 = require("../repositories/EcommerceRepository");
const shared_1 = require("@opsui/shared");
// Import platform-specific services
const ShopifyService_1 = require("./platforms/ShopifyService");
const WooCommerceService_1 = require("./platforms/WooCommerceService");
const MagentoService_1 = require("./platforms/MagentoService");
// ============================================================================
// SERVICE
// ============================================================================
class EcommerceService {
    platformServices;
    constructor() {
        this.platformServices = new Map([
            [shared_1.PlatformType.SHOPIFY, new ShopifyService_1.ShopifyService()],
            [shared_1.PlatformType.WOOCOMMERCE, new WooCommerceService_1.WooCommerceService()],
            [shared_1.PlatformType.MAGENTO, new MagentoService_1.MagentoService()],
        ]);
    }
    // ========================================================================
    // CONNECTION MANAGEMENT
    // ========================================================================
    /**
     * Create a new e-commerce connection
     */
    async createConnection(dto) {
        const connectionId = `ECONN-${Date.now()}-${Math.random().toString(36).substring(2, 8)}`;
        // Create the connection
        const connection = {
            connectionName: dto.connectionName,
            platformType: dto.platformType,
            apiEndpoint: dto.apiEndpoint,
            apiKey: dto.apiKey,
            apiSecret: dto.apiSecret,
            accessToken: dto.accessToken,
            storeUrl: dto.storeUrl,
            apiVersion: dto.apiVersion || 'v1',
            webhookUrl: dto.webhookUrl,
            webhookSecret: dto.webhookSecret,
            isActive: true,
            syncCustomers: dto.syncCustomers ?? true,
            syncProducts: dto.syncProducts ?? true,
            syncInventory: dto.syncInventory ?? true,
            syncOrders: dto.syncOrders ?? true,
            autoImportOrders: dto.autoImportOrders ?? false,
            syncFrequencyMinutes: dto.syncFrequencyMinutes ?? 60,
            connectionSettings: dto.connectionSettings,
            createdBy: dto.createdBy,
        };
        const created = await EcommerceRepository_1.ecommerceRepository.insert({
            ...connection,
            connectionId,
            createdAt: new Date(),
            updatedAt: new Date(),
        });
        // Save platform-specific settings if provided
        if (dto.platformSettings) {
            await this.savePlatformSettings(connectionId, dto.platformType, dto.platformSettings);
        }
        return created;
    }
    /**
     * Update an existing connection
     */
    async updateConnection(connectionId, dto) {
        return await EcommerceRepository_1.ecommerceRepository.update(connectionId, {
            ...dto,
            updatedAt: new Date(),
        });
    }
    /**
     * Get connection by ID
     */
    async getConnection(connectionId) {
        return await EcommerceRepository_1.ecommerceRepository.findById(connectionId);
    }
    /**
     * Get all connections
     */
    async getAllConnections() {
        return await EcommerceRepository_1.ecommerceRepository.findAll({ orderBy: 'created_at', orderDirection: 'DESC' });
    }
    /**
     * Get active connections
     */
    async getActiveConnections() {
        return await EcommerceRepository_1.ecommerceRepository.findActiveConnections();
    }
    /**
     * Delete a connection
     */
    async deleteConnection(connectionId) {
        return await EcommerceRepository_1.ecommerceRepository.delete(connectionId);
    }
    /**
     * Test connection to e-commerce platform
     */
    async testConnection(connectionId) {
        const connection = await EcommerceRepository_1.ecommerceRepository.findByIdOrThrow(connectionId);
        const platformService = this.platformServices.get(connection.platformType);
        if (!platformService) {
            return {
                success: false,
                message: 'Platform not supported',
                responseTimeMs: 0,
            };
        }
        const startTime = Date.now();
        try {
            const result = await platformService.testConnection(connection);
            const responseTime = Date.now() - startTime;
            // Update rate limit info if provided
            if (result.rateLimitRemaining !== undefined) {
                await EcommerceRepository_1.ecommerceRepository.updateRateLimit(connectionId, result.rateLimitRemaining, result.rateLimitResetAt || new Date(Date.now() + 3600000));
            }
            return {
                success: result.success,
                message: result.message,
                responseTimeMs: responseTime,
                platformInfo: result.platformInfo,
            };
        }
        catch (error) {
            return {
                success: false,
                message: error instanceof Error ? error.message : 'Connection test failed',
                responseTimeMs: Date.now() - startTime,
            };
        }
    }
    // ========================================================================
    // PRODUCT MAPPING
    // ========================================================================
    /**
     * Create product mapping
     */
    async createProductMapping(dto) {
        return await EcommerceRepository_1.ecommerceRepository.createProductMapping({
            connectionId: dto.connectionId,
            internalSku: dto.internalSku,
            externalProductId: dto.externalProductId,
            externalVariantId: dto.externalVariantId,
            externalProductTitle: dto.externalProductTitle,
            syncStatus: shared_1.ProductMappingStatus.ACTIVE,
        });
    }
    /**
     * Update product mapping
     */
    async updateProductMapping(mappingId, dto) {
        return await EcommerceRepository_1.ecommerceRepository.updateProductMapping(mappingId, dto);
    }
    /**
     * Get product mappings for a connection
     */
    async getProductMappings(connectionId) {
        return await EcommerceRepository_1.ecommerceRepository.findAllProductMappings(connectionId);
    }
    /**
     * Delete product mapping
     */
    async deleteProductMapping(mappingId) {
        return await EcommerceRepository_1.ecommerceRepository.deleteProductMapping(mappingId);
    }
    // ========================================================================
    // INVENTORY SYNC
    // ========================================================================
    /**
     * Sync inventory for SKUs
     */
    async syncInventory(dto) {
        const connection = await EcommerceRepository_1.ecommerceRepository.findByIdOrThrow(dto.connectionId);
        const platformService = this.platformServices.get(connection.platformType);
        if (!platformService) {
            throw new Error('Platform not supported');
        }
        // Create sync log
        const log = await EcommerceRepository_1.ecommerceRepository.createSyncLog({
            connectionId: dto.connectionId,
            syncType: dto.syncType || shared_1.InventorySyncType.PUSH,
            resourceType: 'INVENTORY',
            resourceCount: dto.skus.length,
            successCount: 0,
            failureCount: 0,
            syncStatus: shared_1.EcommerceSyncStatus.IN_PROGRESS,
            createdBy: 'system',
        });
        let successCount = 0;
        let failureCount = 0;
        const errors = [];
        try {
            for (const sku of dto.skus) {
                try {
                    // Get current inventory from WMS
                    const inventoryResult = await (0, client_1.query)(`SELECT quantity FROM inventory WHERE sku = $1`, [
                        sku,
                    ]);
                    if (inventoryResult.rows.length === 0) {
                        errors.push(`SKU ${sku} not found in inventory`);
                        failureCount++;
                        continue;
                    }
                    const currentQuantity = inventoryResult.rows[0].quantity;
                    // Get product mapping
                    const mapping = await EcommerceRepository_1.ecommerceRepository.findProductMappingBySKU(dto.connectionId, sku);
                    if (!mapping) {
                        errors.push(`No product mapping found for SKU ${sku}`);
                        failureCount++;
                        continue;
                    }
                    // Create inventory sync record
                    await EcommerceRepository_1.ecommerceRepository.createInventorySync({
                        connectionId: dto.connectionId,
                        sku: sku,
                        syncType: dto.syncType || shared_1.InventorySyncType.PUSH,
                        syncStatus: shared_1.EcommerceSyncStatus.IN_PROGRESS,
                        quantityBefore: currentQuantity,
                        quantityAfter: currentQuantity,
                        externalQuantityBefore: undefined,
                    });
                    // Sync to platform
                    if (dto.syncType === shared_1.InventorySyncType.PUSH ||
                        dto.syncType === shared_1.InventorySyncType.BIDIRECTIONAL) {
                        await platformService.updateInventory(connection, mapping, currentQuantity);
                    }
                    // For pull or bidirectional, get platform inventory
                    if (dto.syncType === shared_1.InventorySyncType.PULL ||
                        dto.syncType === shared_1.InventorySyncType.BIDIRECTIONAL) {
                        const platformInventory = await platformService.getInventory(connection, mapping);
                        // Update WMS inventory if different
                        if (platformInventory !== undefined && platformInventory !== currentQuantity) {
                            await (0, client_1.query)(`UPDATE inventory SET quantity = $1 WHERE sku = $2`, [
                                platformInventory,
                                sku,
                            ]);
                        }
                    }
                    successCount++;
                }
                catch (error) {
                    errors.push(`${sku}: ${error instanceof Error ? error.message : 'Unknown error'}`);
                    failureCount++;
                }
            }
            // Update connection last sync
            await EcommerceRepository_1.ecommerceRepository.updateLastSync(dto.connectionId);
            // Update sync log
            await EcommerceRepository_1.ecommerceRepository.updateSyncLog(log.logId, {
                successCount,
                failureCount,
                syncStatus: shared_1.EcommerceSyncStatus.COMPLETED,
                errorSummary: errors.length > 0 ? errors.join('; ') : undefined,
            });
        }
        catch (error) {
            await EcommerceRepository_1.ecommerceRepository.updateSyncLog(log.logId, {
                successCount,
                failureCount,
                syncStatus: shared_1.EcommerceSyncStatus.FAILED,
                errorSummary: error instanceof Error ? error.message : 'Unknown error',
            });
            throw error;
        }
        return (await EcommerceRepository_1.ecommerceRepository.findSyncLogs(dto.connectionId, 1))[0];
    }
    // ========================================================================
    // PRODUCT SYNC
    // ========================================================================
    /**
     * Sync products from platform
     */
    async syncProducts(dto) {
        const connection = await EcommerceRepository_1.ecommerceRepository.findByIdOrThrow(dto.connectionId);
        const platformService = this.platformServices.get(connection.platformType);
        if (!platformService) {
            throw new Error('Platform not supported');
        }
        // Create sync log
        const log = await EcommerceRepository_1.ecommerceRepository.createSyncLog({
            connectionId: dto.connectionId,
            syncType: 'PULL',
            resourceType: 'PRODUCT',
            resourceCount: 0,
            successCount: 0,
            failureCount: 0,
            syncStatus: shared_1.EcommerceSyncStatus.IN_PROGRESS,
            createdBy: 'system',
        });
        let successCount = 0;
        let failureCount = 0;
        const errors = [];
        try {
            // Fetch products from platform
            const products = await platformService.fetchProducts(connection, dto.skus);
            log.resourceCount = products.length;
            for (const product of products) {
                try {
                    // Check if product exists in WMS
                    const existingProduct = await (0, client_1.query)(`SELECT sku FROM products WHERE sku = $1`, [
                        product.sku,
                    ]);
                    if (existingProduct.rows.length === 0 && !dto.includeUnmapped) {
                        continue;
                    }
                    // Create or update product mapping
                    const existingMapping = await EcommerceRepository_1.ecommerceRepository.findProductMappingBySKU(dto.connectionId, product.sku);
                    if (existingMapping) {
                        await EcommerceRepository_1.ecommerceRepository.updateProductMapping(existingMapping.mappingId, {
                            externalProductTitle: product.title,
                            syncStatus: shared_1.ProductMappingStatus.ACTIVE,
                            lastSyncedAt: new Date(),
                        });
                    }
                    else if (dto.includeUnmapped && product.sku) {
                        await EcommerceRepository_1.ecommerceRepository.createProductMapping({
                            connectionId: dto.connectionId,
                            internalSku: product.sku,
                            externalProductId: product.externalProductId,
                            externalVariantId: product.externalVariantId,
                            externalProductTitle: product.title,
                            syncStatus: shared_1.ProductMappingStatus.UNSYNCED,
                        });
                    }
                    successCount++;
                }
                catch (error) {
                    errors.push(`${product.sku || product.externalProductId}: ${error instanceof Error ? error.message : 'Unknown error'}`);
                    failureCount++;
                }
            }
            // Update connection last sync
            await EcommerceRepository_1.ecommerceRepository.updateLastSync(dto.connectionId);
            // Update sync log
            await EcommerceRepository_1.ecommerceRepository.updateSyncLog(log.logId, {
                resourceCount: products.length,
                successCount,
                failureCount,
                syncStatus: shared_1.EcommerceSyncStatus.COMPLETED,
                errorSummary: errors.length > 0 ? errors.join('; ') : undefined,
            });
        }
        catch (error) {
            await EcommerceRepository_1.ecommerceRepository.updateSyncLog(log.logId, {
                successCount,
                failureCount,
                syncStatus: shared_1.EcommerceSyncStatus.FAILED,
                errorSummary: error instanceof Error ? error.message : 'Unknown error',
            });
            throw error;
        }
        return (await EcommerceRepository_1.ecommerceRepository.findSyncLogs(dto.connectionId, 1))[0];
    }
    // ========================================================================
    // ORDER SYNC
    // ========================================================================
    /**
     * Sync orders from platform
     */
    async syncOrders(dto) {
        const connection = await EcommerceRepository_1.ecommerceRepository.findByIdOrThrow(dto.connectionId);
        const platformService = this.platformServices.get(connection.platformType);
        if (!platformService) {
            throw new Error('Platform not supported');
        }
        // Create sync log
        const log = await EcommerceRepository_1.ecommerceRepository.createSyncLog({
            connectionId: dto.connectionId,
            syncType: 'IMPORT',
            resourceType: 'ORDER',
            resourceCount: 0,
            successCount: 0,
            failureCount: 0,
            syncStatus: shared_1.EcommerceSyncStatus.IN_PROGRESS,
            createdBy: 'system',
        });
        let successCount = 0;
        let failureCount = 0;
        const errors = [];
        try {
            // Fetch orders from platform
            const orders = await platformService.fetchOrders(connection, dto.orderIds, dto.daysToLookBack || 7);
            log.resourceCount = orders.length;
            for (const order of orders) {
                try {
                    // Check if order already synced
                    const existingSync = await EcommerceRepository_1.ecommerceRepository.findOrderSyncByExternalId(dto.connectionId, order.externalOrderId);
                    if (existingSync && existingSync.syncStatus === shared_1.EcommerceSyncStatus.COMPLETED) {
                        continue;
                    }
                    // Create or update order sync record
                    if (existingSync) {
                        await EcommerceRepository_1.ecommerceRepository.updateOrderSyncStatus(existingSync.syncId, shared_1.EcommerceSyncStatus.IN_PROGRESS);
                    }
                    else {
                        await EcommerceRepository_1.ecommerceRepository.createOrderSync({
                            connectionId: dto.connectionId,
                            externalOrderId: order.externalOrderId,
                            syncStatus: shared_1.EcommerceSyncStatus.IN_PROGRESS,
                            syncType: shared_1.OrderSyncType.IMPORT,
                            orderData: order,
                            lineItemsData: order.lineItems,
                            customerData: order.customer,
                        });
                    }
                    // Process order - create sales order in WMS
                    const internalOrderId = await this.processPlatformOrder(connection, order);
                    // Update sync record
                    const syncRecord = await EcommerceRepository_1.ecommerceRepository.findOrderSyncByExternalId(dto.connectionId, order.externalOrderId);
                    if (syncRecord) {
                        await EcommerceRepository_1.ecommerceRepository.updateOrderSyncStatus(syncRecord.syncId, shared_1.EcommerceSyncStatus.COMPLETED, internalOrderId);
                    }
                    successCount++;
                }
                catch (error) {
                    errors.push(`${order.externalOrderId}: ${error instanceof Error ? error.message : 'Unknown error'}`);
                    failureCount++;
                    // Update sync record with error
                    const syncRecord = await EcommerceRepository_1.ecommerceRepository.findOrderSyncByExternalId(dto.connectionId, order.externalOrderId);
                    if (syncRecord) {
                        await EcommerceRepository_1.ecommerceRepository.updateOrderSyncStatus(syncRecord.syncId, shared_1.EcommerceSyncStatus.FAILED, undefined, error instanceof Error ? error.message : 'Unknown error');
                    }
                }
            }
            // Update connection last sync
            await EcommerceRepository_1.ecommerceRepository.updateLastSync(dto.connectionId);
            // Update sync log
            await EcommerceRepository_1.ecommerceRepository.updateSyncLog(log.logId, {
                resourceCount: orders.length,
                successCount,
                failureCount,
                syncStatus: shared_1.EcommerceSyncStatus.COMPLETED,
                errorSummary: errors.length > 0 ? errors.join('; ') : undefined,
            });
        }
        catch (error) {
            await EcommerceRepository_1.ecommerceRepository.updateSyncLog(log.logId, {
                successCount,
                failureCount,
                syncStatus: shared_1.EcommerceSyncStatus.FAILED,
                errorSummary: error instanceof Error ? error.message : 'Unknown error',
            });
            throw error;
        }
        return (await EcommerceRepository_1.ecommerceRepository.findSyncLogs(dto.connectionId, 1))[0];
    }
    /**
     * Process a platform order and create internal sales order
     */
    async processPlatformOrder(connection, order) {
        // This would integrate with the sales/order module
        // For now, create a placeholder internal order ID
        const internalOrderId = `SO-${Date.now()}-${Math.random().toString(36).substring(2, 8)}`;
        // TODO: Create sales order in the system
        // - Validate customer (create if not exists)
        // - Validate line items (SKUs)
        // - Create sales order header
        // - Create sales order lines
        // - Set order status based on platform status
        return internalOrderId;
    }
    // ========================================================================
    // WEBHOOK HANDLING
    // ========================================================================
    /**
     * Process incoming webhook
     */
    async processWebhook(connectionId, event, payload) {
        const connection = await EcommerceRepository_1.ecommerceRepository.findByIdOrThrow(connectionId);
        const platformService = this.platformServices.get(connection.platformType);
        if (!platformService) {
            throw new Error('Platform not supported');
        }
        // Verify webhook signature if secret is configured
        if (connection.webhookSecret && platformService.verifyWebhook) {
            const isValid = await platformService.verifyWebhook(connection, payload);
            if (!isValid) {
                throw new Error('Invalid webhook signature');
            }
        }
        // Create webhook record
        const webhook = await EcommerceRepository_1.ecommerceRepository.createWebhook({
            connectionId,
            webhookEvent: event,
            externalResourceId: payload.id || payload.resource_id,
            payload,
            processingStatus: shared_1.WebhookProcessingStatus.PENDING,
            receivedAt: new Date(),
        });
        // Process webhook based on event type
        try {
            await this.handleWebhookEvent(connection, event, payload);
            await EcommerceRepository_1.ecommerceRepository.updateWebhookStatus(webhook.webhookId, shared_1.WebhookProcessingStatus.PROCESSED);
        }
        catch (error) {
            await EcommerceRepository_1.ecommerceRepository.updateWebhookStatus(webhook.webhookId, shared_1.WebhookProcessingStatus.FAILED, error instanceof Error ? error.message : 'Unknown error');
            throw error;
        }
    }
    /**
     * Handle specific webhook event
     */
    async handleWebhookEvent(connection, event, payload) {
        const platformService = this.platformServices.get(connection.platformType);
        if (!platformService) {
            throw new Error('Platform not supported');
        }
        // Process based on event type
        if (event.includes('order') && platformService.handleOrderWebhook) {
            await platformService.handleOrderWebhook(connection, payload);
        }
        else if (event.includes('product') && platformService.handleProductWebhook) {
            await platformService.handleProductWebhook(connection, payload);
        }
        else if (event.includes('inventory') && platformService.handleInventoryWebhook) {
            await platformService.handleInventoryWebhook(connection, payload);
        }
    }
    // ========================================================================
    // STATUS & REPORTING
    // ========================================================================
    /**
     * Get connection status overview
     */
    async getConnectionStatus() {
        return await EcommerceRepository_1.ecommerceRepository.getConnectionStatus();
    }
    /**
     * Get sync errors
     */
    async getSyncErrors() {
        return await EcommerceRepository_1.ecommerceRepository.getSyncErrors();
    }
    /**
     * Get pending syncs
     */
    async getPendingSyncs() {
        return await EcommerceRepository_1.ecommerceRepository.getPendingSyncs();
    }
    /**
     * Get sync logs for a connection
     */
    async getSyncLogs(connectionId, limit = 50) {
        return await EcommerceRepository_1.ecommerceRepository.findSyncLogs(connectionId, limit);
    }
    // ========================================================================
    // PLATFORM SETTINGS
    // ========================================================================
    /**
     * Save platform-specific settings
     */
    async savePlatformSettings(connectionId, platformType, settings) {
        switch (platformType) {
            case shared_1.PlatformType.SHOPIFY:
                await EcommerceRepository_1.ecommerceRepository.saveShopifySettings(connectionId, settings);
                break;
            case shared_1.PlatformType.WOOCOMMERCE:
                await EcommerceRepository_1.ecommerceRepository.saveWooCommerceSettings(connectionId, settings);
                break;
            case shared_1.PlatformType.MAGENTO:
                await EcommerceRepository_1.ecommerceRepository.saveMagentoSettings(connectionId, settings);
                break;
        }
    }
    /**
     * Get platform-specific settings
     */
    async getPlatformSettings(connectionId, platformType) {
        switch (platformType) {
            case shared_1.PlatformType.SHOPIFY:
                return await EcommerceRepository_1.ecommerceRepository.getShopifySettings(connectionId);
            case shared_1.PlatformType.WOOCOMMERCE:
                return await EcommerceRepository_1.ecommerceRepository.getWooCommerceSettings(connectionId);
            case shared_1.PlatformType.MAGENTO:
                return await EcommerceRepository_1.ecommerceRepository.getMagentoSettings(connectionId);
            default:
                return null;
        }
    }
}
exports.EcommerceService = EcommerceService;
// Export singleton instance
exports.ecommerceService = new EcommerceService();
//# sourceMappingURL=EcommerceService.js.map