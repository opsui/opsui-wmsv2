"use strict";
/**
 * Run user role assignments migration
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const client_1 = require("./client");
async function runMigration() {
    const pool = (0, client_1.getPool)();
    try {
        const migrationPath = path_1.default.join(__dirname, 'migrations', 'add_user_role_assignments.sql');
        const migrationSQL = fs_1.default.readFileSync(migrationPath, 'utf-8');
        console.log('Running user role assignments migration...');
        await pool.query(migrationSQL);
        console.log('Migration completed successfully!');
    }
    catch (error) {
        console.error('Migration failed:', error);
        throw error;
    }
    finally {
        await pool.end();
    }
}
runMigration().catch(console.error);
//# sourceMappingURL=run-role-migration.js.map