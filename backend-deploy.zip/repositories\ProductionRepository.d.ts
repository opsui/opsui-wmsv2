/**
 * Production Management Repository
 *
 * Data access layer for production management functionality
 */
import { BillOfMaterial, ProductionOrder, ProductionOutput, ProductionJournal, ProductionOrderStatus } from '@opsui/shared';
export declare class ProductionRepository {
    createBOM(bom: Omit<BillOfMaterial, 'bomId' | 'createdAt' | 'updatedAt'>): Promise<BillOfMaterial>;
    findBOMById(bomId: string): Promise<BillOfMaterial | null>;
    findAllBOMs(filters?: {
        productId?: string;
        status?: string;
    }): Promise<BillOfMaterial[]>;
    updateBOM(bomId: string, updates: Partial<BillOfMaterial>): Promise<BillOfMaterial | null>;
    deleteBOM(bomId: string): Promise<boolean>;
    createProductionOrder(order: Omit<ProductionOrder, 'orderId' | 'orderNumber' | 'createdAt' | 'updatedAt' | 'components' | 'quantityCompleted' | 'quantityRejected'>): Promise<ProductionOrder>;
    findProductionOrderById(orderId: string): Promise<ProductionOrder | null>;
    findAllProductionOrders(filters?: {
        status?: ProductionOrderStatus;
        assignedTo?: string;
        limit?: number;
        offset?: number;
    }): Promise<{
        orders: ProductionOrder[];
        total: number;
    }>;
    updateProductionOrder(orderId: string, updates: Partial<ProductionOrder>): Promise<ProductionOrder | null>;
    createProductionOutput(output: Omit<ProductionOutput, 'outputId'>): Promise<ProductionOutput>;
    createProductionJournalEntry(entry: Omit<ProductionOutput, 'outputId'>): Promise<ProductionOutput>;
    findProductionJournalEntries(orderId: string): Promise<ProductionJournal[]>;
    private mapRowToBOM;
    private mapRowToProductionOrder;
    private mapRowToProductionOutput;
}
export declare const productionRepository: ProductionRepository;
//# sourceMappingURL=ProductionRepository.d.ts.map