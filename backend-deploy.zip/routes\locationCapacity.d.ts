/**
 * Location Capacity routes
 *
 * Endpoints for managing location capacity rules, utilization, and alerts
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=locationCapacity.d.ts.map