/**
 * Advanced Inventory Routes
 *
 * API endpoints for advanced inventory management
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=advancedInventory.d.ts.map