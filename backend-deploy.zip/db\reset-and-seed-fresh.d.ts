/**
 * Reset Database and Seed Fresh Mock Data
 *
 * This script:
 * 1. Clears ALL data from tables (audit_logs, orders, order_items, etc.)
 * 2. Creates fresh mock orders in various states
 * 3. Creates mock order items
 */
export {};
//# sourceMappingURL=reset-and-seed-fresh.d.ts.map