"use strict";
/**
 * Recurring Schedules Routes
 *
 * API endpoints for managing automated recurring cycle count schedules
 */
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const RecurringScheduleService_1 = require("../services/RecurringScheduleService");
const middleware_1 = require("../middleware");
const shared_1 = require("@opsui/shared");
const router = (0, express_1.Router)();
// All routes require authentication
router.use(middleware_1.authenticate);
/**
 * POST /api/cycle-count/schedules
 * Create a new recurring schedule
 */
router.post('/', (0, middleware_1.asyncHandler)(async (req, res) => {
    const { scheduleName, countType, frequencyType, frequencyInterval, location, sku, assignedTo, notes, } = req.body;
    // Validate required fields
    if (!scheduleName || !countType || !frequencyType || !assignedTo) {
        res.status(400).json({
            error: 'Missing required fields',
            code: 'MISSING_FIELDS',
        });
        return;
    }
    const schedule = await RecurringScheduleService_1.recurringScheduleService.createRecurringSchedule({
        scheduleName,
        countType,
        frequencyType,
        frequencyInterval,
        location,
        sku,
        assignedTo,
        notes,
        createdBy: req.user.userId,
    });
    res.status(201).json(schedule);
}));
/**
 * GET /api/cycle-count/schedules
 * Get all recurring schedules with optional filters
 */
router.get('/', (0, middleware_1.asyncHandler)(async (req, res) => {
    const filters = {
        isActive: req.query.isActive === 'true' ? true : req.query.isActive === 'false' ? false : undefined,
        assignedTo: req.query.assignedTo,
        frequencyType: req.query.frequencyType,
        countType: req.query.countType,
        limit: req.query.limit ? parseInt(req.query.limit) : undefined,
        offset: req.query.offset ? parseInt(req.query.offset) : undefined,
    };
    const result = await RecurringScheduleService_1.recurringScheduleService.getAllSchedules(filters);
    res.json(result);
}));
/**
 * GET /api/cycle-count/schedules/:scheduleId
 * Get a specific recurring schedule
 */
router.get('/:scheduleId', (0, middleware_1.asyncHandler)(async (req, res) => {
    const { scheduleId } = req.params;
    const schedule = await RecurringScheduleService_1.recurringScheduleService.getSchedule(scheduleId);
    res.json(schedule);
}));
/**
 * PUT /api/cycle-count/schedules/:scheduleId
 * Update a recurring schedule
 */
router.put('/:scheduleId', (0, middleware_1.asyncHandler)(async (req, res) => {
    const { scheduleId } = req.params;
    const updates = req.body;
    const schedule = await RecurringScheduleService_1.recurringScheduleService.updateSchedule(scheduleId, updates);
    res.json(schedule);
}));
/**
 * DELETE /api/cycle-count/schedules/:scheduleId
 * Delete a recurring schedule
 */
router.delete('/:scheduleId', (0, middleware_1.asyncHandler)(async (req, res) => {
    const { scheduleId } = req.params;
    await RecurringScheduleService_1.recurringScheduleService.deleteSchedule(scheduleId);
    res.status(204).send();
}));
/**
 * POST /api/cycle-count/schedules/process
 * Process all due schedules and generate cycle count plans
 * Admin only - typically called by cron job
 */
router.post('/process', (0, middleware_1.authorize)(shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (_req, res) => {
    const result = await RecurringScheduleService_1.recurringScheduleService.processDueSchedules();
    res.json(result);
}));
exports.default = router;
//# sourceMappingURL=recurringSchedules.js.map