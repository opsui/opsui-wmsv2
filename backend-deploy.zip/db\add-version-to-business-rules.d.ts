/**
 * Add version column to business_rules table
 */
export {};
//# sourceMappingURL=add-version-to-business-rules.d.ts.map