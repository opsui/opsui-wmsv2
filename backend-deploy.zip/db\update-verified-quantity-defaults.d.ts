/**
 * Update NULL verified_quantity values to 0
 *
 * This ensures all existing order_items have verified_quantity set to 0
 * instead of NULL, which can cause issues in the verifyPackingItem function.
 */
export {};
//# sourceMappingURL=update-verified-quantity-defaults.d.ts.map