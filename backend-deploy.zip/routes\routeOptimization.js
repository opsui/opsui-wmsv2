"use strict";
/**
 * Route Optimization API Routes
 *
 * Exposes route optimization algorithms via REST API
 * Provides endpoints for calculating optimal pick routes
 */
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const zod_1 = require("zod");
const logger_1 = require("../config/logger");
const RouteOptimizationService_1 = require("../services/RouteOptimizationService");
const MLPredictionService_1 = require("../services/MLPredictionService");
// ============================================================================
// ROUTER
// ============================================================================
const router = (0, express_1.Router)();
// ============================================================================
// VALIDATION SCHEMAS
// ============================================================================
const optimizeRouteSchema = zod_1.z.object({
    locations: zod_1.z.array(zod_1.z.string().regex(/^[A-Z]-\d{1,3}-\d{2}$/)).min(2),
    startPoint: zod_1.z
        .string()
        .regex(/^[A-Z]-\d{1,3}-\d{2}$/)
        .optional()
        .default('A-01-01'),
    algorithm: zod_1.z.enum(['tsp', 'nearest', 'aisle', 'zone']).optional(),
});
const predictDurationSchema = zod_1.z.object({
    order_id: zod_1.z.string().optional(),
    order_item_count: zod_1.z.number().min(1),
    order_total_value: zod_1.z.number().optional(),
    hour_of_day: zod_1.z.number().min(0).max(23),
    day_of_week: zod_1.z.number().min(0).max(6),
    sku_count: zod_1.z.number().min(1),
    zone_diversity: zod_1.z.number().min(1),
    priority_level: zod_1.z.number().min(1).max(4),
    picker_count: zod_1.z.number().optional(),
});
const forecastDemandSchema = zod_1.z.object({
    sku_id: zod_1.z.string(),
    historical_data: zod_1.z.array(zod_1.z.number()).min(7),
    forecast_horizon_days: zod_1.z.number().min(1).max(365).optional().default(14),
});
const batchPredictDurationSchema = zod_1.z.object({
    orders: zod_1.z
        .array(zod_1.z.object({
        order_id: zod_1.z.string().optional(),
        order_item_count: zod_1.z.number().min(1),
        hour_of_day: zod_1.z.number().min(0).max(23),
        day_of_week: zod_1.z.number().min(0).max(6),
        sku_count: zod_1.z.number().min(1),
        zone_diversity: zod_1.z.number().min(1),
        priority_level: zod_1.z.number().min(1).max(4),
    }))
        .min(1)
        .max(100),
});
// ============================================================================
// ROUTE OPTIMIZATION ENDPOINTS
// ============================================================================
/**
 * POST /api/route-optimization/optimize
 * Calculate optimal route through warehouse locations
 */
router.post('/optimize', async (req, res) => {
    try {
        const body = optimizeRouteSchema.parse(req.body);
        logger_1.logger.info('Route optimization request', {
            locationCount: body.locations.length,
            startPoint: body.startPoint,
            algorithm: body.algorithm,
        });
        // Use ML service for route optimization
        const result = await MLPredictionService_1.mlPredictionService.optimizeRoute(body.locations, body.startPoint);
        res.json({
            success: true,
            data: result,
        });
    }
    catch (error) {
        if (error instanceof zod_1.z.ZodError) {
            res.status(400).json({
                success: false,
                error: 'Validation error',
                details: error.errors,
            });
            return;
        }
        logger_1.logger.error('Route optimization error', { error });
        res.status(500).json({
            success: false,
            error: 'Failed to optimize route',
        });
    }
});
/**
 * POST /api/route-optimization/optimize-detailed
 * Calculate optimal route with detailed pick task information
 */
router.post('/optimize-detailed', async (req, res) => {
    try {
        const { tasks, startLocation = 'DEPOT', options = {} } = req.body;
        if (!Array.isArray(tasks) || tasks.length === 0) {
            res.status(400).json({
                success: false,
                error: 'tasks must be a non-empty array',
            });
            return;
        }
        logger_1.logger.info('Detailed route optimization request', {
            taskCount: tasks.length,
            startLocation,
            options,
        });
        const result = RouteOptimizationService_1.routeOptimizationService.optimizeRoute(tasks, startLocation, options);
        res.json({
            success: true,
            data: result,
        });
    }
    catch (error) {
        logger_1.logger.error('Detailed route optimization error', { error });
        res.status(500).json({
            success: false,
            error: 'Failed to optimize route',
        });
    }
});
/**
 * GET /api/route-optimization/config
 * Get current warehouse configuration
 */
router.get('/config', (_req, res) => {
    try {
        const config = RouteOptimizationService_1.routeOptimizationService.getConfig();
        res.json({
            success: true,
            data: config,
        });
    }
    catch (error) {
        logger_1.logger.error('Failed to get config', { error });
        res.status(500).json({
            success: false,
            error: 'Failed to get configuration',
        });
    }
});
/**
 * PUT /api/route-optimization/config
 * Update warehouse configuration
 */
router.put('/config', (req, res) => {
    try {
        RouteOptimizationService_1.routeOptimizationService.updateConfig(req.body);
        const config = RouteOptimizationService_1.routeOptimizationService.getConfig();
        logger_1.logger.info('Route optimization config updated', { config });
        res.json({
            success: true,
            data: config,
        });
    }
    catch (error) {
        logger_1.logger.error('Failed to update config', { error });
        res.status(500).json({
            success: false,
            error: 'Failed to update configuration',
        });
    }
});
/**
 * POST /api/route-optimization/compare
 * Compare different route optimization strategies
 */
router.post('/compare', async (req, res) => {
    try {
        const { locations, startPoint = 'A-01-01' } = req.body;
        if (!Array.isArray(locations) || locations.length === 0) {
            res.status(400).json({
                success: false,
                error: 'locations must be a non-empty array',
            });
            return;
        }
        logger_1.logger.info('Route optimization comparison request', {
            locationCount: locations.length,
            startPoint,
        });
        // Run all algorithms
        const algorithms = [
            'tsp',
            'nearest',
            'aisle',
            'zone',
        ];
        const results = [];
        for (const algorithm of algorithms) {
            try {
                const result = await MLPredictionService_1.mlPredictionService.optimizeRoute(locations, startPoint);
                results.push({
                    algorithm,
                    ...result,
                });
            }
            catch (error) {
                logger_1.logger.warn(`Algorithm ${algorithm} failed`, { error });
                results.push({
                    algorithm,
                    error: 'Algorithm failed',
                });
            }
        }
        // Find best result
        const validResults = results.filter(r => !('error' in r));
        const best = validResults.length > 0
            ? validResults.sort((a, b) => a.total_distance_meters - b.total_distance_meters)[0]
            : null;
        res.json({
            success: true,
            data: {
                comparison: results,
                best: best ? best.algorithm : null,
                best_distance: best?.total_distance_meters ?? 0,
                best_time: best?.estimated_time_minutes ?? 0,
            },
        });
    }
    catch (error) {
        logger_1.logger.error('Route comparison error', { error });
        res.status(500).json({
            success: false,
            error: 'Failed to compare routes',
        });
    }
});
// ============================================================================
// ML PREDICTION ENDPOINTS
// ============================================================================
/**
 * POST /api/route-optimization/predict-duration
 * Predict order fulfillment duration using ML
 */
router.post('/predict-duration', async (req, res) => {
    try {
        const body = predictDurationSchema.parse(req.body);
        logger_1.logger.info('Duration prediction request', {
            order_id: body.order_id,
            item_count: body.order_item_count,
            sku_count: body.sku_count,
        });
        const prediction = await MLPredictionService_1.mlPredictionService.predictOrderDuration(body);
        res.json({
            success: true,
            data: prediction,
        });
    }
    catch (error) {
        if (error instanceof zod_1.z.ZodError) {
            res.status(400).json({
                success: false,
                error: 'Validation error',
                details: error.errors,
            });
            return;
        }
        logger_1.logger.error('Duration prediction error', { error });
        res.status(500).json({
            success: false,
            error: 'Failed to predict duration',
        });
    }
});
/**
 * POST /api/route-optimization/predict-duration-batch
 * Predict duration for multiple orders at once
 */
router.post('/predict-duration-batch', async (req, res) => {
    try {
        const body = batchPredictDurationSchema.parse(req.body);
        logger_1.logger.info('Batch duration prediction request', {
            orderCount: body.orders.length,
        });
        const predictions = await Promise.all(body.orders.map(order => MLPredictionService_1.mlPredictionService.predictOrderDuration(order)));
        res.json({
            success: true,
            data: {
                predictions,
                total_orders: predictions.length,
            },
        });
    }
    catch (error) {
        if (error instanceof zod_1.z.ZodError) {
            res.status(400).json({
                success: false,
                error: 'Validation error',
                details: error.errors,
            });
            return;
        }
        logger_1.logger.error('Batch duration prediction error', { error });
        res.status(500).json({
            success: false,
            error: 'Failed to predict batch durations',
        });
    }
});
/**
 * POST /api/route-optimization/forecast-demand
 * Forecast SKU demand using time series analysis
 */
router.post('/forecast-demand', async (req, res) => {
    try {
        const body = forecastDemandSchema.parse(req.body);
        logger_1.logger.info('Demand forecast request', {
            sku_id: body.sku_id,
            dataPoints: body.historical_data.length,
            horizon: body.forecast_horizon_days,
        });
        const forecast = await MLPredictionService_1.mlPredictionService.forecastDemand(body.sku_id, body.historical_data, body.forecast_horizon_days);
        res.json({
            success: true,
            data: forecast,
        });
    }
    catch (error) {
        if (error instanceof zod_1.z.ZodError) {
            res.status(400).json({
                success: false,
                error: 'Validation error',
                details: error.errors,
            });
            return;
        }
        logger_1.logger.error('Demand forecast error', { error });
        res.status(500).json({
            success: false,
            error: 'Failed to forecast demand',
        });
    }
});
/**
 * GET /api/route-optimization/model-status
 * Check ML model health and availability
 */
router.get('/model-status', (_req, res) => {
    const useLocalOnly = process.env.ML_USE_LOCAL_ONLY === 'true';
    const mlApiUrl = process.env.ML_API_URL || 'http://localhost:8001';
    res.json({
        success: true,
        data: {
            status: useLocalOnly ? 'local' : 'hybrid',
            ml_api_url: useLocalOnly ? null : mlApiUrl,
            local_available: true,
            features: {
                duration_prediction: true,
                demand_forecasting: true,
                route_optimization: true,
            },
        },
    });
});
exports.default = router;
//# sourceMappingURL=routeOptimization.js.map