/**
 * Wave Picking Routes
 *
 * API endpoints for wave picking operations
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=waves.d.ts.map