"use strict";
/**
 * E-commerce Integration Routes
 *
 * API endpoints for e-commerce platform integration
 */
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const EcommerceService_1 = require("../services/EcommerceService");
const middleware_1 = require("../middleware");
const router = (0, express_1.Router)();
// ============================================================================
// CONNECTION MANAGEMENT
// ============================================================================
/**
 * GET /api/ecommerce/connections
 * Get all e-commerce connections
 */
router.get('/connections', middleware_1.authenticate, (0, middleware_1.asyncHandler)(async (_req, res) => {
    const connections = await EcommerceService_1.ecommerceService.getAllConnections();
    res.json(connections);
}));
/**
 * GET /api/ecommerce/connections/active
 * Get active connections
 */
router.get('/connections/active', middleware_1.authenticate, (0, middleware_1.asyncHandler)(async (_req, res) => {
    const connections = await EcommerceService_1.ecommerceService.getActiveConnections();
    res.json(connections);
}));
/**
 * GET /api/ecommerce/connections/:connectionId
 * Get a specific connection
 */
router.get('/connections/:connectionId', middleware_1.authenticate, (0, middleware_1.asyncHandler)(async (req, res) => {
    const { connectionId } = req.params;
    const connection = await EcommerceService_1.ecommerceService.getConnection(connectionId);
    if (!connection) {
        res.status(404).json({ error: 'Connection not found' });
        return;
    }
    res.json(connection);
}));
/**
 * POST /api/ecommerce/connections
 * Create a new connection
 */
router.post('/connections', middleware_1.authenticate, (0, middleware_1.asyncHandler)(async (req, res) => {
    const connection = await EcommerceService_1.ecommerceService.createConnection({
        ...req.body,
        createdBy: req.user?.userId,
    });
    res.status(201).json(connection);
}));
/**
 * PUT /api/ecommerce/connections/:connectionId
 * Update a connection
 */
router.put('/connections/:connectionId', middleware_1.authenticate, (0, middleware_1.asyncHandler)(async (req, res) => {
    const { connectionId } = req.params;
    const connection = await EcommerceService_1.ecommerceService.updateConnection(connectionId, req.body);
    if (!connection) {
        res.status(404).json({ error: 'Connection not found' });
        return;
    }
    res.json(connection);
}));
/**
 * DELETE /api/ecommerce/connections/:connectionId
 * Delete a connection
 */
router.delete('/connections/:connectionId', middleware_1.authenticate, (0, middleware_1.asyncHandler)(async (req, res) => {
    const { connectionId } = req.params;
    const success = await EcommerceService_1.ecommerceService.deleteConnection(connectionId);
    if (!success) {
        res.status(404).json({ error: 'Connection not found' });
        return;
    }
    res.status(204).send();
}));
/**
 * POST /api/ecommerce/connections/:connectionId/test
 * Test a connection
 */
router.post('/connections/:connectionId/test', middleware_1.authenticate, (0, middleware_1.asyncHandler)(async (req, res) => {
    const { connectionId } = req.params;
    const result = await EcommerceService_1.ecommerceService.testConnection(connectionId);
    res.json(result);
}));
// ============================================================================
// PRODUCT MAPPING
// ============================================================================
/**
 * GET /api/ecommerce/connections/:connectionId/mappings
 * Get product mappings for a connection
 */
router.get('/connections/:connectionId/mappings', middleware_1.authenticate, (0, middleware_1.asyncHandler)(async (req, res) => {
    const { connectionId } = req.params;
    const mappings = await EcommerceService_1.ecommerceService.getProductMappings(connectionId);
    res.json(mappings);
}));
/**
 * POST /api/ecommerce/connections/:connectionId/mappings
 * Create a product mapping
 */
router.post('/connections/:connectionId/mappings', middleware_1.authenticate, (0, middleware_1.asyncHandler)(async (req, res) => {
    const { connectionId } = req.params;
    const mapping = await EcommerceService_1.ecommerceService.createProductMapping({
        ...req.body,
        connectionId,
    });
    res.status(201).json(mapping);
}));
/**
 * PUT /api/ecommerce/mappings/:mappingId
 * Update a product mapping
 */
router.put('/mappings/:mappingId', middleware_1.authenticate, (0, middleware_1.asyncHandler)(async (req, res) => {
    const { mappingId } = req.params;
    const mapping = await EcommerceService_1.ecommerceService.updateProductMapping(mappingId, req.body);
    if (!mapping) {
        res.status(404).json({ error: 'Mapping not found' });
        return;
    }
    res.json(mapping);
}));
/**
 * DELETE /api/ecommerce/mappings/:mappingId
 * Delete a product mapping
 */
router.delete('/mappings/:mappingId', middleware_1.authenticate, (0, middleware_1.asyncHandler)(async (req, res) => {
    const { mappingId } = req.params;
    const success = await EcommerceService_1.ecommerceService.deleteProductMapping(mappingId);
    if (!success) {
        res.status(404).json({ error: 'Mapping not found' });
        return;
    }
    res.status(204).send();
}));
// ============================================================================
// INVENTORY SYNC
// ============================================================================
/**
 * POST /api/ecommerce/sync/inventory
 * Sync inventory
 */
router.post('/sync/inventory', middleware_1.authenticate, (0, middleware_1.asyncHandler)(async (req, res) => {
    const result = await EcommerceService_1.ecommerceService.syncInventory(req.body);
    res.json(result);
}));
// ============================================================================
// PRODUCT SYNC
// ============================================================================
/**
 * POST /api/ecommerce/sync/products
 * Sync products
 */
router.post('/sync/products', middleware_1.authenticate, (0, middleware_1.asyncHandler)(async (req, res) => {
    const result = await EcommerceService_1.ecommerceService.syncProducts(req.body);
    res.json(result);
}));
// ============================================================================
// ORDER SYNC
// ============================================================================
/**
 * POST /api/ecommerce/sync/orders
 * Sync orders
 */
router.post('/sync/orders', middleware_1.authenticate, (0, middleware_1.asyncHandler)(async (req, res) => {
    const result = await EcommerceService_1.ecommerceService.syncOrders(req.body);
    res.json(result);
}));
// ============================================================================
// WEBHOOKS
// ============================================================================
/**
 * POST /api/ecommerce/webhooks/:connectionId
 * Process incoming webhook
 */
router.post('/webhooks/:connectionId', (0, middleware_1.asyncHandler)(async (req, res) => {
    const { connectionId } = req.params;
    const event = req.headers['x-webhook-event'] || 'unknown';
    await EcommerceService_1.ecommerceService.processWebhook(connectionId, event, req.body);
    res.status(200).send();
}));
// ============================================================================
// STATUS & REPORTING
// ============================================================================
/**
 * GET /api/ecommerce/status
 * Get connection status overview
 */
router.get('/status', middleware_1.authenticate, (0, middleware_1.asyncHandler)(async (_req, res) => {
    const status = await EcommerceService_1.ecommerceService.getConnectionStatus();
    res.json(status);
}));
/**
 * GET /api/ecommerce/errors
 * Get sync errors
 */
router.get('/errors', middleware_1.authenticate, (0, middleware_1.asyncHandler)(async (_req, res) => {
    const errors = await EcommerceService_1.ecommerceService.getSyncErrors();
    res.json(errors);
}));
/**
 * GET /api/ecommerce/pending
 * Get pending syncs
 */
router.get('/pending', middleware_1.authenticate, (0, middleware_1.asyncHandler)(async (_req, res) => {
    const pending = await EcommerceService_1.ecommerceService.getPendingSyncs();
    res.json(pending);
}));
/**
 * GET /api/ecommerce/connections/:connectionId/logs
 * Get sync logs for a connection
 */
router.get('/connections/:connectionId/logs', middleware_1.authenticate, (0, middleware_1.asyncHandler)(async (req, res) => {
    const { connectionId } = req.params;
    const limit = parseInt(req.query.limit) || 50;
    const logs = await EcommerceService_1.ecommerceService.getSyncLogs(connectionId, limit);
    res.json(logs);
}));
/**
 * GET /api/ecommerce/connections/:connectionId/settings
 * Get platform-specific settings
 */
router.get('/connections/:connectionId/settings', middleware_1.authenticate, (0, middleware_1.asyncHandler)(async (req, res) => {
    const { connectionId } = req.params;
    const connection = await EcommerceService_1.ecommerceService.getConnection(connectionId);
    if (!connection) {
        res.status(404).json({ error: 'Connection not found' });
        return;
    }
    const settings = await EcommerceService_1.ecommerceService.getPlatformSettings(connectionId, connection.platformType);
    res.json(settings);
}));
exports.default = router;
//# sourceMappingURL=ecommerce.js.map