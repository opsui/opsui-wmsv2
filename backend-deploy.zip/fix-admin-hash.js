"use strict";
/**
 * Fix admin password hash
 *
 * Regenerates the bcrypt hash for the default admin user
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const bcrypt_1 = __importDefault(require("bcrypt"));
const client_1 = require("./db/client");
const logger_1 = require("./config/logger");
async function fixAdminPassword() {
    try {
        logger_1.logger.info('Starting admin password fix...');
        // Generate correct bcrypt hash for 'admin123'
        const password = 'admin123';
        const rounds = 10;
        const passwordHash = await bcrypt_1.default.hash(password, rounds);
        logger_1.logger.info('Generated new hash', {
            length: passwordHash.length,
            startsWith: passwordHash.substring(0, 7),
        });
        // Update admin user in database
        const result = await (0, client_1.query)(`UPDATE users 
       SET password_hash = $1 
       WHERE email = 'admin@wms.local' 
       RETURNING user_id, email, name`, [passwordHash]);
        if (result.rows.length === 0) {
            logger_1.logger.error('Admin user not found!');
            logger_1.logger.info('Creating admin user...');
            // Create admin user if not exists
            await (0, client_1.query)(`INSERT INTO users (user_id, name, email, password_hash, role, active)
         VALUES ('USR-ADMIN01', 'System Administrator', 'admin@wms.local', $1, 'ADMIN', true)
         ON CONFLICT (email) DO UPDATE SET password_hash = $1`, [passwordHash]);
            logger_1.logger.info('Admin user created successfully');
        }
        else {
            logger_1.logger.info('Admin user updated successfully', {
                userId: result.rows[0].user_id,
                email: result.rows[0].email,
            });
        }
        // Verify the hash works
        const isValid = await bcrypt_1.default.compare(password, passwordHash);
        logger_1.logger.info('Hash verification', { isValid });
        if (!isValid) {
            throw new Error('Generated hash does not verify correctly!');
        }
        logger_1.logger.info('✅ Admin password fix completed successfully!');
        logger_1.logger.info('Login credentials:');
        logger_1.logger.info('  Email: admin@wms.local');
        logger_1.logger.info('  Password: admin123');
    }
    catch (error) {
        logger_1.logger.error('Failed to fix admin password', { error });
        throw error;
    }
}
// Run the fix
fixAdminPassword()
    .then(() => {
    logger_1.logger.info('Fix completed. Exiting...');
    process.exit(0);
})
    .catch(error => {
    logger_1.logger.error('Fix failed. Exiting...', { error });
    process.exit(1);
});
//# sourceMappingURL=fix-admin-hash.js.map