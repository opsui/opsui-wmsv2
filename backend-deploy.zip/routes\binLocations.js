"use strict";
/**
 * Bin Location routes
 *
 * Endpoints for managing warehouse bin locations
 */
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const BinLocationService_1 = require("../services/BinLocationService");
const middleware_1 = require("../middleware");
const shared_1 = require("@opsui/shared");
const router = (0, express_1.Router)();
// All bin location routes require authentication
router.use(middleware_1.authenticate);
// ============================================================================
// BIN LOCATION CRUD ROUTES
// ============================================================================
/**
 * POST /api/bin-locations
 * Create a new bin location
 */
router.post('/', (0, middleware_1.authorize)(shared_1.UserRole.STOCK_CONTROLLER, shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { binId, zone, aisle, shelf, type } = req.body;
    // Validate required fields
    if (!binId || !zone || !aisle || !shelf || !type) {
        res.status(400).json({
            error: 'Missing required fields: binId, zone, aisle, shelf, type',
            code: 'MISSING_FIELDS',
        });
        return;
    }
    // Validate type
    if (!Object.values(shared_1.BinType).includes(type)) {
        res.status(400).json({
            error: `Invalid type. Must be one of: ${Object.values(shared_1.BinType).join(', ')}`,
            code: 'INVALID_TYPE',
        });
        return;
    }
    const location = await BinLocationService_1.binLocationService.createBinLocation({
        binId,
        zone,
        aisle,
        shelf,
        type,
    });
    res.status(201).json(location);
}));
/**
 * POST /api/bin-locations/batch
 * Batch create bin locations
 */
router.post('/batch', (0, middleware_1.authorize)(shared_1.UserRole.STOCK_CONTROLLER, shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { locations } = req.body;
    if (!Array.isArray(locations) || locations.length === 0) {
        res.status(400).json({
            error: 'locations must be a non-empty array',
            code: 'INVALID_INPUT',
        });
        return;
    }
    // Validate each location
    for (const loc of locations) {
        if (!loc.binId || !loc.zone || !loc.aisle || !loc.shelf || !loc.type) {
            res.status(400).json({
                error: 'Each location must have binId, zone, aisle, shelf, and type',
                code: 'MISSING_FIELDS',
            });
            return;
        }
        if (!Object.values(shared_1.BinType).includes(loc.type)) {
            res.status(400).json({
                error: `Invalid type. Must be one of: ${Object.values(shared_1.BinType).join(', ')}`,
                code: 'INVALID_TYPE',
            });
            return;
        }
    }
    const result = await BinLocationService_1.binLocationService.batchCreateBinLocations(locations);
    res.status(201).json({
        created: result.created,
        failed: result.failed,
        summary: {
            total: locations.length,
            createdCount: result.created.length,
            failedCount: result.failed.length,
        },
    });
}));
/**
 * GET /api/bin-locations
 * Get all bin locations with optional filters
 */
router.get('/', (0, middleware_1.asyncHandler)(async (req, res) => {
    const filters = {
        zone: req.query.zone,
        type: req.query.type,
        active: req.query.active === 'true' ? true : req.query.active === 'false' ? false : undefined,
        limit: req.query.limit ? parseInt(req.query.limit) : 100,
        offset: req.query.offset ? parseInt(req.query.offset) : 0,
    };
    const result = await BinLocationService_1.binLocationService.getAllBinLocations(filters);
    res.json(result);
}));
/**
 * GET /api/bin-locations/zones
 * Get all available zones
 */
router.get('/zones', (0, middleware_1.asyncHandler)(async (_req, res) => {
    const zones = await BinLocationService_1.binLocationService.getZones();
    res.json({ zones });
}));
/**
 * GET /api/bin-locations/by-zone/:zone
 * Get all bin locations for a specific zone
 */
router.get('/by-zone/:zone', (0, middleware_1.asyncHandler)(async (req, res) => {
    const { zone } = req.params;
    const locations = await BinLocationService_1.binLocationService.getBinLocationsByZone(zone);
    res.json(locations);
}));
/**
 * GET /api/bin-locations/:binId
 * Get a specific bin location by ID
 */
router.get('/:binId', (0, middleware_1.asyncHandler)(async (req, res) => {
    const { binId } = req.params;
    const location = await BinLocationService_1.binLocationService.getBinLocation(binId);
    res.json(location);
}));
/**
 * PATCH /api/bin-locations/:binId
 * Update a bin location
 */
router.patch('/:binId', (0, middleware_1.authorize)(shared_1.UserRole.STOCK_CONTROLLER, shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { binId } = req.params;
    const updates = req.body;
    // Validate type if provided
    if (updates.type !== undefined && !Object.values(shared_1.BinType).includes(updates.type)) {
        res.status(400).json({
            error: `Invalid type. Must be one of: ${Object.values(shared_1.BinType).join(', ')}`,
            code: 'INVALID_TYPE',
        });
        return;
    }
    const location = await BinLocationService_1.binLocationService.updateBinLocation(binId, updates);
    res.json(location);
}));
/**
 * DELETE /api/bin-locations/:binId
 * Delete a bin location
 */
router.delete('/:binId', (0, middleware_1.authorize)(shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { binId } = req.params;
    await BinLocationService_1.binLocationService.deleteBinLocation(binId);
    res.status(204).send();
}));
exports.default = router;
//# sourceMappingURL=binLocations.js.map