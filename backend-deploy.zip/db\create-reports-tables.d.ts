/**
 * Create reports tables
 */
export {};
//# sourceMappingURL=create-reports-tables.d.ts.map