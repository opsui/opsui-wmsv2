"use strict";
/**
 * Cycle Count routes
 *
 * Endpoints for managing cycle counts and inventory adjustments
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const CycleCountService_1 = require("../services/CycleCountService");
const middleware_1 = require("../middleware");
const permissions_1 = require("../middleware/permissions");
const shared_1 = require("@opsui/shared");
const router = (0, express_1.Router)();
// All cycle count routes require authentication
router.use(middleware_1.authenticate);
// ============================================================================
// CYCLE COUNT PLAN ROUTES
// ============================================================================
/**
 * POST /api/cycle-count/plans
 * Create a new cycle count plan
 */
router.post('/plans', (0, middleware_1.authorize)(shared_1.UserRole.STOCK_CONTROLLER, shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { planName, countType, scheduledDate, location, sku, countBy, notes } = req.body;
    // Validate required fields
    if (!planName || !countType || !scheduledDate || !countBy) {
        res.status(400).json({
            error: 'Missing required fields',
            code: 'MISSING_FIELDS',
        });
        return;
    }
    const plan = await CycleCountService_1.cycleCountService.createCycleCountPlan({
        planName,
        countType,
        scheduledDate: new Date(scheduledDate),
        location,
        sku,
        countBy,
        createdBy: req.user.userId,
        notes,
    });
    res.status(201).json(plan);
}));
/**
 * GET /api/cycle-count/plans
 * Get all cycle count plans with optional filters
 * All authenticated users can view, but are filtered based on role:
 * - Pickers/Packers: Only see their assigned counts
 * - Stock Controllers: See their assigned counts
 * - Supervisors/Admins: See all counts
 */
router.get('/plans', (0, middleware_1.asyncHandler)(async (req, res) => {
    const filters = {
        status: req.query.status,
        countType: req.query.countType,
        location: req.query.location,
        countBy: req.query.countBy,
        limit: req.query.limit ? parseInt(req.query.limit) : 50,
        offset: req.query.offset ? parseInt(req.query.offset) : 0,
        requestingUserRole: req.user.role,
        requestingUserId: req.user.userId,
    };
    const result = await CycleCountService_1.cycleCountService.getAllCycleCountPlans(filters);
    res.json(result);
}));
/**
 * GET /api/cycle-count/plans/:planId
 * Get a specific cycle count plan by ID
 */
router.get('/plans/:planId', (0, middleware_1.asyncHandler)(async (req, res) => {
    const { planId } = req.params;
    const plan = await CycleCountService_1.cycleCountService.getCycleCountPlan(planId);
    res.json(plan);
}));
/**
 * POST /api/cycle-count/plans/:planId/start
 * Start a cycle count plan
 */
router.post('/plans/:planId/start', (0, middleware_1.authorize)(shared_1.UserRole.STOCK_CONTROLLER, shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { planId } = req.params;
    const plan = await CycleCountService_1.cycleCountService.startCycleCountPlan(planId);
    res.json(plan);
}));
/**
 * POST /api/cycle-count/plans/:planId/complete
 * Complete a cycle count plan
 */
router.post('/plans/:planId/complete', (0, middleware_1.authorize)(shared_1.UserRole.STOCK_CONTROLLER, shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { planId } = req.params;
    const plan = await CycleCountService_1.cycleCountService.completeCycleCountPlan(planId);
    res.json(plan);
}));
/**
 * POST /api/cycle-count/plans/:planId/reconcile
 * Reconcile a cycle count plan (approve all variances)
 * Requires APPROVE_CYCLE_COUNTS permission
 */
router.post('/plans/:planId/reconcile', (0, permissions_1.requirePermission)(shared_1.Permission.APPROVE_CYCLE_COUNTS), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { planId } = req.params;
    const { notes } = req.body;
    const plan = await CycleCountService_1.cycleCountService.reconcileCycleCountPlan({
        planId,
        reconciledBy: req.user.userId,
        notes,
    });
    res.json(plan);
}));
// ============================================================================
// CYCLE COUNT ENTRY ROUTES
// ============================================================================
/**
 * POST /api/cycle-count/entries
 * Create a cycle count entry (record counted quantity)
 * Requires PERFORM_CYCLE_COUNTS permission
 */
router.post('/entries', (0, permissions_1.requirePermission)(shared_1.Permission.PERFORM_CYCLE_COUNTS), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { planId, sku, binLocation, countedQuantity, notes } = req.body;
    // Validate required fields
    if (!planId || !sku || !binLocation || countedQuantity === undefined) {
        res.status(400).json({
            error: 'Missing required fields',
            code: 'MISSING_FIELDS',
        });
        return;
    }
    const entry = await CycleCountService_1.cycleCountService.createCycleCountEntry({
        planId,
        sku,
        binLocation,
        countedQuantity: parseFloat(countedQuantity),
        countedBy: req.user.userId,
        notes,
    });
    res.status(201).json(entry);
}));
/**
 * PATCH /api/cycle-count/entries/:entryId/variance
 * Update variance status (approve/reject)
 * Requires APPROVE_CYCLE_COUNTS permission
 */
router.patch('/entries/:entryId/variance', (0, permissions_1.requirePermission)(shared_1.Permission.APPROVE_CYCLE_COUNTS), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { entryId } = req.params;
    const { status, notes } = req.body;
    if (!status) {
        res.status(400).json({
            error: 'Status is required',
            code: 'MISSING_STATUS',
        });
        return;
    }
    const entry = await CycleCountService_1.cycleCountService.updateVarianceStatus({
        entryId,
        status,
        reviewedBy: req.user.userId,
        notes,
    });
    res.json(entry);
}));
/**
 * POST /api/cycle-count/plans/:planId/bulk-variance-update
 * Bulk update variance status (approve/reject all pending variances)
 * Requires APPROVE_CYCLE_COUNTS permission
 */
router.post('/plans/:planId/bulk-variance-update', (0, permissions_1.requirePermission)(shared_1.Permission.APPROVE_CYCLE_COUNTS), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { planId } = req.params;
    const { status, notes, autoApproveZeroVariance = false } = req.body;
    if (!status || !['APPROVED', 'REJECTED'].includes(status)) {
        res.status(400).json({
            error: 'Status must be APPROVED or REJECTED',
            code: 'INVALID_STATUS',
        });
        return;
    }
    const result = await CycleCountService_1.cycleCountService.bulkUpdateVarianceStatus({
        planId,
        status,
        reviewedBy: req.user.userId,
        notes,
        autoApproveZeroVariance,
    });
    res.json(result);
}));
/**
 * GET /api/cycle-count/plans/:planId/reconcile-summary
 * Get summary of inventory adjustments before reconciling
 */
router.get('/plans/:planId/reconcile-summary', (0, middleware_1.authorize)(shared_1.UserRole.STOCK_CONTROLLER, shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { planId } = req.params;
    const summary = await CycleCountService_1.cycleCountService.getReconcileSummary(planId);
    res.json(summary);
}));
/**
 * POST /api/cycle-count/plans/:planId/cancel
 * Cancel a cycle count plan (only SCHEDULED or IN_PROGRESS)
 */
router.post('/plans/:planId/cancel', (0, middleware_1.authorize)(shared_1.UserRole.STOCK_CONTROLLER, shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { planId } = req.params;
    const { reason } = req.body;
    const plan = await CycleCountService_1.cycleCountService.cancelCycleCountPlan({
        planId,
        cancelledBy: req.user.userId,
        reason,
    });
    res.json(plan);
}));
/**
 * GET /api/cycle-count/plans/:planId/check-collisions
 * Check for potential collisions with other active counts in same location
 */
router.get('/plans/:planId/check-collisions', (0, middleware_1.asyncHandler)(async (req, res) => {
    const { planId } = req.params;
    const collisions = await CycleCountService_1.cycleCountService.checkForCollisions(planId);
    res.json(collisions);
}));
/**
 * GET /api/cycle-count/plans/:planId/export
 * Export cycle count data as CSV
 */
router.get('/plans/:planId/export', (0, middleware_1.authorize)(shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { planId } = req.params;
    const csvData = await CycleCountService_1.cycleCountService.exportCycleCountData(planId);
    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', `attachment; filename="cycle-count-${planId}.csv"`);
    res.send(csvData);
}));
/**
 * GET /api/cycle-count/plans/:planId/audit-log
 * Get audit log for a cycle count plan
 */
router.get('/plans/:planId/audit-log', (0, middleware_1.authorize)(shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { planId } = req.params;
    const auditLog = await CycleCountService_1.cycleCountService.getCycleCountAuditLog(planId);
    res.json(auditLog);
}));
// ============================================================================
// TOLERANCE ROUTES
// ============================================================================
/**
 * GET /api/cycle-count/tolerances
 * Get all tolerance rules
 */
router.get('/tolerances', (0, middleware_1.authorize)(shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (_req, res) => {
    const tolerances = await CycleCountService_1.cycleCountService.getAllTolerances();
    res.json(tolerances);
}));
/**
 * GET /api/cycle-count/debug-permissions
 * TEMPORARY: Debug endpoint to check user permissions
 */
router.get('/debug-permissions', (0, middleware_1.asyncHandler)(async (req, res) => {
    try {
        console.log('[debug-permissions] Request received, req.user:', req.user);
        if (!req.user) {
            console.log('[debug-permissions] No user found in request');
            res.status(401).json({
                error: 'Not authenticated',
                code: 'NOT_AUTHENTICATED',
            });
            return;
        }
        const { customRoleRepository } = await Promise.resolve().then(() => __importStar(require('../repositories/CustomRoleRepository')));
        const { DEFAULT_ROLE_PERMISSIONS, Permission } = await Promise.resolve().then(() => __importStar(require('@opsui/shared')));
        console.log('[debug-permissions] Getting permissions for user:', req.user.userId, 'role:', req.user.role);
        const user = req.user;
        const userRoleKey = user.role;
        const defaultPerms = DEFAULT_ROLE_PERMISSIONS[userRoleKey] || [];
        console.log('[debug-permissions] Default permissions for role', user.role, ':', defaultPerms.length);
        const userPerms = await customRoleRepository.getUserPermissions(user.userId, user.role);
        console.log('[debug-permissions] User permissions:', userPerms.length);
        const debugInfo = {
            userId: user.userId,
            role: user.role,
            baseRole: user.baseRole,
            effectiveRole: user.effectiveRole,
            availableRoles: Object.keys(DEFAULT_ROLE_PERMISSIONS),
            defaultPermissions: defaultPerms,
            userPermissions: userPerms,
            hasPerformCycleCounts: userPerms.includes(Permission.PERFORM_CYCLE_COUNTS),
            hasAdminFullAccess: userPerms.includes(Permission.ADMIN_FULL_ACCESS),
        };
        console.log('[debug-permissions] Debug info:', JSON.stringify(debugInfo, null, 2));
        res.json(debugInfo);
    }
    catch (error) {
        console.error('[debug-permissions] Error:', error);
        res.status(500).json({
            error: error.message,
            stack: error.stack,
        });
    }
}));
exports.default = router;
//# sourceMappingURL=cycleCount.js.map