/**
 * Authentication and authorization middleware
 *
 * Handles JWT validation and role-based access control
 */
import { UserRole } from '@opsui/shared';
import { NextFunction, Request, Response } from 'express';
export interface JWTPayload {
    userId: string;
    email: string;
    role: UserRole;
    baseRole: UserRole;
    activeRole?: UserRole | null;
    effectiveRole: UserRole;
    organizationId?: string | null;
    organizationRole?: string | null;
    iat?: number;
    exp?: number;
}
/**
 * Compact JWT payload for optimized token size (~40% smaller)
 * Uses shortened field names to reduce token payload
 */
export interface CompactJWTPayload {
    uid: string;
    eml: string;
    r: UserRole;
    ar?: UserRole | null;
    oid?: string | null;
    or?: string | null;
    iat?: number;
    exp?: number;
}
export interface AuthenticatedRequest extends Request {
    id?: string;
    user?: JWTPayload;
    organizationId?: string | null;
}
/**
 * Verify JWT token and attach user to request
 * Supports active role switching for multi-role users
 * TEST MODE: When config.testMode is true, requires special test API key
 */
export declare function authenticate(req: AuthenticatedRequest, _res: Response, next: NextFunction): void;
/**
 * Check if user has required role
 * ADMIN base role always has access regardless of effective role
 */
export declare function authorize(...allowedRoles: UserRole[]): (req: AuthenticatedRequest, _res: Response, next: NextFunction) => void;
/**
 * Check if user is admin
 * ADMIN base role always has access regardless of effective role
 */
export declare function requireAdmin(req: AuthenticatedRequest, _res: Response, next: NextFunction): void;
/**
 * Check if user is supervisor or admin
 */
export declare function requireSupervisor(req: AuthenticatedRequest, _res: Response, next: NextFunction): void;
/**
 * Check if user is a picker
 */
export declare function requirePicker(req: AuthenticatedRequest, _res: Response, next: NextFunction): void;
/**
 * Generate JWT token for user (compact format)
 * Uses shortened field names for ~40% smaller token size
 */
export declare function generateToken(user: {
    userId: string;
    email: string;
    role: UserRole;
    activeRole?: UserRole | null;
}): string;
/**
 * Generate refresh token (longer-lived, compact format)
 */
export declare function generateRefreshToken(user: {
    userId: string;
    email: string;
    role: UserRole;
    activeRole?: UserRole | null;
}): string;
/**
 * Verify and decode JWT token
 * Handles both compact (new) and legacy (old) token formats
 */
export declare function verifyToken(token: string): JWTPayload;
//# sourceMappingURL=auth.d.ts.map