/**
 * Migration 050: Create RMA (Return Merchandise Authorization) Tables
 *
 * Creates tables for managing customer returns, warranty claims, and refurbishments
 */
import { PoolClient } from 'pg';
export declare function up(pgClient: PoolClient): Promise<void>;
export declare function down(pgClient: PoolClient): Promise<void>;
export declare const description = "Create RMA (Return Merchandise Authorization) tables";
export declare const version = 50;
//# sourceMappingURL=050_create_rma_tables.d.ts.map