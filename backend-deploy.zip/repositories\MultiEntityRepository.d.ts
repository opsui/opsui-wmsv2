/**
 * Multi-Entity Repository
 *
 * Data access layer for multi-company, multi-subsidiary ERP operations
 * Handles entities, inter-company transactions, consolidation rules, and entity user assignments
 */
import { BaseRepository } from './BaseRepository';
import type { Entity, EntityWithParent, IntercompanyTransaction, IntercompanyTransactionWithDetails, EntityRelationship, EntityRelationshipWithDetails, EntitySetting, EntityUser, EntityUserWithDetails, ConsolidationRule, ConsolidationRuleWithDetails, EntityExchangeRate, EntityAuditLog, EntityHierarchyNode, EntityQueryFilters, IntercompanyTransactionQueryFilters } from '@opsui/shared';
export declare class EntityRepository extends BaseRepository<Entity> {
    constructor();
    findByCode(code: string): Promise<Entity | null>;
    findByIdWithParent(entityId: string): Promise<EntityWithParent | null>;
    findByIdWithHierarchy(entityId: string): Promise<EntityWithParent | null>;
    findChildren(parentId: string): Promise<Entity[]>;
    findSubsidiaries(entityId: string, includeChildren?: boolean): Promise<Entity[]>;
    getHierarchyTree(rootEntityId?: string): Promise<EntityHierarchyNode[]>;
    queryWithFilters(filters?: EntityQueryFilters): Promise<Entity[]>;
    softDelete(entityId: string): Promise<boolean>;
}
export declare class IntercompanyTransactionRepository extends BaseRepository<IntercompanyTransaction> {
    constructor();
    findByNumber(transactionNumber: string): Promise<IntercompanyTransaction | null>;
    findByIdWithDetails(transactionId: string): Promise<IntercompanyTransactionWithDetails | null>;
    queryWithFilters(filters?: IntercompanyTransactionQueryFilters): Promise<IntercompanyTransaction[]>;
    findPending(entityId?: string): Promise<IntercompanyTransaction[]>;
    updateStatus(transactionId: string, status: string, approvedBy?: string): Promise<boolean>;
}
export declare class EntityRelationshipRepository extends BaseRepository<EntityRelationship> {
    constructor();
    findByEntities(entityId: string, relatedEntityId: string): Promise<EntityRelationship | null>;
    findByIdWithDetails(relationshipId: string): Promise<EntityRelationshipWithDetails | null>;
    findByEntityId(entityId: string): Promise<EntityRelationship[]>;
    findActive(entityId?: string): Promise<EntityRelationship[]>;
}
export declare class EntitySettingsRepository extends BaseRepository<EntitySetting> {
    constructor();
    findByEntityAndKey(entityId: string, key: string): Promise<EntitySetting | null>;
    findByEntityId(entityId: string): Promise<EntitySetting[]>;
    getValue(entityId: string, key: string, defaultValue?: string): Promise<string | null>;
    upsertSetting(entityId: string, key: string, value: string, type?: 'STRING' | 'NUMBER' | 'BOOLEAN' | 'JSON', updatedBy?: string): Promise<EntitySetting>;
    getSettingsMap(entityId: string): Promise<Record<string, string>>;
}
export declare class EntityUsersRepository extends BaseRepository<EntityUser> {
    constructor();
    findByEntityAndUser(entityId: string, userId: string): Promise<EntityUser | null>;
    findByIdWithDetails(entityUserId: string): Promise<EntityUserWithDetails | null>;
    findByUserId(userId: string): Promise<EntityUser[]>;
    findByEntityId(entityId: string): Promise<EntityUser[]>;
    getUserDefaultEntity(userId: string): Promise<Entity | null>;
    setDefaultEntity(userId: string, entityId: string): Promise<boolean>;
    hasPermission(userId: string, entityId: string, permission: string): Promise<boolean>;
}
export declare class ConsolidationRuleRepository extends BaseRepository<ConsolidationRule> {
    constructor();
    findByParentAndSubsidiary(parentId: string, subsidiaryId: string): Promise<ConsolidationRule | null>;
    findByIdWithDetails(ruleId: string): Promise<ConsolidationRuleWithDetails | null>;
    findByParentId(parentId: string): Promise<ConsolidationRule[]>;
    findBySubsidiaryId(subsidiaryId: string): Promise<ConsolidationRule[]>;
    findActive(parentId?: string): Promise<ConsolidationRule[]>;
}
export declare class EntityExchangeRateRepository extends BaseRepository<EntityExchangeRate> {
    constructor();
    findByEntityAndCurrenciesAndDate(entityId: string, fromCurrency: string, toCurrency: string, rateDate: Date): Promise<EntityExchangeRate | null>;
    findLatestRate(entityId: string, fromCurrency: string, toCurrency: string): Promise<EntityExchangeRate | null>;
    findByEntityId(entityId: string): Promise<EntityExchangeRate[]>;
    upsertRate(entityId: string, fromCurrency: string, toCurrency: string, rateDate: Date, exchangeRate: number, createdBy: string, isOverride?: boolean): Promise<EntityExchangeRate>;
}
export declare class EntityAuditLogRepository extends BaseRepository<EntityAuditLog> {
    constructor();
    findByEntityId(entityId: string, limit?: number): Promise<EntityAuditLog[]>;
    findByAction(action: string, limit?: number): Promise<EntityAuditLog[]>;
    findByUserId(userId: string, limit?: number): Promise<EntityAuditLog[]>;
    log(entityId: string | null, action: string, oldValues: Record<string, unknown> | null, newValues: Record<string, unknown> | null, userId: string | null, ipAddress?: string, userAgent?: string, relatedEntityId?: string | null): Promise<EntityAuditLog>;
}
export declare const multiEntityRepository: {
    entities: EntityRepository;
    intercompanyTransactions: IntercompanyTransactionRepository;
    relationships: EntityRelationshipRepository;
    settings: EntitySettingsRepository;
    users: EntityUsersRepository;
    consolidation: ConsolidationRuleRepository;
    exchangeRates: EntityExchangeRateRepository;
    auditLog: EntityAuditLogRepository;
};
//# sourceMappingURL=MultiEntityRepository.d.ts.map