/**
 * @file AuthService.ts
 * @purpose Handles user authentication, token generation, and session management
 * @complexity medium (JWT tokens, bcrypt hashing, refresh token rotation)
 * @tested yes (88% coverage)
 * @last-change 2025-01-19 (added file annotation header)
 * @dependencies UserRepository, bcrypt, JWT (jsonwebtoken)
 * @domain auth
 *
 * @description
 * Authentication and authorization service with JWT access tokens and refresh tokens.
 * Implements refresh token rotation for security.
 * Passwords hashed with bcrypt (10 rounds).
 *
 * @invariants
 * - All passwords are hashed with bcrypt (never stored plaintext)
 * - Access tokens expire in 15 minutes
 * - Refresh tokens are single-use and rotated on refresh
 * - All authentication failures are logged
 *
 * @performance
 * - Bcrypt hashing: ~250ms per password (intentionally slow for security)
 * - JWT generation: ~5ms
 * - Token validation: ~10ms
 *
 * @security
 * - Rate limiting required for login endpoint
 * - Passwords hashed with bcrypt (10 rounds)
 * - Refresh tokens stored in HTTP-only cookies
 * - All authentication attempts logged for audit
 *
 * @see {@link UserRepository} for user data access
 * @see {@link packages/backend/src/middleware/auth.ts} for JWT validation
 * @see {@link packages/backend/src/routes/auth.ts} for auth endpoints
 */
import { User, UserRole } from '@opsui/shared';
import { JWTPayload } from '../middleware/auth';
export interface LoginCredentials {
    email: string;
    password: string;
}
export interface AuthTokens {
    accessToken: string;
    refreshToken: string;
    user: Omit<User, 'passwordHash'>;
}
export interface RefreshTokenPayload extends JWTPayload {
    userId: string;
    email: string;
    role: UserRole;
}
export declare class AuthService {
    login(credentials: LoginCredentials): Promise<AuthTokens>;
    verifyToken(token: string): Promise<JWTPayload>;
    refreshToken(refreshToken: string): Promise<AuthTokens>;
    getUserById(userId: string): Promise<Omit<User, 'passwordHash'> | null>;
    setActiveRole(userId: string, activeRole: UserRole | null): Promise<User>;
    getActiveRole(userId: string): Promise<UserRole>;
    logout(userId: string, tokenId?: string, expiresAt?: number): Promise<void>;
    changePassword(userId: string, currentPassword: string, newPassword: string): Promise<void>;
    updateCurrentView(userId: string, view: string): Promise<void>;
    setIdle(userId: string): Promise<void>;
    validatePasswordStrength(password: string): {
        valid: boolean;
        errors: string[];
    };
    hashPassword(password: string): Promise<string>;
    comparePassword(password: string, hash: string): Promise<boolean>;
}
export declare const authService: AuthService;
//# sourceMappingURL=AuthService.d.ts.map