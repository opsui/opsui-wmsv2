"use strict";
/**
 * Metrics and dashboard routes
 */
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const MetricsService_1 = require("../services/MetricsService");
const middleware_1 = require("../middleware");
const shared_1 = require("@opsui/shared");
const router = (0, express_1.Router)();
// All metrics routes require authentication
router.use(middleware_1.authenticate);
/**
 * GET /api/metrics/dashboard
 * Get dashboard metrics
 */
router.get('/dashboard', (0, middleware_1.authorize)(shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (_req, res) => {
    const metrics = await MetricsService_1.metricsService.getDashboardMetrics();
    res.json(metrics);
}));
/**
 * GET /api/metrics/picker/:pickerId
 * Get performance metrics for a specific picker
 */
router.get('/picker/:pickerId', (0, middleware_1.authorize)(shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (req, res) => {
    const pickerId = req.params.pickerId;
    // Default to last 7 days
    const endDate = new Date();
    const startDate = new Date(endDate.getTime() - 7 * 24 * 60 * 60 * 1000);
    // Allow custom date range
    if (req.query.startDate) {
        startDate.setTime(new Date(req.query.startDate).getTime());
    }
    if (req.query.endDate) {
        endDate.setTime(new Date(req.query.endDate).getTime());
    }
    const performance = await MetricsService_1.metricsService.getPickerPerformance(pickerId, startDate, endDate);
    res.json(performance);
}));
/**
 * GET /api/metrics/pickers
 * Get performance metrics for all pickers
 */
router.get('/pickers', (0, middleware_1.authorize)(shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (req, res) => {
    console.log('[MetricsRoute] /pickers query params:', req.query);
    const endDate = new Date();
    const startDate = new Date(endDate.getTime() - 7 * 24 * 60 * 60 * 1000);
    if (req.query.startDate) {
        const parsedStart = new Date(req.query.startDate);
        if (!isNaN(parsedStart.getTime())) {
            startDate.setTime(parsedStart.getTime());
        }
    }
    if (req.query.endDate) {
        const parsedEnd = new Date(req.query.endDate);
        if (!isNaN(parsedEnd.getTime())) {
            endDate.setTime(parsedEnd.getTime());
        }
    }
    console.log('[MetricsRoute] Fetching picker performance from', startDate.toISOString(), 'to', endDate.toISOString());
    const performance = await MetricsService_1.metricsService.getAllPickersPerformance(startDate, endDate);
    console.log('[MetricsRoute] Picker performance result:', performance?.length || 0, 'pickers');
    res.json(performance);
}));
/**
 * GET /api/metrics/packers
 * Get performance metrics for all packers
 */
router.get('/packers', (0, middleware_1.authorize)(shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (req, res) => {
    const endDate = new Date();
    const startDate = new Date(endDate.getTime() - 7 * 24 * 60 * 60 * 1000);
    if (req.query.startDate) {
        const parsedStart = new Date(req.query.startDate);
        if (!isNaN(parsedStart.getTime())) {
            startDate.setTime(parsedStart.getTime());
        }
    }
    if (req.query.endDate) {
        const parsedEnd = new Date(req.query.endDate);
        if (!isNaN(parsedEnd.getTime())) {
            endDate.setTime(parsedEnd.getTime());
        }
    }
    const performance = await MetricsService_1.metricsService.getAllPackersPerformance(startDate, endDate);
    res.json(performance);
}));
/**
 * GET /api/metrics/stock-controllers
 * Get performance metrics for all stock controllers
 */
router.get('/stock-controllers', (0, middleware_1.authorize)(shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (req, res) => {
    const endDate = new Date();
    const startDate = new Date(endDate.getTime() - 7 * 24 * 60 * 60 * 1000);
    if (req.query.startDate) {
        const parsedStart = new Date(req.query.startDate);
        if (!isNaN(parsedStart.getTime())) {
            startDate.setTime(parsedStart.getTime());
        }
    }
    if (req.query.endDate) {
        const parsedEnd = new Date(req.query.endDate);
        if (!isNaN(parsedEnd.getTime())) {
            endDate.setTime(parsedEnd.getTime());
        }
    }
    const performance = await MetricsService_1.metricsService.getAllStockControllersPerformance(startDate, endDate);
    res.json(performance);
}));
/**
 * GET /api/metrics/orders/status-breakdown
 * Get order status breakdown
 */
router.get('/orders/status-breakdown', (0, middleware_1.authorize)(shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (_req, res) => {
    const breakdown = await MetricsService_1.metricsService.getOrderStatusBreakdown();
    res.json(breakdown);
}));
/**
 * GET /api/metrics/orders/hourly-throughput
 * Get hourly throughput for the last 24 hours
 */
router.get('/orders/hourly-throughput', (0, middleware_1.authorize)(shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (_req, res) => {
    const throughput = await MetricsService_1.metricsService.getHourlyThroughput();
    res.json(throughput);
}));
/**
 * GET /api/metrics/orders/throughput
 * Get throughput by time range
 * Query params: range (daily|weekly|monthly|quarterly|yearly)
 */
router.get('/orders/throughput', (0, middleware_1.authorize)(shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (req, res) => {
    const range = req.query.range || 'daily';
    // Validate range
    const validRanges = ['daily', 'weekly', 'monthly', 'quarterly', 'yearly'];
    if (!validRanges.includes(range)) {
        res.status(400).json({ error: 'Invalid range. Must be one of: ' + validRanges.join(', ') });
        return;
    }
    const throughput = await MetricsService_1.metricsService.getThroughputByRange(range);
    res.json(throughput);
}));
/**
 * GET /api/metrics/skus/top-picked
 * Get top SKUs by scan type (pick, pack, verify, all)
 * Query params: limit, scanType, timePeriod
 */
router.get('/skus/top-picked', (0, middleware_1.authorize)(shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (req, res) => {
    const limit = req.query.limit ? parseInt(req.query.limit) : 10;
    const scanType = req.query.scanType || 'pick';
    const timePeriod = req.query.timePeriod || 'monthly';
    // Validate scanType
    const validScanTypes = ['pick', 'pack', 'verify', 'all'];
    if (!validScanTypes.includes(scanType)) {
        res
            .status(400)
            .json({ error: 'Invalid scanType. Must be one of: ' + validScanTypes.join(', ') });
        return;
    }
    // Validate timePeriod
    const validTimePeriods = ['daily', 'weekly', 'monthly', 'yearly'];
    if (!validTimePeriods.includes(timePeriod)) {
        res
            .status(400)
            .json({ error: 'Invalid timePeriod. Must be one of: ' + validTimePeriods.join(', ') });
        return;
    }
    const topSKUs = await MetricsService_1.metricsService.getTopSKUsByScanType(scanType, limit, timePeriod);
    res.json(topSKUs);
}));
/**
 * GET /api/metrics/picker-activity
 * Get real-time picker activity
 */
router.get('/picker-activity', (0, middleware_1.authorize)(shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (_req, res) => {
    console.log('[MetricsRoute] Calling getPickerActivity');
    const activity = await MetricsService_1.metricsService.getPickerActivity();
    console.log('[MetricsRoute] Activity count:', activity?.length || 0);
    if (activity && activity.length > 0) {
        console.log('[MetricsRoute] First picker:', JSON.stringify(activity[0], null, 2));
    }
    res.json(activity);
}));
/**
 * GET /api/metrics/picker/:pickerId/orders
 * Get all orders with progress for a specific picker
 */
router.get('/picker/:pickerId/orders', (0, middleware_1.authorize)(shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (req, res) => {
    const pickerId = req.params.pickerId;
    const orders = await MetricsService_1.metricsService.getPickerOrders(pickerId);
    res.json(orders);
}));
/**
 * GET /api/metrics/packer-activity
 * Get real-time packer activity
 */
router.get('/packer-activity', (0, middleware_1.authorize)(shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (_req, res) => {
    console.log('[MetricsRoute] Calling getPackerActivity');
    const activity = await MetricsService_1.metricsService.getPackerActivity();
    console.log('[MetricsRoute] Packer activity count:', activity?.length || 0);
    if (activity && activity.length > 0) {
        console.log('[MetricsRoute] First packer:', JSON.stringify(activity[0], null, 2));
    }
    res.json(activity);
}));
/**
 * GET /api/metrics/packer/:packerId/orders
 * Get all orders with progress for a specific packer
 */
router.get('/packer/:packerId/orders', (0, middleware_1.authorize)(shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (req, res) => {
    const packerId = req.params.packerId;
    const orders = await MetricsService_1.metricsService.getPackerOrders(packerId);
    res.json(orders);
}));
/**
 * GET /api/metrics/stock-controller-activity
 * Get real-time stock controller activity
 */
router.get('/stock-controller-activity', (0, middleware_1.authorize)(shared_1.UserRole.STOCK_CONTROLLER, shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (_req, res) => {
    console.log('[MetricsRoute] Calling getStockControllerActivity');
    const activity = await MetricsService_1.metricsService.getStockControllerActivity();
    console.log('[MetricsRoute] Stock controller activity count:', activity?.length || 0);
    if (activity && activity.length > 0) {
        console.log('[MetricsRoute] First stock controller:', JSON.stringify(activity[0], null, 2));
    }
    res.json(activity);
}));
/**
 * GET /api/metrics/stock-controller/:controllerId/transactions
 * Get transaction history for a specific stock controller
 */
router.get('/stock-controller/:controllerId/transactions', (0, middleware_1.authorize)(shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (req, res) => {
    const controllerId = req.params.controllerId;
    const limit = req.query.limit ? parseInt(req.query.limit) : 50;
    const transactions = await MetricsService_1.metricsService.getStockControllerTransactions(controllerId, limit);
    res.json(transactions);
}));
/**
 * GET /api/metrics/my-performance
 * Get current user's performance metrics
 */
router.get('/my-performance', (0, middleware_1.authorize)(shared_1.UserRole.PICKER, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (req, res) => {
    if (!req.user) {
        res.status(401).json({ error: 'Not authenticated' });
        return;
    }
    const endDate = new Date();
    const startDate = new Date(endDate.getTime() - 7 * 24 * 60 * 60 * 1000);
    if (req.query.startDate) {
        startDate.setTime(new Date(req.query.startDate).getTime());
    }
    if (req.query.endDate) {
        endDate.setTime(new Date(req.query.endDate).getTime());
    }
    const performance = await MetricsService_1.metricsService.getPickerPerformance(req.user.userId, startDate, endDate);
    res.json(performance);
}));
exports.default = router;
//# sourceMappingURL=metrics.js.map