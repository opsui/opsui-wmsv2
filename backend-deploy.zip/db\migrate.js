"use strict";
/**
 * Database migration runner
 *
 * Reads and executes the schema.sql file to create/refresh the database schema.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.runMigrations = runMigrations;
exports.dropAllTables = dropAllTables;
exports.resetDatabase = resetDatabase;
exports.migrateCli = main;
require("dotenv/config");
const fs_1 = require("fs");
const path_1 = require("path");
const url_1 = require("url");
const client_1 = require("./client");
const logger_1 = require("../config/logger");
// ES module equivalent of __dirname
const __dirname = (0, path_1.dirname)((0, url_1.fileURLToPath)(import.meta.url));
// ============================================================================
// MIGRATION FUNCTIONS
// ============================================================================
/**
 * Run database migrations
 */
async function runMigrations() {
    try {
        logger_1.logger.info('Starting database migrations...');
        // Read schema file - check both dist and src locations
        let schemaPath = (0, path_1.join)(__dirname, 'schema.sql');
        try {
            (0, fs_1.readFileSync)(schemaPath, 'utf-8');
        }
        catch {
            // Not in dist, try src (for development)
            schemaPath = (0, path_1.join)(__dirname, '../../src/db/schema.sql');
        }
        const schema = (0, fs_1.readFileSync)(schemaPath, 'utf-8');
        // Execute schema
        await (0, client_1.query)(schema);
        logger_1.logger.info('Database migrations completed successfully');
    }
    catch (error) {
        logger_1.logger.error('Database migration failed', {
            error: error instanceof Error ? error.message : String(error),
        });
        throw error;
    }
}
/**
 * Drop all tables (use with caution!)
 */
async function dropAllTables() {
    try {
        logger_1.logger.warn('Dropping all database tables...');
        await (0, client_1.query)(`
      DROP TABLE IF EXISTS
        order_state_changes CASCADE,
        inventory_transactions CASCADE,
        pick_tasks CASCADE,
        order_items CASCADE,
        orders CASCADE,
        inventory_units CASCADE,
        bin_locations CASCADE,
        skus CASCADE,
        users CASCADE;
    `);
        logger_1.logger.warn('All tables dropped successfully');
    }
    catch (error) {
        logger_1.logger.error('Failed to drop tables', {
            error: error instanceof Error ? error.message : String(error),
        });
        throw error;
    }
}
/**
 * Reset database (drop and recreate)
 */
async function resetDatabase() {
    try {
        logger_1.logger.warn('Resetting database...');
        await dropAllTables();
        await runMigrations();
        logger_1.logger.warn('Database reset completed');
    }
    catch (error) {
        logger_1.logger.error('Database reset failed', {
            error: error instanceof Error ? error.message : String(error),
        });
        throw error;
    }
}
// ============================================================================
// CLI ENTRY POINT
// ============================================================================
/**
 * Main function for running migrations from command line
 */
async function main() {
    const command = process.argv[2] || 'migrate';
    try {
        switch (command) {
            case 'migrate':
                await runMigrations();
                break;
            case 'drop':
                await dropAllTables();
                break;
            case 'reset':
                await resetDatabase();
                break;
            default:
                console.error(`Unknown command: ${command}`);
                console.error('Usage: npm run db:migrate | npm run db:drop | npm run db:reset');
                process.exit(1);
        }
        await (0, client_1.closePool)();
        process.exit(0);
    }
    catch (error) {
        logger_1.logger.error('Migration script failed', {
            error: error instanceof Error ? error.message : String(error),
        });
        await (0, client_1.closePool)();
        process.exit(1);
    }
}
// Run if called directly
if (import.meta.url === `file://${process.argv[1].replace(/\\/g, '/')}`) {
    main();
}
//# sourceMappingURL=migrate.js.map