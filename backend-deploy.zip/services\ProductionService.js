"use strict";
/**
 * Production Management Service
 *
 * Business logic for production order management and manufacturing workflows
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.productionService = exports.ProductionService = void 0;
const ProductionRepository_1 = require("../repositories/ProductionRepository");
const shared_1 = require("@opsui/shared");
class ProductionService {
    // ========================================================================
    // BILL OF MATERIALS
    // ========================================================================
    async createBOM(dto, createdBy) {
        // Validate BOM
        if (!dto.name || dto.name.trim() === '') {
            throw new Error('BOM name is required');
        }
        if (!dto.productId || dto.productId.trim() === '') {
            throw new Error('Product ID is required');
        }
        if (!dto.components || dto.components.length === 0) {
            throw new Error('BOM must have at least one component');
        }
        // Validate all SKUs exist
        // This would integrate with the SKU service
        const bom = await ProductionRepository_1.productionRepository.createBOM({
            ...dto,
            status: shared_1.BillOfMaterialStatus.DRAFT,
            version: '1.0',
            createdBy,
        });
        return bom;
    }
    async getBOMById(bomId) {
        const bom = await ProductionRepository_1.productionRepository.findBOMById(bomId);
        if (!bom) {
            throw new shared_1.NotFoundError('BOM', bomId);
        }
        return bom;
    }
    async getAllBOMs(filters) {
        return await ProductionRepository_1.productionRepository.findAllBOMs(filters);
    }
    async updateBOM(bomId, dto, userId) {
        const bom = await this.getBOMById(bomId);
        // Validate BOM updates
        if (dto.status === shared_1.BillOfMaterialStatus.ACTIVE && bom.status !== shared_1.BillOfMaterialStatus.DRAFT) {
            throw new Error('Only DRAFT BOMs can be activated');
        }
        // Handle component updates if provided
        let updateData = { ...dto, updatedBy: userId };
        delete updateData.components; // Handle separately
        const updated = await ProductionRepository_1.productionRepository.updateBOM(bomId, updateData);
        if (!updated) {
            throw new shared_1.NotFoundError('BOM', bomId);
        }
        // TODO: Update components if provided (would require separate table operations)
        return updated;
    }
    async activateBOM(bomId, userId) {
        return await this.updateBOM(bomId, { status: shared_1.BillOfMaterialStatus.ACTIVE }, userId);
    }
    async deleteBOM(bomId) {
        // Check if BOM is used by any active production orders
        // This would integrate with production order repository
        return await ProductionRepository_1.productionRepository.deleteBOM(bomId);
    }
    // ========================================================================
    // PRODUCTION ORDERS
    // ========================================================================
    async createProductionOrder(dto, createdBy) {
        // Validate production order
        if (!dto.bomId || dto.bomId.trim() === '') {
            throw new Error('BOM ID is required');
        }
        if (dto.quantityToProduce <= 0) {
            throw new Error('Quantity to produce must be greater than 0');
        }
        if (dto.scheduledStartDate >= dto.scheduledEndDate) {
            throw new Error('Scheduled end date must be after start date');
        }
        // Check if BOM exists and is active
        const bom = await ProductionRepository_1.productionRepository.findBOMById(dto.bomId);
        if (!bom) {
            throw new shared_1.NotFoundError('BOM', dto.bomId);
        }
        if (bom.status !== shared_1.BillOfMaterialStatus.ACTIVE) {
            throw new Error('BOM must be active to create production order');
        }
        // Get product name and unit of measure from BOM
        const productId = bom.productId;
        const order = await ProductionRepository_1.productionRepository.createProductionOrder({
            ...dto,
            productId,
            productName: `Product ${productId}`, // Would fetch from SKU service
            unitOfMeasure: bom.unitOfMeasure || 'EA',
            status: shared_1.ProductionOrderStatus.PLANNED,
            materialsReserved: false,
            priority: dto.priority || shared_1.ProductionOrderPriority.MEDIUM,
            createdBy,
        });
        return order;
    }
    async getProductionOrderById(orderId) {
        const order = await ProductionRepository_1.productionRepository.findProductionOrderById(orderId);
        if (!order) {
            throw new shared_1.NotFoundError('Production Order', orderId);
        }
        return order;
    }
    async getAllProductionOrders(filters) {
        return await ProductionRepository_1.productionRepository.findAllProductionOrders(filters);
    }
    async updateProductionOrder(orderId, dto, userId) {
        const order = await ProductionRepository_1.productionRepository.findProductionOrderById(orderId);
        if (!order) {
            throw new shared_1.NotFoundError('Production Order', orderId);
        }
        // Validate status transitions
        if (dto.status) {
            this.validateStatusTransition(order.status, dto.status);
        }
        const updated = await ProductionRepository_1.productionRepository.updateProductionOrder(orderId, {
            ...dto,
            updatedBy: userId,
        });
        return updated;
    }
    async releaseProductionOrder(orderId, userId) {
        const order = await this.getProductionOrderById(orderId);
        if (order.status !== 'PLANNED' && order.status !== 'DRAFT') {
            throw new Error('Only PLANNED or DRAFT orders can be released');
        }
        // Check material availability
        // This would integrate with inventory service
        const updated = await ProductionRepository_1.productionRepository.updateProductionOrder(orderId, {
            status: shared_1.ProductionOrderStatus.RELEASED,
            materialsReserved: true,
            updatedBy: userId,
        });
        return updated;
    }
    async startProductionOrder(orderId, userId) {
        const order = await this.getProductionOrderById(orderId);
        if (order.status !== 'RELEASED') {
            throw new Error('Only RELEASED orders can be started');
        }
        const updated = await ProductionRepository_1.productionRepository.updateProductionOrder(orderId, {
            status: shared_1.ProductionOrderStatus.IN_PROGRESS,
            actualStartDate: new Date(),
            updatedBy: userId,
        });
        // Log journal entry
        await ProductionRepository_1.productionRepository.createProductionJournalEntry({
            orderId,
            producedAt: new Date(),
            producedBy: userId,
            productId: order.productId,
            quantity: 0,
            notes: 'Production started',
        });
        return updated;
    }
    async recordProductionOutput(dto, userId) {
        const order = await this.getProductionOrderById(dto.orderId);
        if (order.status !== 'IN_PROGRESS') {
            throw new Error('Production order must be IN_PROGRESS to record output');
        }
        // Validate quantities
        if (dto.quantity <= 0) {
            throw new Error('Quantity must be greater than 0');
        }
        const totalCompleted = order.quantityCompleted + dto.quantity;
        const totalRejected = order.quantityRejected + (dto.quantityRejected || 0);
        if (totalCompleted + totalRejected > order.quantityToProduce) {
            throw new Error('Total output cannot exceed quantity to produce');
        }
        const output = await ProductionRepository_1.productionRepository.createProductionOutput({
            ...dto,
            productId: order.productId,
            producedAt: new Date(),
            producedBy: userId,
        });
        // Check if order is complete
        if (totalCompleted >= order.quantityToProduce) {
            await ProductionRepository_1.productionRepository.updateProductionOrder(dto.orderId, {
                status: shared_1.ProductionOrderStatus.COMPLETED,
                actualEndDate: new Date(),
                updatedBy: userId,
            });
        }
        return output;
    }
    async getProductionJournal(orderId) {
        await this.getProductionOrderById(orderId); // Validate order exists
        return await ProductionRepository_1.productionRepository.findProductionJournalEntries(orderId);
    }
    // ========================================================================
    // PRODUCTION ORDER WORKFLOW
    // ========================================================================
    async cancelProductionOrder(orderId, userId) {
        const order = await this.getProductionOrderById(orderId);
        // Can only cancel orders that are not already completed
        if (order.status === shared_1.ProductionOrderStatus.COMPLETED) {
            throw new Error('Cannot cancel a completed order');
        }
        const updated = await ProductionRepository_1.productionRepository.updateProductionOrder(orderId, {
            status: shared_1.ProductionOrderStatus.CANCELLED,
            updatedBy: userId,
        });
        // Log journal entry
        await ProductionRepository_1.productionRepository.createProductionJournalEntry({
            orderId,
            producedAt: new Date(),
            producedBy: userId,
            productId: order.productId,
            quantity: 0,
            notes: 'Order cancelled',
        });
        return updated;
    }
    async holdProductionOrder(orderId, userId) {
        const order = await this.getProductionOrderById(orderId);
        // Can only hold orders that are in progress or released
        if (order.status !== shared_1.ProductionOrderStatus.IN_PROGRESS &&
            order.status !== shared_1.ProductionOrderStatus.RELEASED) {
            throw new Error('Only IN_PROGRESS or RELEASED orders can be put on hold');
        }
        const updated = await ProductionRepository_1.productionRepository.updateProductionOrder(orderId, {
            status: shared_1.ProductionOrderStatus.ON_HOLD,
            updatedBy: userId,
        });
        // Log journal entry
        await ProductionRepository_1.productionRepository.createProductionJournalEntry({
            orderId,
            producedAt: new Date(),
            producedBy: userId,
            productId: order.productId,
            quantity: 0,
            notes: 'Order put on hold',
        });
        return updated;
    }
    async resumeProductionOrder(orderId, userId) {
        const order = await this.getProductionOrderById(orderId);
        if (order.status !== shared_1.ProductionOrderStatus.ON_HOLD) {
            throw new Error('Only ON_HOLD orders can be resumed');
        }
        const updated = await ProductionRepository_1.productionRepository.updateProductionOrder(orderId, {
            status: shared_1.ProductionOrderStatus.IN_PROGRESS,
            updatedBy: userId,
        });
        // Log journal entry
        await ProductionRepository_1.productionRepository.createProductionJournalEntry({
            orderId,
            producedAt: new Date(),
            producedBy: userId,
            productId: order.productId,
            quantity: 0,
            notes: 'Order resumed',
        });
        return updated;
    }
    // ========================================================================
    // MATERIAL MANAGEMENT
    // ========================================================================
    async issueMaterial(dto, _userId) {
        const order = await this.getProductionOrderById(dto.orderId);
        if (order.status !== shared_1.ProductionOrderStatus.RELEASED &&
            order.status !== shared_1.ProductionOrderStatus.IN_PROGRESS) {
            throw new Error('Can only issue materials for RELEASED or IN_PROGRESS orders');
        }
        // This would integrate with inventory service
        // For now, just update the component issued quantity
        // TODO: Implement inventory integration and component update
    }
    async returnMaterial(dto, _userId) {
        const order = await this.getProductionOrderById(dto.orderId);
        // Can return materials from active or completed orders
        if (order.status !== shared_1.ProductionOrderStatus.IN_PROGRESS &&
            order.status !== shared_1.ProductionOrderStatus.ON_HOLD &&
            order.status !== shared_1.ProductionOrderStatus.COMPLETED) {
            throw new Error('Can only return materials from active or completed orders');
        }
        // This would integrate with inventory service
        // TODO: Implement inventory integration
    }
    // ========================================================================
    // DASHBOARD
    // ========================================================================
    async getDashboardMetrics() {
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const tomorrow = new Date(today);
        tomorrow.setDate(tomorrow.getDate() + 1);
        const result = await ProductionRepository_1.productionRepository.findAllProductionOrders({
            limit: 1000,
        });
        const orders = result.orders;
        return {
            queued: orders.filter(o => o.status === shared_1.ProductionOrderStatus.PLANNED || o.status === 'DRAFT')
                .length,
            inProgress: orders.filter(o => o.status === shared_1.ProductionOrderStatus.IN_PROGRESS).length,
            completedToday: orders.filter(o => o.status === shared_1.ProductionOrderStatus.COMPLETED &&
                o.actualEndDate &&
                new Date(o.actualEndDate) >= today &&
                new Date(o.actualEndDate) < tomorrow).length,
            // Note: ON_HOLD status doesn't exist in the enum, counting CANCELLED as proxy
            onHold: orders.filter(o => o.status === shared_1.ProductionOrderStatus.CANCELLED).length,
        };
    }
    // ========================================================================
    // PRIVATE HELPERS
    // ========================================================================
    validateStatusTransition(currentStatus, newStatus) {
        const validTransitions = {
            DRAFT: [shared_1.ProductionOrderStatus.PLANNED, shared_1.ProductionOrderStatus.CANCELLED],
            PLANNED: [shared_1.ProductionOrderStatus.RELEASED, shared_1.ProductionOrderStatus.CANCELLED],
            RELEASED: [
                shared_1.ProductionOrderStatus.IN_PROGRESS,
                shared_1.ProductionOrderStatus.ON_HOLD,
                shared_1.ProductionOrderStatus.CANCELLED,
            ],
            IN_PROGRESS: [
                shared_1.ProductionOrderStatus.ON_HOLD,
                shared_1.ProductionOrderStatus.COMPLETED,
                shared_1.ProductionOrderStatus.CANCELLED,
            ],
            ON_HOLD: [shared_1.ProductionOrderStatus.IN_PROGRESS, shared_1.ProductionOrderStatus.CANCELLED],
            COMPLETED: [],
            CANCELLED: [],
        };
        const allowed = validTransitions[currentStatus] || [];
        if (!allowed.includes(newStatus)) {
            throw new Error(`Cannot transition from ${currentStatus} to ${newStatus}`);
        }
    }
}
exports.ProductionService = ProductionService;
// Singleton instance
exports.productionService = new ProductionService();
//# sourceMappingURL=ProductionService.js.map