/**
 * Inbound Receiving routes
 *
 * Endpoints for managing Advance Shipping Notices (ASN), receipts, and putaway tasks
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=inbound.d.ts.map