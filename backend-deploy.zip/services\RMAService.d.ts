/**
 * RMA (Return Merchandise Authorization) Service
 *
 * Business logic for handling customer returns, warranty claims, refurbishments, and exchanges
 */
import { RMARequest, CreateRMADTO, RMAInspection, RMAInspectionDTO, UpdateRMAStatusDTO, ProcessRefundDTO, SendReplacementDTO } from '@opsui/shared';
export declare class RMAService {
    createRMARequest(dto: CreateRMADTO, createdBy: string): Promise<RMARequest>;
    getRMAById(rmaId: string): Promise<RMARequest>;
    getRMAs(filters?: any): Promise<{
        requests: RMARequest[];
        total: number;
    }>;
    updateRMAStatus(rmaId: string, dto: UpdateRMAStatusDTO, userId: string): Promise<RMARequest>;
    approveRMA(rmaId: string, userId: string): Promise<RMARequest>;
    rejectRMA(rmaId: string, rejectionReason: string, userId: string): Promise<RMARequest>;
    markAsReceived(rmaId: string, userId: string): Promise<RMARequest>;
    startInspection(rmaId: string, userId: string): Promise<RMARequest>;
    createInspection(rmaId: string, dto: RMAInspectionDTO, userId: string): Promise<RMAInspection>;
    getInspections(rmaId: string): Promise<RMAInspection[]>;
    processRefund(rmaId: string, dto: ProcessRefundDTO, userId: string): Promise<RMARequest>;
    sendReplacement(rmaId: string, dto: SendReplacementDTO, userId: string): Promise<RMARequest>;
    closeRMA(rmaId: string, userId: string): Promise<RMARequest>;
    addCommunication(rmaId: string, type: 'EMAIL' | 'PHONE' | 'SMS' | 'NOTE', direction: 'INBOUND' | 'OUTBOUND', content: string, userId: string, subject?: string): Promise<void>;
    getCommunications(rmaId: string): Promise<any[]>;
    getActivityLog(rmaId: string, limit?: number): Promise<any[]>;
    getDashboard(): Promise<{
        pendingRequests: number;
        awaitingApproval: number;
        inProgress: number;
        completedToday: number;
        completedThisWeek: number;
        completedThisMonth: number;
        urgent: number;
        overdue: number;
        totalRefundValue: number;
        pendingRefundValue: number;
    }>;
    private isValidStatusTransition;
    private updateStatusTimestamps;
}
export declare const rmaService: RMAService;
//# sourceMappingURL=RMAService.d.ts.map