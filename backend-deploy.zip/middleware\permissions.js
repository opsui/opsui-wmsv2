"use strict";
/**
 * Permission-based access control middleware
 *
 * Checks if users have specific permissions based on their role(s)
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.permissionsCleanupInterval = void 0;
exports.hasPermission = hasPermission;
exports.hasAnyPermission = hasAnyPermission;
exports.hasAllPermissions = hasAllPermissions;
exports.requirePermission = requirePermission;
exports.requireAnyPermission = requireAnyPermission;
exports.requireAllPermissions = requireAllPermissions;
exports.clearUserPermissionsCache = clearUserPermissionsCache;
exports.clearAllPermissionsCache = clearAllPermissionsCache;
const shared_1 = require("@opsui/shared");
const CustomRoleRepository_1 = require("../repositories/CustomRoleRepository");
// Cache for user permissions to avoid repeated database lookups
const permissionsCache = new Map();
// const CACHE_TTL = 5 * 60 * 1000; // 5 minutes - temporarily unused due to cache bypass
/**
 * Clean up expired cache entries
 */
function cleanExpiredCacheEntries() {
    const now = Date.now();
    for (const [key, value] of permissionsCache.entries()) {
        if (value.expiresAt < now) {
            permissionsCache.delete(key);
        }
    }
}
// Run cache cleanup every minute
// Skip in test environment to prevent hanging intervals
if (process.env.NODE_ENV !== 'test') {
    setInterval(cleanExpiredCacheEntries, 60000);
}
// Export interval ID for cleanup (not used in test mode)
exports.permissionsCleanupInterval = null;
/**
 * Get all permissions for a user
 * Combines permissions from their base role and any custom roles
 */
async function getUserPermissions(userId, baseRole) {
    // TEMPORARY: Bypass cache for debugging
    // Check cache first
    // const cached = permissionsCache.get(userId);
    // if (cached && cached.expiresAt > Date.now()) {
    //   console.log('[getUserPermissions] Returning cached permissions for user:', userId);
    //   return cached.permissions;
    // }
    console.log('[getUserPermissions] Cache BYPASSED, fetching fresh permissions for user:', userId, 'role:', baseRole);
    // Get permissions from repository (combines base role and custom role permissions)
    const permissions = await CustomRoleRepository_1.customRoleRepository.getUserPermissions(userId, baseRole);
    console.log('[getUserPermissions] Fetched permissions:', permissions.length, 'for user:', userId);
    // Cache with expiration (commented out for debugging)
    // permissionsCache.set(userId, {
    //   permissions,
    //   expiresAt: Date.now() + CACHE_TTL,
    // });
    return permissions;
}
/**
 * Check if user has a specific permission
 */
function hasPermission(userPermissions, requiredPermission) {
    // Convert to strings for comparison (handles enum reference issues)
    const permissionStrings = userPermissions.map(p => String(p));
    const required = String(requiredPermission);
    // Admins have full access
    if (permissionStrings.includes('admin_full_access')) {
        console.log('[hasPermission] User has ADMIN_FULL_ACCESS, granting access');
        return true;
    }
    console.log('[hasPermission] Checking for permission:', required, 'in', permissionStrings);
    const hasPermission = permissionStrings.includes(required);
    console.log('[hasPermission] Has permission:', hasPermission);
    return hasPermission;
}
/**
 * Check if user has ANY of the specified permissions (OR logic)
 */
function hasAnyPermission(userPermissions, requiredPermissions) {
    // Admins have full access
    if (userPermissions.includes(shared_1.Permission.ADMIN_FULL_ACCESS)) {
        return true;
    }
    return requiredPermissions.some(permission => userPermissions.includes(permission));
}
/**
 * Check if user has ALL of the specified permissions (AND logic)
 */
function hasAllPermissions(userPermissions, requiredPermissions) {
    // Admins have full access
    if (userPermissions.includes(shared_1.Permission.ADMIN_FULL_ACCESS)) {
        return true;
    }
    return requiredPermissions.every(permission => userPermissions.includes(permission));
}
/**
 * Middleware factory to require a specific permission
 *
 * @example
 * router.get('/orders', requirePermission(Permission.VIEW_ORDERS), getOrdersHandler);
 */
function requirePermission(permission) {
    return async (req, _res, next) => {
        try {
            if (!req.user) {
                throw new shared_1.ForbiddenError('Authentication required');
            }
            // ADMIN base role always has full access, regardless of effective role
            if (req.user.baseRole === shared_1.UserRole.ADMIN) {
                console.log('[requirePermission] User has ADMIN base role, granting access');
                next();
                return;
            }
            console.log('[requirePermission] Checking permission:', permission, 'for user:', req.user.userId, 'role:', req.user.role, 'baseRole:', req.user.baseRole);
            const userPermissions = await getUserPermissions(req.user.userId, req.user.role);
            console.log('[requirePermission] User permissions count:', userPermissions.length);
            console.log('[requirePermission] Permissions:', userPermissions.map(p => String(p)));
            console.log('[requirePermission] Required:', String(permission));
            console.log('[requirePermission] Has ADMIN_FULL_ACCESS:', userPermissions.includes('admin_full_access'));
            console.log('[requirePermission] Has required permission:', userPermissions.includes(permission));
            if (!hasPermission(userPermissions, permission)) {
                // Include debug info in the error details
                const debugInfo = {
                    userId: req.user.userId,
                    role: req.user.role,
                    baseRole: req.user.baseRole,
                    required: String(permission),
                    userPermissions: userPermissions.map(p => String(p)),
                    hasAdminFullAccess: userPermissions.includes('admin_full_access'),
                };
                console.log('[requirePermission] Permission denied, debug info:', debugInfo);
                // Use WMSError directly to include debug details
                throw new shared_1.WMSError('FORBIDDEN', 403, `Permission required: ${permission.replace(/_/g, ' ')}`, debugInfo);
            }
            next();
        }
        catch (error) {
            next(error);
        }
    };
}
/**
 * Middleware factory to require ANY of the specified permissions (OR logic)
 *
 * @example
 * router.post('/reports', requireAnyPermission([
 *   Permission.VIEW_REPORTS,
 *   Permission.GENERATE_REPORTS
 * ]), generateReportHandler);
 */
function requireAnyPermission(permissions) {
    return async (req, _res, next) => {
        try {
            if (!req.user) {
                throw new shared_1.ForbiddenError('Authentication required');
            }
            const userPermissions = await getUserPermissions(req.user.userId, req.user.role);
            if (!hasAnyPermission(userPermissions, permissions)) {
                throw new shared_1.ForbiddenError(`One of these permissions required: ${permissions.map(p => p.replace(/_/g, ' ')).join(', ')}`);
            }
            next();
        }
        catch (error) {
            next(error);
        }
    };
}
/**
 * Middleware factory to require ALL of the specified permissions (AND logic)
 *
 * @example
 * router.post('/orders', requireAllPermissions([
 *   Permission.VIEW_ORDERS,
 *   Permission.CREATE_ORDERS
 * ]), createOrderHandler);
 */
function requireAllPermissions(permissions) {
    return async (req, _res, next) => {
        try {
            if (!req.user) {
                throw new shared_1.ForbiddenError('Authentication required');
            }
            const userPermissions = await getUserPermissions(req.user.userId, req.user.role);
            if (!hasAllPermissions(userPermissions, permissions)) {
                throw new shared_1.ForbiddenError(`All of these permissions required: ${permissions.map(p => p.replace(/_/g, ' ')).join(', ')}`);
            }
            next();
        }
        catch (error) {
            next(error);
        }
    };
}
/**
 * Clear permissions cache for a specific user
 * Call this when granting/revoking roles or changing permissions
 */
function clearUserPermissionsCache(userId) {
    permissionsCache.delete(userId);
}
/**
 * Clear entire permissions cache
 * Call this when role definitions change
 */
function clearAllPermissionsCache() {
    permissionsCache.clear();
}
//# sourceMappingURL=permissions.js.map