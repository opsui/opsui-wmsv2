/**
 * Shipping routes
 *
 * Endpoints for managing carriers, shipments, labels, and tracking
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=shipping.d.ts.map