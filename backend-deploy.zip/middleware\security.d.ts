/**
 * Security Middleware
 *
 * Provides CSRF protection, rate limiting, and other security measures
 */
import { Request, Response, NextFunction } from 'express';
/**
 * Rate limiter for authentication endpoints
 * Prevents brute force attacks on login
 * DISABLED in development mode
 */
export declare const authRateLimiter: import("express-rate-limit").RateLimitRequestHandler;
/**
 * Rate limiter for general API endpoints
 * DISABLED in development mode
 */
export declare const apiRateLimiter: import("express-rate-limit").RateLimitRequestHandler;
/**
 * Stricter rate limiter for write operations (POST, PUT, DELETE, PATCH)
 * DISABLED in development mode
 */
export declare const writeOperationRateLimiter: import("express-rate-limit").RateLimitRequestHandler;
/**
 * CSRF token validation middleware
 *
 * For API-first applications with JWT tokens, we use a simpler approach:
 * - Require Origin header for state-changing operations
 * - Validate Origin against whitelist
 * - Use SameSite cookie policy
 */
export declare const csrfProtection: (req: Request, res: Response, next: NextFunction) => void | Response<any, Record<string, any>>;
/**
 * Add security-related headers to responses
 */
export declare const securityHeaders: (_req: Request, res: Response, next: NextFunction) => void;
/**
 * Limit request body size to prevent DoS attacks
 */
export declare const requestSizeLimit: (req: Request, res: Response, next: NextFunction) => void;
/**
 * Basic input sanitization middleware
 * Removes potentially dangerous characters from request body
 */
export declare const sanitizeInput: (req: Request, _res: Response, next: NextFunction) => void;
//# sourceMappingURL=security.d.ts.map