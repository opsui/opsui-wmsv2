/**
 * Role Assignment routes
 *
 * Allows admins to grant and revoke additional roles for users
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=roleAssignments.d.ts.map