/**
 * Multi-Entity Service
 *
 * Business logic for multi-company, multi-subsidiary ERP operations
 * Handles entity management, inter-company transactions, consolidation, and entity user assignments
 */
import type { Entity, EntityWithParent, EntityHierarchyNode, CreateEntityDTO, UpdateEntityDTO, IntercompanyTransaction, IntercompanyTransactionWithDetails, CreateIntercompanyTransactionDTO, UpdateIntercompanyTransactionDTO, EntityRelationship, EntityRelationshipWithDetails, CreateEntityRelationshipDTO, EntityUser, EntityUserWithDetails, AssignEntityUserDTO, UpdateEntityUserDTO, ConsolidationRule, ConsolidationRuleWithDetails, CreateConsolidationRuleDTO, UpdateConsolidationRuleDTO, EntityExchangeRate, CreateEntityExchangeRateDTO, EntityAuditLog, EntityQueryFilters, IntercompanyTransactionQueryFilters, IntercompanyTransactionSummary, ConsolidatedFinancials } from '@opsui/shared';
declare class MultiEntityService {
    /**
     * Get all entities with optional filters
     */
    getEntities(filters?: EntityQueryFilters): Promise<Entity[]>;
    /**
     * Get entity by ID
     */
    getEntityById(entityId: string): Promise<EntityWithParent>;
    /**
     * Get entity with hierarchy
     */
    getEntityWithHierarchy(entityId: string): Promise<EntityWithParent>;
    /**
     * Get entity hierarchy tree
     */
    getEntityHierarchy(rootEntityId?: string): Promise<EntityHierarchyNode[]>;
    /**
     * Create new entity
     */
    createEntity(dto: CreateEntityDTO, createdBy: string): Promise<Entity>;
    /**
     * Update entity
     */
    updateEntity(entityId: string, dto: UpdateEntityDTO, updatedBy: string): Promise<Entity>;
    /**
     * Delete entity (soft delete)
     */
    deleteEntity(entityId: string, deletedBy: string): Promise<boolean>;
    /**
     * Get entity subsidiaries
     */
    getEntitySubsidiaries(entityId: string, includeChildren?: boolean): Promise<Entity[]>;
    /**
     * Get inter-company transactions with filters
     */
    getIntercompanyTransactions(filters?: IntercompanyTransactionQueryFilters): Promise<IntercompanyTransaction[]>;
    /**
     * Get inter-company transaction by ID with details
     */
    getIntercompanyTransactionById(transactionId: string): Promise<IntercompanyTransactionWithDetails>;
    /**
     * Create inter-company transaction
     */
    createIntercompanyTransaction(dto: CreateIntercompanyTransactionDTO, createdBy: string): Promise<IntercompanyTransaction>;
    /**
     * Update inter-company transaction
     */
    updateIntercompanyTransaction(transactionId: string, dto: UpdateIntercompanyTransactionDTO, updatedBy: string): Promise<IntercompanyTransaction>;
    /**
     * Approve inter-company transaction
     */
    approveIntercompanyTransaction(transactionId: string, approvedBy: string): Promise<IntercompanyTransaction>;
    /**
     * Get inter-company transaction summary
     */
    getIntercompanyTransactionSummary(filters?: IntercompanyTransactionQueryFilters): Promise<IntercompanyTransactionSummary>;
    /**
     * Get relationships for an entity
     */
    getEntityRelationships(entityId: string): Promise<EntityRelationshipWithDetails[]>;
    /**
     * Create entity relationship
     */
    createEntityRelationship(dto: CreateEntityRelationshipDTO, createdBy: string): Promise<EntityRelationship>;
    /**
     * Delete entity relationship
     */
    deleteEntityRelationship(relationshipId: string): Promise<boolean>;
    /**
     * Get all settings for an entity
     */
    getEntitySettings(entityId: string): Promise<Record<string, string>>;
    /**
     * Get a specific setting value
     */
    getEntitySetting(entityId: string, key: string, defaultValue?: string): Promise<string | null>;
    /**
     * Set entity setting
     */
    setEntitySetting(entityId: string, key: string, value: string, type: 'STRING' | 'NUMBER' | 'BOOLEAN' | 'JSON', updatedBy: string): Promise<Entity>;
    /**
     * Get users assigned to an entity
     */
    getEntityUsers(entityId: string): Promise<EntityUserWithDetails[]>;
    /**
     * Get entities for a user
     */
    getUserEntities(userId: string): Promise<EntityUser[]>;
    /**
     * Get user's default entity
     */
    getUserDefaultEntity(userId: string): Promise<Entity | null>;
    /**
     * Assign user to entity
     */
    assignUserToEntity(dto: AssignEntityUserDTO, createdBy: string): Promise<EntityUser>;
    /**
     * Update entity user assignment
     */
    updateEntityUserAssignment(entityUserId: string, dto: UpdateEntityUserDTO): Promise<EntityUser>;
    /**
     * Remove user from entity
     */
    removeUserFromEntity(entityUserId: string): Promise<boolean>;
    /**
     * Set default entity for user
     */
    setUserDefaultEntity(userId: string, entityId: string): Promise<boolean>;
    /**
     * Check if user has permission on entity
     */
    checkEntityPermission(userId: string, entityId: string, permission: string): Promise<boolean>;
    /**
     * Get consolidation rules
     */
    getConsolidationRules(parentId?: string): Promise<ConsolidationRuleWithDetails[]>;
    /**
     * Get consolidation rule by ID
     */
    getConsolidationRuleById(ruleId: string): Promise<ConsolidationRuleWithDetails>;
    /**
     * Create consolidation rule
     */
    createConsolidationRule(dto: CreateConsolidationRuleDTO, createdBy: string): Promise<ConsolidationRule>;
    /**
     * Update consolidation rule
     */
    updateConsolidationRule(ruleId: string, dto: UpdateConsolidationRuleDTO): Promise<ConsolidationRule>;
    /**
     * Delete consolidation rule
     */
    deleteConsolidationRule(ruleId: string): Promise<boolean>;
    /**
     * Get exchange rates for an entity
     */
    getEntityExchangeRates(entityId: string): Promise<EntityExchangeRate[]>;
    /**
     * Get latest exchange rate
     */
    getLatestExchangeRate(entityId: string, fromCurrency: string, toCurrency: string): Promise<EntityExchangeRate | null>;
    /**
     * Set exchange rate
     */
    setExchangeRate(dto: CreateEntityExchangeRateDTO, createdBy: string): Promise<EntityExchangeRate>;
    /**
     * Get audit log for an entity
     */
    getEntityAuditLog(entityId: string, limit?: number): Promise<EntityAuditLog[]>;
    /**
     * Generate consolidated financial statements
     * This is a placeholder for the full consolidation logic
     */
    generateConsolidatedFinancials(period: string, parentEntityId: string): Promise<ConsolidatedFinancials>;
}
export declare const multiEntityService: MultiEntityService;
export {};
//# sourceMappingURL=MultiEntityService.d.ts.map