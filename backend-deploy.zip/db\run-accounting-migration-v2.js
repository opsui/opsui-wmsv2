"use strict";
/**
 * Run the accounting tables migration v2
 * This version uses non-conflicting table names
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const client_1 = require("./client");
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const url_1 = require("url");
const __filename = (0, url_1.fileURLToPath)(import.meta.url);
const __dirname = path_1.default.dirname(__filename);
async function runMigration() {
    try {
        console.log('Running accounting tables migration v2...');
        // Read and execute the migration SQL file
        const migrationPath = path_1.default.join(__dirname, 'migrations', '042_add_accounting_tables_v2.sql');
        const migrationSQL = fs_1.default.readFileSync(migrationPath, 'utf8');
        // Execute the migration
        await (0, client_1.query)(migrationSQL);
        console.log('✅ Accounting tables migration v2 completed successfully!');
        await (0, client_1.closePool)();
        process.exit(0);
    }
    catch (error) {
        console.error('Migration failed:', error);
        await (0, client_1.closePool)();
        process.exit(1);
    }
}
runMigration();
//# sourceMappingURL=run-accounting-migration-v2.js.map