/**
 * Notification Service
 *
 * Handles creation, delivery, and management of user notifications
 * Supports multiple channels: EMAIL, SMS, PUSH, IN_APP
 */
export interface Notification {
    notificationId: string;
    userId: string;
    type: string;
    channel: 'EMAIL' | 'SMS' | 'PUSH' | 'IN_APP';
    title: string;
    message: string;
    status: 'PENDING' | 'SENT' | 'DELIVERED' | 'FAILED' | 'READ';
    priority?: 'LOW' | 'NORMAL' | 'HIGH' | 'URGENT';
    data?: Record<string, any>;
    scheduledFor?: Date;
    createdAt: Date;
    readAt?: Date;
    sentAt?: Date;
    deliveredAt?: Date;
    failedAt?: Date;
    errorMessage?: string;
}
export interface NotificationPreference {
    userId: string;
    emailEnabled?: boolean;
    smsEnabled?: boolean;
    pushEnabled?: boolean;
    inAppEnabled?: boolean;
    quietHoursEnabled?: boolean;
    quietHoursStart?: string;
    quietHoursEnd?: string;
    quietHoursTimezone?: string;
    smsPhone?: string;
    typePreferences?: Record<string, {
        email: boolean;
        sms: boolean;
        push: boolean;
        inApp: boolean;
    }>;
}
export interface SendNotificationInput {
    userId: string;
    type: string;
    channel: 'EMAIL' | 'SMS' | 'PUSH' | 'IN_APP';
    title: string;
    message: string;
    data?: Record<string, any>;
    priority?: 'LOW' | 'NORMAL' | 'HIGH' | 'URGENT';
    scheduledFor?: Date;
}
export interface BulkSendInput {
    userIds: string[];
    type: string;
    channels: string[];
    title: string;
    message: string;
    data?: Record<string, any>;
    priority?: 'LOW' | 'NORMAL' | 'HIGH' | 'URGENT';
}
export declare class NotificationService {
    private emailProvider;
    private smsProvider;
    private pushProvider;
    constructor();
    /**
     * Get notifications for a user
     */
    getNotifications(userId: string, options?: {
        type?: string;
        status?: string;
        channel?: string;
        unreadOnly?: boolean;
        limit?: number;
        offset?: number;
    }): Promise<{
        notifications: Notification[];
        total: number;
    }>;
    /**
     * Mark notification as read
     */
    markAsRead(notificationId: string, userId: string): Promise<boolean>;
    /**
     * Mark all notifications as read for a user
     */
    markAllAsRead(userId: string): Promise<number>;
    /**
     * Delete a notification
     */
    deleteNotification(notificationId: string, userId: string): Promise<boolean>;
    /**
     * Get notification preferences for a user
     */
    getNotificationPreferences(userId: string): Promise<NotificationPreference | null>;
    /**
     * Update notification preferences for a user
     */
    updateNotificationPreferences(userId: string, preferences: Partial<NotificationPreference>): Promise<void>;
    /**
     * Get notification stats for a user
     */
    getNotificationStats(userId: string): Promise<{
        total: number;
        unread: number;
        byType: Record<string, number>;
    }>;
    /**
     * Send a notification to a user
     */
    sendNotification(input: SendNotificationInput): Promise<{
        success: boolean;
        notification?: Notification;
        error?: string;
    }>;
    /**
     * Send bulk notifications to multiple users
     */
    bulkSend(input: BulkSendInput): Promise<{
        success: boolean;
        sent: number;
        failed: number;
        errors: string[];
    }>;
    /**
     * Send notification from template
     */
    sendFromTemplate(userId: string, templateName: string, variables: Record<string, any>): Promise<{
        success: boolean;
        notification?: Notification;
        error?: string;
    }>;
    /**
     * List notifications with filters (alias for getNotifications)
     */
    listNotifications(userId: string, options?: {
        type?: string;
        status?: string;
        channel?: string;
        unreadOnly?: boolean;
        limit?: number;
        offset?: number;
    }): Promise<{
        notifications: Notification[];
        total: number;
    }>;
    /**
     * Get notification preferences
     */
    getPreferences(userId: string): Promise<NotificationPreference | null>;
    /**
     * Update notification preferences
     */
    updatePreferences(userId: string, preferences: Partial<NotificationPreference>): Promise<NotificationPreference>;
    /**
     * Deliver notification via appropriate channel
     */
    private deliverNotification;
    /**
     * Map database row to Notification object
     */
    private mapRowToNotification;
    /**
     * Replace variables in template string
     */
    private replaceVariables;
    /**
     * Convert camelCase to snake_case
     */
    private camelToSnake;
    /**
     * Map notification type string to NotificationEvent type
     */
    private getNotificationType;
}
export declare const notificationService: NotificationService;
//# sourceMappingURL=NotificationService.d.ts.map