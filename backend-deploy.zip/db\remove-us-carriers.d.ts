/**
 * Migration: Remove US-specific carriers
 *
 * Removes FedEx, UPS, and USPS as they don't operate in New Zealand
 */
export {};
//# sourceMappingURL=remove-us-carriers.d.ts.map