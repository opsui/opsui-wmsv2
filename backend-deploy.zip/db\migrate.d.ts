/**
 * Database migration runner
 *
 * Reads and executes the schema.sql file to create/refresh the database schema.
 */
import 'dotenv/config';
/**
 * Run database migrations
 */
export declare function runMigrations(): Promise<void>;
/**
 * Drop all tables (use with caution!)
 */
export declare function dropAllTables(): Promise<void>;
/**
 * Reset database (drop and recreate)
 */
export declare function resetDatabase(): Promise<void>;
/**
 * Main function for running migrations from command line
 */
declare function main(): Promise<void>;
export { main as migrateCli };
//# sourceMappingURL=migrate.d.ts.map