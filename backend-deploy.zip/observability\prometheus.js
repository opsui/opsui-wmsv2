"use strict";
/**
 * Prometheus Metrics Middleware
 *
 * Provides HTTP metrics endpoint for Prometheus scraping
 * and request tracking middleware
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.metricsMiddleware = exports.rateLimitViolationsTotal = exports.exceptionsTotal = exports.ordersByStatusGauge = exports.activeUsersGauge = exports.inventoryTransactionsTotal = exports.pickDurationMs = exports.picksCompletedTotal = exports.orderProcessingDurationMs = exports.ordersProcessedTotal = exports.cacheSize = exports.cacheMissesTotal = exports.cacheHitsTotal = exports.dbErrorsTotal = exports.dbConnectionPool = exports.dbQueryDurationMs = exports.httpConcurrentRequests = exports.httpErrorsTotal = exports.httpResponseSizeBytes = exports.httpRequestSizeBytes = exports.httpRequestDurationMs = exports.httpRequestsTotal = void 0;
exports.metricsEndpoint = metricsEndpoint;
exports.healthWithMetrics = healthWithMetrics;
exports.resetMetrics = resetMetrics;
exports.getMetricsAsJSON = getMetricsAsJSON;
exports.createCounter = createCounter;
exports.createHistogram = createHistogram;
exports.createGauge = createGauge;
const prom_client_1 = __importStar(require("prom-client"));
const logger_1 = require("../config/logger");
// ============================================================================
// REGISTRY
// ============================================================================
const register = new prom_client_1.Registry();
// Add default metrics (CPU, memory, etc.)
prom_client_1.default.collectDefaultMetrics({
    register,
    prefix: 'wms_',
});
// ============================================================================
// HTTP METRICS
// ============================================================================
/**
 * Counter for total HTTP requests
 */
exports.httpRequestsTotal = new prom_client_1.Counter({
    name: 'wms_http_requests_total',
    help: 'Total number of HTTP requests',
    labelNames: ['method', 'route', 'status_code'],
    registers: [register],
});
/**
 * Histogram for HTTP request duration
 */
exports.httpRequestDurationMs = new prom_client_1.Histogram({
    name: 'wms_http_request_duration_ms',
    help: 'Duration of HTTP requests in milliseconds',
    labelNames: ['method', 'route', 'status_code'],
    buckets: [1, 5, 10, 25, 50, 100, 250, 500, 1000, 2500, 5000, 10000],
    registers: [register],
});
/**
 * Histogram for request size
 */
exports.httpRequestSizeBytes = new prom_client_1.Histogram({
    name: 'wms_http_request_size_bytes',
    help: 'Size of HTTP requests in bytes',
    labelNames: ['method', 'route'],
    buckets: [100, 1000, 10000, 100000, 1000000, 10000000],
    registers: [register],
});
/**
 * Histogram for response size
 */
exports.httpResponseSizeBytes = new prom_client_1.Histogram({
    name: 'wms_http_response_size_bytes',
    help: 'Size of HTTP responses in bytes',
    labelNames: ['method', 'route', 'status_code'],
    buckets: [100, 1000, 10000, 100000, 1000000, 10000000],
    registers: [register],
});
/**
 * Counter for HTTP errors
 */
exports.httpErrorsTotal = new prom_client_1.Counter({
    name: 'wms_http_errors_total',
    help: 'Total number of HTTP errors',
    labelNames: ['method', 'route', 'status_code', 'error_type'],
    registers: [register],
});
/**
 * Gauge for concurrent requests
 */
exports.httpConcurrentRequests = new prom_client_1.Gauge({
    name: 'wms_http_concurrent_requests',
    help: 'Number of concurrent HTTP requests',
    registers: [register],
});
// ============================================================================
// DATABASE METRICS
// ============================================================================
/**
 * Histogram for database query duration
 */
exports.dbQueryDurationMs = new prom_client_1.Histogram({
    name: 'wms_db_query_duration_ms',
    help: 'Duration of database queries in milliseconds',
    labelNames: ['operation', 'table'],
    buckets: [1, 5, 10, 25, 50, 100, 250, 500, 1000],
    registers: [register],
});
/**
 * Gauge for database connection pool
 */
exports.dbConnectionPool = new prom_client_1.Gauge({
    name: 'wms_db_connection_pool',
    help: 'Database connection pool statistics',
    labelNames: ['state'], // total, waiting, idle, active
    registers: [register],
});
/**
 * Counter for database errors
 */
exports.dbErrorsTotal = new prom_client_1.Counter({
    name: 'wms_db_errors_total',
    help: 'Total number of database errors',
    labelNames: ['operation', 'error_code'],
    registers: [register],
});
// ============================================================================
// CACHE METRICS (Redis)
// ============================================================================
/**
 * Counter for cache hits
 */
exports.cacheHitsTotal = new prom_client_1.Counter({
    name: 'wms_cache_hits_total',
    help: 'Total number of cache hits',
    labelNames: ['cache_type'],
    registers: [register],
});
/**
 * Counter for cache misses
 */
exports.cacheMissesTotal = new prom_client_1.Counter({
    name: 'wms_cache_misses_total',
    help: 'Total number of cache misses',
    labelNames: ['cache_type'],
    registers: [register],
});
/**
 * Gauge for cache size
 */
exports.cacheSize = new prom_client_1.Gauge({
    name: 'wms_cache_size',
    help: 'Current cache size',
    labelNames: ['cache_type'],
    registers: [register],
});
// ============================================================================
// BUSINESS METRICS
// ============================================================================
/**
 * Counter for orders processed
 */
exports.ordersProcessedTotal = new prom_client_1.Counter({
    name: 'wms_orders_processed_total',
    help: 'Total number of orders processed',
    labelNames: ['status', 'priority'],
    registers: [register],
});
/**
 * Histogram for order processing duration
 */
exports.orderProcessingDurationMs = new prom_client_1.Histogram({
    name: 'wms_order_processing_duration_ms',
    help: 'Duration from order creation to shipment in milliseconds',
    labelNames: ['priority'],
    buckets: [60000, 300000, 900000, 1800000, 3600000, 7200000, 14400000, 28800000],
    registers: [register],
});
/**
 * Counter for picks completed
 */
exports.picksCompletedTotal = new prom_client_1.Counter({
    name: 'wms_picks_completed_total',
    help: 'Total number of picks completed',
    labelNames: ['picker_id', 'zone'],
    registers: [register],
});
/**
 * Histogram for pick duration
 */
exports.pickDurationMs = new prom_client_1.Histogram({
    name: 'wms_pick_duration_ms',
    help: 'Duration of individual picks in milliseconds',
    labelNames: ['picker_id', 'zone'],
    buckets: [1000, 5000, 10000, 30000, 60000, 120000, 300000],
    registers: [register],
});
/**
 * Counter for inventory transactions
 */
exports.inventoryTransactionsTotal = new prom_client_1.Counter({
    name: 'wms_inventory_transactions_total',
    help: 'Total number of inventory transactions',
    labelNames: ['transaction_type', 'sku'],
    registers: [register],
});
/**
 * Gauge for current active users
 */
exports.activeUsersGauge = new prom_client_1.Gauge({
    name: 'wms_active_users',
    help: 'Number of currently active users by role',
    labelNames: ['role'],
    registers: [register],
});
/**
 * Gauge for orders by status
 */
exports.ordersByStatusGauge = new prom_client_1.Gauge({
    name: 'wms_orders_by_status',
    help: 'Number of orders by current status',
    labelNames: ['status'],
    registers: [register],
});
/**
 * Counter for exceptions raised
 */
exports.exceptionsTotal = new prom_client_1.Counter({
    name: 'wms_exceptions_total',
    help: 'Total number of order exceptions',
    labelNames: ['exception_type', 'severity'],
    registers: [register],
});
// ============================================================================
// RATE LIMITING METRICS
// ============================================================================
/**
 * Counter for rate limit violations
 */
exports.rateLimitViolationsTotal = new prom_client_1.Counter({
    name: 'wms_rate_limit_violations_total',
    help: 'Total number of rate limit violations',
    labelNames: ['endpoint', 'limit_type'],
    registers: [register],
});
// ============================================================================
// MIDDLEWARE
// ============================================================================
/**
 * Metrics tracking middleware
 */
const metricsMiddleware = (req, res, next) => {
    const start = Date.now();
    // Increment concurrent requests
    exports.httpConcurrentRequests.inc();
    // Track request size
    const contentLength = req.get('content-length');
    if (contentLength) {
        exports.httpRequestSizeBytes
            .labels(req.method, req.route?.path || req.path)
            .observe(parseInt(contentLength, 10));
    }
    // Hook into response finish
    res.on('finish', () => {
        const duration = Date.now() - start;
        const route = req.route?.path || req.path;
        const statusCode = res.statusCode.toString();
        // Record request duration
        exports.httpRequestDurationMs.labels(req.method, route, statusCode).observe(duration);
        // Increment total requests
        exports.httpRequestsTotal.labels(req.method, route, statusCode).inc();
        // Track response size
        if (res.get('content-length')) {
            exports.httpResponseSizeBytes
                .labels(req.method, route, statusCode)
                .observe(parseInt(res.get('content-length'), 10));
        }
        // Track errors
        if (statusCode.startsWith('4') || statusCode.startsWith('5')) {
            exports.httpErrorsTotal.labels(req.method, route, statusCode, 'http_error').inc();
        }
        // Decrement concurrent requests
        exports.httpConcurrentRequests.dec();
    });
    next();
};
exports.metricsMiddleware = metricsMiddleware;
// ============================================================================
// METRICS ENDPOINT
// ============================================================================
/**
 * Metrics endpoint handler for Prometheus scraping
 * Returns metrics in Prometheus text format
 */
async function metricsEndpoint(_req, res) {
    try {
        res.set('Content-Type', register.contentType);
        res.end(await register.metrics());
    }
    catch (error) {
        logger_1.logger.error('Error generating metrics', { error });
        res.status(500).end('Error generating metrics');
    }
}
/**
 * Health check endpoint that includes metrics
 */
async function healthWithMetrics(_req, res) {
    try {
        res.json({
            status: 'healthy',
            timestamp: new Date().toISOString(),
            uptime: process.uptime(),
            metrics: {
                memory: process.memoryUsage(),
                cpu: process.cpuUsage(),
            },
        });
    }
    catch (error) {
        logger_1.logger.error('Error in health check', { error });
        res.status(500).json({ status: 'error', error: 'Health check failed' });
    }
}
// ============================================================================
// UTILITY FUNCTIONS
// ============================================================================
/**
 * Reset all metrics (useful for testing)
 */
function resetMetrics() {
    register.resetMetrics();
}
/**
 * Get metrics as JSON (for debugging)
 */
async function getMetricsAsJSON() {
    return register.getMetricsAsJSON();
}
/**
 * Create a custom counter
 */
function createCounter(name, help, labelNames = []) {
    return new prom_client_1.Counter({
        name: `wms_${name}`,
        help,
        labelNames,
        registers: [register],
    });
}
/**
 * Create a custom histogram
 */
function createHistogram(name, help, options) {
    return new prom_client_1.Histogram({
        name: `wms_${name}`,
        help,
        labelNames: options?.labelNames || [],
        buckets: options?.buckets || [1, 5, 10, 25, 50, 100, 250, 500, 1000],
        registers: [register],
    });
}
/**
 * Create a custom gauge
 */
function createGauge(name, help, labelNames = []) {
    return new prom_client_1.Gauge({
        name: `wms_${name}`,
        help,
        labelNames,
        registers: [register],
    });
}
// ============================================================================
// EXPORTS
// ============================================================================
exports.default = {
    register,
    metricsEndpoint,
    healthWithMetrics,
    metricsMiddleware: exports.metricsMiddleware,
    resetMetrics,
    getMetricsAsJSON,
    createCounter,
    createHistogram,
    createGauge,
    // HTTP metrics
    httpRequestsTotal: exports.httpRequestsTotal,
    httpRequestDurationMs: exports.httpRequestDurationMs,
    httpRequestSizeBytes: exports.httpRequestSizeBytes,
    httpResponseSizeBytes: exports.httpResponseSizeBytes,
    httpErrorsTotal: exports.httpErrorsTotal,
    httpConcurrentRequests: exports.httpConcurrentRequests,
    // Database metrics
    dbQueryDurationMs: exports.dbQueryDurationMs,
    dbConnectionPool: exports.dbConnectionPool,
    dbErrorsTotal: exports.dbErrorsTotal,
    // Cache metrics
    cacheHitsTotal: exports.cacheHitsTotal,
    cacheMissesTotal: exports.cacheMissesTotal,
    cacheSize: exports.cacheSize,
    // Business metrics
    ordersProcessedTotal: exports.ordersProcessedTotal,
    orderProcessingDurationMs: exports.orderProcessingDurationMs,
    picksCompletedTotal: exports.picksCompletedTotal,
    pickDurationMs: exports.pickDurationMs,
    inventoryTransactionsTotal: exports.inventoryTransactionsTotal,
    activeUsersGauge: exports.activeUsersGauge,
    ordersByStatusGauge: exports.ordersByStatusGauge,
    exceptionsTotal: exports.exceptionsTotal,
    // Rate limiting
    rateLimitViolationsTotal: exports.rateLimitViolationsTotal,
};
//# sourceMappingURL=prometheus.js.map