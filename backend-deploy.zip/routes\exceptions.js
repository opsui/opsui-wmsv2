"use strict";
/**
 * Order Exception routes
 *
 * Endpoints for logging and resolving order exceptions during fulfillment
 */
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const OrderExceptionService_1 = require("../services/OrderExceptionService");
const middleware_1 = require("../middleware");
const shared_1 = require("@opsui/shared");
const router = (0, express_1.Router)();
// All exception routes require authentication
router.use(middleware_1.authenticate);
/**
 * POST /api/exceptions/log
 * Log a new exception during picking
 */
router.post('/log', middleware_1.authenticate, (0, middleware_1.asyncHandler)(async (req, res) => {
    if (!req.user) {
        res.status(401).json({ error: 'Not authenticated' });
        return;
    }
    console.log('[POST /api/exceptions/log] Request body:', JSON.stringify(req.body, null, 2));
    // Normalize snake_case to camelCase for compatibility with API client
    const orderId = req.body.orderId || req.body.order_id;
    const orderItemId = req.body.orderItemId || req.body.order_item_id;
    const sku = req.body.sku;
    const type = req.body.type;
    const quantityExpected = req.body.quantityExpected ?? req.body.quantity_expected;
    const quantityActual = req.body.quantityActual ?? req.body.quantity_actual;
    const reason = req.body.reason;
    const substituteSku = req.body.substituteSku ?? req.body.substitute_sku;
    // Validate required fields
    if (!orderId ||
        !orderItemId ||
        !sku ||
        !type ||
        typeof quantityExpected !== 'number' ||
        typeof quantityActual !== 'number' ||
        !reason) {
        res.status(400).json({
            error: 'Missing required fields',
            code: 'MISSING_FIELDS',
            details: {
                orderId: !!orderId,
                orderItemId: !!orderItemId,
                sku: !!sku,
                type: !!type,
                quantityExpected: typeof quantityExpected === 'number',
                quantityActual: typeof quantityActual === 'number',
                reason: !!reason,
            },
        });
        return;
    }
    // Validate exception type
    const validTypes = Object.values(shared_1.ExceptionType);
    if (!validTypes.includes(type)) {
        res.status(400).json({
            error: 'Invalid exception type',
            code: 'INVALID_TYPE',
            validTypes,
        });
        return;
    }
    const exception = await OrderExceptionService_1.orderExceptionService.logException({
        orderId,
        orderItemId,
        sku,
        type,
        quantityExpected,
        quantityActual,
        reason,
        reportedBy: req.user.userId,
        substituteSku,
    });
    res.json(exception);
}));
/**
 * GET /api/exceptions
 * Get all exceptions with optional filters
 */
router.get('/', (0, middleware_1.authorize)(shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (req, res) => {
    const filters = {
        status: req.query.status,
        orderId: req.query.orderId,
        limit: req.query.limit ? parseInt(req.query.limit) : 50,
        offset: req.query.offset ? parseInt(req.query.offset) : 0,
    };
    const result = await OrderExceptionService_1.orderExceptionService.getAllExceptions(filters);
    res.json(result);
}));
/**
 * GET /api/exceptions/open
 * Get all open exceptions that need attention
 */
router.get('/open', (0, middleware_1.authorize)(shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (req, res) => {
    const filters = {
        orderId: req.query.orderId,
        sku: req.query.sku,
        type: req.query.type,
        limit: req.query.limit ? parseInt(req.query.limit) : 50,
        offset: req.query.offset ? parseInt(req.query.offset) : 0,
    };
    const result = await OrderExceptionService_1.orderExceptionService.getOpenExceptions(filters);
    res.json(result);
}));
/**
 * GET /api/exceptions/summary
 * Get exception summary statistics
 */
router.get('/summary', (0, middleware_1.authorize)(shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (_req, res) => {
    const summary = await OrderExceptionService_1.orderExceptionService.getExceptionSummary();
    res.json(summary);
}));
/**
 * GET /api/exceptions/:exceptionId
 * Get a specific exception by ID
 */
router.get('/:exceptionId', (0, middleware_1.authorize)(shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { exceptionId } = req.params;
    const exception = await OrderExceptionService_1.orderExceptionService.getException(exceptionId);
    res.json(exception);
}));
/**
 * POST /api/exceptions/:exceptionId/resolve
 * Resolve an exception with a specific action
 */
router.post('/:exceptionId/resolve', (0, middleware_1.authorize)(shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (req, res) => {
    if (!req.user) {
        res.status(401).json({ error: 'Not authenticated' });
        return;
    }
    const { exceptionId } = req.params;
    const { resolution, notes, substituteSku, newQuantity, newBinLocation } = req.body;
    // Validate resolution
    if (!resolution) {
        res.status(400).json({
            error: 'Resolution is required',
            code: 'MISSING_RESOLUTION',
        });
        return;
    }
    const resolved = await OrderExceptionService_1.orderExceptionService.resolveException({
        exceptionId,
        resolution,
        notes,
        resolvedBy: req.user.userId,
        substituteSku,
        newQuantity,
        newBinLocation,
    });
    res.json(resolved);
}));
/**
 * POST /api/exceptions/report-problem
 * Report a general problem (not tied to a specific order)
 */
router.post('/report-problem', middleware_1.authenticate, (0, middleware_1.asyncHandler)(async (req, res) => {
    if (!req.user) {
        res.status(401).json({ error: 'Not authenticated' });
        return;
    }
    const { problemType, location, description } = req.body;
    // Validate required fields
    if (!problemType || !description) {
        res.status(400).json({
            error: 'Missing required fields',
            code: 'MISSING_FIELDS',
        });
        return;
    }
    // Store problem report in database via service
    const problemReport = await OrderExceptionService_1.orderExceptionService.reportProblem({
        problemType,
        location,
        description,
        reportedBy: req.user.userId,
    });
    res.json({
        success: true,
        message: 'Problem reported successfully',
        data: problemReport,
    });
}));
/**
 * GET /api/exceptions/problems
 * Get all problem reports
 */
router.get('/problems', (0, middleware_1.authorize)(shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (req, res) => {
    const filters = {
        status: req.query.status,
        problemType: req.query.problemType,
        limit: req.query.limit ? parseInt(req.query.limit) : 50,
        offset: req.query.offset ? parseInt(req.query.offset) : 0,
    };
    const result = await OrderExceptionService_1.orderExceptionService.getProblemReports(filters);
    res.json(result);
}));
/**
 * POST /api/exceptions/problems/:problemId/resolve
 * Resolve a problem report
 */
router.post('/problems/:problemId/resolve', (0, middleware_1.authorize)(shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (req, res) => {
    if (!req.user) {
        res.status(401).json({ error: 'Not authenticated' });
        return;
    }
    const { problemId } = req.params;
    const { resolution, notes } = req.body;
    // Validate resolution
    if (!resolution) {
        res.status(400).json({
            error: 'Resolution is required',
            code: 'MISSING_RESOLUTION',
        });
        return;
    }
    const resolved = await OrderExceptionService_1.orderExceptionService.resolveProblemReport({
        problemId,
        resolution,
        notes,
        resolvedBy: req.user.userId,
    });
    res.json({
        success: true,
        message: 'Problem report resolved successfully',
        data: resolved,
    });
}));
exports.default = router;
//# sourceMappingURL=exceptions.js.map