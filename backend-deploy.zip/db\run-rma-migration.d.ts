/**
 * Run RMA Migration
 */
export {};
//# sourceMappingURL=run-rma-migration.d.ts.map