"use strict";
/**
 * Module Entitlement Middleware
 *
 * Checks if a module is enabled for the current entity before allowing access
 * Integrates with the existing auth middleware
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.requireModule = requireModule;
exports.requireAnyModule = requireAnyModule;
exports.requireAllModules = requireAllModules;
exports.checkModuleEntitlement = checkModuleEntitlement;
exports.attachEnabledModules = attachEnabledModules;
exports.checkModuleAccess = checkModuleAccess;
exports.moduleGate = moduleGate;
exports.getRequiredModuleForPath = getRequiredModuleForPath;
exports.getRequiredModulesForRoutes = getRequiredModulesForRoutes;
const logger_1 = require("../config/logger");
const shared_1 = require("@opsui/shared");
const ModuleSubscriptionService_1 = require("../services/ModuleSubscriptionService");
const shared_2 = require("@opsui/shared");
// Route-to-module mapping for automatic module detection
const ROUTE_MODULE_MAP = {
    // Core Warehouse
    '/api/orders': 'order-management',
    '/api/customers': 'order-management',
    '/api/inventory': 'inventory-management',
    '/api/skus': 'inventory-management',
    '/api/bins': 'inventory-management',
    '/api/receiving': 'receiving-inbound',
    '/api/asn': 'receiving-inbound',
    '/api/suppliers': 'receiving-inbound',
    '/api/shipping': 'shipping-outbound',
    '/api/packing': 'shipping-outbound',
    '/api/carriers': 'shipping-outbound',
    // Advanced Warehouse
    '/api/cycle-counts': 'cycle-counting',
    '/api/waves': 'wave-picking',
    '/api/pick-tasks': 'wave-picking',
    '/api/zones': 'zone-picking',
    '/api/zone-picking': 'zone-picking',
    '/api/slotting': 'slotting-optimization',
    // Logistics
    '/api/routes': 'route-optimization',
    '/api/optimization': 'route-optimization',
    // Quality & Compliance
    '/api/quality': 'quality-control',
    '/api/inspections': 'quality-control',
    '/api/exceptions': 'exceptions-management',
    // Business Automation
    '/api/business-rules': 'business-rules-engine',
    '/api/rules': 'business-rules-engine',
    // Analytics
    '/api/reports': 'dashboards-reporting',
    '/api/analytics': 'dashboards-reporting',
    '/api/ml': 'ml-ai-predictions',
    '/api/predictions': 'ml-ai-predictions',
    // Enterprise
    '/api/accounting': 'finance-accounting',
    '/api/finance': 'finance-accounting',
    '/api/journals': 'finance-accounting',
    '/api/hr': 'human-resources',
    '/api/employees': 'human-resources',
    '/api/manufacturing': 'production-manufacturing',
    '/api/production': 'production-manufacturing',
    '/api/bom': 'production-manufacturing',
    '/api/procurement': 'procurement',
    '/api/purchase-orders': 'procurement',
    '/api/vendors': 'procurement',
    '/api/maintenance': 'maintenance-management',
    '/api/assets': 'maintenance-management',
    '/api/work-orders': 'maintenance-management',
    '/api/rma': 'returns-management',
    '/api/returns': 'returns-management',
};
// Routes that are always accessible (core system)
const ALWAYS_ACCESSIBLE_ROUTES = [
    '/api/auth',
    '/api/users',
    '/api/modules',
    '/api/health',
    '/api/ping',
    '/api/entities',
    '/api/me',
];
// ============================================================================
// HELPER FUNCTIONS
// ============================================================================
/**
 * Get the module ID for a given route path
 */
function getModuleForRoute(path) {
    // Check for exact match first
    if (ROUTE_MODULE_MAP[path]) {
        return ROUTE_MODULE_MAP[path];
    }
    // Check for prefix match
    for (const [route, moduleId] of Object.entries(ROUTE_MODULE_MAP)) {
        if (path.startsWith(route + '/') || path === route) {
            return moduleId;
        }
    }
    return null;
}
/**
 * Check if a route is always accessible
 */
function isAlwaysAccessible(path) {
    return ALWAYS_ACCESSIBLE_ROUTES.some(route => path.startsWith(route + '/') || path === route);
}
/**
 * Get the entity ID from the request
 * This can come from:
 * 1. X-Entity-Id header (explicit entity selection)
 * 2. User's default entity
 * 3. Query parameter (for some operations)
 */
function getEntityIdFromRequest(req) {
    // Check header first
    const headerEntityId = req.headers['x-entity-id'];
    if (headerEntityId) {
        return headerEntityId;
    }
    // Check query parameter
    const queryEntityId = req.query.entityId;
    if (queryEntityId) {
        return queryEntityId;
    }
    // TODO: Get user's default entity from JWT or database
    // For now, return null and rely on default behavior
    return null;
}
// ============================================================================
// MIDDLEWARE
// ============================================================================
/**
 * Middleware to check if a specific module is enabled
 */
function requireModule(moduleId) {
    return async (req, _res, next) => {
        try {
            if (!req.user) {
                return next(new shared_1.ForbiddenError('User not authenticated'));
            }
            // Get entity ID
            const entityId = getEntityIdFromRequest(req);
            if (!entityId) {
                // If no entity context, allow access (will be handled by entity middleware)
                return next();
            }
            const enabled = await (0, ModuleSubscriptionService_1.isModuleEnabled)(entityId, moduleId);
            if (!enabled) {
                const moduleDef = shared_2.MODULE_DEFINITIONS[moduleId];
                logger_1.logger.warn('Module access denied', {
                    userId: req.user.userId,
                    entityId,
                    moduleId,
                    moduleName: moduleDef?.name ?? moduleId,
                });
                return next(new shared_1.ForbiddenError(`Module '${moduleDef?.name ?? moduleId}' is not enabled for your organization. ` +
                    `Please contact your administrator to enable this feature.`));
            }
            // Attach enabled modules to request for later use
            req.enabledModules = await (0, ModuleSubscriptionService_1.getEnabledModules)(entityId);
            next();
        }
        catch (error) {
            logger_1.logger.error('Error checking module entitlement', { error, moduleId });
            next(error);
        }
    };
}
/**
 * Middleware to check if any of the specified modules are enabled
 */
function requireAnyModule(...moduleIds) {
    return async (req, _res, next) => {
        try {
            if (!req.user) {
                return next(new shared_1.ForbiddenError('User not authenticated'));
            }
            const entityId = getEntityIdFromRequest(req);
            if (!entityId) {
                return next();
            }
            const modulesStatus = await (0, ModuleSubscriptionService_1.areModulesEnabled)(entityId, moduleIds);
            const hasAny = Object.values(modulesStatus).some(enabled => enabled);
            if (!hasAny) {
                const moduleNames = moduleIds.map(id => shared_2.MODULE_DEFINITIONS[id]?.name ?? id);
                logger_1.logger.warn('Module access denied - none enabled', {
                    userId: req.user.userId,
                    entityId,
                    moduleIds,
                });
                return next(new shared_1.ForbiddenError(`None of the required modules (${moduleNames.join(', ')}) are enabled for your organization.`));
            }
            req.enabledModules = await (0, ModuleSubscriptionService_1.getEnabledModules)(entityId);
            next();
        }
        catch (error) {
            logger_1.logger.error('Error checking module entitlements', { error, moduleIds });
            next(error);
        }
    };
}
/**
 * Middleware to check if all specified modules are enabled
 */
function requireAllModules(...moduleIds) {
    return async (req, _res, next) => {
        try {
            if (!req.user) {
                return next(new shared_1.ForbiddenError('User not authenticated'));
            }
            const entityId = getEntityIdFromRequest(req);
            if (!entityId) {
                return next();
            }
            const modulesStatus = await (0, ModuleSubscriptionService_1.areModulesEnabled)(entityId, moduleIds);
            const missingModules = moduleIds.filter(id => !modulesStatus[id]);
            if (missingModules.length > 0) {
                const missingNames = missingModules.map(id => shared_2.MODULE_DEFINITIONS[id]?.name ?? id);
                logger_1.logger.warn('Module access denied - missing modules', {
                    userId: req.user.userId,
                    entityId,
                    missingModules,
                });
                return next(new shared_1.ForbiddenError(`The following modules are required but not enabled: ${missingNames.join(', ')}`));
            }
            req.enabledModules = await (0, ModuleSubscriptionService_1.getEnabledModules)(entityId);
            next();
        }
        catch (error) {
            logger_1.logger.error('Error checking module entitlements', { error, moduleIds });
            next(error);
        }
    };
}
/**
 * Automatic module detection middleware
 * Checks if the module associated with the current route is enabled
 */
function checkModuleEntitlement(req, _res, next) {
    // Skip if route is always accessible
    if (isAlwaysAccessible(req.path)) {
        return next();
    }
    // Get module for current route
    const moduleId = getModuleForRoute(req.path);
    if (!moduleId) {
        // No module mapping found - allow access (route might not be module-gated)
        return next();
    }
    // Use requireModule middleware
    requireModule(moduleId)(req, _res, next);
}
/**
 * Middleware to attach enabled modules to request without blocking
 * Useful for conditional UI rendering
 */
async function attachEnabledModules(req, _res, next) {
    try {
        if (!req.user) {
            return next();
        }
        const entityId = getEntityIdFromRequest(req);
        if (!entityId) {
            return next();
        }
        req.enabledModules = await (0, ModuleSubscriptionService_1.getEnabledModules)(entityId);
        next();
    }
    catch (error) {
        // Don't block on error, just log
        logger_1.logger.error('Error attaching enabled modules', { error });
        next();
    }
}
/**
 * Helper function to check if a module is enabled (for use in routes)
 */
async function checkModuleAccess(entityId, moduleId) {
    const enabled = await (0, ModuleSubscriptionService_1.isModuleEnabled)(entityId, moduleId);
    const moduleDef = shared_2.MODULE_DEFINITIONS[moduleId];
    return {
        enabled,
        moduleName: moduleDef?.name ?? moduleId,
    };
}
/**
 * Express middleware factory for route-specific module checking
 * Use this when defining routes to automatically gate them by module
 */
function moduleGate(moduleId) {
    return requireModule(moduleId);
}
// ============================================================================
// ROUTE CONFIGURATION HELPER
// ============================================================================
/**
 * Get the module ID that should be checked for a given path
 * Useful for frontend route configuration
 */
function getRequiredModuleForPath(path) {
    return getModuleForRoute(path);
}
/**
 * Check which modules are required for a set of routes
 */
function getRequiredModulesForRoutes(routes) {
    const modules = new Set();
    for (const route of routes) {
        const moduleId = getModuleForRoute(route);
        if (moduleId) {
            modules.add(moduleId);
        }
    }
    return Array.from(modules);
}
//# sourceMappingURL=moduleEntitlement.js.map