/**
 * @file InventoryService.ts
 * @purpose Manages inventory tracking, reservations, deductions, and reconciliation
 * @complexity high (atomic reservations, transaction logging, invariants enforcement)
 * @tested yes (92% coverage)
 * @last-change 2025-01-19 (added file annotation header)
 * @dependencies InventoryRepository, SKURepository, db.transaction
 * @domain inventory
 *
 * @description
 * Core inventory management with reservation system to prevent overselling.
 * All inventory modifications create transaction audit records.
 * Enforces invariants: inventory never negative, reserved ≤ total.
 *
 * @invariants
 * - Inventory quantity can never be negative
 * - Reserved quantity can never exceed total quantity
 * - All modifications create audit trail in inventory_transactions
 * - Reservations are atomic (no race conditions)
 *
 * @performance
 * - Uses SELECT FOR UPDATE to prevent race conditions
 * - Typical query time: ~30ms
 * - Transaction overhead: ~40ms for reservations
 *
 * @security
 * - All mutations require authentication
 * - Inventory checks prevent unauthorized access
 * - Audit trail tracks all changes by user
 *
 * @see {@link InventoryRepository} for data access methods
 * @see {@link OrderService} for reservation coordination
 * @see {@link packages/backend/src/db/schema.sql} for inventory table constraints
 */
import { InventoryUnit, TransactionType, InventoryTransaction } from '@opsui/shared';
export declare class InventoryService {
    getInventoryBySKU(sku: string): Promise<InventoryUnit[]>;
    getInventoryByBinLocation(binLocation: string): Promise<InventoryUnit[]>;
    getAvailableInventory(sku: string): Promise<Array<{
        binLocation: string;
        available: number;
    }>>;
    getTotalAvailable(sku: string): Promise<number>;
    reserveInventory(sku: string, binLocation: string, quantity: number, orderId: string): Promise<InventoryUnit>;
    releaseReservation(sku: string, binLocation: string, quantity: number, orderId: string): Promise<InventoryUnit>;
    deductInventory(sku: string, binLocation: string, quantity: number, orderId: string): Promise<InventoryUnit>;
    adjustInventory(sku: string, binLocation: string, quantity: number, userId: string, reason: string): Promise<InventoryUnit>;
    getTransactionHistory(filters?: {
        sku?: string;
        orderId?: string;
        type?: TransactionType;
        limit?: number;
        offset?: number;
    }): Promise<{
        transactions: InventoryTransaction[];
        total: number;
    }>;
    getLowStockAlerts(threshold?: number): Promise<Array<{
        sku: string;
        binLocation: string;
        available: number;
        quantity: number;
    }>>;
    reconcileInventory(sku: string): Promise<{
        expected: number;
        actual: number;
        discrepancies: Array<{
            binLocation: string;
            expected: number;
            actual: number;
            difference: number;
        }>;
    }>;
    getSKUWithInventory(sku: string): Promise<{
        sku: string;
        name: string;
        description: string;
        image: string | undefined;
        category: string;
        binLocations: string[];
        inventory: Array<{
            binLocation: string;
            quantity: number;
            available: number;
        }>;
    }>;
    searchSKUs(searchTerm: string): Promise<Array<{
        sku: string;
        name: string;
        category: string;
        barcode: string;
        binLocations: string[];
        unitPrice?: number;
        unitCost?: number;
        currency?: string;
        image?: string;
        description?: string;
        totalQuantity?: number;
        totalAvailable?: number;
        locationCount?: number;
    }>>;
    getAllSKUs(limit?: number): Promise<Array<{
        sku: string;
        name: string;
        category: string;
        barcode: string;
        binLocations: string[];
        unitPrice?: number;
        unitCost?: number;
        currency?: string;
        image?: string;
        description?: string;
        totalQuantity?: number;
        totalAvailable?: number;
        locationCount?: number;
    }>>;
    getCategories(): Promise<string[]>;
    getInventoryMetrics(): Promise<{
        totalSKUs: number;
        totalInventoryUnits: number;
        lowStockCount: number;
        outOfStockCount: number;
    }>;
}
export declare const inventoryService: InventoryService;
//# sourceMappingURL=InventoryService.d.ts.map