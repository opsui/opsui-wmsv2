/**
 * Interleaved Count Service
 *
 * Handles micro-counts performed during picking and other operations
 */
import { MicroCount, CreateMicroCountDTO } from '@opsui/shared';
export declare class InterleavedCountService {
    /**
     * Create a micro-count (quick count during picking)
     * This can create a new cycle count plan on-the-fly or add to an existing one
     */
    createMicroCount(dto: CreateMicroCountDTO): Promise<MicroCount>;
    /**
     * Get micro-count statistics for a user
     */
    getMicroCountStats(userId: string, days?: number): Promise<{
        totalMicroCounts: number;
        accurateCounts: number;
        varianceCounts: number;
        autoAdjustedCounts: number;
        averageAccuracy: number;
    }>;
    /**
     * Get applicable tolerance for an SKU/location
     */
    private getApplicableTolerance;
}
export declare const interleavedCountService: InterleavedCountService;
//# sourceMappingURL=InterleavedCountService.d.ts.map