/**
 * Projects Repository
 *
 * Data access layer for project management operations
 * Handles projects, tasks, milestones, time entries, expenses, billing, and resources
 */
import { BaseRepository } from './BaseRepository';
import type { Project, ProjectWithDetails, ProjectSummary, ProjectTask, ProjectTaskWithDetails, ProjectMilestone, ProjectTimeEntry, ProjectTimeEntryWithDetails, ProjectExpense, ProjectBudgetItem, ProjectBillingSchedule, ProjectResource, ProjectResourceWithDetails, ProjectIssue, ProjectQueryFilters, TimeEntryQueryFilters, ExpenseQueryFilters } from '@opsui/shared';
export declare class ProjectRepository extends BaseRepository<Project> {
    constructor();
    findByNumber(projectNumber: string): Promise<Project | null>;
    findByIdWithDetails(projectId: string): Promise<ProjectWithDetails | null>;
    getProjectSummary(projectId: string): Promise<ProjectSummary | null>;
    queryWithFilters(filters?: ProjectQueryFilters): Promise<Project[]>;
    softDelete(projectId: string): Promise<boolean>;
    updateActuals(projectId: string): Promise<void>;
}
export declare class ProjectTaskRepository extends BaseRepository<ProjectTask> {
    constructor();
    findByProjectId(projectId: string): Promise<ProjectTask[]>;
    findByIdWithDetails(taskId: string): Promise<ProjectTaskWithDetails | null>;
    findChildren(parentTaskId: string): Promise<ProjectTask[]>;
    findRootTasks(projectId: string): Promise<ProjectTask[]>;
    getGanttChartData(projectId: string): Promise<any[]>;
}
export declare class ProjectTimeEntryRepository extends BaseRepository<ProjectTimeEntry> {
    constructor();
    findByProjectId(projectId: string): Promise<ProjectTimeEntry[]>;
    findByEmployeeId(employeeId: string): Promise<ProjectTimeEntry[]>;
    findByIdWithDetails(timeEntryId: string): Promise<ProjectTimeEntryWithDetails | null>;
    queryWithFilters(filters?: TimeEntryQueryFilters): Promise<ProjectTimeEntry[]>;
    findPendingApprovals(projectId?: string): Promise<ProjectTimeEntry[]>;
    findUnbilled(projectId: string): Promise<ProjectTimeEntry[]>;
    batchApprove(timeEntryIds: string[], approved: boolean, approvedBy: string): Promise<void>;
}
export declare class ProjectExpenseRepository extends BaseRepository<ProjectExpense> {
    constructor();
    findByProjectId(projectId: string): Promise<ProjectExpense[]>;
    queryWithFilters(filters?: ExpenseQueryFilters): Promise<ProjectExpense[]>;
    findPendingApprovals(projectId?: string): Promise<ProjectExpense[]>;
    findUnbilled(projectId: string): Promise<ProjectExpense[]>;
    batchApprove(expenseIds: string[], approved: boolean, approvedBy: string, rejectionReason?: string): Promise<void>;
}
export declare class ProjectMilestoneRepository extends BaseRepository<ProjectMilestone> {
    constructor();
    findByProjectId(projectId: string): Promise<ProjectMilestone[]>;
    findPending(projectId?: string): Promise<ProjectMilestone[]>;
    findOverdue(): Promise<ProjectMilestone[]>;
    markAsComplete(milestoneId: string): Promise<ProjectMilestone | null>;
}
export declare class ProjectBudgetItemRepository extends BaseRepository<ProjectBudgetItem> {
    constructor();
    findByProjectId(projectId: string): Promise<ProjectBudgetItem[]>;
}
export declare class ProjectBillingScheduleRepository extends BaseRepository<ProjectBillingSchedule> {
    constructor();
    findByProjectId(projectId: string): Promise<ProjectBillingSchedule[]>;
    findPending(projectId?: string): Promise<ProjectBillingSchedule[]>;
    findOverdue(): Promise<ProjectBillingSchedule[]>;
    updateStatus(scheduleId: string, status: string, invoiceId?: string): Promise<boolean>;
}
export declare class ProjectResourceRepository extends BaseRepository<ProjectResource> {
    constructor();
    findByProjectId(projectId: string): Promise<ProjectResource[]>;
    findByIdWithDetails(resourceId: string): Promise<ProjectResourceWithDetails | null>;
    findByUserId(userId: string): Promise<ProjectResource[]>;
    findActive(projectId?: string): Promise<ProjectResource[]>;
    removeResource(resourceId: string): Promise<boolean>;
}
export declare class ProjectIssueRepository extends BaseRepository<ProjectIssue> {
    constructor();
    findByProjectId(projectId: string): Promise<ProjectIssue[]>;
    findOpen(projectId?: string): Promise<ProjectIssue[]>;
    findCritical(): Promise<ProjectIssue[]>;
}
export declare const projectsRepository: {
    projects: ProjectRepository;
    tasks: ProjectTaskRepository;
    timeEntries: ProjectTimeEntryRepository;
    expenses: ProjectExpenseRepository;
    milestones: ProjectMilestoneRepository;
    budgetItems: ProjectBudgetItemRepository;
    billingSchedule: ProjectBillingScheduleRepository;
    resources: ProjectResourceRepository;
    issues: ProjectIssueRepository;
};
//# sourceMappingURL=ProjectsRepository.d.ts.map