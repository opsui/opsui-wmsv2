"use strict";
/**
 * Winston logger configuration
 *
 * Provides structured logging with different levels and transports
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.logger = void 0;
const winston_1 = __importDefault(require("winston"));
// ============================================================================
// CONFIGURATION
// ============================================================================
const logLevel = (() => {
    const value = process.env.LOG_LEVEL;
    // eslint-disable-next-line @typescript-eslint/no-unnecessary-condition
    if (value !== undefined && value !== null) {
        const trimmed = value.trim();
        if (trimmed) {
            return trimmed;
        }
    }
    return 'info';
})();
const logFile = (() => {
    const value = process.env.LOG_FILE;
    // eslint-disable-next-line @typescript-eslint/no-unnecessary-condition
    if (value !== undefined && value !== null) {
        const trimmed = value.trim();
        if (trimmed) {
            return trimmed;
        }
    }
    return 'logs/wms.log';
})();
// Define log format
const logFormat = winston_1.default.format.combine(winston_1.default.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }), winston_1.default.format.errors({ stack: true }), winston_1.default.format.splat(), winston_1.default.format.json());
// Console format for development
const consoleFormat = winston_1.default.format.combine(winston_1.default.format.colorize(), winston_1.default.format.timestamp({ format: 'HH:mm:ss' }), winston_1.default.format.printf(({ timestamp, level, message, ...meta }) => {
    const ts = String(timestamp);
    const lvl = String(level);
    const msg = String(message);
    let result = `${ts} [${lvl}]: ${msg}`;
    if (Object.keys(meta).length > 0) {
        result += ` ${JSON.stringify(meta)}`;
    }
    return result;
}));
// ============================================================================
// LOGGER INSTANCE
// ============================================================================
const transports = [
    // Console transport
    new winston_1.default.transports.Console({
        format: process.env.NODE_ENV === 'production' ? logFormat : consoleFormat,
    }),
];
// File transport (only in production)
if (process.env.NODE_ENV === 'production') {
    transports.push(new winston_1.default.transports.File({
        filename: logFile,
        format: logFormat,
        maxsize: 10 * 1024 * 1024, // 10MB
        maxFiles: 5,
    }));
    // Error log file
    transports.push(new winston_1.default.transports.File({
        filename: 'logs/error.log',
        level: 'error',
        format: logFormat,
        maxsize: 10 * 1024 * 1024, // 10MB
        maxFiles: 5,
    }));
}
exports.logger = winston_1.default.createLogger({
    level: logLevel,
    format: logFormat,
    transports,
    exitOnError: false,
});
// ============================================================================
// CONVENIENCE METHODS
// ============================================================================
exports.default = {
    debug: (message, meta) => exports.logger.debug(message, meta),
    info: (message, meta) => exports.logger.info(message, meta),
    warn: (message, meta) => exports.logger.warn(message, meta),
    error: (message, meta) => exports.logger.error(message, meta),
    logger: exports.logger,
};
