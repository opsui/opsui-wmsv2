"use strict";
/**
 * OpenTelemetry Configuration and Instrumentation
 *
 * Provides distributed tracing and metrics instrumentation
 * for the Warehouse Management System.
 *
 * @see https://opentelemetry.io/docs/instrumentation/js/
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.errorsTotal = exports.inventoryTransactions = exports.picksCompleted = exports.ordersProcessed = exports.dbQueryDuration = exports.httpResponseSize = exports.httpRequestSize = exports.httpRequestDuration = void 0;
exports.initializeTelemetry = initializeTelemetry;
exports.withSpan = withSpan;
exports.addSpanAttributes = addSpanAttributes;
exports.addSpanEvent = addSpanEvent;
exports.recordException = recordException;
exports.createCounter = createCounter;
exports.createHistogram = createHistogram;
exports.createGauge = createGauge;
const sdk_node_1 = require("@opentelemetry/sdk-node");
const auto_instrumentations_node_1 = require("@opentelemetry/auto-instrumentations-node");
const exporter_trace_otlp_grpc_1 = require("@opentelemetry/exporter-trace-otlp-grpc");
const exporter_metrics_otlp_grpc_1 = require("@opentelemetry/exporter-metrics-otlp-grpc");
const sdk_metrics_1 = require("@opentelemetry/sdk-metrics");
const diag = __importStar(require("@opentelemetry/api"));
const config_1 = __importDefault(require("../config"));
// ============================================================================
// EXPORTERS
// ============================================================================
/**
 * Trace exporter - sends traces to OTLP collector (e.g., Jaeger, Tempo)
 */
const traceExporter = new exporter_trace_otlp_grpc_1.OTLPTraceExporter({
    url: config_1.default.otel.collectorUrl || 'http://localhost:4317',
    headers: {},
});
/**
 * Metrics exporter - sends metrics to OTLP collector (e.g., Prometheus)
 */
const metricExporter = new exporter_metrics_otlp_grpc_1.OTLPMetricExporter({
    url: config_1.default.otel.collectorUrl || 'http://localhost:4317',
    headers: {},
});
// ============================================================================
// METRICS READER
// ============================================================================
const metricReader = new sdk_metrics_1.PeriodicExportingMetricReader({
    exporter: metricExporter,
    exportIntervalMillis: 60000, // Export metrics every 60 seconds
    exportTimeoutMillis: 30000,
});
// ============================================================================
// OPENTELEMETRY SDK
// ============================================================================
/**
 * Initialize OpenTelemetry SDK
 * Call this before importing any other application code
 */
function initializeTelemetry() {
    const sdk = new sdk_node_1.NodeSDK({
        traceExporter,
        metricReader,
        instrumentations: [
            (0, auto_instrumentations_node_1.getNodeAutoInstrumentations)({
                // Disable some instrumentations if not needed
                '@opentelemetry/instrumentation-fs': {
                    enabled: false,
                },
            }),
        ],
    });
    // Initialize the SDK
    sdk.start();
    // Graceful shutdown
    process.on('SIGTERM', () => {
        sdk
            .shutdown()
            .then(() => console.log('OpenTelemetry shut down successfully'))
            .catch(error => console.error('Error shutting down OpenTelemetry', error));
    });
    console.log('OpenTelemetry initialized successfully');
    return sdk;
}
// ============================================================================
// TRACING UTILITIES
// ============================================================================
const tracer = diag.trace.getTracer('wms-backend', '1.0.0');
/**
 * Wrap an async function with a span
 */
async function withSpan(name, fn, attributes) {
    return tracer.startActiveSpan(name, async (span) => {
        try {
            if (attributes) {
                span.setAttributes(attributes);
            }
            const result = await fn(span);
            span.setStatus({ code: diag.SpanStatusCode.OK });
            return result;
        }
        catch (error) {
            span.recordException(error);
            span.setStatus({ code: diag.SpanStatusCode.ERROR, message: error.message });
            throw error;
        }
        finally {
            span.end();
        }
    });
}
/**
 * Add attributes to current span
 */
function addSpanAttributes(attributes) {
    try {
        const activeSpan = diag.trace.getActiveSpan();
        if (activeSpan) {
            activeSpan.setAttributes(attributes);
        }
    }
    catch (error) {
        // Silently fail - tracing should not break the application
        console.error('[OpenTelemetry] Failed to add span attributes:', error);
    }
}
/**
 * Add event to current span
 */
function addSpanEvent(name, attributes) {
    try {
        const activeSpan = diag.trace.getActiveSpan();
        if (activeSpan) {
            activeSpan.addEvent(name, attributes);
        }
    }
    catch (error) {
        // Silently fail - tracing should not break the application
        console.error('[OpenTelemetry] Failed to add span event:', error);
    }
}
/**
 * Record exception on current span
 */
function recordException(error) {
    try {
        const activeSpan = diag.trace.getActiveSpan();
        if (activeSpan) {
            activeSpan.recordException(error);
        }
    }
    catch (err) {
        // Silently fail - tracing should not break the application
        console.error('[OpenTelemetry] Failed to record exception:', err);
    }
}
// ============================================================================
// METRICS UTILITIES
// ============================================================================
const meter = diag.metrics.getMeter('wms-backend', '1.0.0');
/**
 * Create a counter metric
 */
function createCounter(name, options) {
    return meter.createCounter(name, {
        description: options?.description,
        unit: options?.unit || '1',
    });
}
/**
 * Create a histogram metric
 */
function createHistogram(name, options) {
    return meter.createHistogram(name, {
        description: options?.description,
        unit: options?.unit || 'ms',
    });
}
/**
 * Create a gauge metric
 */
function createGauge(name, options) {
    return meter.createObservableGauge(name, {
        description: options?.description,
        unit: options?.unit || '1',
    });
}
// ============================================================================
// PRE-DEFINED METRICS
// ============================================================================
// Request metrics
exports.httpRequestDuration = createHistogram('http_request_duration', {
    description: 'Duration of HTTP requests',
    unit: 'ms',
});
exports.httpRequestSize = createHistogram('http_request_size', {
    description: 'Size of HTTP requests',
    unit: 'By',
});
exports.httpResponseSize = createHistogram('http_response_size', {
    description: 'Size of HTTP responses',
    unit: 'By',
});
// Database metrics
exports.dbQueryDuration = createHistogram('db_query_duration', {
    description: 'Duration of database queries',
    unit: 'ms',
});
// Business metrics
exports.ordersProcessed = createCounter('orders_processed_total', {
    description: 'Total number of orders processed',
    unit: '1',
});
exports.picksCompleted = createCounter('picks_completed_total', {
    description: 'Total number of picks completed',
    unit: '1',
});
exports.inventoryTransactions = createCounter('inventory_transactions_total', {
    description: 'Total number of inventory transactions',
    unit: '1',
});
// Error metrics
exports.errorsTotal = createCounter('errors_total', {
    description: 'Total number of errors',
    unit: '1',
});
// ============================================================================
// EXPORTS
// ============================================================================
exports.default = {
    initializeTelemetry,
    withSpan,
    addSpanAttributes,
    addSpanEvent,
    recordException,
    createCounter,
    createHistogram,
    createGauge,
    httpRequestDuration: exports.httpRequestDuration,
    httpRequestSize: exports.httpRequestSize,
    httpResponseSize: exports.httpResponseSize,
    dbQueryDuration: exports.dbQueryDuration,
    ordersProcessed: exports.ordersProcessed,
    picksCompleted: exports.picksCompleted,
    inventoryTransactions: exports.inventoryTransactions,
    errorsTotal: exports.errorsTotal,
    tracer,
    meter,
};
//# sourceMappingURL=telemetry.js.map