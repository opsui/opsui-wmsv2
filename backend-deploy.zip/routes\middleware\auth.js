"use strict";
/**
 * Authentication and authorization middleware
 *
 * Handles JWT validation and role-based access control
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.authenticate = authenticate;
exports.authorize = authorize;
exports.requireAdmin = requireAdmin;
exports.requireSupervisor = requireSupervisor;
exports.requirePicker = requirePicker;
exports.generateToken = generateToken;
exports.generateRefreshToken = generateRefreshToken;
exports.verifyToken = verifyToken;
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const logger_1 = require("../config/logger");
const config_1 = __importDefault(require("../config"));
const shared_1 = require("@opsui/shared");
// ============================================================================
// AUTHENTICATION MIDDLEWARE
// ============================================================================
/**
 * Verify JWT token and attach user to request
 * Supports active role switching for multi-role users
 * TEST MODE: When config.testMode is true, requires special test API key
 */
function authenticate(req, _res, next) {
    try {
        // SECURITY: Test mode requires special X-Test-API-Key header for authenticated test requests
        // This prevents accidental exposure while allowing automated testing
        if (config_1.default.testMode && config_1.default.nodeEnv !== 'production') {
            const testApiKey = req.headers['x-test-api-key'];
            if (testApiKey === process.env.TEST_API_KEY) {
                // Verify test API key is set before using test mode
                if (!process.env.TEST_API_KEY) {
                    logger_1.logger.error('TEST MODE: TEST_API_KEY environment variable not set');
                    return next(new shared_1.UnauthorizedError('Test mode not properly configured'));
                }
                // Attach a mock admin user for testing
                req.user = {
                    userId: 'test-admin-user',
                    email: 'test@wms.local',
                    role: shared_1.UserRole.ADMIN,
                    baseRole: shared_1.UserRole.ADMIN,
                    activeRole: null,
                    effectiveRole: shared_1.UserRole.ADMIN,
                };
                logger_1.logger.debug('TEST MODE: Authentication via test API key');
                return next();
            }
            // If test API key is not provided, fall through to normal JWT authentication
        }
        // SECURITY: If testMode is enabled in production, log a critical security warning
        if (config_1.default.testMode && config_1.default.nodeEnv === 'production') {
            logger_1.logger.error('SECURITY CRITICAL: TEST_MODE is enabled in production! This is a security risk.');
        }
        // Get token from Authorization header
        const authHeader = req.headers.authorization;
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            throw new shared_1.UnauthorizedError('Missing or invalid Authorization header');
        }
        const token = authHeader.substring(7);
        // Verify token with proper type checking
        const decoded = jsonwebtoken_1.default.verify(token, config_1.default.jwt.secret);
        // Determine effective role (active role or base role)
        const effectiveRole = decoded.activeRole || decoded.role;
        // Attach user to request with all role information
        req.user = {
            userId: decoded.userId,
            email: decoded.email,
            role: effectiveRole,
            baseRole: decoded.role,
            activeRole: decoded.activeRole || null,
            effectiveRole: effectiveRole,
        };
        logger_1.logger.debug('User authenticated', {
            userId: decoded.userId,
            email: decoded.email,
            baseRole: decoded.role,
            activeRole: decoded.activeRole,
            effectiveRole,
        });
        next();
    }
    catch (error) {
        if (error instanceof jsonwebtoken_1.default.TokenExpiredError) {
            next(new shared_1.UnauthorizedError('Token expired'));
        }
        else if (error instanceof jsonwebtoken_1.default.JsonWebTokenError) {
            next(new shared_1.UnauthorizedError('Invalid token'));
        }
        else {
            next(error);
        }
    }
}
// ============================================================================
// AUTHORIZATION MIDDLEWARE
// ============================================================================
/**
 * Check if user has required role
 * ADMIN base role always has access regardless of effective role
 */
function authorize(...allowedRoles) {
    return (req, _res, next) => {
        if (!req.user) {
            return next(new shared_1.UnauthorizedError('User not authenticated'));
        }
        // ADMIN base role always has access to everything
        if (req.user.baseRole === shared_1.UserRole.ADMIN) {
            next();
            return;
        }
        if (!allowedRoles.includes(req.user.role)) {
            return next(new shared_1.ForbiddenError(`User role '${req.user.role}' not authorized for this resource`));
        }
        next();
    };
}
/**
 * Check if user is admin
 * ADMIN base role always has access regardless of effective role
 */
function requireAdmin(req, _res, next) {
    if (!req.user) {
        return next(new shared_1.UnauthorizedError('User not authenticated'));
    }
    // Check base role - admins with any active role should still have admin access
    if (req.user.baseRole !== shared_1.UserRole.ADMIN) {
        return next(new shared_1.ForbiddenError('Admin access required'));
    }
    next();
}
/**
 * Check if user is supervisor or admin
 */
function requireSupervisor(req, _res, next) {
    if (!req.user) {
        return next(new shared_1.UnauthorizedError('User not authenticated'));
    }
    if (req.user.role !== shared_1.UserRole.SUPERVISOR && req.user.role !== shared_1.UserRole.ADMIN) {
        return next(new shared_1.ForbiddenError('Supervisor or admin access required'));
    }
    next();
}
/**
 * Check if user is a picker
 */
function requirePicker(req, _res, next) {
    if (!req.user) {
        return next(new shared_1.UnauthorizedError('User not authenticated'));
    }
    if (req.user.role !== shared_1.UserRole.PICKER && req.user.role !== shared_1.UserRole.ADMIN) {
        return next(new shared_1.ForbiddenError('Picker access required'));
    }
    next();
}
// ============================================================================
// TOKEN GENERATION
// ============================================================================
/**
 * Generate JWT token for user
 */
function generateToken(user) {
    const effectiveRole = user.activeRole || user.role;
    const payload = {
        userId: user.userId,
        email: user.email,
        role: user.role,
        baseRole: user.role,
        activeRole: user.activeRole,
        effectiveRole: effectiveRole,
    };
    return jsonwebtoken_1.default.sign(payload, config_1.default.jwt.secret, {
        expiresIn: config_1.default.jwt.expiresIn,
    });
}
/**
 * Generate refresh token (longer-lived)
 */
function generateRefreshToken(user) {
    const effectiveRole = user.activeRole || user.role;
    const payload = {
        userId: user.userId,
        email: user.email,
        role: user.role,
        baseRole: user.role,
        activeRole: user.activeRole,
        effectiveRole: effectiveRole,
    };
    return jsonwebtoken_1.default.sign(payload, config_1.default.jwt.secret, {
        expiresIn: config_1.default.jwt.refreshExpiresIn,
    });
}
/**
 * Verify and decode JWT token
 */
function verifyToken(token) {
    return jsonwebtoken_1.default.verify(token, config_1.default.jwt.secret);
}
