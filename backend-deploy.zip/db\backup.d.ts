/**
 * Database Backup Utility
 *
 * Creates JSON backups of database data
 */
/**
 * Create a backup of all database data
 */
export declare function createBackup(backupName?: string): Promise<string>;
/**
 * Restore database from a backup file
 */
export declare function restoreBackup(backupPath: string): Promise<void>;
/**
 * List all available backups
 */
export declare function listBackups(): Promise<string[]>;
declare function main(): Promise<void>;
export { main as backupCli };
//# sourceMappingURL=backup.d.ts.map