/**
 * Recurring Schedules Routes
 *
 * API endpoints for managing automated recurring cycle count schedules
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=recurringSchedules.d.ts.map