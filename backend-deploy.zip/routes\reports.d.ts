/**
 * Reports API Routes
 *
 * REST API for managing reports, executions, dashboards, and exports.
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=reports.d.ts.map