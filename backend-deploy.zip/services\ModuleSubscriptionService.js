"use strict";
/**
 * Module Subscription Service
 *
 * Manages module subscriptions per entity for modular ERP pricing
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.invalidateModuleCache = invalidateModuleCache;
exports.isModuleEnabled = isModuleEnabled;
exports.getEnabledModules = getEnabledModules;
exports.areModulesEnabled = areModulesEnabled;
exports.getModulesWithStatus = getModulesWithStatus;
exports.getEntityUserTier = getEntityUserTier;
exports.setEntityUserTier = setEntityUserTier;
exports.updateUserCount = updateUserCount;
exports.enableModule = enableModule;
exports.disableModule = disableModule;
exports.updateModuleSubscription = updateModuleSubscription;
exports.getEntityBillingSummary = getEntityBillingSummary;
exports.enableAddon = enableAddon;
exports.disableAddon = disableAddon;
exports.enableModules = enableModules;
exports.getModuleAuditLog = getModuleAuditLog;
const client_1 = require("../db/client");
const shared_1 = require("@opsui/shared");
// ============================================================================
// IN-MEMORY CACHE
// ============================================================================
// Cache: entityId -> Set of enabled moduleIds
const moduleCache = new Map();
// Cache: entityId -> user tier
const tierCache = new Map();
let cacheInitialized = false;
/**
 * Initialize cache from database
 */
async function initializeCache() {
    if (cacheInitialized)
        return;
    const pool = (0, client_1.getPool)();
    // Load all active module subscriptions
    const modulesResult = await pool.query(`
    SELECT entity_id, module_id
    FROM module_subscriptions
    WHERE subscription_status IN ('ACTIVE', 'TRIAL')
      AND (subscription_end IS NULL OR subscription_end >= CURRENT_DATE)
  `);
    moduleCache.clear();
    for (const row of modulesResult.rows) {
        const entityId = row.entity_id;
        const moduleId = row.module_id;
        if (!moduleCache.has(entityId)) {
            moduleCache.set(entityId, new Set());
        }
        moduleCache.get(entityId).add(moduleId);
    }
    // Load all user tiers
    const tiersResult = await pool.query('SELECT * FROM entity_user_tiers');
    tierCache.clear();
    for (const row of tiersResult.rows) {
        tierCache.set(row.entity_id, row);
    }
    cacheInitialized = true;
}
/**
 * Invalidate cache (call after database updates)
 */
function invalidateModuleCache() {
    cacheInitialized = false;
    moduleCache.clear();
    tierCache.clear();
}
// ============================================================================
// MODULE CHECKING FUNCTIONS
// ============================================================================
/**
 * Check if a module is enabled for an entity
 */
async function isModuleEnabled(entityId, moduleId) {
    await initializeCache();
    const entityModules = moduleCache.get(entityId);
    if (!entityModules)
        return false;
    return entityModules.has(moduleId);
}
/**
 * Get all enabled modules for an entity
 */
async function getEnabledModules(entityId) {
    await initializeCache();
    const entityModules = moduleCache.get(entityId);
    if (!entityModules)
        return [];
    return Array.from(entityModules);
}
/**
 * Check if multiple modules are enabled
 */
async function areModulesEnabled(entityId, moduleIds) {
    await initializeCache();
    const entityModules = moduleCache.get(entityId);
    return moduleIds.reduce((acc, moduleId) => {
        acc[moduleId] = entityModules?.has(moduleId) ?? false;
        return acc;
    }, {});
}
/**
 * Get module definitions with enabled status for an entity
 */
async function getModulesWithStatus(entityId) {
    const pool = (0, client_1.getPool)();
    // Get all enabled modules
    const enabledModules = await getEnabledModules(entityId);
    // Get subscription details
    const subscriptionsResult = await pool.query(`SELECT * FROM module_subscriptions WHERE entity_id = $1`, [entityId]);
    const subscriptionMap = new Map();
    for (const row of subscriptionsResult.rows) {
        subscriptionMap.set(row.module_id, row);
    }
    // Build result
    return Object.values(shared_1.MODULE_DEFINITIONS).map(module => ({
        ...module,
        isEnabled: enabledModules.includes(module.id),
        subscription: subscriptionMap.get(module.id),
    }));
}
// ============================================================================
// USER TIER FUNCTIONS
// ============================================================================
/**
 * Get the user tier for an entity
 */
async function getEntityUserTier(entityId) {
    await initializeCache();
    return tierCache.get(entityId) || null;
}
/**
 * Set the user tier for an entity
 */
async function setEntityUserTier(entityId, tierId, userId) {
    const pool = (0, client_1.getPool)();
    const tier = shared_1.USER_TIERS[tierId];
    if (!tier) {
        throw new Error(`Invalid tier ID: ${tierId}`);
    }
    // Check if entity exists
    const entityCheck = await pool.query('SELECT entity_id FROM entities WHERE entity_id = $1', [
        entityId,
    ]);
    if (entityCheck.rows.length === 0) {
        throw new Error(`Entity not found: ${entityId}`);
    }
    // Upsert the tier
    const result = await pool.query(`INSERT INTO entity_user_tiers (
      tier_assignment_id, entity_id, tier_id, monthly_fee, effective_date, max_user_count
    )
    VALUES ($1, $2, $3, $4, CURRENT_DATE, $5)
    ON CONFLICT (entity_id) DO UPDATE SET
      tier_id = $3,
      monthly_fee = $4,
      effective_date = CURRENT_DATE,
      max_user_count = $5,
      updated_at = NOW()
    RETURNING *`, [`UT-${entityId.slice(-5)}`, entityId, tierId, tier.monthlyFee, tier.maxUsers]);
    invalidateModuleCache();
    return result.rows[0];
}
/**
 * Update user count for an entity's tier
 */
async function updateUserCount(entityId) {
    const pool = (0, client_1.getPool)();
    // Count active users for entity
    const countResult = await pool.query(`SELECT COUNT(DISTINCT user_id) as count
     FROM entity_users
     WHERE entity_id = $1 AND is_active = true`, [entityId]);
    const userCount = parseInt(countResult.rows[0].count, 10);
    // Update the tier record
    await pool.query(`UPDATE entity_user_tiers
     SET current_user_count = $1, updated_at = NOW()
     WHERE entity_id = $2`, [userCount, entityId]);
    invalidateModuleCache();
    return userCount;
}
// ============================================================================
// SUBSCRIPTION MANAGEMENT
// ============================================================================
/**
 * Enable a module for an entity
 */
async function enableModule(dto) {
    const pool = (0, client_1.getPool)();
    // Validate module exists
    const moduleDef = shared_1.MODULE_DEFINITIONS[dto.moduleId];
    if (!moduleDef) {
        throw new Error(`Invalid module ID: ${dto.moduleId}`);
    }
    // Check dependencies
    const enabledModules = await getEnabledModules(dto.entityId);
    if (!(0, shared_1.areDependenciesSatisfied)(dto.moduleId, enabledModules)) {
        const unsatisfied = (0, shared_1.getUnsatisfiedDependencies)(dto.moduleId, enabledModules);
        throw new Error(`Cannot enable module '${dto.moduleId}'. The following dependencies are not satisfied: ${unsatisfied.join(', ')}`);
    }
    // Determine price
    const price = dto.customPrice ??
        (dto.billingCycle === 'ANNUAL' ? moduleDef.pricing.annual : moduleDef.pricing.monthly);
    // Generate subscription ID
    const subscriptionId = `MS-${Date.now().toString(36).toUpperCase()}`;
    const result = await pool.query(`INSERT INTO module_subscriptions (
      subscription_id, entity_id, module_id, billing_cycle, price_per_period,
      discount_percentage, subscription_status, subscription_start, subscription_end,
      notes, created_by
    )
    VALUES ($1, $2, $3, $4, $5, $6, 'ACTIVE', $7, $8, $9, $10)
    ON CONFLICT (entity_id, module_id) DO UPDATE SET
      billing_cycle = $4,
      price_per_period = $5,
      discount_percentage = $6,
      subscription_status = 'ACTIVE',
      subscription_start = $7,
      subscription_end = $8,
      notes = $9,
      updated_at = NOW()
    RETURNING *`, [
        subscriptionId,
        dto.entityId,
        dto.moduleId,
        dto.billingCycle,
        price,
        dto.discountPercentage ?? 0,
        dto.startDate ?? new Date(),
        dto.endDate ?? null,
        dto.notes ?? null,
        dto.createdBy ?? null,
    ]);
    // Log audit
    await pool.query(`INSERT INTO module_audit_log (audit_id, entity_id, module_id, action, new_values, user_id)
     VALUES ($1, $2, $3, 'MODULE_ENABLED', $4, $5)`, [
        `MAL-${Date.now().toString(36).toUpperCase()}`,
        dto.entityId,
        dto.moduleId,
        JSON.stringify(result.rows[0]),
        dto.createdBy,
    ]);
    invalidateModuleCache();
    return result.rows[0];
}
/**
 * Disable a module for an entity
 */
async function disableModule(entityId, moduleId, userId, reason) {
    const pool = (0, client_1.getPool)();
    // Check if other modules depend on this one
    const enabledModules = await getEnabledModules(entityId);
    const dependentModules = [];
    for (const enabledModuleId of enabledModules) {
        const moduleDef = shared_1.MODULE_DEFINITIONS[enabledModuleId];
        if (moduleDef?.dependencies?.includes(moduleId)) {
            dependentModules.push(enabledModuleId);
        }
    }
    if (dependentModules.length > 0) {
        throw new Error(`Cannot disable module '${moduleId}'. The following modules depend on it: ${dependentModules.join(', ')}. Disable them first.`);
    }
    const result = await pool.query(`UPDATE module_subscriptions
     SET subscription_status = 'CANCELLED',
         subscription_end = CURRENT_DATE,
         notes = COALESCE($3, notes),
         updated_at = NOW()
     WHERE entity_id = $1 AND module_id = $2
     RETURNING *`, [entityId, moduleId, reason]);
    if (result.rows.length === 0) {
        throw new Error(`Module subscription not found: ${moduleId} for entity ${entityId}`);
    }
    // Log audit
    await pool.query(`INSERT INTO module_audit_log (audit_id, entity_id, module_id, action, old_values, user_id)
     VALUES ($1, $2, $3, 'MODULE_DISABLED', $4, $5)`, [
        `MAL-${Date.now().toString(36).toUpperCase()}`,
        entityId,
        moduleId,
        JSON.stringify(result.rows[0]),
        userId,
    ]);
    invalidateModuleCache();
}
/**
 * Update a module subscription
 */
async function updateModuleSubscription(entityId, moduleId, updates, userId) {
    const pool = (0, client_1.getPool)();
    const setClauses = ['updated_at = NOW()'];
    const values = [];
    let paramIndex = 1;
    if (updates.billingCycle !== undefined) {
        setClauses.push(`billing_cycle = $${paramIndex++}`);
        values.push(updates.billingCycle);
    }
    if (updates.pricePerPeriod !== undefined) {
        setClauses.push(`price_per_period = $${paramIndex++}`);
        values.push(updates.pricePerPeriod);
    }
    if (updates.discountPercentage !== undefined) {
        setClauses.push(`discount_percentage = $${paramIndex++}`);
        values.push(updates.discountPercentage);
    }
    if (updates.subscriptionStatus !== undefined) {
        setClauses.push(`subscription_status = $${paramIndex++}`);
        values.push(updates.subscriptionStatus);
    }
    if (updates.subscriptionEnd !== undefined) {
        setClauses.push(`subscription_end = $${paramIndex++}`);
        values.push(updates.subscriptionEnd);
    }
    if (updates.autoRenew !== undefined) {
        setClauses.push(`auto_renew = $${paramIndex++}`);
        values.push(updates.autoRenew);
    }
    if (updates.notes !== undefined) {
        setClauses.push(`notes = $${paramIndex++}`);
        values.push(updates.notes);
    }
    values.push(entityId, moduleId);
    const result = await pool.query(`UPDATE module_subscriptions
     SET ${setClauses.join(', ')}
     WHERE entity_id = $${paramIndex++} AND module_id = $${paramIndex++}
     RETURNING *`, values);
    if (result.rows.length === 0) {
        throw new Error(`Module subscription not found: ${moduleId} for entity ${entityId}`);
    }
    // Log audit
    await pool.query(`INSERT INTO module_audit_log (audit_id, entity_id, module_id, action, old_values, new_values, user_id)
     VALUES ($1, $2, $3, 'BILLING_UPDATED', $4, $5, $6)`, [
        `MAL-${Date.now().toString(36).toUpperCase()}`,
        entityId,
        moduleId,
        JSON.stringify({}),
        JSON.stringify(result.rows[0]),
        userId,
    ]);
    invalidateModuleCache();
    return result.rows[0];
}
// ============================================================================
// BILLING CALCULATIONS
// ============================================================================
/**
 * Get billing summary for an entity
 */
async function getEntityBillingSummary(entityId) {
    const pool = (0, client_1.getPool)();
    // Get enabled modules
    const modules = await getModulesWithStatus(entityId);
    const enabledModules = modules.filter(m => m.isEnabled);
    // Get user tier
    const userTier = await getEntityUserTier(entityId);
    const tierInfo = userTier ? shared_1.USER_TIERS[userTier.tier_id] : shared_1.USER_TIERS['tier-1-5'];
    // Get addons
    const addonsResult = await pool.query(`SELECT * FROM addon_subscriptions WHERE entity_id = $1 AND is_active = true`, [entityId]);
    const addons = addonsResult.rows.map(row => ({
        addonId: row.addon_id,
        monthlyFee: parseFloat(row.monthly_fee),
        isActive: row.is_active,
    }));
    // Calculate totals - convert to monthly equivalent
    const monthlyModuleTotal = enabledModules.reduce((sum, m) => {
        let price;
        if (m.subscription?.price_per_period) {
            // If there's a subscription, check the billing cycle
            if (m.subscription.billing_cycle === 'ANNUAL') {
                // Annual price - convert to monthly equivalent
                price = m.subscription.price_per_period / 12;
            }
            else {
                // Monthly price (or TRIAL/CUSTOM)
                price = m.subscription.price_per_period;
            }
        }
        else {
            // No subscription - use module definition pricing
            price = m.pricing.monthly;
        }
        return sum + price;
    }, 0);
    const addonMonthlyTotal = addons.reduce((sum, a) => sum + a.monthlyFee, 0);
    const totalMonthly = monthlyModuleTotal + tierInfo.monthlyFee + addonMonthlyTotal;
    // Calculate annual total - sum of actual annual prices where applicable
    const annualModuleTotal = enabledModules.reduce((sum, m) => {
        let price;
        if (m.subscription?.price_per_period) {
            if (m.subscription.billing_cycle === 'ANNUAL') {
                // Already annual price
                price = m.subscription.price_per_period;
            }
            else {
                // Monthly price - convert to annual
                price = m.subscription.price_per_period * 12;
            }
        }
        else {
            // Use annual pricing from definition
            price = m.pricing.annual;
        }
        return sum + price;
    }, 0);
    const annualTierTotal = tierInfo.monthlyFee * 12;
    const annualAddonTotal = addonMonthlyTotal * 12;
    const totalAnnual = annualModuleTotal + annualTierTotal + annualAddonTotal;
    return {
        entityId,
        enabledModules: enabledModules.map(m => ({
            moduleId: m.id,
            moduleName: m.name,
            pricePerPeriod: m.subscription?.price_per_period ?? m.pricing.monthly,
            billingCycle: m.subscription?.billing_cycle ?? 'MONTHLY',
            status: m.subscription?.subscription_status ?? 'ACTIVE',
        })),
        userTier: {
            tierId: userTier?.tier_id ?? 'tier-1-5',
            tierName: tierInfo.name,
            monthlyFee: tierInfo.monthlyFee,
            currentUserCount: userTier?.current_user_count ?? 0,
            maxUserCount: tierInfo.maxUsers,
        },
        addons,
        totals: {
            monthly: Math.round(totalMonthly * 100) / 100,
            annual: Math.round(totalAnnual * 100) / 100,
            currency: 'USD',
        },
    };
}
// ============================================================================
// ADDON MANAGEMENT
// ============================================================================
/**
 * Enable an addon for an entity
 */
async function enableAddon(entityId, addonId, userId) {
    const pool = (0, client_1.getPool)();
    const addonSubscriptionId = `AS-${Date.now().toString(36).toUpperCase()}`;
    // Get addon pricing from shared types would require importing ADD_ON_SERVICES
    // For now, use placeholder values that should be updated
    const oneTimeFee = 0;
    const monthlyFee = 0;
    const result = await pool.query(`INSERT INTO addon_subscriptions (
      addon_subscription_id, entity_id, addon_id, one_time_fee, monthly_fee, is_active
    )
    VALUES ($1, $2, $3, $4, $5, true)
    ON CONFLICT (entity_id, addon_id) DO UPDATE SET
      is_active = true,
      updated_at = NOW()
    RETURNING *`, [addonSubscriptionId, entityId, addonId, oneTimeFee, monthlyFee]);
    return result.rows[0];
}
/**
 * Disable an addon for an entity
 */
async function disableAddon(entityId, addonId) {
    const pool = (0, client_1.getPool)();
    await pool.query(`UPDATE addon_subscriptions
     SET is_active = false, updated_at = NOW()
     WHERE entity_id = $1 AND addon_id = $2`, [entityId, addonId]);
}
// ============================================================================
// BULK OPERATIONS
// ============================================================================
/**
 * Enable multiple modules at once (for bundles)
 */
async function enableModules(dto) {
    const results = [];
    // Sort modules by dependencies
    const sortedModules = sortModulesByDependencies(dto.moduleIds);
    for (const moduleId of sortedModules) {
        const subscription = await enableModule({
            ...dto,
            moduleId,
        });
        results.push(subscription);
    }
    return results;
}
/**
 * Sort modules so dependencies come first
 */
function sortModulesByDependencies(moduleIds) {
    const sorted = [];
    const remaining = new Set(moduleIds);
    while (remaining.size > 0) {
        let addedAny = false;
        for (const moduleId of remaining) {
            const moduleDef = shared_1.MODULE_DEFINITIONS[moduleId];
            const dependencies = moduleDef?.dependencies ?? [];
            // Check if all dependencies are either already sorted or not in the input
            const canAdd = dependencies.every(dep => sorted.includes(dep) || !moduleIds.includes(dep));
            if (canAdd) {
                sorted.push(moduleId);
                remaining.delete(moduleId);
                addedAny = true;
            }
        }
        // If no modules were added, there's a circular dependency or all deps are external
        if (!addedAny && remaining.size > 0) {
            // Add remaining modules anyway
            for (const moduleId of remaining) {
                sorted.push(moduleId);
            }
            break;
        }
    }
    return sorted;
}
/**
 * Get audit log for an entity
 */
async function getModuleAuditLog(entityId, limit = 50) {
    const pool = (0, client_1.getPool)();
    const result = await pool.query(`SELECT audit_id, module_id, action, old_values, new_values, user_id, created_at
     FROM module_audit_log
     WHERE entity_id = $1
     ORDER BY created_at DESC
     LIMIT $2`, [entityId, limit]);
    return result.rows;
}
//# sourceMappingURL=ModuleSubscriptionService.js.map