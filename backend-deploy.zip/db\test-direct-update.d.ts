/**
 * Test direct database update of current_view
 *
 * This bypasses the API and directly updates the database to verify
 * that the issue is in the API/frontend layer, not the database.
 */
export {};
//# sourceMappingURL=test-direct-update.d.ts.map