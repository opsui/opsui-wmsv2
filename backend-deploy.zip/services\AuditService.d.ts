/**
 * Audit Service - SOC2/ISO27001 Compliant Audit Logging
 *
 * Provides comprehensive audit trail for:
 * - User authentication and authorization changes
 * - Data access and modifications
 * - Configuration changes
 * - Security events
 * - Admin actions
 *
 * Features:
 * - Immutable audit trail (records cannot be deleted or modified)
 * - Automatic retention management
 * - Structured event types and categories
 * - Integration with OpenTelemetry for distributed tracing
 *
 * @see https://www.aicpa.org/soc4so
 * @see https://www.iso.org/standard/27001
 */
/**
 * Audit event categories for organizing audit logs
 */
export declare enum AuditCategory {
    AUTHENTICATION = "AUTHENTICATION",
    AUTHORIZATION = "AUTHORIZATION",
    USER_MANAGEMENT = "USER_MANAGEMENT",
    DATA_ACCESS = "DATA_ACCESS",
    DATA_MODIFICATION = "DATA_MODIFICATION",
    CONFIGURATION = "CONFIGURATION",
    SECURITY = "SECURITY",
    API_ACCESS = "API_ACCESS",
    SYSTEM = "SYSTEM"
}
/**
 * Specific audit event types for detailed tracking
 */
export declare enum AuditEventType {
    LOGIN_SUCCESS = "LOGIN_SUCCESS",
    LOGIN_FAILED = "LOGIN_FAILED",
    LOGOUT = "LOGOUT",
    PASSWORD_CHANGE = "PASSWORD_CHANGE",
    PASSWORD_RESET = "PASSWORD_RESET",
    MFA_ENABLED = "MFA_ENABLED",
    MFA_DISABLED = "MFA_DISABLED",
    ROLE_GRANTED = "ROLE_GRANTED",
    ROLE_REVOKED = "ROLE_REVOKED",
    PERMISSION_GRANTED = "PERMISSION_GRANTED",
    PERMISSION_REVOKED = "PERMISSION_REVOKED",
    CUSTOM_ROLE_CREATED = "CUSTOM_ROLE_CREATED",
    CUSTOM_ROLE_UPDATED = "CUSTOM_ROLE_UPDATED",
    CUSTOM_ROLE_DELETED = "CUSTOM_ROLE_DELETED",
    USER_CREATED = "USER_CREATED",
    USER_UPDATED = "USER_UPDATED",
    USER_DELETED = "USER_DELETED",
    USER_REACTIVATED = "USER_REACTIVATED",
    USER_DEACTIVATED = "USER_DEACTIVATED",
    ORDER_VIEWED = "ORDER_VIEWED",
    ORDERS_EXPORTED = "ORDERS_EXPORTED",
    INVENTORY_VIEWED = "INVENTORY_VIEWED",
    INVENTORY_EXPORTED = "INVENTORY_EXPORTED",
    REPORT_GENERATED = "REPORT_GENERATED",
    ORDER_CREATED = "ORDER_CREATED",
    ORDER_UPDATED = "ORDER_UPDATED",
    ORDER_CANCELLED = "ORDER_CANCELLED",
    ORDER_CLAIMED = "ORDER_CLAIMED",
    ORDER_UNCLAIMED = "ORDER_UNCLAIMED",
    ORDER_CONTINUED = "ORDER_CONTINUED",
    INVENTORY_ADJUSTED = "INVENTORY_ADJUSTED",
    ITEM_SCANNED = "ITEM_SCANNED",
    PICK_CONFIRMED = "PICK_CONFIRMED",
    PACK_COMPLETED = "PACK_COMPLETED",
    WAVE_CREATED = "WAVE_CREATED",
    WAVE_RELEASED = "WAVE_RELEASED",
    WAVE_COMPLETED = "WAVE_COMPLETED",
    SLOTTING_IMPLEMENTED = "SLOTTING_IMPLEMENTED",
    ZONE_ASSIGNED = "ZONE_ASSIGNED",
    ZONE_RELEASED = "ZONE_RELEASED",
    ZONE_REBALANCED = "ZONE_REBALANCED",
    PUTAWAY_COMPLETED = "PUTAWAY_COMPLETED",
    CYCLE_COUNT_PLAN_CREATED = "CYCLE_COUNT_PLAN_CREATED",
    CYCLE_COUNT_STARTED = "CYCLE_COUNT_STARTED",
    CYCLE_COUNT_COMPLETED = "CYCLE_COUNT_COMPLETED",
    CYCLE_COUNT_RECONCILED = "CYCLE_COUNT_RECONCILED",
    BIN_LOCATION_CREATED = "BIN_LOCATION_CREATED",
    BIN_LOCATION_UPDATED = "BIN_LOCATION_UPDATED",
    BIN_LOCATION_DELETED = "BIN_LOCATION_DELETED",
    CONFIG_UPDATED = "CONFIG_UPDATED",
    FEATURE_FLAG_CHANGED = "FEATURE_FLAG_CHANGED",
    RATE_LIMIT_CHANGED = "RATE_LIMIT_CHANGED",
    SUSPICIOUS_ACTIVITY = "SUSPICIOUS_ACTIVITY",
    RATE_LIMIT_EXCEEDED = "RATE_LIMIT_EXCEEDED",
    UNAUTHORIZED_ACCESS_ATTEMPT = "UNAUTHORIZED_ACCESS_ATTEMPT",
    CSRF_DETECTED = "CSRF_DETECTED",
    API_KEY_CREATED = "API_KEY_CREATED",
    API_KEY_DELETED = "API_KEY_DELETED",
    WEBHOOK_CONFIGURED = "WEBHOOK_CONFIGURED",
    SYSTEM_BACKUP = "SYSTEM_BACKUP",
    SYSTEM_RESTORE = "SYSTEM_RESTORE",
    MAINTENANCE_MODE = "MAINTENANCE_MODE",
    API_ACCESS = "API_ACCESS"
}
/**
 * Audit log entry structure
 * Matches the database schema from migration 008_create_audit_logs.sql
 */
export interface AuditLog {
    id?: number;
    auditId?: string;
    occurredAt?: Date;
    userId: string | null;
    userEmail?: string | null;
    userRole?: string | null;
    sessionId?: string | null;
    actionType: AuditEventType;
    actionCategory: AuditCategory;
    resourceType?: string | null;
    resourceId?: string | null;
    actionDescription: string;
    oldValues?: Record<string, unknown> | null;
    newValues?: Record<string, unknown> | null;
    changedFields?: string[] | null;
    ipAddress?: string | null;
    userAgent?: string | null;
    requestId?: string | null;
    correlationId?: string | null;
    status?: 'SUCCESS' | 'FAILURE' | 'PARTIAL';
    errorCode?: string | null;
    errorMessage?: string | null;
    metadata?: Record<string, unknown> | null;
    retentionUntil?: Date;
}
/**
 * Query options for filtering audit logs
 */
export interface AuditQueryOptions {
    userId?: string;
    username?: string;
    category?: AuditCategory;
    action?: AuditEventType;
    resourceType?: string;
    resourceId?: string;
    startDate?: Date;
    endDate?: Date;
    limit?: number;
    offset?: number;
}
/**
 * Get the singleton audit service instance
 */
export declare function getAuditService(): AuditService;
/**
 * Main Audit Service class
 *
 * Thread-safe audit logging with OpenTelemetry integration
 */
export declare class AuditService {
    private pool;
    private isInitialized;
    constructor();
    /**
     * Initialize audit service
     * Creates table if not exists and sets up retention policy
     */
    initialize(): Promise<void>;
    /**
     * Log an audit event
     *
     * @param auditLog - The audit log entry to record
     * @returns The created audit log ID
     */
    log(auditLog: AuditLog): Promise<number>;
    /**
     * Query audit logs with filters
     *
     * @param options - Query filters and pagination
     * @returns Array of audit logs
     */
    query(options?: AuditQueryOptions): Promise<AuditLog[]>;
    /**
     * Get audit log by ID
     *
     * @param id - Audit log ID
     * @returns The audit log or null if not found
     */
    getById(id: number): Promise<AuditLog | null>;
    /**
     * Get audit history for a specific resource
     *
     * @param resourceType - Type of resource (e.g., 'order', 'user')
     * @param resourceId - ID of the resource
     * @param limit - Maximum number of records to return
     * @returns Array of audit logs for the resource
     */
    getResourceHistory(resourceType: string, resourceId: string, limit?: number): Promise<AuditLog[]>;
    /**
     * Get user activity history
     *
     * @param userId - User ID (string)
     * @param limit - Maximum number of records to return
     * @returns Array of audit logs for the user
     */
    getUserActivity(userId: string, limit?: number): Promise<AuditLog[]>;
    /**
     * Get security events (failed logins, suspicious activity, etc.)
     *
     * @param startDate - Start date for query (default: 7 days ago)
     * @param endDate - End date for query (default: now)
     * @returns Array of security-related audit logs
     */
    getSecurityEvents(startDate?: Date, endDate?: Date): Promise<AuditLog[]>;
    /**
     * Get audit statistics
     *
     * @param startDate - Start date for statistics (default: 30 days ago)
     * @param endDate - End date for statistics (default: now)
     * @returns Statistics object with counts by category and action
     */
    getStatistics(startDate?: Date, endDate?: Date): Promise<{
        totalLogs: number;
        byCategory: Record<string, number>;
        byAction: Record<string, number>;
        topUsers: Array<{
            userEmail: string;
            count: number;
        }>;
    }>;
    /**
     * Log authentication event
     */
    logAuth(actionType: AuditEventType, userId: string | null, userEmail: string | null, ipAddress: string | null, userAgent: string | null, description: string, metadata?: Record<string, unknown>): Promise<number>;
    /**
     * Log authorization/role change event
     */
    logAuthorization(actionType: AuditEventType, userId: string | null, userEmail: string | null, userRole: string | null, resourceType: string, resourceId: string | null, description: string, oldValues?: Record<string, unknown>, newValues?: Record<string, unknown>, metadata?: Record<string, unknown> | null, ipAddress?: string | null, userAgent?: string | null): Promise<number>;
    /**
     * Log data modification event
     */
    logDataModification(actionType: AuditEventType, userId: string | null, userEmail: string | null, resourceType: string, resourceId: string | null, description: string, oldValues?: Record<string, unknown>, newValues?: Record<string, unknown>, ipAddress?: string | null, userAgent?: string | null): Promise<number>;
    /**
     * Log security event
     */
    logSecurityEvent(actionType: AuditEventType, description: string, ipAddress: string | null, userAgent: string | null, metadata?: Record<string, unknown>): Promise<number>;
    /**
     * Get current OpenTelemetry trace ID if available
     * Safely handles cases where telemetry is not available
     */
    private getCurrentTraceId;
    /**
     * Clean up old audit logs based on retention policy
     * This should be called by a scheduled job
     *
     * @param retentionDays - Number of days to retain logs (default: 90 days)
     * @returns Number of logs deleted
     */
    cleanupOldLogs(retentionDays?: number): Promise<number>;
}
export default AuditService;
//# sourceMappingURL=AuditService.d.ts.map