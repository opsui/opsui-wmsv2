"use strict";
/**
 * Automation routes
 *
 * Endpoints for ASRS, robots, drones, and other automation systems integration
 */
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const AutomationService_1 = require("../services/AutomationService");
const middleware_1 = require("../middleware");
const shared_1 = require("@opsui/shared");
const router = (0, express_1.Router)();
// All automation routes require authentication
router.use(middleware_1.authenticate);
/**
 * POST /api/automation/tasks
 * Create an automation task
 */
router.post('/tasks', (0, middleware_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR, shared_1.UserRole.STOCK_CONTROLLER), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { taskType, assignedTo, priority, location, sku, quantity, metadata } = req.body;
    // Validate required fields
    if (!taskType || !assignedTo || priority === undefined || !location) {
        res.status(400).json({
            error: 'Missing required fields',
            code: 'MISSING_FIELDS',
        });
        return;
    }
    const task = await AutomationService_1.automationService.createAutomationTask({
        taskType,
        assignedTo,
        priority: parseInt(priority),
        location,
        sku,
        quantity: quantity ? parseInt(quantity) : undefined,
        metadata,
        createdBy: req.user.userId,
    });
    res.status(201).json(task);
}));
/**
 * GET /api/automation/tasks/:taskId
 * Get automation task by ID
 */
router.get('/tasks/:taskId', (0, middleware_1.asyncHandler)(async (req, res) => {
    const { taskId } = req.params;
    const task = await AutomationService_1.automationService.getAutomationTask(taskId);
    res.json(task);
}));
/**
 * GET /api/automation/tasks/pending/:assignedTo
 * Get pending tasks for a robot/system
 */
router.get('/tasks/pending/:assignedTo', (0, middleware_1.asyncHandler)(async (req, res) => {
    const { assignedTo } = req.params;
    const taskType = req.query.taskType;
    const tasks = await AutomationService_1.automationService.getPendingTasks(assignedTo, taskType);
    res.json(tasks);
}));
/**
 * PATCH /api/automation/tasks/:taskId/result
 * Update task status and result
 */
router.patch('/tasks/:taskId/result', (0, middleware_1.asyncHandler)(async (req, res) => {
    const { taskId } = req.params;
    const { status, countedQuantity, variance, notes } = req.body;
    if (!status) {
        res.status(400).json({
            error: 'Status is required',
            code: 'MISSING_STATUS',
        });
        return;
    }
    const task = await AutomationService_1.automationService.updateTaskResult(taskId, status, {
        countedQuantity,
        variance,
        notes,
    });
    res.json(task);
}));
/**
 * POST /api/automation/rfid/scan
 * Process RFID scan results
 */
router.post('/rfid/scan', (0, middleware_1.asyncHandler)(async (req, res) => {
    const { tags, scanDuration, scanLocation } = req.body;
    // Validate required fields
    if (!tags || !Array.isArray(tags) || !scanLocation) {
        res.status(400).json({
            error: 'Missing required fields',
            code: 'MISSING_FIELDS',
        });
        return;
    }
    const scanResult = await AutomationService_1.automationService.processRFIDScan({
        tags,
        scanDuration: scanDuration || 0,
        scanLocation,
        scannedBy: req.user.userId,
        scannedAt: new Date(),
    });
    res.json(scanResult);
}));
/**
 * GET /api/automation/rfid/summary/:location
 * Get RFID scan summary for a location
 */
router.get('/rfid/summary/:location', (0, middleware_1.asyncHandler)(async (req, res) => {
    const { location } = req.params;
    const summary = await AutomationService_1.automationService.getRFIDScanSummary(location);
    res.json(summary);
}));
exports.default = router;
//# sourceMappingURL=automation.js.map