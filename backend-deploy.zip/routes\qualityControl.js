"use strict";
/**
 * Quality Control routes
 *
 * Endpoints for managing quality inspections, checklists, and returns
 */
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const QualityControlService_1 = require("../services/QualityControlService");
const middleware_1 = require("../middleware");
const shared_1 = require("@opsui/shared");
const router = (0, express_1.Router)();
// All quality control routes require authentication
router.use(middleware_1.authenticate);
// ============================================================================
// INSPECTION CHECKLIST ROUTES
// ============================================================================
/**
 * POST /api/quality-control/checklists
 * Create an inspection checklist
 */
router.post('/checklists', (0, middleware_1.authorize)(shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { checklistName, description, inspectionType, sku, category, items } = req.body;
    // Validate required fields
    if (!checklistName || !inspectionType || !items || !Array.isArray(items)) {
        res.status(400).json({
            error: 'Missing required fields',
            code: 'MISSING_FIELDS',
        });
        return;
    }
    const checklist = await QualityControlService_1.qualityControlService.createInspectionChecklist({
        checklistName,
        description,
        inspectionType,
        sku,
        category,
        items,
        createdBy: req.user.userId,
    });
    res.status(201).json(checklist);
}));
/**
 * GET /api/quality-control/checklists
 * Get all inspection checklists
 */
router.get('/checklists', (0, middleware_1.asyncHandler)(async (req, res) => {
    const filters = {
        inspectionType: req.query.type,
        sku: req.query.sku,
        category: req.query.category,
        activeOnly: req.query.active === 'true',
    };
    const checklists = await QualityControlService_1.qualityControlService.getAllInspectionChecklists(filters);
    res.json(checklists);
}));
/**
 * GET /api/quality-control/checklists/:checklistId
 * Get a specific inspection checklist
 */
router.get('/checklists/:checklistId', (0, middleware_1.asyncHandler)(async (req, res) => {
    const { checklistId } = req.params;
    const checklist = await QualityControlService_1.qualityControlService.getInspectionChecklist(checklistId);
    res.json(checklist);
}));
// ============================================================================
// QUALITY INSPECTION ROUTES
// ============================================================================
/**
 * POST /api/quality-control/inspections
 * Create a quality inspection
 */
router.post('/inspections', (0, middleware_1.asyncHandler)(async (req, res) => {
    const { inspectionType, referenceType, referenceId, sku, quantityInspected, location, lotNumber, expirationDate, checklistId, notes, } = req.body;
    // Validate required fields
    if (!inspectionType ||
        !referenceType ||
        !referenceId ||
        !sku ||
        quantityInspected === undefined) {
        res.status(400).json({
            error: 'Missing required fields',
            code: 'MISSING_FIELDS',
        });
        return;
    }
    const inspection = await QualityControlService_1.qualityControlService.createInspection({
        inspectionType,
        referenceType,
        referenceId,
        sku,
        quantityInspected: parseInt(quantityInspected),
        inspectorId: req.user.userId,
        location,
        lotNumber,
        expirationDate: expirationDate ? new Date(expirationDate) : undefined,
        checklistId,
        notes,
    });
    res.status(201).json(inspection);
}));
/**
 * GET /api/quality-control/inspections
 * Get all quality inspections
 */
router.get('/inspections', (0, middleware_1.asyncHandler)(async (req, res) => {
    const filters = {
        status: req.query.status,
        inspectionType: req.query.type,
        referenceType: req.query.referenceType,
        referenceId: req.query.referenceId,
        sku: req.query.sku,
        inspectorId: req.query.inspectorId,
        limit: req.query.limit ? parseInt(req.query.limit) : 50,
        offset: req.query.offset ? parseInt(req.query.offset) : 0,
    };
    const result = await QualityControlService_1.qualityControlService.getAllQualityInspections(filters);
    res.json(result);
}));
/**
 * GET /api/quality-control/inspections/:inspectionId
 * Get a specific quality inspection
 */
router.get('/inspections/:inspectionId', (0, middleware_1.asyncHandler)(async (req, res) => {
    const { inspectionId } = req.params;
    const inspection = await QualityControlService_1.qualityControlService.getQualityInspection(inspectionId);
    res.json(inspection);
}));
/**
 * POST /api/quality-control/inspections/:inspectionId/start
 * Start an inspection
 */
router.post('/inspections/:inspectionId/start', (0, middleware_1.asyncHandler)(async (req, res) => {
    const { inspectionId } = req.params;
    const inspection = await QualityControlService_1.qualityControlService.startInspection(inspectionId);
    res.json(inspection);
}));
/**
 * PATCH /api/quality-control/inspections/:inspectionId/status
 * Update inspection status (complete inspection)
 */
router.patch('/inspections/:inspectionId/status', (0, middleware_1.authorize)(shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { inspectionId } = req.params;
    const { status, quantityPassed, quantityFailed, defectType, defectDescription, dispositionAction, dispositionNotes, notes, } = req.body;
    if (!status) {
        res.status(400).json({
            error: 'Status is required',
            code: 'MISSING_STATUS',
        });
        return;
    }
    const inspection = await QualityControlService_1.qualityControlService.updateInspectionStatus({
        inspectionId,
        status,
        quantityPassed: quantityPassed ? parseInt(quantityPassed) : undefined,
        quantityFailed: quantityFailed ? parseInt(quantityFailed) : undefined,
        defectType,
        defectDescription,
        dispositionAction,
        dispositionNotes,
        approvedBy: req.user.userId,
        notes,
    });
    res.json(inspection);
}));
/**
 * GET /api/quality-control/inspections/:inspectionId/results
 * Get inspection results
 */
router.get('/inspections/:inspectionId/results', (0, middleware_1.asyncHandler)(async (req, res) => {
    const { inspectionId } = req.params;
    const results = await QualityControlService_1.qualityControlService.getInspectionResults(inspectionId);
    res.json(results);
}));
/**
 * POST /api/quality-control/inspections/results
 * Save inspection result
 */
router.post('/inspections/results', (0, middleware_1.asyncHandler)(async (req, res) => {
    const { inspectionId, checklistItemId, result, passed, notes, imageUrl } = req.body;
    // Validate required fields
    if (!inspectionId || !checklistItemId || result === undefined || passed === undefined) {
        res.status(400).json({
            error: 'Missing required fields',
            code: 'MISSING_FIELDS',
        });
        return;
    }
    const inspectionResult = await QualityControlService_1.qualityControlService.saveInspectionResult({
        inspectionId,
        checklistItemId,
        result,
        passed,
        notes,
        imageUrl,
    });
    res.status(201).json(inspectionResult);
}));
// ============================================================================
// RETURN AUTHORIZATION ROUTES
// ============================================================================
/**
 * POST /api/quality-control/returns
 * Create a return authorization
 */
router.post('/returns', (0, middleware_1.authorize)(shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { orderId, customerId, customerName, returnReason, items, totalRefundAmount, restockingFee, } = req.body;
    // Validate required fields
    if (!orderId ||
        !customerId ||
        !customerName ||
        !returnReason ||
        !items ||
        !Array.isArray(items) ||
        !totalRefundAmount) {
        res.status(400).json({
            error: 'Missing required fields',
            code: 'MISSING_FIELDS',
        });
        return;
    }
    const returnAuth = await QualityControlService_1.qualityControlService.createReturnAuthorization({
        orderId,
        customerId,
        customerName,
        returnReason,
        items,
        authorizedBy: req.user.userId,
        totalRefundAmount,
        restockingFee,
    });
    res.status(201).json(returnAuth);
}));
/**
 * GET /api/quality-control/returns
 * Get all return authorizations
 */
router.get('/returns', (0, middleware_1.asyncHandler)(async (req, res) => {
    const filters = {
        status: req.query.status,
        orderId: req.query.orderId,
        customerId: req.query.customerId,
        limit: req.query.limit ? parseInt(req.query.limit) : 50,
        offset: req.query.offset ? parseInt(req.query.offset) : 0,
    };
    const result = await QualityControlService_1.qualityControlService.getAllReturnAuthorizations(filters);
    res.json(result);
}));
/**
 * GET /api/quality-control/returns/:returnId
 * Get a specific return authorization
 */
router.get('/returns/:returnId', (0, middleware_1.asyncHandler)(async (req, res) => {
    const { returnId } = req.params;
    const returnAuth = await QualityControlService_1.qualityControlService.getReturnAuthorization(returnId);
    res.json(returnAuth);
}));
/**
 * PATCH /api/quality-control/returns/:returnId/status
 * Update return authorization status
 */
router.patch('/returns/:returnId/status', (0, middleware_1.authorize)(shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { returnId } = req.params;
    const { status } = req.body;
    if (!status) {
        res.status(400).json({
            error: 'Status is required',
            code: 'MISSING_STATUS',
        });
        return;
    }
    const returnAuth = await QualityControlService_1.qualityControlService.updateReturnAuthorizationStatus(returnId, status, req.user.userId);
    res.json(returnAuth);
}));
exports.default = router;
//# sourceMappingURL=qualityControl.js.map