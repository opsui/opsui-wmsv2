/**
 * Add NZC Carrier
 *
 * This script adds the NZC (NZ Couriers) carrier to the carriers table
 */
export declare function addNZCCarrier(): Promise<any>;
export default addNZCCarrier;
//# sourceMappingURL=add-nzc-carrier.d.ts.map