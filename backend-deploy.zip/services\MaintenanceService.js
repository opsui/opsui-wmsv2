"use strict";
/**
 * Maintenance & Assets Service
 *
 * Business logic for asset management and maintenance workflows
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.maintenanceService = exports.MaintenanceService = void 0;
const MaintenanceRepository_1 = require("../repositories/MaintenanceRepository");
const shared_1 = require("@opsui/shared");
class MaintenanceService {
    // ========================================================================
    // ASSETS
    // ========================================================================
    async createAsset(dto, createdBy) {
        // Validate asset
        if (!dto.name || dto.name.trim() === '') {
            throw new Error('Asset name is required');
        }
        if (!dto.type) {
            throw new Error('Asset type is required');
        }
        const asset = await MaintenanceRepository_1.maintenanceRepository.createAsset({
            ...dto,
            purchaseDate: dto.purchaseDate ? new Date(dto.purchaseDate) : undefined,
            warrantyExpiry: dto.warrantyExpiry ? new Date(dto.warrantyExpiry) : undefined,
            status: shared_1.AssetStatus.OPERATIONAL,
            createdBy,
        });
        return asset;
    }
    async getAssetById(assetId) {
        const asset = await MaintenanceRepository_1.maintenanceRepository.findAssetById(assetId);
        if (!asset) {
            throw new shared_1.NotFoundError('Asset', assetId);
        }
        return asset;
    }
    async getAllAssets(filters) {
        return await MaintenanceRepository_1.maintenanceRepository.findAllAssets(filters);
    }
    async updateAsset(assetId, dto, userId) {
        const asset = await MaintenanceRepository_1.maintenanceRepository.findAssetById(assetId);
        if (!asset) {
            throw new shared_1.NotFoundError('Asset', assetId);
        }
        const updated = await MaintenanceRepository_1.maintenanceRepository.updateAsset(assetId, {
            ...dto,
            updatedBy: userId,
        });
        return updated;
    }
    async retireAsset(assetId, userId) {
        const asset = await this.getAssetById(assetId);
        if (asset.status === shared_1.AssetStatus.RETIRED) {
            throw new Error('Asset already retired');
        }
        const updated = await MaintenanceRepository_1.maintenanceRepository.updateAsset(assetId, {
            status: shared_1.AssetStatus.RETIRED,
            updatedBy: userId,
        });
        return updated;
    }
    // ========================================================================
    // MAINTENANCE SCHEDULES
    // ========================================================================
    async createSchedule(dto, createdBy) {
        // Validate schedule
        if (!dto.name || dto.name.trim() === '') {
            throw new Error('Schedule name is required');
        }
        if (!dto.assetId || dto.assetId.trim() === '') {
            throw new Error('Asset ID is required');
        }
        if (!dto.nextDueDate) {
            throw new Error('Next due date is required');
        }
        if (dto.estimatedDurationHours <= 0) {
            throw new Error('Estimated duration must be greater than 0');
        }
        // Validate asset exists
        const asset = await MaintenanceRepository_1.maintenanceRepository.findAssetById(dto.assetId);
        if (!asset) {
            throw new shared_1.NotFoundError('Asset', dto.assetId);
        }
        const schedule = await MaintenanceRepository_1.maintenanceRepository.createSchedule({
            ...dto,
            nextDueDate: new Date(dto.nextDueDate),
            isActive: true,
            createdBy,
        });
        return schedule;
    }
    async getSchedulesByAsset(assetId) {
        await this.getAssetById(assetId);
        return await MaintenanceRepository_1.maintenanceRepository.findSchedulesByAsset(assetId);
    }
    async getUpcomingMaintenance(daysAhead = 7) {
        return await MaintenanceRepository_1.maintenanceRepository.findDueSchedules(daysAhead);
    }
    // ========================================================================
    // WORK ORDERS
    // ========================================================================
    async createWorkOrder(dto, createdBy) {
        // Validate work order
        if (!dto.assetId || dto.assetId.trim() === '') {
            throw new Error('Asset ID is required');
        }
        if (!dto.title || dto.title.trim() === '') {
            throw new Error('Work order title is required');
        }
        if (!dto.scheduledDate) {
            throw new Error('Scheduled date is required');
        }
        if (dto.estimatedDurationHours <= 0) {
            throw new Error('Estimated duration must be greater than 0');
        }
        // Validate asset exists
        const asset = await MaintenanceRepository_1.maintenanceRepository.findAssetById(dto.assetId);
        if (!asset) {
            throw new shared_1.NotFoundError('Asset', dto.assetId);
        }
        const workOrder = await MaintenanceRepository_1.maintenanceRepository.createWorkOrder({
            ...dto,
            scheduledDate: new Date(dto.scheduledDate),
            scheduledStartTime: dto.scheduledStartTime, // Keep as string (HH:mm format)
            status: shared_1.MaintenanceStatus.SCHEDULED,
            createdBy,
        });
        // Update asset status if maintenance type is not preventive
        if (dto.maintenanceType !== 'PREVENTIVE') {
            await MaintenanceRepository_1.maintenanceRepository.updateAsset(dto.assetId, {
                status: shared_1.AssetStatus.IN_MAINTENANCE,
                updatedBy: createdBy,
            });
        }
        return workOrder;
    }
    async getWorkOrderById(workOrderId) {
        const workOrder = await MaintenanceRepository_1.maintenanceRepository.findWorkOrderById(workOrderId);
        if (!workOrder) {
            throw new shared_1.NotFoundError('Work Order', workOrderId);
        }
        return workOrder;
    }
    async getAllWorkOrders(filters) {
        return await MaintenanceRepository_1.maintenanceRepository.findAllWorkOrders(filters);
    }
    async startWorkOrder(workOrderId, userId) {
        const workOrder = await this.getWorkOrderById(workOrderId);
        if (workOrder.status !== 'SCHEDULED') {
            throw new Error('Only SCHEDULED work orders can be started');
        }
        // Update work order
        const updated = await MaintenanceRepository_1.maintenanceRepository.updateWorkOrder(workOrderId, {
            status: 'IN_PROGRESS',
            actualStartDate: new Date(),
            performedBy: userId,
        });
        return updated;
    }
    async completeWorkOrder(workOrderId, dto, userId) {
        const workOrder = await this.getWorkOrderById(workOrderId);
        if (workOrder.status !== 'IN_PROGRESS') {
            throw new Error('Work order must be IN_PROGRESS to complete');
        }
        if (!dto.workPerformed || dto.workPerformed.trim() === '') {
            throw new Error('Work performed description is required');
        }
        const completed = await MaintenanceRepository_1.maintenanceRepository.completeWorkOrder(workOrderId, {
            ...dto,
            completedBy: userId,
        });
        if (!completed) {
            throw new Error('Failed to complete work order');
        }
        // Update asset back to operational
        await MaintenanceRepository_1.maintenanceRepository.updateAsset(workOrder.assetId, {
            status: shared_1.AssetStatus.OPERATIONAL,
            updatedBy: userId,
        });
        // Create service log entry
        await MaintenanceRepository_1.maintenanceRepository.createServiceLog({
            assetId: workOrder.assetId,
            workOrderId,
            serviceDate: new Date(),
            serviceType: workOrder.maintenanceType,
            description: dto.workPerformed,
            performedBy: userId,
            cost: completed.totalCost,
            notes: dto.notes,
            createdBy: userId,
        });
        return completed;
    }
    // ========================================================================
    // SERVICE HISTORY
    // ========================================================================
    async getAssetServiceHistory(assetId, limit = 50) {
        await this.getAssetById(assetId);
        return await MaintenanceRepository_1.maintenanceRepository.findServiceLogsByAsset(assetId, limit);
    }
    async addServiceLog(log) {
        // Validate asset exists
        const asset = await MaintenanceRepository_1.maintenanceRepository.findAssetById(log.assetId);
        if (!asset) {
            throw new shared_1.NotFoundError('Asset', log.assetId);
        }
        if (!log.description || log.description.trim() === '') {
            throw new Error('Service description is required');
        }
        const serviceLog = await MaintenanceRepository_1.maintenanceRepository.createServiceLog({
            ...log,
        });
        // Update asset last maintenance date
        await MaintenanceRepository_1.maintenanceRepository.updateAsset(log.assetId, {
            lastMaintenanceDate: log.serviceDate,
            updatedBy: log.createdBy,
        });
        return serviceLog;
    }
    // ========================================================================
    // METER READINGS
    // ========================================================================
    async addMeterReading(dto, userId) {
        // Validate asset exists
        const asset = await MaintenanceRepository_1.maintenanceRepository.findAssetById(dto.assetId);
        if (!asset) {
            throw new shared_1.NotFoundError('Asset', dto.assetId);
        }
        if (!dto.meterType || dto.meterType.trim() === '') {
            throw new Error('Meter type is required');
        }
        if (dto.value < 0) {
            throw new Error('Meter value cannot be negative');
        }
        if (!dto.unit || dto.unit.trim() === '') {
            throw new Error('Unit is required');
        }
        const reading = await MaintenanceRepository_1.maintenanceRepository.addMeterReading({
            assetId: dto.assetId,
            meterType: dto.meterType,
            value: dto.value,
            unit: dto.unit,
            readingDate: new Date(dto.readingDate),
            readBy: userId,
            notes: dto.notes,
        });
        // Check if reading triggers maintenance
        await this.checkMeterReadingForMaintenance(dto.assetId, dto.meterType, dto.value);
        return reading;
    }
    async getMeterReadingsByAsset(assetId, limit = 100) {
        await this.getAssetById(assetId);
        return await MaintenanceRepository_1.maintenanceRepository.findMeterReadingsByAsset(assetId, limit);
    }
    // ========================================================================
    // DASHBOARD
    // ========================================================================
    async getDashboardMetrics() {
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const tomorrow = new Date(today);
        tomorrow.setDate(tomorrow.getDate() + 1);
        const workOrdersResult = await MaintenanceRepository_1.maintenanceRepository.findAllWorkOrders({
            limit: 1000,
        });
        const assetsResult = await MaintenanceRepository_1.maintenanceRepository.findAllAssets({
            limit: 1000,
        });
        const workOrders = workOrdersResult.workOrders;
        const assets = assetsResult.assets;
        return {
            openRequests: workOrders.filter(wo => wo.status === 'SCHEDULED' || wo.status === 'OVERDUE')
                .length,
            inProgress: workOrders.filter(wo => wo.status === 'IN_PROGRESS').length,
            completedToday: workOrders.filter(wo => wo.status === 'COMPLETED' &&
                wo.completedAt &&
                new Date(wo.completedAt) >= today &&
                new Date(wo.completedAt) < tomorrow).length,
            urgent: workOrders.filter(wo => wo.priority === 'EMERGENCY' || wo.priority === 'HIGH').length,
            equipmentDown: assets.filter(a => a.status === 'OUT_OF_SERVICE').length,
            equipmentNeedsService: assets.filter(a => a.status === 'IN_MAINTENANCE').length,
        };
    }
    // ========================================================================
    // PRIVATE HELPERS
    // ========================================================================
    async checkMeterReadingForMaintenance(assetId, meterType, value) {
        // Check if this reading exceeds any thresholds that should trigger maintenance
        // This would integrate with the maintenance schedule and alert system
        // For now, just log
        console.log(`Checking meter reading ${meterType} = ${value} for asset ${assetId}`);
    }
}
exports.MaintenanceService = MaintenanceService;
// Singleton instance
exports.maintenanceService = new MaintenanceService();
//# sourceMappingURL=MaintenanceService.js.map