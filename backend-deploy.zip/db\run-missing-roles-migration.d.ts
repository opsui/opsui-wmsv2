/**
 * Run the add_all_missing_roles migration
 * This ensures all user roles defined in the frontend enum exist in the database
 */
export {};
//# sourceMappingURL=run-missing-roles-migration.d.ts.map