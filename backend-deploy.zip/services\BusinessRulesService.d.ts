/**
 * Business Rules Engine Service
 *
 * Core service for evaluating and executing business rules.
 * Supports configurable allocation logic and automated decision making.
 */
import { BusinessRule, RuleCondition, RuleAction, RuleEventType } from '@opsui/shared';
interface RuleContext {
    eventType: RuleEventType;
    entity: any;
    entityType: string;
    entityId: string;
    userId: string;
}
interface ConditionEvaluationResult {
    condition: RuleCondition;
    result: boolean;
    error?: string;
}
interface RuleEvaluationResult {
    rule: BusinessRule;
    conditionsMet: boolean;
    conditionResults: ConditionEvaluationResult[];
    shouldExecute: boolean;
}
export declare class BusinessRulesService {
    /**
     * Trigger rule evaluation for an event
     */
    triggerEvent(context?: RuleContext): Promise<void>;
    /**
     * Evaluate and execute a single rule
     */
    evaluateAndExecuteRule(rule: BusinessRule, context: RuleContext): Promise<void>;
    /**
     * Evaluate all conditions for a rule
     */
    evaluateRuleConditions(rule: BusinessRule, context: RuleContext): RuleEvaluationResult;
    /**
     * Evaluate a single condition
     */
    evaluateCondition(condition: RuleCondition, context: RuleContext): ConditionEvaluationResult;
    /**
     * Execute a rule action
     */
    executeAction(action: RuleAction, context: RuleContext): Promise<any>;
    private actionSetPriority;
    private actionAssignUser;
    private actionSendNotification;
    private actionBlockAction;
    private actionModifyField;
    /**
     * Get field value from object using dot notation
     */
    private getFieldValue;
    /**
     * Compare two values for sorting
     */
    private compareValues;
}
export declare const businessRulesService: BusinessRulesService;
export {};
//# sourceMappingURL=BusinessRulesService.d.ts.map