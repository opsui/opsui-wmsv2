/**
 * Fix progress rounding to match JavaScript Math.round() behavior
 *
 * Updates all order progress values using round-half-up instead of banker's rounding
 */
export {};
//# sourceMappingURL=fix-progress-rounding.d.ts.map