/**
 * Migration Runner: Add cycle count variance support to order_exceptions table
 *
 * Run with: npx tsx src/db/migrations/run-cycle-count-variance-migration.ts
 */
declare const Pool: any;
declare const pool: any;
declare function runCycleCountVarianceMigration(): Promise<void>;
//# sourceMappingURL=run-cycle-count-variance-migration.d.ts.map