/**
 * Order repository
 *
 * Handles all database operations for orders and order items
 */
import { CreateOrderDTO, Order, OrderPriority, OrderStatus } from '@opsui/shared';
import { BaseRepository } from './BaseRepository';
export declare class OrderRepository extends BaseRepository<Order> {
    constructor();
    createOrderWithItems(dto: CreateOrderDTO): Promise<Order>;
    getOrderWithItems(orderId: string): Promise<Order>;
    getOrderQueue(filters?: {
        status?: OrderStatus;
        priority?: OrderPriority;
        pickerId?: string;
        limit?: number;
        offset?: number;
    }): Promise<{
        orders: Order[];
        total: number;
    }>;
    getOrdersWithItemsByStatus(filters?: {
        status?: OrderStatus;
        packerId?: string;
    }): Promise<{
        orders: Order[];
    }>;
    claimOrder(orderId: string, pickerId: string): Promise<Order>;
    updateStatus(orderId: string, status: OrderStatus): Promise<Order>;
    cancelOrder(orderId: string, userId: string, reason: string): Promise<Order>;
    getPickerActiveOrders(pickerId: string): Promise<Order[]>;
}
export declare const orderRepository: OrderRepository;
//# sourceMappingURL=OrderRepository.d.ts.map