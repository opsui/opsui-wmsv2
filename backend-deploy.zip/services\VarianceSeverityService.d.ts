/**
 * Variance Severity Service
 *
 * Manages configurable variance severity thresholds for cycle counting.
 * Provides severity determination based on variance percentage.
 */
export interface VarianceSeverityConfig {
    configId: string;
    severityLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
    minVariancePercent: number;
    maxVariancePercent: number;
    requiresApproval: boolean;
    requiresManagerApproval: boolean;
    autoAdjust: boolean;
    colorCode: string;
    isActive: boolean;
    createdAt: Date;
    updatedAt: Date;
}
export interface SeverityDetermination {
    severity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
    config: VarianceSeverityConfig;
    requiresApproval: boolean;
    canAutoAdjust: boolean;
    colorCode: string;
}
export interface CreateSeverityConfigDTO {
    severityLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
    minVariancePercent: number;
    maxVariancePercent: number;
    requiresApproval?: boolean;
    requiresManagerApproval?: boolean;
    autoAdjust?: boolean;
    colorCode?: string;
}
export interface UpdateSeverityConfigDTO {
    minVariancePercent?: number;
    maxVariancePercent?: number;
    requiresApproval?: boolean;
    requiresManagerApproval?: boolean;
    autoAdjust?: boolean;
    colorCode?: string;
    isActive?: boolean;
}
export declare class VarianceSeverityService {
    /**
     * Get all active severity configurations
     */
    getAllSeverityConfigs(includeInactive?: boolean): Promise<VarianceSeverityConfig[]>;
    /**
     * Get severity configuration by ID
     */
    getSeverityConfig(configId: string): Promise<VarianceSeverityConfig>;
    /**
     * Determine severity for a given variance percentage
     */
    getSeverityForVariance(variancePercent: number): Promise<SeverityDetermination>;
    /**
     * Create a new severity configuration
     */
    createSeverityConfig(dto: CreateSeverityConfigDTO): Promise<VarianceSeverityConfig>;
    /**
     * Update an existing severity configuration
     */
    updateSeverityConfig(configId: string, dto: UpdateSeverityConfigDTO): Promise<VarianceSeverityConfig>;
    /**
     * Delete a severity configuration (soft delete by setting inactive)
     */
    deleteSeverityConfig(configId: string): Promise<void>;
    /**
     * Reset to default severity configurations
     */
    resetToDefaults(): Promise<void>;
    /**
     * Initialize default severity configurations
     * Called during system setup
     */
    createDefaultSeverityConfigs(): Promise<void>;
    private mapRowToConfig;
    private createDefaultCriticalConfig;
    private getDefaultColorCode;
}
export declare const varianceSeverityService: VarianceSeverityService;
//# sourceMappingURL=VarianceSeverityService.d.ts.map