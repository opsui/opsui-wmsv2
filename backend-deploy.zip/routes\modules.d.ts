/**
 * Module Subscription Routes
 *
 * REST API endpoints for managing module subscriptions and billing
 * Access: ADMIN only for modifications, SUPERVISOR for read access
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=modules.d.ts.map