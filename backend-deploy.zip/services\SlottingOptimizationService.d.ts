/**
 * Warehouse Slotting Optimization Service
 *
 * Implements ABC analysis and slotting optimization for warehouse efficiency.
 * Slotting determines the optimal placement of products based on:
 * - Velocity (popularity/turnover rate)
 * - Physical characteristics (weight, dimensions)
 * - Compatibility (items frequently ordered together)
 * - Seasonality
 *
 * Benefits:
 * - Reduced travel time for pickers
 * - Improved space utilization
 * - Better inventory organization
 * - Increased throughput
 *
 * References:
 * - Warehouse Slotting Optimization
 * - ABC Analysis for Warehouse Storage
 */
interface UserContext {
    userId?: string | number;
    userEmail?: string;
    userRole?: string;
    ipAddress?: string;
    userAgent?: string;
    requestId?: string;
}
export declare enum ABCClass {
    A = "A",// High velocity (fast-moving) - 80% of movement, 20% of items
    B = "B",// Medium velocity - 15% of movement, 30% of items
    C = "C"
}
export interface SlottingAnalysis {
    sku: string;
    productName: string;
    currentLocation: string;
    abcClass: ABCClass;
    velocity: number;
    recommendedLocation?: string;
    reason?: string;
    priority: 'HIGH' | 'MEDIUM' | 'LOW';
}
export interface SlottingRecommendation {
    sku: string;
    fromLocation: string;
    toLocation: string;
    estimatedBenefit: {
        travelTimeReduction: number;
        annualSavings: number;
    };
    effort: 'LOW' | 'MEDIUM' | 'HIGH';
    priority: number;
}
export interface VelocityData {
    sku: string;
    totalPicks: number;
    picksPerDay: number;
    totalQuantity: number;
    avgOrderQuantity: number;
    lastPickDate: Date;
    daysSinceLastPick: number;
    trend: 'INCREASING' | 'STABLE' | 'DECREASING';
}
export interface SlottingConfig {
    zoneA: string[];
    zoneB: string[];
    zoneC: string[];
    weightConsiderations: {
        maxWeightForShelves: number;
        maxWeightForHighShelves: number;
    };
    sizeConsiderations: {
        bulkStorageZones: string[];
        smallItemZones: string[];
    };
}
export declare class SlottingOptimizationService {
    private pool;
    private config;
    constructor();
    /**
     * Run ABC analysis for all SKUs
     */
    runABCAnalysis(days?: number): Promise<SlottingAnalysis[]>;
    /**
     * Get slotting recommendations for implementation
     */
    getSlottingRecommendations(options?: {
        minPriority?: 'HIGH' | 'MEDIUM' | 'LOW';
        maxRecommendations?: number;
    }): Promise<SlottingRecommendation[]>;
    /**
     * Implement a slotting recommendation
     */
    implementRecommendation(recommendation: SlottingRecommendation, context: UserContext): Promise<void>;
    /**
     * Get velocity data for a specific SKU
     */
    getVelocityData(sku: string, days?: number): Promise<VelocityData | null>;
    /**
     * Get slotting statistics
     */
    getSlottingStats(): Promise<{
        totalSKUs: number;
        classA: {
            count: number;
            percentage: number;
        };
        classB: {
            count: number;
            percentage: number;
        };
        classC: {
            count: number;
            percentage: number;
        };
        optimalPlacement: number;
    }>;
    /**
     * Calculate ABC class based on velocity percentile
     */
    private calculateABCClass;
    /**
     * Generate slotting recommendation
     */
    private generateRecommendation;
    /**
     * Calculate priority for slotting change
     */
    private calculatePriority;
    /**
     * Calculate benefit of moving an item
     */
    private calculateBenefit;
    /**
     * Calculate effort required to move an item
     */
    private calculateEffort;
    /**
     * Calculate overall recommendation priority
     */
    private calculateRecommendationPriority;
    /**
     * Update slotting configuration
     */
    updateConfig(config: Partial<SlottingConfig>): void;
    /**
     * Get current configuration
     */
    getConfig(): SlottingConfig;
}
export declare const slottingOptimizationService: SlottingOptimizationService;
export default slottingOptimizationService;
//# sourceMappingURL=SlottingOptimizationService.d.ts.map