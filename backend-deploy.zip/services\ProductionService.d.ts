/**
 * Production Management Service
 *
 * Business logic for production order management and manufacturing workflows
 */
import { ProductionOrder, BillOfMaterial, ProductionOutput, CreateProductionOrderDTO, UpdateProductionOrderDTO, RecordProductionOutputDTO, CreateBOMDTO, UpdateBOMDTO, IssueMaterialDTO, ReturnMaterialDTO, ProductionOrderStatus } from '@opsui/shared';
export declare class ProductionService {
    createBOM(dto: CreateBOMDTO, createdBy: string): Promise<BillOfMaterial>;
    getBOMById(bomId: string): Promise<BillOfMaterial>;
    getAllBOMs(filters?: {
        productId?: string;
        status?: string;
    }): Promise<BillOfMaterial[]>;
    updateBOM(bomId: string, dto: UpdateBOMDTO, userId: string): Promise<BillOfMaterial>;
    activateBOM(bomId: string, userId: string): Promise<BillOfMaterial>;
    deleteBOM(bomId: string): Promise<boolean>;
    createProductionOrder(dto: CreateProductionOrderDTO, createdBy: string): Promise<ProductionOrder>;
    getProductionOrderById(orderId: string): Promise<ProductionOrder>;
    getAllProductionOrders(filters?: {
        status?: ProductionOrderStatus;
        assignedTo?: string;
        limit?: number;
        offset?: number;
    }): Promise<{
        orders: ProductionOrder[];
        total: number;
    }>;
    updateProductionOrder(orderId: string, dto: UpdateProductionOrderDTO, userId: string): Promise<ProductionOrder>;
    releaseProductionOrder(orderId: string, userId: string): Promise<ProductionOrder>;
    startProductionOrder(orderId: string, userId: string): Promise<ProductionOrder>;
    recordProductionOutput(dto: RecordProductionOutputDTO, userId: string): Promise<ProductionOutput>;
    getProductionJournal(orderId: string): Promise<any[]>;
    cancelProductionOrder(orderId: string, userId: string): Promise<ProductionOrder>;
    holdProductionOrder(orderId: string, userId: string): Promise<ProductionOrder>;
    resumeProductionOrder(orderId: string, userId: string): Promise<ProductionOrder>;
    issueMaterial(dto: IssueMaterialDTO, _userId: string): Promise<void>;
    returnMaterial(dto: ReturnMaterialDTO, _userId: string): Promise<void>;
    getDashboardMetrics(): Promise<{
        queued: number;
        inProgress: number;
        completedToday: number;
        onHold: number;
    }>;
    private validateStatusTransition;
}
export declare const productionService: ProductionService;
//# sourceMappingURL=ProductionService.d.ts.map