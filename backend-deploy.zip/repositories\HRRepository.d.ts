/**
 * HR Repository
 *
 * Data access layer for HR & Payroll operations
 * Handles employee records, timesheets, payroll runs, and leave management
 */
import { type PoolClient } from '../db/client';
import { BaseRepository } from './BaseRepository';
import type { HREmployee, HREmployeeTaxDetails, HREmployment, HRBankAccount, HRTimesheet, HRTimesheetEntry, HRPayrollPeriod, HRPayrollRun, HRPayItem, HRDeductionType, HREmployeeDeduction, HRLeaveType, HRLeaveBalance, HRLeaveRequest, HRTaxTable, HREmployeeWithDetails, HRTimesheetWithEntries } from '@opsui/shared';
export declare class EmployeeRepository extends BaseRepository<HREmployee> {
    constructor();
    findByEmail(email: string): Promise<HREmployee | null>;
    findByIdWithDetails(employeeId: string): Promise<HREmployeeWithDetails | null>;
    findActive(): Promise<HREmployee[]>;
    softDelete(employeeId: string): Promise<boolean>;
    restore(employeeId: string): Promise<boolean>;
    search(searchTerm: string, limit?: number): Promise<HREmployee[]>;
}
export declare class EmployeeTaxDetailsRepository extends BaseRepository<HREmployeeTaxDetails> {
    constructor();
    findByEmployeeId(employeeId: string): Promise<HREmployeeTaxDetails | null>;
    upsert(employeeId: string, data: Partial<HREmployeeTaxDetails>): Promise<HREmployeeTaxDetails>;
}
export declare class EmploymentRepository extends BaseRepository<HREmployment> {
    constructor();
    findByEmployeeId(employeeId: string): Promise<HREmployment[]>;
    findPrimaryByEmployeeId(employeeId: string): Promise<HREmployment | null>;
}
export declare class BankAccountRepository extends BaseRepository<HRBankAccount> {
    constructor();
    findByEmployeeId(employeeId: string): Promise<HRBankAccount[]>;
    findPrimaryByEmployeeId(employeeId: string): Promise<HRBankAccount | null>;
}
export declare class TimesheetRepository extends BaseRepository<HRTimesheet> {
    constructor();
    findByEmployeeId(employeeId: string, limit?: number): Promise<HRTimesheet[]>;
    findByPeriod(startDate: string, endDate: string): Promise<HRTimesheet[]>;
    findByEmployeeAndPeriod(employeeId: string, startDate: string, endDate: string): Promise<HRTimesheet | null>;
    findWithEntries(timesheetId: string): Promise<HRTimesheetWithEntries | null>;
    findByStatus(status: string): Promise<HRTimesheet[]>;
    updateStatus(timesheetId: string, status: string, userId?: string): Promise<HRTimesheet | null>;
}
export declare class TimesheetEntryRepository extends BaseRepository<HRTimesheetEntry> {
    constructor();
    findByTimesheetId(timesheetId: string): Promise<HRTimesheetEntry[]>;
    deleteByTimesheetId(timesheetId: string, client?: PoolClient): Promise<number>;
}
export declare class PayrollPeriodRepository extends BaseRepository<HRPayrollPeriod> {
    constructor();
    findActive(): Promise<HRPayrollPeriod[]>;
    findCurrentPeriod(): Promise<HRPayrollPeriod | null>;
    findNextPeriod(): Promise<HRPayrollPeriod | null>;
}
export declare class PayrollRunRepository extends BaseRepository<HRPayrollRun> {
    constructor();
    findByPeriodId(periodId: string): Promise<HRPayrollRun[]>;
    findLatest(): Promise<HRPayrollRun | null>;
    findByStatus(status: string): Promise<HRPayrollRun[]>;
    getNextRunNumber(periodId: string): Promise<number>;
}
export declare class PayItemRepository extends BaseRepository<HRPayItem> {
    constructor();
    findByPayrollRunId(payrollRunId: string): Promise<HRPayItem[]>;
    findByEmployeeId(employeeId: string, limit?: number): Promise<HRPayItem[]>;
    deleteByPayrollRunId(payrollRunId: string, client?: PoolClient): Promise<number>;
}
export declare class LeaveRequestRepository extends BaseRepository<HRLeaveRequest> {
    constructor();
    findByEmployeeId(employeeId: string): Promise<HRLeaveRequest[]>;
    findByStatus(status: string): Promise<HRLeaveRequest[]>;
    findByDateRange(startDate: string, endDate: string): Promise<HRLeaveRequest[]>;
}
export declare class LeaveBalanceRepository extends BaseRepository<HRLeaveBalance> {
    constructor();
    findByEmployeeId(employeeId: string): Promise<HRLeaveBalance[]>;
    findByEmployeeAndLeaveType(employeeId: string, leaveTypeId: string): Promise<HRLeaveBalance[]>;
    findCurrentBalance(employeeId: string, leaveTypeId: string): Promise<HRLeaveBalance | null>;
}
export declare class DeductionTypeRepository extends BaseRepository<HRDeductionType> {
    constructor();
    findActive(): Promise<HRDeductionType[]>;
    findByCode(code: string): Promise<HRDeductionType | null>;
    findByCategory(category: string): Promise<HRDeductionType[]>;
}
export declare class EmployeeDeductionRepository extends BaseRepository<HREmployeeDeduction> {
    constructor();
    findByEmployeeId(employeeId: string): Promise<HREmployeeDeduction[]>;
}
export declare class TaxTableRepository extends BaseRepository<HRTaxTable> {
    constructor();
    findByTaxCode(taxCode: string): Promise<HRTaxTable[]>;
    findActiveRates(): Promise<HRTaxTable[]>;
}
export declare class LeaveTypeRepository extends BaseRepository<HRLeaveType> {
    constructor();
    findActive(): Promise<HRLeaveType[]>;
}
declare class HRRepository {
    readonly employees: EmployeeRepository;
    readonly taxDetails: EmployeeTaxDetailsRepository;
    readonly employments: EmploymentRepository;
    readonly bankAccounts: BankAccountRepository;
    readonly timesheets: TimesheetRepository;
    readonly timesheetEntries: TimesheetEntryRepository;
    readonly payrollPeriods: PayrollPeriodRepository;
    readonly payrollRuns: PayrollRunRepository;
    readonly payItems: PayItemRepository;
    readonly leaveRequests: LeaveRequestRepository;
    readonly leaveBalances: LeaveBalanceRepository;
    readonly deductionTypes: DeductionTypeRepository;
    readonly employeeDeductions: EmployeeDeductionRepository;
    readonly taxTables: TaxTableRepository;
    readonly leaveTypes: LeaveTypeRepository;
    withTransaction<R>(callback: (client: PoolClient) => Promise<R>): Promise<R>;
}
export declare const hrRepository: HRRepository;
export {};
//# sourceMappingURL=HRRepository.d.ts.map