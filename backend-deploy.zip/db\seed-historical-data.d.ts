/**
 * Historical Data Seed
 *
 * Adds historical pick_tasks and additional users for:
 * - Weekly Picker Performance chart
 * - Top 10 SKUs by Scan Frequency chart
 */
export {};
//# sourceMappingURL=seed-historical-data.d.ts.map