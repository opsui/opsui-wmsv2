/**
 * Cycle Count KPI routes
 *
 * Endpoints for cycle count analytics and dashboards
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=cycleCountKPI.d.ts.map