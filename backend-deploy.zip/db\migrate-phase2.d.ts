/**
 * Phase 2 Migration Runner
 *
 * Runs the Phase 2 Operational Excellence migrations
 */
/**
 * Run Phase 2 migrations
 */
export declare function runPhase2Migrations(): Promise<void>;
/**
 * Main function
 */
declare function main(): Promise<void>;
export { main as migratePhase2Cli };
//# sourceMappingURL=migrate-phase2.d.ts.map