/**
 * Root Cause Analysis Routes
 *
 * API endpoints for variance root cause categorization and analysis
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=rootCauseAnalysis.d.ts.map