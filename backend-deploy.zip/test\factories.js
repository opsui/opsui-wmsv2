"use strict";
/**
 * Test Data Factories
 *
 * Provides factory functions for creating test data.
 * Uses faker.js for generating realistic test data.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.perfTestHelpers = exports.apiTestHelpers = exports.testDbHelpers = exports.inventoryFactory = exports.pickTaskFactory = exports.orderItemFactory = exports.orderFactory = exports.userFactory = void 0;
const faker_1 = require("@faker-js/faker");
const shared_1 = require("@opsui/shared");
/**
 * Factory for creating test users
 */
exports.userFactory = {
    create(overrides = {}) {
        const roles = Object.values(shared_1.UserRole);
        return {
            userId: `USR-${faker_1.faker.string.uuid()}`,
            email: faker_1.faker.internet.email(),
            name: faker_1.faker.person.fullName(),
            role: faker_1.faker.helpers.arrayElement(roles),
            active: true,
            createdAt: faker_1.faker.date.past(),
            ...overrides,
        };
    },
    createPicker(overrides = {}) {
        return this.create({
            role: shared_1.UserRole.PICKER,
            ...overrides,
        });
    },
    createPacker(overrides = {}) {
        return this.create({
            role: shared_1.UserRole.PACKER,
            ...overrides,
        });
    },
    createAdmin(overrides = {}) {
        return this.create({
            role: shared_1.UserRole.ADMIN,
            ...overrides,
        });
    },
    createSupervisor(overrides = {}) {
        return this.create({
            role: shared_1.UserRole.SUPERVISOR,
            ...overrides,
        });
    },
};
/**
 * Factory for creating test orders
 */
exports.orderFactory = {
    create(overrides = {}) {
        const orderId = `ORD-${faker_1.faker.date.past().toISOString().slice(0, 10).replace(/-/g, '')}-${faker_1.faker.string.numeric(6)}`;
        return {
            orderId,
            customerName: faker_1.faker.person.fullName(),
            customerId: `CUST-${faker_1.faker.string.numeric(6)}`,
            status: shared_1.OrderStatus.PENDING,
            priority: faker_1.faker.helpers.arrayElement(Object.values(shared_1.OrderPriority)),
            pickerId: undefined,
            packerId: undefined,
            items: [],
            progress: 0,
            createdAt: faker_1.faker.date.past(),
            updatedAt: faker_1.faker.date.recent(),
            ...overrides,
        };
    },
    createPicking(overrides = {}) {
        const picker = exports.userFactory.createPicker();
        return this.create({
            status: shared_1.OrderStatus.PICKING,
            pickerId: picker.userId,
            ...overrides,
        });
    },
    createPicked(overrides = {}) {
        const picker = exports.userFactory.createPicker();
        return this.create({
            status: shared_1.OrderStatus.PICKED,
            pickerId: picker.userId,
            items: exports.orderItemFactory.createList(3, { pickedQuantity: 10 }),
            ...overrides,
        });
    },
    createPacking(overrides = {}) {
        const picker = exports.userFactory.createPicker();
        const packer = exports.userFactory.createPacker();
        return this.create({
            status: shared_1.OrderStatus.PACKING,
            pickerId: picker.userId,
            packerId: packer.userId,
            items: exports.orderItemFactory.createList(3, { pickedQuantity: 10 }),
            ...overrides,
        });
    },
    createShipped(overrides = {}) {
        const picker = exports.userFactory.createPicker();
        const packer = exports.userFactory.createPacker();
        return this.create({
            status: shared_1.OrderStatus.SHIPPED,
            pickerId: picker.userId,
            packerId: packer.userId,
            items: exports.orderItemFactory.createList(3, { pickedQuantity: 10 }),
            ...overrides,
        });
    },
    createWithItems(itemCount, overrides = {}) {
        return this.create({
            items: exports.orderItemFactory.createList(itemCount),
            ...overrides,
        });
    },
};
/**
 * Factory for creating test order items
 */
exports.orderItemFactory = {
    create(overrides = {}) {
        return {
            orderItemId: `ITM-${faker_1.faker.string.uuid()}`,
            orderId: exports.orderFactory.create().orderId,
            sku: `PROD-${faker_1.faker.string.alphanumeric({ casing: 'upper', length: 6 })}`,
            name: faker_1.faker.commerce.productName(),
            quantity: faker_1.faker.number.int({ min: 1, max: 100 }),
            pickedQuantity: 0,
            binLocation: `A-${faker_1.faker.string.numeric(2)}-${faker_1.faker.string.numeric(2)}`,
            status: shared_1.OrderItemStatus.PENDING,
            ...overrides,
        };
    },
    createList(count, overrides = {}) {
        return Array.from({ length: count }, () => this.create(overrides));
    },
    createPicked(overrides = {}) {
        const quantity = faker_1.faker.number.int({ min: 1, max: 100 });
        return this.create({
            quantity,
            pickedQuantity: quantity,
            ...overrides,
        });
    },
};
/**
 * Factory for creating test pick tasks
 */
exports.pickTaskFactory = {
    create(overrides = {}) {
        const order = exports.orderFactory.create();
        const item = exports.orderItemFactory.create({ orderId: order.orderId });
        return {
            pickTaskId: `TSK-${faker_1.faker.date.past().toISOString().slice(0, 10).replace(/-/g, '')}-${faker_1.faker.string.numeric(6)}`,
            orderId: order.orderId,
            orderItemId: item.orderItemId,
            sku: item.sku,
            name: item.name,
            targetBin: item.binLocation,
            quantity: item.quantity,
            pickedQuantity: 0,
            status: shared_1.TaskStatus.PENDING,
            ...overrides,
        };
    },
    createInProgress(overrides = {}) {
        const picker = exports.userFactory.createPicker();
        return this.create({
            status: shared_1.TaskStatus.IN_PROGRESS,
            pickerId: picker.userId,
            startedAt: faker_1.faker.date.recent(),
            ...overrides,
        });
    },
    createCompleted(overrides = {}) {
        const picker = exports.userFactory.createPicker();
        return this.create({
            status: shared_1.TaskStatus.COMPLETED,
            pickerId: picker.userId,
            completedAt: faker_1.faker.date.recent(),
            ...overrides,
        });
    },
    createList(count, overrides = {}) {
        return Array.from({ length: count }, () => this.create(overrides));
    },
};
/**
 * Factory for creating test inventory
 */
exports.inventoryFactory = {
    create(overrides = {}) {
        const quantity = faker_1.faker.number.int({ min: 10, max: 1000 });
        const reserved = faker_1.faker.number.int({ min: 0, max: Math.floor(quantity / 2) });
        return {
            unitId: `INV-${faker_1.faker.string.uuid()}`,
            sku: `PROD-${faker_1.faker.string.alphanumeric({ casing: 'upper', length: 6 })}`,
            quantity,
            reserved,
            available: quantity - reserved,
            binLocation: `${faker_1.faker.helpers.arrayElement(['A', 'B', 'C'])}-${faker_1.faker.number.int({ min: 1, max: 20 })}-${faker_1.faker.number.int({ min: 1, max: 20 })}`,
            lastUpdated: faker_1.faker.date.recent(),
            ...overrides,
        };
    },
    createLowStock(overrides = {}) {
        return this.create({
            quantity: 15,
            reserved: 10,
            available: 5,
            ...overrides,
        });
    },
    createOutOfStock(overrides = {}) {
        return this.create({
            quantity: 0,
            reserved: 0,
            available: 0,
            ...overrides,
        });
    },
    createList(count, overrides = {}) {
        return Array.from({ length: count }, () => this.create(overrides));
    },
};
/**
 * Test database helpers
 */
exports.testDbHelpers = {
    /**
     * Clean all test data from database
     */
    async cleanDatabase(db) {
        await db('inventory_transactions').truncate();
        await db('order_state_changes').truncate();
        await db('pick_tasks').truncate();
        await db('order_items').truncate();
        await db('orders').truncate();
        await db('inventory').truncate();
        await db('users').truncate();
    },
    /**
     * Seed test database with sample data
     */
    async seedTestData(db) {
        // Create users
        const picker = exports.userFactory.createPicker();
        const packer = exports.userFactory.createPacker();
        const admin = exports.userFactory.createAdmin();
        await db('users').insert([picker, packer, admin]);
        // Create inventory
        const inventory = exports.inventoryFactory.createList(10);
        await db('inventory').insert(inventory);
        // Create order
        const order = exports.orderFactory.createWithItems(3);
        await db('orders').insert(order);
        await db('order_items').insert(order.items);
        // Create pick tasks
        const pickTasks = exports.pickTaskFactory.createList(3);
        await db('pick_tasks').insert(pickTasks);
    },
    /**
     * Create test transaction
     */
    async createTestTransaction(db) {
        return db.transaction();
    },
};
/**
 * API test helpers
 */
exports.apiTestHelpers = {
    /**
     * Get authentication token for test user
     */
    async getAuthToken(request, email, password) {
        const response = await request.post('/api/auth/login').send({ email, password });
        return response.body.token;
    },
    /**
     * Create authenticated request
     */
    authenticatedRequest(token) {
        return {
            headers: {
                Authorization: `Bearer ${token}`,
            },
        };
    },
    /**
     * Expect error response
     */
    expectErrorResponse(response, statusCode, errorCode) {
        expect(response.status).toBe(statusCode);
        expect(response.body.error).toBeDefined();
        expect(response.body.code).toBe(errorCode);
    },
};
/**
 * Performance test helpers
 */
exports.perfTestHelpers = {
    /**
     * Measure execution time
     */
    async measureTime(fn) {
        const start = Date.now();
        const result = await fn();
        const duration = Date.now() - start;
        return { result, duration };
    },
    /**
     * Generate load test data
     */
    generateLoadTestData(orderCount) {
        return {
            users: [exports.userFactory.createPicker(), exports.userFactory.createPacker(), exports.userFactory.createAdmin()],
            orders: Array.from({ length: orderCount }, () => exports.orderFactory.create()),
            inventory: exports.inventoryFactory.createList(100),
        };
    },
};
//# sourceMappingURL=factories.js.map