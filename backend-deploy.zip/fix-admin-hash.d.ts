/**
 * Fix admin password hash
 *
 * Regenerates the bcrypt hash for the default admin user
 */
export {};
//# sourceMappingURL=fix-admin-hash.d.ts.map