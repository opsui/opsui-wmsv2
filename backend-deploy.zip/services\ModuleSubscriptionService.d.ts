/**
 * Module Subscription Service
 *
 * Manages module subscriptions per entity for modular ERP pricing
 */
import { ModuleId, UserTierId, ModuleDefinition } from '@opsui/shared';
export type BillingCycle = 'MONTHLY' | 'ANNUAL' | 'TRIAL' | 'CUSTOM';
export type SubscriptionStatus = 'ACTIVE' | 'SUSPENDED' | 'CANCELLED' | 'EXPIRED' | 'TRIAL' | 'PENDING_PAYMENT';
export interface ModuleSubscription {
    subscription_id: string;
    entity_id: string;
    module_id: ModuleId;
    billing_cycle: BillingCycle;
    price_per_period: number;
    currency: string;
    discount_percentage: number;
    subscription_status: SubscriptionStatus;
    subscription_start: Date;
    subscription_end: Date | null;
    trial_ends_at: Date | null;
    last_billing_date: Date | null;
    next_billing_date: Date | null;
    billing_day_of_month: number;
    auto_renew: boolean;
    user_count_at_billing: number;
    notes: string | null;
    created_at: Date;
    updated_at: Date;
    created_by: string | null;
}
export interface EntityUserTier {
    tier_assignment_id: string;
    entity_id: string;
    tier_id: UserTierId;
    monthly_fee: number;
    currency: string;
    effective_date: Date;
    expiry_date: Date | null;
    current_user_count: number;
    max_user_count: number | null;
    last_billing_date: Date | null;
    next_billing_date: Date | null;
    created_at: Date;
    updated_at: Date;
}
export interface AddonSubscription {
    addon_subscription_id: string;
    entity_id: string;
    addon_id: string;
    one_time_fee: number;
    monthly_fee: number;
    currency: string;
    is_active: boolean;
    subscription_start: Date;
    subscription_end: Date | null;
    notes: string | null;
    created_at: Date;
    updated_at: Date;
    created_by: string | null;
}
export interface CreateModuleSubscriptionDTO {
    entityId: string;
    moduleId: ModuleId;
    billingCycle: BillingCycle;
    customPrice?: number;
    discountPercentage?: number;
    startDate?: Date;
    endDate?: Date;
    notes?: string;
    createdBy?: string;
}
export interface UpdateModuleSubscriptionDTO {
    billingCycle?: BillingCycle;
    pricePerPeriod?: number;
    discountPercentage?: number;
    subscriptionStatus?: SubscriptionStatus;
    subscriptionEnd?: Date | null;
    autoRenew?: boolean;
    notes?: string;
}
export interface EntityBillingSummary {
    entityId: string;
    enabledModules: Array<{
        moduleId: ModuleId;
        moduleName: string;
        pricePerPeriod: number;
        billingCycle: BillingCycle;
        status: SubscriptionStatus;
    }>;
    userTier: {
        tierId: UserTierId;
        tierName: string;
        monthlyFee: number;
        currentUserCount: number;
        maxUserCount: number | null;
    };
    addons: Array<{
        addonId: string;
        monthlyFee: number;
        isActive: boolean;
    }>;
    totals: {
        monthly: number;
        annual: number;
        currency: string;
    };
}
/**
 * Invalidate cache (call after database updates)
 */
export declare function invalidateModuleCache(): void;
/**
 * Check if a module is enabled for an entity
 */
export declare function isModuleEnabled(entityId: string, moduleId: ModuleId): Promise<boolean>;
/**
 * Get all enabled modules for an entity
 */
export declare function getEnabledModules(entityId: string): Promise<ModuleId[]>;
/**
 * Check if multiple modules are enabled
 */
export declare function areModulesEnabled(entityId: string, moduleIds: ModuleId[]): Promise<Record<ModuleId, boolean>>;
/**
 * Get module definitions with enabled status for an entity
 */
export declare function getModulesWithStatus(entityId: string): Promise<Array<ModuleDefinition & {
    isEnabled: boolean;
    subscription?: ModuleSubscription;
}>>;
/**
 * Get the user tier for an entity
 */
export declare function getEntityUserTier(entityId: string): Promise<EntityUserTier | null>;
/**
 * Set the user tier for an entity
 */
export declare function setEntityUserTier(entityId: string, tierId: UserTierId, userId?: string): Promise<EntityUserTier>;
/**
 * Update user count for an entity's tier
 */
export declare function updateUserCount(entityId: string): Promise<number>;
/**
 * Enable a module for an entity
 */
export declare function enableModule(dto: CreateModuleSubscriptionDTO): Promise<ModuleSubscription>;
/**
 * Disable a module for an entity
 */
export declare function disableModule(entityId: string, moduleId: ModuleId, userId?: string, reason?: string): Promise<void>;
/**
 * Update a module subscription
 */
export declare function updateModuleSubscription(entityId: string, moduleId: ModuleId, updates: UpdateModuleSubscriptionDTO, userId?: string): Promise<ModuleSubscription>;
/**
 * Get billing summary for an entity
 */
export declare function getEntityBillingSummary(entityId: string): Promise<EntityBillingSummary>;
/**
 * Enable an addon for an entity
 */
export declare function enableAddon(entityId: string, addonId: string, userId?: string): Promise<AddonSubscription>;
/**
 * Disable an addon for an entity
 */
export declare function disableAddon(entityId: string, addonId: string): Promise<void>;
/**
 * Enable multiple modules at once (for bundles)
 */
export declare function enableModules(dto: Omit<CreateModuleSubscriptionDTO, 'moduleId'> & {
    moduleIds: ModuleId[];
}): Promise<ModuleSubscription[]>;
/**
 * Get audit log for an entity
 */
export declare function getModuleAuditLog(entityId: string, limit?: number): Promise<Array<{
    audit_id: string;
    module_id: string | null;
    action: string;
    old_values: object | null;
    new_values: object | null;
    user_id: string | null;
    created_at: Date;
}>>;
//# sourceMappingURL=ModuleSubscriptionService.d.ts.map