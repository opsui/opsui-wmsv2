/**
 * Database client configuration
 *
 * Handles PostgreSQL connection pooling and provides
 * a singleton connection pool for the application.
 */
import { Pool, PoolClient as PoolClientType, QueryResult } from 'pg';
export type PoolClient = PoolClientType;
/**
 * Get or create the database connection pool
 */
export declare function getPool(): Pool;
/**
 * Close the database connection pool
 */
export declare function closePool(): Promise<void>;
/**
 * Test database connection
 */
export declare function testConnection(): Promise<boolean>;
/**
 * Execute a query with parameters
 */
export declare function query<T extends Record<string, any> = Record<string, any>>(text: string, params?: any[]): Promise<QueryResult<T>>;
/**
 * Execute a query within a transaction
 */
export declare function transaction<T>(callback: (client: PoolClient) => Promise<T>): Promise<T>;
/**
 * Get a client from the pool for manual transaction management
 */
export declare function getClient(): Promise<PoolClient>;
/**
 * Get database health status
 */
export declare function getHealthStatus(): Promise<{
    healthy: boolean;
    connections: number;
    waiting: number;
    max: number;
}>;
/**
 * Setup graceful shutdown handlers
 */
export declare function setupShutdownHandlers(): void;
//# sourceMappingURL=client.d.ts.map