/**
 * @purpose: Notification repository - handles all database operations for notifications
 * @domain: Notifications
 * @tested: No tests yet (0% coverage)
 * @last-change: 2025-01-25 - Initial implementation
 * @dependencies: BaseRepository, pg, logger
 * @description: Manages notification persistence, preferences, templates, and queue
 * @invariants: All notifications have valid userId, type, and channel
 * @performance: Queries optimized with indexes on userId, type, status, channel
 * @security: User-scoped queries prevent cross-user notification access
 */
import { BaseRepository } from './BaseRepository';
import { Notification, NotificationPreferences, NotificationTemplate, NotificationQueue, CreateNotificationDTO, ListNotificationsParams, NotificationType, NotificationStatus, UpdateNotificationPreferencesDTO, NotificationStats } from '@opsui/shared';
export declare class NotificationRepository extends BaseRepository<Notification> {
    constructor();
    createNotification(dto: CreateNotificationDTO): Promise<Notification>;
    listNotifications(userId: string, params?: ListNotificationsParams): Promise<{
        notifications: Notification[];
        total: number;
    }>;
    getNotificationStats(userId: string): Promise<NotificationStats>;
    markAsRead(notificationId: string): Promise<Notification | null>;
    markAllAsRead(userId: string): Promise<number>;
    updateStatus(notificationId: string, status: NotificationStatus, externalId?: string, errorMessage?: string): Promise<Notification | null>;
    deleteNotification(notificationId: string, userId: string): Promise<boolean>;
    cleanupExpired(): Promise<number>;
    getPreferences(userId: string): Promise<NotificationPreferences | null>;
    createDefaultPreferences(userId: string): Promise<NotificationPreferences>;
    updatePreferences(userId: string, dto: UpdateNotificationPreferencesDTO): Promise<NotificationPreferences>;
    updatePushSubscription(userId: string, pushSubscription: any): Promise<NotificationPreferences>;
    removePushSubscription(userId: string): Promise<NotificationPreferences | null>;
    getTemplateByName(name: string): Promise<NotificationTemplate | null>;
    getTemplatesByType(type: NotificationType): Promise<NotificationTemplate[]>;
    enqueueJob(jobType: string, payload: Record<string, any>, priority?: number): Promise<NotificationQueue>;
    getNextPendingJobs(limit?: number): Promise<NotificationQueue[]>;
    updateQueueJob(queueId: string, status: string, errorMessage?: string): Promise<NotificationQueue | null>;
    deleteCompletedJobs(): Promise<number>;
}
export declare const notificationRepository: NotificationRepository;
//# sourceMappingURL=NotificationRepository.d.ts.map