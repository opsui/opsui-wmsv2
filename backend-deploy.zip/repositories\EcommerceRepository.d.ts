/**
 * E-commerce Integration Repository
 *
 * Data access layer for e-commerce platform integration
 */
import { BaseRepository } from './BaseRepository';
import type { EcommerceConnection, EcommerceProductMapping, EcommerceInventorySync, EcommerceOrderSync, EcommerceCustomerSync, EcommerceWebhook, EcommerceSyncLog, EcommerceConnectionStatus, EcommerceSyncError, EcommercePendingSync, PlatformType, ProductMappingStatus, EcommerceSyncStatus, WebhookProcessingStatus } from '@opsui/shared';
export declare class EcommerceRepository extends BaseRepository<EcommerceConnection> {
    constructor();
    /**
     * Find connection by platform type
     */
    findByPlatformType(platformType: PlatformType): Promise<EcommerceConnection[]>;
    /**
     * Find active connections
     */
    findActiveConnections(): Promise<EcommerceConnection[]>;
    /**
     * Find connection by name
     */
    findByName(connectionName: string): Promise<EcommerceConnection | null>;
    /**
     * Update connection last sync timestamp
     */
    updateLastSync(connectionId: string): Promise<void>;
    /**
     * Update rate limit info
     */
    updateRateLimit(connectionId: string, remaining: number, resetAt: Date): Promise<void>;
    /**
     * Find product mapping by connection and external ID
     */
    findProductMapping(connectionId: string, externalProductId: string): Promise<EcommerceProductMapping | null>;
    /**
     * Find product mapping by internal SKU
     */
    findProductMappingBySKU(connectionId: string, internalSku: string): Promise<EcommerceProductMapping | null>;
    /**
     * Find all product mappings for a connection
     */
    findAllProductMappings(connectionId: string): Promise<EcommerceProductMapping[]>;
    /**
     * Find product mappings by status
     */
    findProductMappingsByStatus(connectionId: string, status: ProductMappingStatus): Promise<EcommerceProductMapping[]>;
    /**
     * Create product mapping
     */
    createProductMapping(mapping: Omit<EcommerceProductMapping, 'mappingId' | 'createdAt' | 'updatedAt'>): Promise<EcommerceProductMapping>;
    /**
     * Update product mapping
     */
    updateProductMapping(mappingId: string, updates: Partial<Omit<EcommerceProductMapping, 'mappingId' | 'createdAt' | 'updatedAt'>>): Promise<EcommerceProductMapping | null>;
    /**
     * Delete product mapping
     */
    deleteProductMapping(mappingId: string): Promise<boolean>;
    /**
     * Create inventory sync record
     */
    createInventorySync(sync: Omit<EcommerceInventorySync, 'syncId' | 'startedAt' | 'variance'>): Promise<EcommerceInventorySync>;
    /**
     * Update inventory sync status
     */
    updateInventorySyncStatus(syncId: string, status: EcommerceSyncStatus, externalQuantityAfter?: number, errorMessage?: string): Promise<EcommerceInventorySync | null>;
    /**
     * Find recent inventory syncs for a connection
     */
    findRecentInventorySyncs(connectionId: string, limit?: number): Promise<EcommerceInventorySync[]>;
    /**
     * Find failed inventory syncs
     */
    findFailedInventorySyncs(connectionId?: string): Promise<EcommerceInventorySync[]>;
    /**
     * Create order sync record
     */
    createOrderSync(sync: Omit<EcommerceOrderSync, 'syncId' | 'createdAt' | 'processingAttempts'>): Promise<EcommerceOrderSync>;
    /**
     * Update order sync status
     */
    updateOrderSyncStatus(syncId: string, status: EcommerceSyncStatus, internalOrderId?: string, errorMessage?: string, incrementAttempts?: boolean): Promise<EcommerceOrderSync | null>;
    /**
     * Find order sync by external order ID
     */
    findOrderSyncByExternalId(connectionId: string, externalOrderId: string): Promise<EcommerceOrderSync | null>;
    /**
     * Find pending order syncs
     */
    findPendingOrderSyncs(connectionId?: string): Promise<EcommerceOrderSync[]>;
    /**
     * Find failed order syncs
     */
    findFailedOrderSyncs(connectionId?: string): Promise<EcommerceOrderSync[]>;
    /**
     * Find recent order syncs
     */
    findRecentOrderSyncs(connectionId: string, limit?: number): Promise<EcommerceOrderSync[]>;
    /**
     * Create customer sync record
     */
    createCustomerSync(sync: Omit<EcommerceCustomerSync, 'syncId' | 'createdAt' | 'updatedAt'>): Promise<EcommerceCustomerSync>;
    /**
     * Update customer sync
     */
    updateCustomerSync(syncId: string, updates: Partial<Omit<EcommerceCustomerSync, 'syncId' | 'createdAt' | 'updatedAt'>>): Promise<EcommerceCustomerSync | null>;
    /**
     * Find customer sync by external ID
     */
    findCustomerSyncByExternalId(connectionId: string, externalCustomerId: string): Promise<EcommerceCustomerSync | null>;
    /**
     * Create webhook record
     */
    createWebhook(webhook: Omit<EcommerceWebhook, 'webhookId' | 'createdAt' | 'retryCount'>): Promise<EcommerceWebhook>;
    /**
     * Update webhook processing status
     */
    updateWebhookStatus(webhookId: string, status: WebhookProcessingStatus, errorMessage?: string, incrementRetry?: boolean): Promise<EcommerceWebhook | null>;
    /**
     * Find pending webhooks
     */
    findPendingWebhooks(connectionId?: string): Promise<EcommerceWebhook[]>;
    /**
     * Find recent webhooks
     */
    findRecentWebhooks(connectionId: string, limit?: number): Promise<EcommerceWebhook[]>;
    /**
     * Create sync log
     */
    createSyncLog(log: Omit<EcommerceSyncLog, 'logId' | 'startedAt'>): Promise<EcommerceSyncLog>;
    /**
     * Update sync log
     */
    updateSyncLog(logId: string, updates: Partial<Omit<EcommerceSyncLog, 'logId' | 'startedAt' | 'completedAt'>>): Promise<EcommerceSyncLog | null>;
    /**
     * Find sync logs for a connection
     */
    findSyncLogs(connectionId: string, limit?: number): Promise<EcommerceSyncLog[]>;
    /**
     * Get connection status view data
     */
    getConnectionStatus(): Promise<EcommerceConnectionStatus[]>;
    /**
     * Get sync errors view data
     */
    getSyncErrors(): Promise<EcommerceSyncError[]>;
    /**
     * Get pending sync view data
     */
    getPendingSyncs(): Promise<EcommercePendingSync[]>;
    /**
     * Get Shopify settings for a connection
     */
    getShopifySettings(connectionId: string): Promise<any>;
    /**
     * Save Shopify settings for a connection
     */
    saveShopifySettings(connectionId: string, settings: any): Promise<void>;
    /**
     * Get WooCommerce settings for a connection
     */
    getWooCommerceSettings(connectionId: string): Promise<any>;
    /**
     * Save WooCommerce settings for a connection
     */
    saveWooCommerceSettings(connectionId: string, settings: any): Promise<void>;
    /**
     * Get Magento settings for a connection
     */
    getMagentoSettings(connectionId: string): Promise<any>;
    /**
     * Save Magento settings for a connection
     */
    saveMagentoSettings(connectionId: string, settings: any): Promise<void>;
}
export declare const ecommerceRepository: EcommerceRepository;
//# sourceMappingURL=EcommerceRepository.d.ts.map