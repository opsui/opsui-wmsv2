"use strict";
/**
 * Run RMA Migration
 */
Object.defineProperty(exports, "__esModule", { value: true });
const client_1 = require("./client");
const _050_create_rma_tables_1 = require("./migrations/050_create_rma_tables");
async function runMigration() {
    const pool = (0, client_1.getPool)();
    const client = await pool.connect();
    try {
        await client.query('BEGIN');
        await (0, _050_create_rma_tables_1.up)(client);
        await client.query('COMMIT');
        console.log('RMA migration completed successfully!');
    }
    catch (error) {
        await client.query('ROLLBACK');
        console.error('Migration failed:', error);
        throw error;
    }
    finally {
        client.release();
    }
}
runMigration()
    .then(() => process.exit(0))
    .catch(() => process.exit(1));
//# sourceMappingURL=run-rma-migration.js.map