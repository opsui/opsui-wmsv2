/**
 * Order Exception Service
 *
 * Handles order exceptions during fulfillment - short picks, damages, substitutions, etc.
 */
import { ExceptionType, ExceptionStatus, OrderException, LogExceptionDTO, ResolveExceptionDTO } from '@opsui/shared';
export declare class OrderExceptionService {
    logException(dto: LogExceptionDTO): Promise<OrderException>;
    getException(exceptionId: string): Promise<OrderException>;
    getOpenExceptions(filters?: {
        orderId?: string;
        sku?: string;
        type?: ExceptionType;
        limit?: number;
        offset?: number;
    }): Promise<{
        exceptions: OrderException[];
        total: number;
    }>;
    getAllExceptions(filters?: {
        status?: ExceptionStatus;
        orderId?: string;
        limit?: number;
        offset?: number;
    }): Promise<{
        exceptions: OrderException[];
        total: number;
    }>;
    resolveException(dto: ResolveExceptionDTO): Promise<OrderException>;
    getExceptionSummary(): Promise<{
        total: number;
        open: number;
        resolved: number;
        byType: Record<string, number>;
    }>;
    reportProblem(dto: {
        problemType: string;
        location?: string;
        description: string;
        reportedBy: string;
    }): Promise<{
        problemId: string;
        problemType: string;
        location: string | null;
        description: string;
        reportedBy: string;
        reportedAt: Date;
        status: string;
    }>;
    getProblemReports(filters?: {
        status?: string;
        problemType?: string;
        limit?: number;
        offset?: number;
    }): Promise<{
        problems: Array<{
            problemId: string;
            problemType: string;
            location: string | null;
            description: string;
            reportedBy: string;
            reportedAt: Date;
            status: string;
            resolution?: string;
            resolvedBy?: string;
            resolvedAt?: Date;
        }>;
        total: number;
    }>;
    resolveProblemReport(dto: {
        problemId: string;
        resolution: string;
        notes?: string;
        resolvedBy: string;
    }): Promise<{
        problemId: string;
        status: string;
        resolution: string;
        resolvedBy: string;
        resolvedAt: Date;
    }>;
    private mapRowToException;
}
export declare const orderExceptionService: OrderExceptionService;
//# sourceMappingURL=OrderExceptionService.d.ts.map