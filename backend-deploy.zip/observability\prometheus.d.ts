/**
 * Prometheus Metrics Middleware
 *
 * Provides HTTP metrics endpoint for Prometheus scraping
 * and request tracking middleware
 */
import { Request, Response, NextFunction } from 'express';
import promClient, { Counter, Histogram, Gauge } from 'prom-client';
/**
 * Counter for total HTTP requests
 */
export declare const httpRequestsTotal: promClient.Counter<"route" | "method" | "status_code">;
/**
 * Histogram for HTTP request duration
 */
export declare const httpRequestDurationMs: promClient.Histogram<"route" | "method" | "status_code">;
/**
 * Histogram for request size
 */
export declare const httpRequestSizeBytes: promClient.Histogram<"route" | "method">;
/**
 * Histogram for response size
 */
export declare const httpResponseSizeBytes: promClient.Histogram<"route" | "method" | "status_code">;
/**
 * Counter for HTTP errors
 */
export declare const httpErrorsTotal: promClient.Counter<"route" | "method" | "status_code" | "error_type">;
/**
 * Gauge for concurrent requests
 */
export declare const httpConcurrentRequests: promClient.Gauge<string>;
/**
 * Histogram for database query duration
 */
export declare const dbQueryDurationMs: promClient.Histogram<"operation" | "table">;
/**
 * Gauge for database connection pool
 */
export declare const dbConnectionPool: promClient.Gauge<"state">;
/**
 * Counter for database errors
 */
export declare const dbErrorsTotal: promClient.Counter<"operation" | "error_code">;
/**
 * Counter for cache hits
 */
export declare const cacheHitsTotal: promClient.Counter<"cache_type">;
/**
 * Counter for cache misses
 */
export declare const cacheMissesTotal: promClient.Counter<"cache_type">;
/**
 * Gauge for cache size
 */
export declare const cacheSize: promClient.Gauge<"cache_type">;
/**
 * Counter for orders processed
 */
export declare const ordersProcessedTotal: promClient.Counter<"status" | "priority">;
/**
 * Histogram for order processing duration
 */
export declare const orderProcessingDurationMs: promClient.Histogram<"priority">;
/**
 * Counter for picks completed
 */
export declare const picksCompletedTotal: promClient.Counter<"zone" | "picker_id">;
/**
 * Histogram for pick duration
 */
export declare const pickDurationMs: promClient.Histogram<"zone" | "picker_id">;
/**
 * Counter for inventory transactions
 */
export declare const inventoryTransactionsTotal: promClient.Counter<"sku" | "transaction_type">;
/**
 * Gauge for current active users
 */
export declare const activeUsersGauge: promClient.Gauge<"role">;
/**
 * Gauge for orders by status
 */
export declare const ordersByStatusGauge: promClient.Gauge<"status">;
/**
 * Counter for exceptions raised
 */
export declare const exceptionsTotal: promClient.Counter<"severity" | "exception_type">;
/**
 * Counter for rate limit violations
 */
export declare const rateLimitViolationsTotal: promClient.Counter<"endpoint" | "limit_type">;
/**
 * Metrics tracking middleware
 */
export declare const metricsMiddleware: (req: Request, res: Response, next: NextFunction) => void;
/**
 * Metrics endpoint handler for Prometheus scraping
 * Returns metrics in Prometheus text format
 */
export declare function metricsEndpoint(_req: Request, res: Response): Promise<void>;
/**
 * Health check endpoint that includes metrics
 */
export declare function healthWithMetrics(_req: Request, res: Response): Promise<void>;
/**
 * Reset all metrics (useful for testing)
 */
export declare function resetMetrics(): void;
/**
 * Get metrics as JSON (for debugging)
 */
export declare function getMetricsAsJSON(): Promise<any>;
/**
 * Create a custom counter
 */
export declare function createCounter(name: string, help: string, labelNames?: string[]): Counter<string>;
/**
 * Create a custom histogram
 */
export declare function createHistogram(name: string, help: string, options?: {
    labelNames?: string[];
    buckets?: number[];
}): Histogram<string>;
/**
 * Create a custom gauge
 */
export declare function createGauge(name: string, help: string, labelNames?: string[]): Gauge<string>;
declare const _default: {
    register: promClient.Registry<"text/plain; version=0.0.4; charset=utf-8">;
    metricsEndpoint: typeof metricsEndpoint;
    healthWithMetrics: typeof healthWithMetrics;
    metricsMiddleware: (req: Request, res: Response, next: NextFunction) => void;
    resetMetrics: typeof resetMetrics;
    getMetricsAsJSON: typeof getMetricsAsJSON;
    createCounter: typeof createCounter;
    createHistogram: typeof createHistogram;
    createGauge: typeof createGauge;
    httpRequestsTotal: promClient.Counter<"route" | "method" | "status_code">;
    httpRequestDurationMs: promClient.Histogram<"route" | "method" | "status_code">;
    httpRequestSizeBytes: promClient.Histogram<"route" | "method">;
    httpResponseSizeBytes: promClient.Histogram<"route" | "method" | "status_code">;
    httpErrorsTotal: promClient.Counter<"route" | "method" | "status_code" | "error_type">;
    httpConcurrentRequests: promClient.Gauge<string>;
    dbQueryDurationMs: promClient.Histogram<"operation" | "table">;
    dbConnectionPool: promClient.Gauge<"state">;
    dbErrorsTotal: promClient.Counter<"operation" | "error_code">;
    cacheHitsTotal: promClient.Counter<"cache_type">;
    cacheMissesTotal: promClient.Counter<"cache_type">;
    cacheSize: promClient.Gauge<"cache_type">;
    ordersProcessedTotal: promClient.Counter<"status" | "priority">;
    orderProcessingDurationMs: promClient.Histogram<"priority">;
    picksCompletedTotal: promClient.Counter<"zone" | "picker_id">;
    pickDurationMs: promClient.Histogram<"zone" | "picker_id">;
    inventoryTransactionsTotal: promClient.Counter<"sku" | "transaction_type">;
    activeUsersGauge: promClient.Gauge<"role">;
    ordersByStatusGauge: promClient.Gauge<"status">;
    exceptionsTotal: promClient.Counter<"severity" | "exception_type">;
    rateLimitViolationsTotal: promClient.Counter<"endpoint" | "limit_type">;
};
export default _default;
//# sourceMappingURL=prometheus.d.ts.map