"use strict";
/**
 * Pagination Utilities
 *
 * Provides helpers for paginated responses with metadata
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.calculatePaginationMeta = calculatePaginationMeta;
exports.parsePaginationParams = parsePaginationParams;
exports.calculateSqlOffset = calculateSqlOffset;
exports.sendPaginatedResponse = sendPaginatedResponse;
exports.addOrderByClause = addOrderByClause;
exports.addPaginationClause = addPaginationClause;
// ============================================================================
// PAGINATION METADATA CALCULATION
// ============================================================================
/**
 * Calculate pagination metadata from total count and current params
 */
function calculatePaginationMeta(total, page, limit) {
    const totalPages = Math.ceil(total / limit);
    const hasNextPage = page < totalPages;
    const hasPreviousPage = page > 1;
    return {
        page,
        limit,
        total,
        totalPages,
        hasNextPage,
        hasPreviousPage,
        nextPage: hasNextPage ? page + 1 : undefined,
        previousPage: hasPreviousPage ? page - 1 : undefined,
    };
}
/**
 * Parse and validate pagination query parameters
 */
function parsePaginationParams(query, defaultPage = 1, defaultLimit = 20, maxLimit = 100) {
    const page = Math.max(defaultPage, parseInt(query.page || defaultPage.toString(), 10));
    const limit = Math.min(maxLimit, Math.max(1, parseInt(query.limit || defaultLimit.toString(), 10)));
    const sortBy = query.sortBy || 'createdAt';
    const sortOrder = (query.sortOrder || 'desc');
    return {
        page,
        limit,
        sortBy,
        sortOrder,
    };
}
/**
 * Calculate SQL offset and limit from pagination params
 */
function calculateSqlOffset(pagination) {
    const offset = (pagination.page - 1) * pagination.limit;
    return {
        offset,
        limit: pagination.limit,
    };
}
/**
 * Send paginated response with metadata
 */
function sendPaginatedResponse(res, data, total, pagination) {
    const paginationMeta = calculatePaginationMeta(total, pagination.page, pagination.limit);
    res.json({
        data,
        pagination: paginationMeta,
        success: true,
    });
}
// ============================================================================
// DATABASE QUERY HELPERS
// ============================================================================
/**
 * Add ORDER BY clause to SQL query based on pagination params
 */
function addOrderByClause(sql, sortBy, sortOrder = 'desc') {
    // Validate sortBy to prevent SQL injection
    const validSortColumns = [
        'createdAt',
        'updatedAt',
        'orderId',
        'sku',
        'status',
        'priority',
        'name',
        'quantity',
    ];
    const safeSortBy = validSortColumns.includes(sortBy) ? sortBy : 'createdAt';
    const safeSortOrder = sortOrder === 'asc' ? 'ASC' : 'DESC';
    return `${sql} ORDER BY ${safeSortBy} ${safeSortOrder}`;
}
/**
 * Add pagination (LIMIT/OFFSET) to SQL query
 */
function addPaginationClause(sql, offset, _limit) {
    return `${sql} LIMIT $${offset + 1} OFFSET $${offset + 2}`;
}
//# sourceMappingURL=pagination.js.map