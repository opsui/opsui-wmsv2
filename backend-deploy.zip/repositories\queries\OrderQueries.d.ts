/**
 * Order Query Constants
 *
 * Centralized SQL queries for order-related operations to eliminate duplication
 */
/**
 * Query to fetch pick tasks for PICKING orders
 * Used in: getOrderWithItems, getOrderQueue, getOrdersWithItemsByStatus
 * Includes on-hand inventory quantity for each item
 *
 * On-hand priority:
 * 1. inventory_units.available for the specific bin (if exists)
 * 2. Sum of all inventory_units.available for this SKU (if no bin match)
 * 3. 0 as final fallback
 */
export declare const FETCH_PICK_TASKS_WITH_BARCODE_QUERY = "\n  SELECT\n    pt.pick_task_id as order_item_id,\n    pt.order_id,\n    pt.sku,\n    pt.name,\n    pt.target_bin as bin_location,\n    pt.quantity,\n    pt.picked_quantity as picked_quantity,\n    0 as verified_quantity,\n    pt.status,\n    pt.completed_at,\n    pt.skip_reason,\n    s.barcode,\n    COALESCE(\n      i_specific.available,\n      i_total.total_available,\n      0\n    ) as on_hand_quantity\n  FROM pick_tasks pt\n  LEFT JOIN skus s ON pt.sku = s.sku\n  LEFT JOIN inventory_units i_specific ON pt.sku = i_specific.sku AND pt.target_bin = i_specific.bin_location\n  LEFT JOIN (\n    SELECT sku, SUM(available) as total_available\n    FROM inventory_units\n    GROUP BY sku\n  ) i_total ON pt.sku = i_total.sku\n  WHERE pt.order_id = $1\n  ORDER BY pt.pick_task_id ASC\n";
/**
 * Query to fetch order items for non-PICKING orders
 * Used in: getOrderWithItems, getOrderQueue, getOrdersWithItemsByStatus
 */
export declare const FETCH_ORDER_ITEMS_WITH_BARCODE_QUERY = "\n  SELECT\n    oi.order_item_id,\n    oi.order_id,\n    oi.sku,\n    oi.name,\n    oi.bin_location,\n    oi.quantity,\n    oi.picked_quantity,\n    0 as verified_quantity,\n    oi.status,\n    s.barcode\n  FROM order_items oi\n  LEFT JOIN skus s ON oi.sku = s.sku\n  WHERE oi.order_id = $1\n  ORDER BY oi.order_item_id\n";
/**
 * Common CASE expression for calculating order progress
 * Returns progress percentage based on completed OR skipped pick tasks
 * SKIPPED items count as complete for progress purposes
 */
export declare const PROGRESS_CALCULATION = "\n  CASE\n    WHEN o.status = 'PICKING'\n    THEN ROUND(\n      CAST(\n        (SELECT COUNT(*) FILTER (WHERE pt.status IN ('COMPLETED', 'SKIPPED')) FROM pick_tasks pt WHERE pt.order_id = o.order_id) AS FLOAT\n      ) / NULLIF(\n        (SELECT COUNT(*) FROM pick_tasks pt WHERE pt.order_id = o.order_id),\n        0\n      ) * 100\n    )\n    ELSE 0\n  END as progress\n";
/**
 * Query to update order progress based on pick task completion
 * SKIPPED items count as complete for progress purposes
 */
export declare const UPDATE_ORDER_PROGRESS_QUERY = "\n  UPDATE orders\n  SET progress = (\n    SELECT FLOOR(\n      (CAST(COUNT(*) FILTER (WHERE pt.status IN ('COMPLETED', 'SKIPPED')) AS NUMERIC) /\n       NULLIF(COUNT(*), 0)) * 100 + 0.5\n    )\n    FROM pick_tasks pt\n    WHERE pt.order_id = $1\n  )\n  WHERE order_id = $1\n";
/**
 * Maps database row to order item camelCase format
 * Handles both pick tasks and order items
 */
export declare function mapOrderItem(row: any): any;
/**
 * Determines which query to use based on order status
 */
export declare function getOrderItemsQuery(status: string): string;
//# sourceMappingURL=OrderQueries.d.ts.map