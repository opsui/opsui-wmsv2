"use strict";
/**
 * Run the add_active_role migration
 */
Object.defineProperty(exports, "__esModule", { value: true });
const client_1 = require("./client");
async function runMigration() {
    try {
        console.log('Running add_active_role migration...');
        // Execute migration - add active_role column
        await (0, client_1.query)(`ALTER TABLE users ADD COLUMN IF NOT EXISTS active_role user_role`);
        console.log('Migration completed successfully!');
        await (0, client_1.closePool)();
        process.exit(0);
    }
    catch (error) {
        console.error('Migration failed:', error);
        await (0, client_1.closePool)();
        process.exit(1);
    }
}
runMigration();
//# sourceMappingURL=run-migration.js.map