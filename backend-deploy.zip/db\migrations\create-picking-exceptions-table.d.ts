/**
 * Migration: Create picking_exceptions table
 *
 * This table stores manual overrides and exceptions during picking
 * that affect inventory accuracy and require audit trailing.
 */
export declare function createPickingExceptionsTable(): Promise<void>;
//# sourceMappingURL=create-picking-exceptions-table.d.ts.map