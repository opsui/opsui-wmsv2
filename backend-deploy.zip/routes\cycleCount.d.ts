/**
 * Cycle Count routes
 *
 * Endpoints for managing cycle counts and inventory adjustments
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=cycleCount.d.ts.map