/**
 * Reports Service
 *
 * Business logic for generating reports, executing queries,
 * and formatting data for export.
 */
import { ReportExecution, ReportFormat, ExportJob } from '@opsui/shared';
export declare class ReportsService {
    /**
     * Execute a report and return the results
     */
    executeReport(reportId: string, format: ReportFormat, parameters: Record<string, any>, executedBy: string): Promise<{
        execution: ReportExecution;
        data: any[];
    }>;
    /**
     * Build SQL query from report definition
     */
    private buildReportQuery;
    /**
     * Get data source table for report type
     */
    private getDataSource;
    /**
     * Apply filter to query
     */
    private applyFilter;
    /**
     * Process query results
     */
    private processResults;
    /**
     * Generate file URL for report output
     */
    private generateFileUrl;
    /**
     * Create an export job
     */
    createExportJob(entityType: string, format: ReportFormat, fields: string[], filters: any[], createdBy: string): Promise<ExportJob>;
    /**
     * Process export job (async)
     */
    private processExportJob;
    /**
     * Fetch data for export based on entity type
     */
    private fetchExportData;
    /**
     * Generate export file based on format
     */
    private generateExportFile;
    /**
     * Generate CSV file
     */
    private generateCSV;
    /**
     * Generate Excel file
     */
    private generateExcel;
    /**
     * Generate PDF file
     */
    private generatePDF;
}
export declare const reportsService: ReportsService;
//# sourceMappingURL=ReportsService.d.ts.map