/**
 * Test current-view API endpoint
 *
 * This script tests the /api/auth/current-view endpoint to verify
 * that it correctly updates the database.
 */
declare function testCurrentViewAPI(): Promise<void>;
export { testCurrentViewAPI };
//# sourceMappingURL=test-current-view-api.d.ts.map