/**
 * Graceful Shutdown Manager
 * Ensures clean termination of all services and resources
 *
 * Handles:
 * - HTTP server closure
 * - Database connection cleanup
 * - Port lock release
 * - In-flight request completion
 * - WebSocket connection closure
 * - Cache flushing
 * - Logging completion
 */
import { Server } from 'http';
import { Logger } from 'winston';
interface ShutdownOptions {
    server: Server;
    port: number;
    logger: Logger;
    cleanupTasks?: Array<() => Promise<void>>;
    forceTimeout?: number;
}
interface ShutdownState {
    isShuttingDown: boolean;
    shutdownStartedAt?: Date;
    signalsReceived: string[];
}
/**
 * Setup comprehensive graceful shutdown handlers
 */
export declare function setupGracefulShutdown(options: ShutdownOptions): void;
/**
 * Create a health check that fails during shutdown
 */
export declare function createShutdownAwareHealthCheck(): () => boolean;
/**
 * Check if shutdown is in progress
 */
export declare function isShuttingDown(): boolean;
/**
 * Get shutdown state
 */
export declare function getShutdownState(): ShutdownState;
/**
 * Register additional cleanup task
 */
export declare function addCleanupTask(_task: () => Promise<void>): void;
/**
 * Immediate emergency shutdown (bypasses graceful shutdown)
 */
export declare function emergencyShutdown(reason: string): Promise<void>;
/**
 * Watch for parent process death (for PM2, Docker, etc.)
 */
export declare function watchParentProcess(): void;
/**
 * Shutdown manager for coordinating multiple services
 */
export declare class ShutdownManager {
    private services;
    private logger;
    constructor(logger: Logger);
    /**
     * Register a service shutdown handler
     */
    register(name: string, shutdownFn: () => Promise<void>): void;
    /**
     * Shutdown all registered services in order
     */
    shutdownAll(reverseOrder?: boolean): Promise<void>;
    /**
     * Get list of registered services
     */
    getRegisteredServices(): string[];
}
export {};
//# sourceMappingURL=gracefulShutdown.d.ts.map