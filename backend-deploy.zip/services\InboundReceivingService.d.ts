/**
 * Inbound Receiving Service
 *
 * Handles Advance Shipping Notices (ASN), receipts, and putaway workflows
 */
import { ASNStatus, ReceiptType, ReceiptStatus, PutawayStatus, AdvanceShippingNotice, Receipt, PutawayTask, CreateASNDTO, CreateReceiptDTO, UpdatePutawayTaskDTO } from '@opsui/shared';
export declare class InboundReceivingService {
    /**
     * Get dashboard metrics for inwards goods
     */
    getDashboardMetrics(): Promise<{
        pendingASNs: number;
        inTransitASNs: number;
        activeReceipts: number;
        pendingPutaway: number;
        inProgressPutaway: number;
        todayReceived: number;
        todayPutaway: number;
    }>;
    /**
     * Create a new Advance Shipping Notice
     */
    createASN(dto: CreateASNDTO): Promise<AdvanceShippingNotice>;
    /**
     * Get ASN by ID
     */
    getASN(asnId: string): Promise<AdvanceShippingNotice>;
    /**
     * Get all ASNs with optional filters
     */
    getAllASNs(filters?: {
        status?: ASNStatus;
        supplierId?: string;
        limit?: number;
        offset?: number;
    }): Promise<{
        asns: AdvanceShippingNotice[];
        total: number;
    }>;
    /**
     * Update ASN status
     */
    updateASNStatus(asnId: string, status: ASNStatus): Promise<AdvanceShippingNotice>;
    /**
     * Create a new receipt
     */
    createReceipt(dto: CreateReceiptDTO): Promise<Receipt>;
    /**
     * Get receipt by ID
     */
    getReceipt(receiptId: string): Promise<Receipt>;
    /**
     * Get all receipts with optional filters
     */
    getAllReceipts(filters?: {
        status?: ReceiptStatus;
        asnId?: string;
        receiptType?: ReceiptType;
        limit?: number;
        offset?: number;
    }): Promise<{
        receipts: Receipt[];
        total: number;
    }>;
    /**
     * Create putaway tasks for a receipt line item
     */
    private createPutawayTasksForReceiptLine;
    /**
     * Get putaway tasks by status
     */
    getPutawayTasks(filters?: {
        status?: PutawayStatus;
        assignedTo?: string;
        limit?: number;
        offset?: number;
    }): Promise<{
        tasks: PutawayTask[];
        total: number;
    }>;
    /**
     * Assign putaway task to user
     */
    assignPutawayTask(putawayTaskId: string, userId: string): Promise<PutawayTask>;
    /**
     * Update putaway task (complete or partial putaway)
     */
    updatePutawayTask(dto: UpdatePutawayTaskDTO): Promise<PutawayTask>;
    private mapRowToASN;
    private mapRowToASNLineItem;
    private mapRowToReceipt;
    private mapRowToReceiptLineItem;
    private mapRowToPutawayTask;
    /**
     * Get all license plates with optional filters
     */
    getLicensePlates(filters?: {
        status?: string;
        limit?: number;
        offset?: number;
    }): Promise<{
        licensePlates: any[];
        total: number;
    }>;
    /**
     * Get license plate by ID
     */
    getLicensePlate(licensePlateId: string): Promise<any>;
    /**
     * Get license plate by barcode
     */
    getLicensePlateByBarcode(barcode: string): Promise<any>;
    /**
     * Create a new license plate
     */
    createLicensePlate(dto: {
        receiptLineId?: string;
        sku: string;
        quantity: number;
        lotNumber?: string;
        serialNumber?: string;
        createdBy: string;
    }): Promise<any>;
    /**
     * Seal a license plate
     */
    sealLicensePlate(licensePlateId: string): Promise<any>;
    /**
     * Update license plate status
     */
    updateLicensePlateStatus(licensePlateId: string, status: string): Promise<any>;
    /**
     * Get suggested staging location for SKU
     */
    getSuggestedStaging(sku: string): Promise<any>;
    /**
     * Get all staging locations with optional filters
     */
    getStagingLocations(filters?: {
        zone?: string;
        status?: string;
        limit?: number;
        offset?: number;
    }): Promise<{
        stagingLocations: any[];
        total: number;
    }>;
    /**
     * Get staging location by ID
     */
    getStagingLocation(stagingLocationId: string): Promise<any>;
    /**
     * Assign license plate to staging location
     */
    assignToStagingLocation(dto: {
        licensePlateId: string;
        stagingLocationId: string;
        userId: string;
    }): Promise<any>;
    /**
     * Release license plate from staging
     */
    releaseFromStaging(licensePlateId: string): Promise<any>;
    /**
     * Get staging location contents
     */
    getStagingLocationContents(stagingLocationId: string): Promise<any>;
    /**
     * Get all receiving exceptions with optional filters
     */
    getReceivingExceptions(filters?: {
        status?: string;
        exceptionType?: string;
        limit?: number;
        offset?: number;
    }): Promise<{
        exceptions: any[];
        total: number;
    }>;
    /**
     * Get receiving exception by ID
     */
    getReceivingException(exceptionId: string): Promise<any>;
    /**
     * Create a new receiving exception
     */
    createReceivingException(dto: {
        receiptId?: string;
        sku: string;
        exceptionType: string;
        expectedQuantity: number;
        actualQuantity: number;
        notes?: string;
        createdBy: string;
    }): Promise<any>;
    /**
     * Update receiving exception status
     */
    updateReceivingExceptionStatus(exceptionId: string, status: string): Promise<any>;
    /**
     * Resolve a receiving exception
     */
    resolveReceivingException(dto: {
        exceptionId: string;
        resolution: string;
        resolutionNotes?: string;
        resolvedBy: string;
    }): Promise<any>;
}
export declare const inboundReceivingService: InboundReceivingService;
//# sourceMappingURL=InboundReceivingService.d.ts.map