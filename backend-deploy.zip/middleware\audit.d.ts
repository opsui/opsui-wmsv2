/**
 * Audit Logging Middleware
 *
 * Logs ALL API requests to the audit_logs table for comprehensive tracking.
 * This ensures complete visibility into all system activity regardless of role.
 *
 * Logs captured:
 * - Every API request (GET, POST, PUT, PATCH, DELETE)
 * - Request body for write operations
 * - Response status
 * - User identity (if authenticated)
 * - IP address and user agent
 * - Request duration
 */
import { Request, Response, NextFunction } from 'express';
/**
 * Middleware to log ALL API requests to audit logs
 */
export declare function auditLoggingMiddleware(req: Request, res: Response, next: NextFunction): Promise<void>;
//# sourceMappingURL=audit.d.ts.map