/**
 * Accounting & Financial Service
 *
 * Business logic for financial metrics, cost analysis, profit/loss reporting,
 * inventory valuation, and transaction logging
 */
import { FinancialMetrics, AccountingPeriod, InventoryValuation, LaborCostDetail, TransactionType, FinancialTransaction, ProfitLossStatement, VendorPerformanceFinancial, CustomerFinancialSummary, UserRole, AccountType, JournalEntryStatus, ChartOfAccounts, JournalEntry, JournalEntryLine, TrialBalance, AccountBalance, BalanceSheet, CashFlowStatement, CreateAccountDTO, UpdateAccountDTO, CreateJournalEntryDTO, ARPayment, CreditMemo, APPayment, BankReconciliation, RevenueContract, ExchangeRate, Currency, Budget, Forecast, FixedAsset, DepreciationSchedule, AuditLog, DocumentAttachment, Approval, CashPosition, ApplyPaymentDTO, CreateCreditMemoDTO, CreateBankReconciliationDTO, CreateRevenueContractDTO, CreateBudgetDTO, CreateFixedAssetDTO } from '@opsui/shared';
export declare class AccountingService {
    getFinancialMetrics(filters: {
        period?: AccountingPeriod;
        startDate?: Date;
        endDate?: Date;
        includePreviousPeriod?: boolean;
    }): Promise<FinancialMetrics>;
    getInventoryValuationDetails(filters?: {
        category?: string;
        zone?: string;
        sku?: string;
    }): Promise<InventoryValuation[]>;
    getLaborCostDetails(filters: {
        startDate: Date;
        endDate: Date;
        userId?: string;
        role?: UserRole;
    }): Promise<LaborCostDetail[]>;
    createTransaction(data: {
        transactionType: TransactionType;
        amount: number;
        currency?: string;
        referenceType: 'ORDER' | 'RETURN' | 'EXCEPTION' | 'GENERAL';
        referenceId: string;
        description: string;
        customerId?: string;
        vendorId?: string;
        createdBy: string;
        account: string;
        notes?: string;
    }): Promise<FinancialTransaction>;
    getTransactions(filters?: {
        transactionType?: TransactionType;
        referenceType?: string;
        customerId?: string;
        vendorId?: string;
        status?: string;
        limit?: number;
        offset?: number;
    }): Promise<{
        transactions: FinancialTransaction[];
        total: number;
    }>;
    generateProfitLossStatement(filters: {
        period?: AccountingPeriod;
        startDate?: Date;
        endDate?: Date;
    }): Promise<ProfitLossStatement>;
    getVendorPerformanceFinancial(vendorId: string, filters: {
        period?: AccountingPeriod;
        startDate?: Date;
        endDate?: Date;
    }): Promise<VendorPerformanceFinancial>;
    getCustomerFinancialSummary(customerId: string, filters: {
        period?: AccountingPeriod;
        startDate?: Date;
        endDate?: Date;
    }): Promise<CustomerFinancialSummary>;
    private getPeriodStartDate;
    private generateId;
    private getPreviousPeriodMetrics;
    private calculateVendorScore;
    private getVendorRating;
    private getCreditStatus;
    private getRevenueMetrics;
    private getCostMetrics;
    private getInventoryValuation;
    private getExceptionMetrics;
    private getQCMetrics;
    private getOrderMetrics;
    private getTransactionMetrics;
    getChartOfAccounts(filters?: {
        accountType?: AccountType;
        isActive?: boolean;
    }): Promise<ChartOfAccounts[]>;
    getAccount(accountId: string): Promise<ChartOfAccounts | null>;
    createAccount(data: CreateAccountDTO): Promise<ChartOfAccounts>;
    updateAccount(accountId: string, data: UpdateAccountDTO): Promise<ChartOfAccounts>;
    getAccountBalance(accountId: string, asOfDate: Date): Promise<AccountBalance>;
    getJournalEntries(filters?: {
        status?: JournalEntryStatus;
        dateFrom?: Date;
        dateTo?: Date;
        limit?: number;
        offset?: number;
    }): Promise<{
        entries: JournalEntry[];
        total: number;
    }>;
    getJournalEntry(entryId: string): Promise<JournalEntry | null>;
    getJournalEntryLines(journalEntryId: string): Promise<JournalEntryLine[]>;
    createJournalEntry(data: CreateJournalEntryDTO): Promise<JournalEntry>;
    approveJournalEntry(entryId: string, approvedBy: string): Promise<JournalEntry>;
    postJournalEntry(entryId: string): Promise<JournalEntry>;
    reverseJournalEntry(entryId: string, reason: string, reversedBy: string): Promise<JournalEntry>;
    getTrialBalance(asOfDate: Date): Promise<TrialBalance>;
    getTrialBalanceLines(trialBalanceId: string): Promise<any[]>;
    getBalanceSheet(asOfDate: Date): Promise<BalanceSheet>;
    private getBalanceSheetItems;
    getCashFlowStatement(startDate: Date, endDate: Date): Promise<CashFlowStatement>;
    private getOperatingCashFlow;
    private getInvestingCashFlow;
    private getFinancingCashFlow;
    getARAgingReport(asOfDate: Date): Promise<{
        asOfDate: Date;
        buckets: Array<{
            days: number;
            label: string;
            amount: number;
            count: number;
        }>;
        totalOutstanding: number;
    }>;
    applyARPayment(data: ApplyPaymentDTO): Promise<ARPayment>;
    createCreditMemo(data: CreateCreditMemoDTO): Promise<CreditMemo>;
    getAPAgingReport(asOfDate: Date): Promise<{
        asOfDate: Date;
        buckets: Array<{
            days: number;
            label: string;
            amount: number;
            count: number;
        }>;
        totalOutstanding: number;
    }>;
    approveAPInvoice(payableId: string, approvedBy: string): Promise<any>;
    processAPPayment(payableId: string, paymentData: {
        paymentDate: Date;
        paymentMethod: string;
        amount: number;
        createdBy: string;
    }): Promise<APPayment>;
    getCashPosition(asOfDate: Date): Promise<CashPosition>;
    createBankReconciliation(data: CreateBankReconciliationDTO): Promise<BankReconciliation>;
    createRevenueContract(data: CreateRevenueContractDTO): Promise<RevenueContract>;
    recognizeRevenue(contractId: string, milestoneId?: string): Promise<{
        recognized: boolean;
        amount: number;
        date: Date;
    }>;
    getCurrencies(): Promise<Currency[]>;
    getExchangeRate(fromCurrency: string, toCurrency: string, date: Date): Promise<number>;
    setExchangeRate(data: {
        fromCurrency: string;
        toCurrency: string;
        rateDate: Date;
        exchangeRate: number;
        createdBy: string;
    }): Promise<ExchangeRate>;
    createBudget(data: CreateBudgetDTO): Promise<Budget>;
    getBudgetVsActual(budgetId: string): Promise<{
        budget: Budget;
        lines: Array<{
            accountId: string;
            accountName: string;
            period: string;
            budgetedAmount: number;
            actualAmount: number;
            variance: number;
            variancePercent: number;
        }>;
    }>;
    createForecast(data: {
        forecastName: string;
        forecastType: string;
        startDate: Date;
        endDate: Date;
        createdBy: string;
        lines: Array<{
            accountId: string;
            period: string;
            forecastedAmount: number;
        }>;
    }): Promise<Forecast>;
    createFixedAsset(data: CreateFixedAssetDTO): Promise<FixedAsset>;
    calculateDepreciation(assetId: string, throughDate: Date): Promise<DepreciationSchedule[]>;
    getAssetRegister(asOfDate: Date): Promise<{
        asOfDate: Date;
        assets: FixedAsset[];
        totalOriginalCost: number;
        totalAccumulatedDepreciation: number;
        totalNetBookValue: number;
    }>;
    getAuditLog(filters?: {
        tableName?: string;
        recordId?: string;
        action?: string;
        startDate?: Date;
        endDate?: Date;
        limit?: number;
    }): Promise<AuditLog[]>;
    getDocuments(recordType: string, recordId: string): Promise<DocumentAttachment[]>;
    attachDocument(data: {
        recordType: string;
        recordId: string;
        documentName: string;
        documentType: string;
        filePath: string;
        fileSize: number;
        uploadedBy: string;
    }): Promise<DocumentAttachment>;
    createApprovalRequest(data: {
        approvalType: string;
        recordId: string;
        requestedBy: string;
    }): Promise<Approval>;
    approveRequest(approvalId: string, approvedBy: string, comments?: string): Promise<Approval>;
    /**
     * Create journal entries for a processed payroll run
     * Called by HRService after payroll is processed
     *
     * Journal Entry Structure:
     * Debit: Wages Expense (gross pay + employer contributions)
     * Credit: Wages Payable (net pay)
     * Credit: PAYE Payable (PAYE tax)
     * Credit: KiwiSaver Payable (employee + employer KS)
     * Credit: ACC Payable (ACC levy)
     * Credit: Student Loan Payable (if applicable)
     */
    createPayrollJournalEntry(payrollRun: {
        payrollRunId: string;
        periodStartDate: string;
        periodEndDate: string;
        totalGrossPay: number;
        totalNetPay: number;
        totalTax: number;
        totalKiwiSaver: number;
        totalACC: number;
        totalEmployerContributions: number;
        employeeCount: number;
    }): Promise<string>;
}
export declare const accountingService: AccountingService;
//# sourceMappingURL=AccountingService.d.ts.map