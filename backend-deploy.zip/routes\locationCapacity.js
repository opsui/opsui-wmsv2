"use strict";
/**
 * Location Capacity routes
 *
 * Endpoints for managing location capacity rules, utilization, and alerts
 */
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const LocationCapacityService_1 = require("../services/LocationCapacityService");
const middleware_1 = require("../middleware");
const shared_1 = require("@opsui/shared");
const router = (0, express_1.Router)();
// All location capacity routes require authentication
router.use(middleware_1.authenticate);
// ============================================================================
// CAPACITY RULE ROUTES
// ============================================================================
/**
 * POST /api/location-capacity/rules
 * Create a new capacity rule
 */
router.post('/rules', (0, middleware_1.authorize)(shared_1.UserRole.STOCK_CONTROLLER, shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { ruleName, description, capacityType, capacityUnit, appliesTo, zone, locationType, specificLocation, maximumCapacity, warningThreshold, allowOverfill, overfillThreshold, priority, } = req.body;
    // Validate required fields
    if (!ruleName ||
        !capacityType ||
        !capacityUnit ||
        !appliesTo ||
        maximumCapacity === undefined) {
        res.status(400).json({
            error: 'Missing required fields',
            code: 'MISSING_FIELDS',
        });
        return;
    }
    const rule = await LocationCapacityService_1.locationCapacityService.createCapacityRule({
        ruleName,
        description,
        capacityType,
        capacityUnit,
        appliesTo,
        zone,
        locationType,
        specificLocation,
        maximumCapacity,
        warningThreshold: warningThreshold || 80,
        allowOverfill: allowOverfill || false,
        overfillThreshold,
        priority: priority || 0,
        createdBy: req.user.userId,
    });
    res.status(201).json(rule);
}));
/**
 * GET /api/location-capacity/rules
 * Get all capacity rules
 */
router.get('/rules', (0, middleware_1.asyncHandler)(async (_req, res) => {
    const rules = await LocationCapacityService_1.locationCapacityService.getAllCapacityRules();
    res.json(rules);
}));
/**
 * GET /api/location-capacity/rules/:ruleId
 * Get a specific capacity rule by ID
 */
router.get('/rules/:ruleId', (0, middleware_1.asyncHandler)(async (req, res) => {
    const { ruleId } = req.params;
    const rule = await LocationCapacityService_1.locationCapacityService.getCapacityRule(ruleId);
    res.json(rule);
}));
/**
 * PATCH /api/location-capacity/rules/:ruleId
 * Update a capacity rule
 */
router.patch('/rules/:ruleId', (0, middleware_1.authorize)(shared_1.UserRole.STOCK_CONTROLLER, shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { ruleId } = req.params;
    const updates = req.body;
    const rule = await LocationCapacityService_1.locationCapacityService.updateCapacityRule(ruleId, updates);
    res.json(rule);
}));
/**
 * DELETE /api/location-capacity/rules/:ruleId
 * Delete a capacity rule
 */
router.delete('/rules/:ruleId', (0, middleware_1.authorize)(shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { ruleId } = req.params;
    await LocationCapacityService_1.locationCapacityService.deleteCapacityRule(ruleId);
    res.status(204).send();
}));
// ============================================================================
// LOCATION CAPACITY ROUTES
// ============================================================================
/**
 * GET /api/location-capacity/locations/:binLocation
 * Get capacity for a specific location
 */
router.get('/locations/:binLocation', (0, middleware_1.asyncHandler)(async (req, res) => {
    const { binLocation } = req.params;
    const capacity = await LocationCapacityService_1.locationCapacityService.getLocationCapacity(binLocation);
    res.json(capacity);
}));
/**
 * GET /api/location-capacity/locations
 * Get all location capacities with optional filters
 */
router.get('/locations', (0, middleware_1.asyncHandler)(async (req, res) => {
    const filters = {
        capacityType: req.query.capacityType,
        status: req.query.status,
        showAlertsOnly: req.query.showAlertsOnly === 'true',
        limit: req.query.limit ? parseInt(req.query.limit) : 100,
        offset: req.query.offset ? parseInt(req.query.offset) : 0,
    };
    const result = await LocationCapacityService_1.locationCapacityService.getAllLocationCapacities(filters);
    res.json(result);
}));
/**
 * POST /api/location-capacity/locations/:binLocation/recalculate
 * Recalculate capacity utilization for a location
 */
router.post('/locations/:binLocation/recalculate', (0, middleware_1.authorize)(shared_1.UserRole.STOCK_CONTROLLER, shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { binLocation } = req.params;
    const capacity = await LocationCapacityService_1.locationCapacityService.recalculateLocationCapacity(binLocation);
    res.json(capacity);
}));
// ============================================================================
// CAPACITY ALERT ROUTES
// ============================================================================
/**
 * GET /api/location-capacity/alerts
 * Get all capacity alerts
 */
router.get('/alerts', (0, middleware_1.asyncHandler)(async (req, res) => {
    const filters = {
        acknowledged: req.query.acknowledged === 'true'
            ? true
            : req.query.acknowledged === 'false'
                ? false
                : undefined,
        alertType: req.query.alertType,
        limit: req.query.limit ? parseInt(req.query.limit) : 50,
        offset: req.query.offset ? parseInt(req.query.offset) : 0,
    };
    const result = await LocationCapacityService_1.locationCapacityService.getAllCapacityAlerts(filters);
    res.json(result);
}));
/**
 * POST /api/location-capacity/alerts/:alertId/acknowledge
 * Acknowledge a capacity alert
 */
router.post('/alerts/:alertId/acknowledge', (0, middleware_1.asyncHandler)(async (req, res) => {
    const { alertId } = req.params;
    const alert = await LocationCapacityService_1.locationCapacityService.acknowledgeCapacityAlert({
        alertId,
        acknowledgedBy: req.user.userId,
    });
    res.json(alert);
}));
exports.default = router;
//# sourceMappingURL=locationCapacity.js.map