/**
 * User repository
 *
 * Handles all database operations for users
 */
import { BaseRepository } from './BaseRepository';
import { User, UserRole } from '@opsui/shared';
export declare class UserRepository extends BaseRepository<User> {
    constructor();
    findByEmail(email: string): Promise<User | null>;
    findById(id: string): Promise<User | null>;
    findByEmailOrThrow(email: string): Promise<User>;
    findByRole(role: UserRole, activeOnly?: boolean): Promise<User[]>;
    findActivePickers(): Promise<User[]>;
    verifyPassword(email: string, password: string): Promise<User | null>;
    createUserWithPassword(data: {
        userId: string;
        name: string;
        email: string;
        password: string;
        role: UserRole;
    }): Promise<User>;
    updatePassword(userId: string, newPassword: string): Promise<void>;
    updateLastLogin(userId: string): Promise<void>;
    setCurrentTask(userId: string, taskId: string | null): Promise<void>;
    getUserSafe(userId: string): Promise<Omit<User, 'passwordHash'> | null>;
    setActiveRole(userId: string, activeRole: UserRole | null): Promise<void>;
    /**
     * Attach additional roles to a user object
     * This fetches granted roles from user_role_assignments table
     */
    private attachAdditionalRoles;
    /**
     * Attach entityId to a user object
     * This fetches the user's default entity (or first active entity) from entity_users table
     */
    private attachEntityId;
    /**
     * Enrich user with additional roles and entity assignment
     */
    private enrichUser;
    /**
     * Get all users with their additional roles and entity attached
     */
    getAllUsers(): Promise<User[]>;
    /**
     * Get users that can be assigned tasks
     * Returns basic user info (userId, name, role) for active users in specified roles
     */
    getAssignableUsers(roles: string[]): Promise<Array<{
        userId: string;
        name: string;
        role: string;
    }>>;
    deactivateUser(userId: string): Promise<User>;
    /**
     * Mark user for deletion (soft delete)
     * User will be permanently deleted after 3 days unless restored
     */
    softDeleteUser(userId: string): Promise<User>;
    /**
     * Restore a soft-deleted user
     * Clears the deleted_at timestamp to prevent permanent deletion
     */
    restoreUser(userId: string): Promise<User>;
    /**
     * Permanently delete users past the 3-day grace period
     * This should be called by a scheduled job
     */
    cleanupDeletedUsers(): Promise<number>;
    activateUser(userId: string): Promise<User>;
    updateUser(userId: string, updates: {
        name?: string;
        email?: string;
        role?: UserRole;
        active?: boolean;
    }): Promise<User>;
}
export declare const userRepository: UserRepository;
//# sourceMappingURL=UserRepository.d.ts.map