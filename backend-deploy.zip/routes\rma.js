"use strict";
/**
 * RMA (Return Merchandise Authorization) Routes
 *
 * API endpoints for managing customer returns, warranty claims, and refurbishments
 */
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const RMAService_1 = require("../services/RMAService");
const middleware_1 = require("../middleware");
const shared_1 = require("@opsui/shared");
const router = (0, express_1.Router)();
// Debug logging
console.log('[RMA Routes] Registering RMA routes...');
// All RMA routes require authentication
router.use(middleware_1.authenticate);
// ============================================================================
// DASHBOARD
// ============================================================================
/**
 * GET /api/rma/dashboard
 * Get RMA dashboard statistics
 * Access: Users with RMA role, ADMIN, or SUPERVISOR
 */
router.get('/dashboard', (0, middleware_1.authorize)(shared_1.UserRole.RMA, shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR), (0, middleware_1.asyncHandler)(async (_req, res) => {
    console.log('[RMA Routes] GET /dashboard called');
    const dashboard = await RMAService_1.rmaService.getDashboard();
    res.json(dashboard);
}));
// ============================================================================
// RMA REQUESTS
// ============================================================================
/**
 * POST /api/rma/requests
 * Create a new RMA request
 * Access: Users with RMA role (or ADMIN, SUPERVISOR)
 */
router.post('/requests', (0, middleware_1.authorize)(shared_1.UserRole.RMA, shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR), (0, middleware_1.asyncHandler)(async (req, res) => {
    const rma = await RMAService_1.rmaService.createRMARequest(req.body, req.user.userId);
    res.status(201).json(rma);
}));
/**
 * GET /api/rma/requests
 * Get all RMA requests with optional filtering
 * Access: Users with RMA role, ADMIN, or SUPERVISOR
 */
router.get('/requests', (0, middleware_1.authorize)(shared_1.UserRole.RMA, shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { status, reason, priority, customerId, orderId, limit, offset } = req.query;
    const filters = {};
    if (status)
        filters.status = status;
    if (reason)
        filters.reason = reason;
    if (priority)
        filters.priority = priority;
    if (customerId)
        filters.customerId = customerId;
    if (orderId)
        filters.orderId = orderId;
    if (limit)
        filters.limit = parseInt(limit);
    if (offset)
        filters.offset = parseInt(offset);
    const result = await RMAService_1.rmaService.getRMAs(filters);
    res.json(result);
}));
/**
 * GET /api/rma/requests/:rmaId
 * Get a specific RMA request by ID
 * Access: Users with VIEW_RMA_REQUESTS permission
 */
router.get('/requests/:rmaId', (0, middleware_1.authorize)(shared_1.UserRole.RMA, shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { rmaId } = req.params;
    const rma = await RMAService_1.rmaService.getRMAById(rmaId);
    res.json(rma);
}));
/**
 * PUT /api/rma/requests/:rmaId/status
 * Update RMA status
 * Access: Users with PROCESS_RMA permission (or ADMIN, SUPERVISOR)
 */
router.put('/requests/:rmaId/status', (0, middleware_1.authorize)(shared_1.UserRole.RMA, shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { rmaId } = req.params;
    const rma = await RMAService_1.rmaService.updateRMAStatus(rmaId, req.body, req.user.userId);
    res.json(rma);
}));
/**
 * POST /api/rma/requests/:rmaId/approve
 * Approve an RMA request
 * Access: Users with PROCESS_RMA permission
 */
router.post('/requests/:rmaId/approve', (0, middleware_1.authorize)(shared_1.UserRole.RMA, shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { rmaId } = req.params;
    const rma = await RMAService_1.rmaService.approveRMA(rmaId, req.user.userId);
    res.json(rma);
}));
/**
 * POST /api/rma/requests/:rmaId/reject
 * Reject an RMA request
 * Access: Users with PROCESS_RMA permission
 */
router.post('/requests/:rmaId/reject', (0, middleware_1.authorize)(shared_1.UserRole.RMA, shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { rmaId } = req.params;
    const { rejectionReason } = req.body;
    if (!rejectionReason || rejectionReason.trim() === '') {
        res.status(400).json({ error: 'Rejection reason is required' });
        return;
    }
    const rma = await RMAService_1.rmaService.rejectRMA(rmaId, rejectionReason, req.user.userId);
    res.json(rma);
}));
/**
 * POST /api/rma/requests/:rmaId/receive
 * Mark RMA as received
 * Access: Users with PROCESS_RMA permission
 */
router.post('/requests/:rmaId/receive', (0, middleware_1.authorize)(shared_1.UserRole.RMA, shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { rmaId } = req.params;
    const rma = await RMAService_1.rmaService.markAsReceived(rmaId, req.user.userId);
    res.json(rma);
}));
/**
 * POST /api/rma/requests/:rmaId/inspect
 * Start inspection for RMA
 * Access: Users with PROCESS_RMA permission
 */
router.post('/requests/:rmaId/inspect', (0, middleware_1.authorize)(shared_1.UserRole.RMA, shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { rmaId } = req.params;
    const rma = await RMAService_1.rmaService.startInspection(rmaId, req.user.userId);
    res.json(rma);
}));
/**
 * POST /api/rma/requests/:rmaId/close
 * Close an RMA request
 * Access: Users with PROCESS_RMA permission
 */
router.post('/requests/:rmaId/close', (0, middleware_1.authorize)(shared_1.UserRole.RMA, shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { rmaId } = req.params;
    const rma = await RMAService_1.rmaService.closeRMA(rmaId, req.user.userId);
    res.json(rma);
}));
// ============================================================================
// INSPECTIONS
// ============================================================================
/**
 * POST /api/rma/requests/:rmaId/inspections
 * Create an inspection record
 * Access: Users with PROCESS_RMA permission
 */
router.post('/requests/:rmaId/inspections', (0, middleware_1.authorize)(shared_1.UserRole.RMA, shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { rmaId } = req.params;
    const inspection = await RMAService_1.rmaService.createInspection(rmaId, req.body, req.user.userId);
    res.status(201).json(inspection);
}));
/**
 * GET /api/rma/requests/:rmaId/inspections
 * Get inspection records for an RMA
 * Access: Users with VIEW_RMA_REQUESTS permission
 */
router.get('/requests/:rmaId/inspections', (0, middleware_1.authorize)(shared_1.UserRole.RMA, shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { rmaId } = req.params;
    const inspections = await RMAService_1.rmaService.getInspections(rmaId);
    res.json({ inspections, count: inspections.length });
}));
// ============================================================================
// RESOLUTIONS
// ============================================================================
/**
 * POST /api/rma/requests/:rmaId/refund
 * Process refund for RMA
 * Access: Users with PROCESS_RMA permission
 */
router.post('/requests/:rmaId/refund', (0, middleware_1.authorize)(shared_1.UserRole.RMA, shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { rmaId } = req.params;
    const rma = await RMAService_1.rmaService.processRefund(rmaId, req.body, req.user.userId);
    res.json(rma);
}));
/**
 * POST /api/rma/requests/:rmaId/replacement
 * Send replacement for RMA
 * Access: Users with PROCESS_RMA permission
 */
router.post('/requests/:rmaId/replacement', (0, middleware_1.authorize)(shared_1.UserRole.RMA, shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { rmaId } = req.params;
    const rma = await RMAService_1.rmaService.sendReplacement(rmaId, req.body, req.user.userId);
    res.json(rma);
}));
// ============================================================================
// COMMUNICATIONS
// ============================================================================
/**
 * POST /api/rma/requests/:rmaId/communications
 * Add a communication record
 * Access: Users with PROCESS_RMA permission
 */
router.post('/requests/:rmaId/communications', (0, middleware_1.authorize)(shared_1.UserRole.RMA, shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { rmaId } = req.params;
    const { type, direction, content, subject } = req.body;
    await RMAService_1.rmaService.addCommunication(rmaId, type, direction, content, req.user.userId, subject);
    res.status(201).json({ message: 'Communication added' });
}));
/**
 * GET /api/rma/requests/:rmaId/communications
 * Get communication history for an RMA
 * Access: Users with VIEW_RMA_REQUESTS permission
 */
router.get('/requests/:rmaId/communications', (0, middleware_1.authorize)(shared_1.UserRole.RMA, shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { rmaId } = req.params;
    const communications = await RMAService_1.rmaService.getCommunications(rmaId);
    res.json({ communications, count: communications.length });
}));
// ============================================================================
// ACTIVITY LOG
// ============================================================================
/**
 * GET /api/rma/requests/:rmaId/activity
 * Get activity log for an RMA
 * Access: Users with VIEW_RMA_REQUESTS permission
 */
router.get('/requests/:rmaId/activity', (0, middleware_1.authorize)(shared_1.UserRole.RMA, shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { rmaId } = req.params;
    const { limit } = req.query;
    const activity = await RMAService_1.rmaService.getActivityLog(rmaId, limit ? parseInt(limit) : 50);
    res.json({ activity, count: activity.length });
}));
exports.default = router;
//# sourceMappingURL=rma.js.map