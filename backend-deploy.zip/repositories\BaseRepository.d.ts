/**
 * Base repository
 *
 * Provides common CRUD operations for all repositories
 */
import { PoolClient } from 'pg';
/**
 * Convert snake_case to camelCase
 */
export declare function toCamelCase(str: string): string;
export interface QueryResult<T> {
    rows: T[];
    rowCount: number;
}
export type QueryOptions = {
    limit?: number;
    offset?: number;
    orderBy?: string;
    orderDirection?: 'ASC' | 'DESC';
};
export declare abstract class BaseRepository<T extends Record<string, any>> {
    protected tableName: string;
    protected primaryKey: string;
    constructor(tableName: string, primaryKey: string);
    findById(id: string): Promise<T | null>;
    findByIdOrThrow(id: string): Promise<T>;
    findAll(options?: QueryOptions): Promise<T[]>;
    findManyByColumn<K extends keyof T>(column: K, value: T[K], options?: QueryOptions): Promise<T[]>;
    findOneByColumn<K extends keyof T>(column: K, value: T[K]): Promise<T | null>;
    count(whereClause?: string, params?: any[]): Promise<number>;
    exists(whereClause: string, params: any[]): Promise<boolean>;
    insert(data: Partial<T>, client?: PoolClient): Promise<T>;
    insertMany(data: Partial<T>[], client?: PoolClient): Promise<T[]>;
    update(id: string, data: Partial<T>, client?: PoolClient): Promise<T | null>;
    updateOrThrow(id: string, data: Partial<T>, client?: PoolClient): Promise<T>;
    delete(id: string, client?: PoolClient): Promise<boolean>;
    deleteMany(ids: string[], client?: PoolClient): Promise<number>;
    rawQuery(sql: string, params?: any[]): Promise<T[]>;
    rawQueryOne(sql: string, params?: any[]): Promise<T | null>;
    withTransaction<R>(callback: (client: PoolClient) => Promise<R>): Promise<R>;
}
//# sourceMappingURL=BaseRepository.d.ts.map