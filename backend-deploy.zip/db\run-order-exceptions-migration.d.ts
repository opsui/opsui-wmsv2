/**
 * Run order_exceptions table migration
 *
 * Creates the order_exceptions table for tracking exceptions during fulfillment.
 */
declare function runOrderExceptionsMigration(): Promise<void>;
export { runOrderExceptionsMigration };
//# sourceMappingURL=run-order-exceptions-migration.d.ts.map