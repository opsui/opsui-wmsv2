"use strict";
/**
 * NotificationHelper Service
 * Provides notification functionality for various warehouse operations
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.NotificationPriority = exports.NotificationType = void 0;
exports.notifyUser = notifyUser;
exports.notifyAll = notifyAll;
exports.broadcastEvent = broadcastEvent;
exports.notifyExceptionReported = notifyExceptionReported;
var NotificationType;
(function (NotificationType) {
    NotificationType["INFO"] = "info";
    NotificationType["WARNING"] = "warning";
    NotificationType["ERROR"] = "error";
    NotificationType["SUCCESS"] = "success";
    // Specific notification types
    NotificationType["EXCEPTION_REPORTED"] = "exception_reported";
    NotificationType["QUALITY_FAILED"] = "quality_failed";
    NotificationType["QUALITY_APPROVED"] = "quality_approved";
    NotificationType["ORDER_SHIPPED"] = "order_shipped";
    NotificationType["WAVE_CREATED"] = "wave_created";
    NotificationType["WAVE_COMPLETED"] = "wave_completed";
    NotificationType["ZONE_ASSIGNED"] = "zone_assigned";
})(NotificationType || (exports.NotificationType = NotificationType = {}));
var NotificationPriority;
(function (NotificationPriority) {
    NotificationPriority["LOW"] = "low";
    NotificationPriority["NORMAL"] = "normal";
    NotificationPriority["MEDIUM"] = "medium";
    NotificationPriority["HIGH"] = "high";
    NotificationPriority["URGENT"] = "urgent";
})(NotificationPriority || (exports.NotificationPriority = NotificationPriority = {}));
/**
 * Send a notification to a specific user
 */
async function notifyUser(notification) {
    console.log(`[Notification] User: ${notification.userId}`);
}
/**
 * Send a notification to all relevant users
 */
async function notifyAll(notification) {
    console.log(`[Broadcast Notification] ${notification.title}`);
}
/**
 * Broadcast an event to all connected clients
 */
async function broadcastEvent(event, _data) {
    console.log(`[Broadcast Event] ${event}`);
}
/**
 * Send exception notification
 */
async function notifyExceptionReported(
// eslint-disable-next-line @typescript-eslint/no-explicit-any
notification) {
    await notifyAll({
        type: NotificationType.EXCEPTION_REPORTED,
        priority: NotificationPriority.HIGH,
        title: `Order Exception: ${notification.orderId || 'N/A'}`,
        message: notification.description || 'No description provided',
        data: notification,
    });
}
//# sourceMappingURL=NotificationHelper.js.map