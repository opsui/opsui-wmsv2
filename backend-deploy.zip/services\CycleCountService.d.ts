/**
 * Cycle Count Service
 *
 * Handles scheduled and ad-hoc cycle counting for inventory accuracy
 */
import { CycleCountPlan, CycleCountEntry, CycleCountTolerance, CreateCycleCountPlanDTO, CreateCycleCountEntryDTO, UpdateVarianceStatusDTO, ReconcileCycleCountDTO, CycleCountStatus, CycleCountType, VarianceStatus } from '@opsui/shared';
export declare class CycleCountService {
    /**
     * Bulk update variance status for all pending variances in a plan
     */
    bulkUpdateVarianceStatus(dto: {
        planId: string;
        status: VarianceStatus;
        reviewedBy: string;
        notes?: string;
        autoApproveZeroVariance?: boolean;
    }): Promise<{
        updated: number;
        skipped: number;
        adjustments: any[];
    }>;
    /**
     * Get reconcile summary - shows what inventory adjustments will be made
     */
    getReconcileSummary(planId: string): Promise<{
        pendingVarianceCount: number;
        totalAdjustmentValue: number;
        skusToAdjust: Array<{
            sku: string;
            binLocation: string;
            systemQuantity: number;
            countedQuantity: number;
            variance: number;
            variancePercent: number;
        }>;
        zeroVarianceEntries: number;
    }>;
    /**
     * Cancel a cycle count plan (only SCHEDULED or IN_PROGRESS)
     */
    cancelCycleCountPlan(dto: {
        planId: string;
        cancelledBy: string;
        reason?: string;
    }): Promise<CycleCountPlan>;
    /**
     * Check for collisions - other active counts in the same location
     */
    checkForCollisions(planId: string): Promise<{
        hasCollisions: boolean;
        collidingCounts: Array<{
            planId: string;
            planName: string;
            location: string;
            status: string;
            assignedTo: string;
        }>;
    }>;
    /**
     * Export cycle count data as CSV
     */
    exportCycleCountData(planId: string): Promise<string>;
    /**
     * Get audit log for a cycle count plan
     */
    getCycleCountAuditLog(planId: string): Promise<Array<{
        timestamp: Date;
        action: string;
        userId: string;
        userName: string;
        details: any;
    }>>;
    /**
     * Create a new cycle count plan
     */
    createCycleCountPlan(dto: CreateCycleCountPlanDTO): Promise<CycleCountPlan>;
    /**
     * Get cycle count plan by ID
     */
    getCycleCountPlan(planId: string): Promise<CycleCountPlan>;
    /**
     * Get all cycle count plans with optional filters
     * Access control:
     * - PICKER, PACKER: Can only see plans where count_by = their userId
     * - STOCK_CONTROLLER: Can see plans where count_by = their userId OR created_by = their userId
     * - SUPERVISOR, ADMIN: Can see all plans
     */
    getAllCycleCountPlans(filters?: {
        status?: CycleCountStatus;
        countType?: CycleCountType;
        location?: string;
        countBy?: string;
        limit?: number;
        offset?: number;
        requestingUserRole?: string;
        requestingUserId?: string;
    }): Promise<{
        plans: CycleCountPlan[];
        total: number;
    }>;
    /**
     * Start a cycle count plan
     * For BLANKET, ABC, SPOT_CHECK, RECEIVING, and SHIPPING types, automatically generate count entries
     */
    startCycleCountPlan(planId: string, startedBy?: string): Promise<CycleCountPlan>;
    /**
     * Complete a cycle count plan
     */
    completeCycleCountPlan(planId: string): Promise<CycleCountPlan>;
    /**
     * Reconcile a cycle count plan (approve all variances)
     */
    reconcileCycleCountPlan(dto: ReconcileCycleCountDTO): Promise<CycleCountPlan>;
    /**
     * Generate count entries automatically based on count type
     * Called when starting a cycle count plan
     */
    private generateCountEntriesForType;
    /**
     * BLANKET count: Generate entries for ALL SKUs in the location
     */
    private generateBlanketCountEntries;
    /**
     * ABC count: Generate entries for high-value items (ABC category A)
     */
    private generateABCCountEntries;
    /**
     * SPOT_CHECK count: Random sample of items in location(s)
     */
    private generateSpotCheckEntries;
    /**
     * RECEIVING count: Items from recent receipts (last 7 days)
     */
    private generateReceivingCountEntries;
    /**
     * SHIPPING count: Items in orders ready to ship
     */
    private generateShippingCountEntries;
    /**
     * AD_HOC count: Generate entries for specified SKUs (comma-separated)
     * If location is also specified, only include SKUs in that location
     */
    private generateAdHocCountEntries;
    /**
     * Create a cycle count entry (record counted quantity)
     */
    createCycleCountEntry(dto: CreateCycleCountEntryDTO): Promise<CycleCountEntry>;
    /**
     * Update variance status (approve/reject)
     */
    updateVarianceStatus(dto: UpdateVarianceStatusDTO): Promise<CycleCountEntry>;
    /**
     * Process variance adjustment (create transaction and update inventory)
     */
    private processVarianceAdjustment;
    /**
     * Get all tolerance rules
     */
    getAllTolerances(): Promise<CycleCountTolerance[]>;
    /**
     * Get applicable tolerance for an SKU/location
     */
    private getApplicableTolerance;
    /**
     * Create inventory transaction for adjustment
     */
    private createAdjustmentTransaction;
    /**
     * Adjust inventory up (increase quantity)
     */
    private adjustInventoryUp;
    /**
     * Adjust inventory down (decrease quantity)
     */
    private adjustInventoryDown;
    private mapRowToCycleCountPlan;
    private mapRowToCycleCountEntry;
    private mapRowToTolerance;
}
export declare const cycleCountService: CycleCountService;
//# sourceMappingURL=CycleCountService.d.ts.map