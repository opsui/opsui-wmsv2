"use strict";
/**
 * User repository
 *
 * Handles all database operations for users
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.userRepository = exports.UserRepository = void 0;
const BaseRepository_1 = require("./BaseRepository");
const client_1 = require("../db/client");
const shared_1 = require("@opsui/shared");
const bcrypt_1 = __importDefault(require("bcrypt"));
// ============================================================================
// USER REPOSITORY
// ============================================================================
class UserRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super('users', 'user_id');
    }
    // --------------------------------------------------------------------------
    // FIND BY EMAIL
    // --------------------------------------------------------------------------
    async findByEmail(email) {
        // Exclude soft-deleted users (deleted_at IS NULL)
        const result = await (0, client_1.query)(`SELECT * FROM users WHERE email = $1 AND deleted_at IS NULL`, [email]);
        if (result.rows.length === 0) {
            return null;
        }
        const user = result.rows[0];
        return await this.enrichUser(user);
    }
    // --------------------------------------------------------------------------
    // FIND BY ID (override to exclude soft-deleted users)
    // --------------------------------------------------------------------------
    async findById(id) {
        // Exclude soft-deleted users (deleted_at IS NULL)
        const result = await (0, client_1.query)(`SELECT * FROM users WHERE user_id = $1 AND deleted_at IS NULL`, [id]);
        const user = result.rows[0];
        return user ? await this.enrichUser(user) : null;
    }
    // --------------------------------------------------------------------------
    // FIND BY EMAIL OR THROW
    // --------------------------------------------------------------------------
    async findByEmailOrThrow(email) {
        const user = await this.findByEmail(email);
        if (!user) {
            throw new shared_1.NotFoundError('User', `email: ${email}`);
        }
        return user;
    }
    // --------------------------------------------------------------------------
    // FIND BY ROLE
    // --------------------------------------------------------------------------
    async findByRole(role, activeOnly = true) {
        const result = await (0, client_1.query)(`SELECT * FROM users
       WHERE role = $1 ${activeOnly ? 'AND active = true' : ''}
       ORDER BY name`, [role]);
        return result.rows;
    }
    // --------------------------------------------------------------------------
    // FIND ACTIVE PICKERS
    // --------------------------------------------------------------------------
    async findActivePickers() {
        const result = await (0, client_1.query)(`SELECT DISTINCT u.*
       FROM users u
       INNER JOIN orders o ON u.user_id = o.picker_id
       WHERE u.role = 'PICKER' AND u.active = true AND o.status = 'PICKING'
       ORDER BY u.name`);
        return result.rows;
    }
    // --------------------------------------------------------------------------
    // VERIFY PASSWORD
    // --------------------------------------------------------------------------
    async verifyPassword(email, password) {
        // Get user with password hash (also check soft-delete)
        const result = await (0, client_1.query)(`SELECT * FROM users WHERE email = $1 AND deleted_at IS NULL`, [
            email,
        ]);
        if (result.rows.length === 0) {
            return null;
        }
        const userWithHash = result.rows[0];
        // Verify password (column name is already camelCased by query function)
        const isValid = await bcrypt_1.default.compare(password, userWithHash.passwordHash);
        if (!isValid) {
            return null;
        }
        // Return user without password hash - use already camelCased keys
        const { passwordHash: _, ...userWithoutPassword } = userWithHash;
        // Attach additional roles before returning
        return await this.enrichUser(userWithoutPassword);
    }
    // --------------------------------------------------------------------------
    // CREATE USER WITH HASHED PASSWORD
    // --------------------------------------------------------------------------
    async createUserWithPassword(data) {
        // Check if email already exists
        const existingUser = await this.findByEmail(data.email);
        if (existingUser) {
            throw new shared_1.ConflictError('User with this email already exists');
        }
        // Hash password
        const passwordHash = await bcrypt_1.default.hash(data.password, 10);
        // Create user
        const user = await this.insert({
            userId: data.userId,
            name: data.name,
            email: data.email,
            passwordHash,
            role: data.role,
            active: true,
        });
        // Return user without password hash
        const { passwordHash: _, ...userWithoutPassword } = user;
        return userWithoutPassword;
    }
    // --------------------------------------------------------------------------
    // UPDATE PASSWORD
    // --------------------------------------------------------------------------
    async updatePassword(userId, newPassword) {
        const passwordHash = await bcrypt_1.default.hash(newPassword, 10);
        await (0, client_1.query)(`UPDATE users SET password_hash = $1 WHERE user_id = $2`, [passwordHash, userId]);
    }
    // --------------------------------------------------------------------------
    // UPDATE USER ACTIVITY
    // --------------------------------------------------------------------------
    async updateLastLogin(userId) {
        await (0, client_1.query)(`UPDATE users SET last_login_at = NOW() WHERE user_id = $1`, [userId]);
    }
    // --------------------------------------------------------------------------
    // SET CURRENT TASK
    // --------------------------------------------------------------------------
    async setCurrentTask(userId, taskId) {
        await (0, client_1.query)(`UPDATE users SET current_task_id = $1 WHERE user_id = $2`, [taskId, userId]);
    }
    // --------------------------------------------------------------------------
    // GET USER WITHOUT SENSITIVE DATA
    // --------------------------------------------------------------------------
    async getUserSafe(userId) {
        const result = await (0, client_1.query)(`SELECT * FROM users WHERE user_id = $1`, [userId]);
        const user = result.rows[0];
        if (!user)
            return null;
        // Attach additional roles
        return await this.enrichUser(user);
    }
    // --------------------------------------------------------------------------
    // SET ACTIVE ROLE
    // --------------------------------------------------------------------------
    async setActiveRole(userId, activeRole) {
        await (0, client_1.query)(`UPDATE users SET active_role = $1 WHERE user_id = $2`, [activeRole, userId]);
    }
    // --------------------------------------------------------------------------
    // ATTACH ADDITIONAL ROLES
    // --------------------------------------------------------------------------
    /**
     * Attach additional roles to a user object
     * This fetches granted roles from user_role_assignments table
     */
    async attachAdditionalRoles(user) {
        try {
            const result = await (0, client_1.query)(`SELECT role
         FROM user_role_assignments
         WHERE user_id = $1 AND active = true
         ORDER BY granted_at DESC`, [user.userId]);
            return {
                ...user,
                additionalRoles: result.rows.map(row => row.role),
            };
        }
        catch (error) {
            // If user_role_assignments table doesn't exist, just return the user without additional roles
            if (error.code === '42P01') {
                return {
                    ...user,
                    additionalRoles: [],
                };
            }
            throw error;
        }
    }
    // --------------------------------------------------------------------------
    // ATTACH ENTITY ID
    // --------------------------------------------------------------------------
    /**
     * Attach entityId to a user object
     * This fetches the user's default entity (or first active entity) from entity_users table
     */
    async attachEntityId(user) {
        try {
            const result = await (0, client_1.query)(`SELECT entity_id as "entityId"
         FROM entity_users
         WHERE user_id = $1 AND is_active = true
         ORDER BY is_default_entity DESC, created_at ASC
         LIMIT 1`, [user.userId]);
            return {
                ...user,
                entityId: result.rows[0]?.entityId || null,
            };
        }
        catch (error) {
            // If entity_users table doesn't exist, return user without entityId
            if (error.code === '42P01') {
                return {
                    ...user,
                    entityId: null,
                };
            }
            throw error;
        }
    }
    // --------------------------------------------------------------------------
    // ENRICH USER (attach both additional roles and entity)
    // --------------------------------------------------------------------------
    /**
     * Enrich user with additional roles and entity assignment
     */
    async enrichUser(user) {
        let enrichedUser = await this.attachAdditionalRoles(user);
        enrichedUser = await this.attachEntityId(enrichedUser);
        return enrichedUser;
    }
    // --------------------------------------------------------------------------
    // GET ALL USERS
    // --------------------------------------------------------------------------
    /**
     * Get all users with their additional roles and entity attached
     */
    async getAllUsers() {
        const result = await (0, client_1.query)(`SELECT * FROM users ORDER BY created_at DESC`);
        // Enrich each user with additional roles and entity
        const usersWithRoles = await Promise.all(result.rows.map(user => this.enrichUser(user)));
        return usersWithRoles;
    }
    /**
     * Get users that can be assigned tasks
     * Returns basic user info (userId, name, role) for active users in specified roles
     */
    async getAssignableUsers(roles) {
        const placeholders = roles.map((_, i) => `$${i + 1}`).join(', ');
        const result = await (0, client_1.query)(`SELECT user_id, name, role
       FROM users
       WHERE active = true
         AND deleted_at IS NULL
         AND role IN (${placeholders})
       ORDER BY name ASC`, roles);
        return result.rows.map(row => ({
            userId: row.user_id,
            name: row.name,
            role: row.role,
        }));
    }
    // --------------------------------------------------------------------------
    // DEACTIVATE USER
    // --------------------------------------------------------------------------
    async deactivateUser(userId) {
        const result = await (0, client_1.query)(`UPDATE users SET active = false WHERE user_id = $1 RETURNING *`, [
            userId,
        ]);
        if (result.rows.length === 0) {
            throw new shared_1.NotFoundError('User', userId);
        }
        return await this.enrichUser(result.rows[0]);
    }
    // --------------------------------------------------------------------------
    // SOFT DELETE USER
    // --------------------------------------------------------------------------
    /**
     * Mark user for deletion (soft delete)
     * User will be permanently deleted after 3 days unless restored
     */
    async softDeleteUser(userId) {
        const result = await (0, client_1.query)(`UPDATE users SET deleted_at = NOW() WHERE user_id = $1 RETURNING *`, [userId]);
        if (result.rows.length === 0) {
            throw new shared_1.NotFoundError('User', userId);
        }
        return await this.enrichUser(result.rows[0]);
    }
    // --------------------------------------------------------------------------
    // RESTORE USER
    // --------------------------------------------------------------------------
    /**
     * Restore a soft-deleted user
     * Clears the deleted_at timestamp to prevent permanent deletion
     */
    async restoreUser(userId) {
        const result = await (0, client_1.query)(`UPDATE users SET deleted_at = NULL WHERE user_id = $1 RETURNING *`, [userId]);
        if (result.rows.length === 0) {
            throw new shared_1.NotFoundError('User', userId);
        }
        return await this.enrichUser(result.rows[0]);
    }
    // --------------------------------------------------------------------------
    // PERMANENTLY DELETE EXPIRED USERS
    // --------------------------------------------------------------------------
    /**
     * Permanently delete users past the 3-day grace period
     * This should be called by a scheduled job
     */
    async cleanupDeletedUsers() {
        // Call the database function
        const result = await (0, client_1.query)(`SELECT cleanup_deleted_users() as count`);
        return result.rows[0]?.count || 0;
    }
    // --------------------------------------------------------------------------
    // ACTIVATE USER
    // --------------------------------------------------------------------------
    async activateUser(userId) {
        const result = await (0, client_1.query)(`UPDATE users SET active = true WHERE user_id = $1 RETURNING *`, [
            userId,
        ]);
        if (result.rows.length === 0) {
            throw new shared_1.NotFoundError('User', userId);
        }
        return await this.enrichUser(result.rows[0]);
    }
    // --------------------------------------------------------------------------
    // UPDATE USER
    // --------------------------------------------------------------------------
    async updateUser(userId, updates) {
        // Build dynamic update query
        const fields = [];
        const values = [];
        let paramIndex = 1;
        if (updates.name !== undefined) {
            fields.push(`name = $${paramIndex++}`);
            values.push(updates.name);
        }
        if (updates.email !== undefined) {
            fields.push(`email = $${paramIndex++}`);
            values.push(updates.email);
        }
        if (updates.role !== undefined) {
            fields.push(`role = $${paramIndex++}`);
            values.push(updates.role);
        }
        if (updates.active !== undefined) {
            fields.push(`active = $${paramIndex++}`);
            values.push(updates.active);
        }
        if (fields.length === 0) {
            throw new Error('No fields to update');
        }
        values.push(userId);
        const result = await (0, client_1.query)(`UPDATE users
       SET ${fields.join(', ')}
       WHERE user_id = $${paramIndex}
       RETURNING user_id, name, email, role, active, current_task_id, created_at, last_login_at`, values);
        if (result.rows.length === 0) {
            throw new shared_1.NotFoundError('User', userId);
        }
        return await this.enrichUser(result.rows[0]);
    }
}
exports.UserRepository = UserRepository;
// Singleton instance
exports.userRepository = new UserRepository();
//# sourceMappingURL=UserRepository.js.map