"use strict";
/**
 * Feature Flag Service
 *
 * Manages feature flags for enabling/disabling application features
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.invalidateFlagCache = invalidateFlagCache;
exports.getFlag = getFlag;
exports.isFlagEnabled = isFlagEnabled;
exports.getAllFlags = getAllFlags;
exports.getFlagsByCategory = getFlagsByCategory;
exports.setFlag = setFlag;
exports.createFlag = createFlag;
exports.deleteFlag = deleteFlag;
exports.getCategorySummary = getCategorySummary;
const client_1 = require("../db/client");
// In-memory cache for feature flags
const flagCache = new Map();
let cacheInitialized = false;
/**
 * Initialize the flag cache from database
 */
async function initializeCache() {
    if (cacheInitialized)
        return;
    const pool = (0, client_1.getPool)();
    const result = await pool.query('SELECT * FROM feature_flags ORDER BY category, name');
    flagCache.clear();
    for (const row of result.rows) {
        flagCache.set(row.flag_key, row);
    }
    cacheInitialized = true;
}
/**
 * Invalidate cache (call after database updates)
 */
function invalidateFlagCache() {
    cacheInitialized = false;
    flagCache.clear();
}
/**
 * Get a single feature flag by key
 */
async function getFlag(key) {
    await initializeCache();
    const flag = flagCache.get(key);
    return flag || null;
}
/**
 * Check if a feature flag is enabled
 */
async function isFlagEnabled(key) {
    const flag = await getFlag(key);
    return flag?.is_enabled ?? false;
}
/**
 * Get all feature flags
 */
async function getAllFlags() {
    await initializeCache();
    return Array.from(flagCache.values()).sort((a, b) => {
        // Sort by category first, then by name
        if (a.category !== b.category) {
            return a.category.localeCompare(b.category);
        }
        return a.name.localeCompare(b.name);
    });
}
/**
 * Get feature flags by category
 */
async function getFlagsByCategory(category) {
    await initializeCache();
    return Array.from(flagCache.values())
        .filter(flag => flag.category === category)
        .sort((a, b) => a.name.localeCompare(b.name));
}
/**
 * Set a feature flag's enabled state
 */
async function setFlag(key, enabled) {
    const pool = (0, client_1.getPool)();
    const result = await pool.query(`UPDATE feature_flags
     SET is_enabled = $1
     WHERE flag_key = $2
     RETURNING *`, [enabled, key]);
    if (result.rows.length === 0) {
        throw new Error(`Feature flag '${key}' not found`);
    }
    invalidateFlagCache();
    return result.rows[0];
}
/**
 * Create a new feature flag
 */
async function createFlag(data) {
    const pool = (0, client_1.getPool)();
    // Check if flag key already exists
    const existing = await pool.query('SELECT flag_key FROM feature_flags WHERE flag_key = $1', [
        data.flag_key,
    ]);
    if (existing.rows.length > 0) {
        throw new Error(`Feature flag with key '${data.flag_key}' already exists`);
    }
    const result = await pool.query(`INSERT INTO feature_flags (flag_key, name, description, is_enabled, category)
     VALUES ($1, $2, $3, $4, $5)
     RETURNING *`, [data.flag_key, data.name, data.description || null, data.is_enabled ?? false, data.category]);
    invalidateFlagCache();
    return result.rows[0];
}
/**
 * Delete a feature flag
 */
async function deleteFlag(key) {
    const pool = (0, client_1.getPool)();
    const result = await pool.query('DELETE FROM feature_flags WHERE flag_key = $1 RETURNING flag_key', [key]);
    if (result.rows.length === 0) {
        throw new Error(`Feature flag '${key}' not found`);
    }
    invalidateFlagCache();
}
/**
 * Get flag categories with counts
 */
async function getCategorySummary() {
    const pool = (0, client_1.getPool)();
    const result = await pool.query(`
    SELECT
      category,
      COUNT(*) as count,
      SUM(CASE WHEN is_enabled THEN 1 ELSE 0 END) as enabled
    FROM feature_flags
    GROUP BY category
    ORDER BY category
  `);
    return result.rows;
}
//# sourceMappingURL=FeatureFlagService.js.map