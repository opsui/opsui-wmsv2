"use strict";
/**
 * Manufacturing API Routes
 *
 * REST API for manufacturing operations
 * Handles work centers, routings, MPS, MRP, production orders,
 * shop floor control, quality, and capacity planning
 */
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const ManufacturingService_1 = require("../services/ManufacturingService");
const middleware_1 = require("../middleware");
const shared_1 = require("@opsui/shared");
const router = (0, express_1.Router)();
// All manufacturing routes require authentication
router.use(middleware_1.authenticate);
// Manufacturing management requires Admin, Supervisor, or Production access
const manufacturingAuth = (0, middleware_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR);
// Shop floor operations can be accessed by workers
const shopFloorAuth = (0, middleware_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR, shared_1.UserRole.INWARDS);
// Analytics and reporting
const analyticsAuth = (0, middleware_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ACCOUNTING);
// ============================================================================
// DASHBOARD
// ============================================================================
/**
 * GET /api/manufacturing/dashboard
 * Get manufacturing dashboard metrics
 */
router.get('/dashboard', analyticsAuth, (0, middleware_1.asyncHandler)(async (req, res) => {
    const entityId = req.query.entity_id;
    const metrics = await ManufacturingService_1.manufacturingService.getDashboardMetrics(entityId);
    res.json(metrics);
}));
// ============================================================================
// WORK CENTERS
// ============================================================================
/**
 * GET /api/manufacturing/work-centers
 * Get all work centers with optional filters
 */
router.get('/work-centers', manufacturingAuth, (0, middleware_1.asyncHandler)(async (req, res) => {
    const filters = {
        entity_id: req.query.entity_id,
        department: req.query.department,
        work_center_status: req.query.work_center_status,
        site_id: req.query.site_id,
        search: req.query.search,
    };
    const workCenters = await ManufacturingService_1.manufacturingService.getWorkCenters(filters);
    res.json(workCenters);
}));
/**
 * GET /api/manufacturing/work-centers/active
 * Get active work centers
 */
router.get('/work-centers/active', manufacturingAuth, (0, middleware_1.asyncHandler)(async (_req, res) => {
    const workCenters = await ManufacturingService_1.manufacturingService.getWorkCenters({
        work_center_status: shared_1.WorkCenterStatus.ACTIVE,
    });
    res.json(workCenters);
}));
/**
 * GET /api/manufacturing/work-centers/:id
 * Get work center with queue information
 */
router.get('/work-centers/:id', manufacturingAuth, (0, middleware_1.asyncHandler)(async (req, res) => {
    const workCenter = await ManufacturingService_1.manufacturingService.getWorkCenterWithQueue(req.params.id);
    if (!workCenter) {
        res.status(404).json({ error: 'Work center not found' });
        return;
    }
    res.json(workCenter);
}));
/**
 * POST /api/manufacturing/work-centers
 * Create a new work center
 */
router.post('/work-centers', manufacturingAuth, (0, middleware_1.asyncHandler)(async (_req, res) => {
    const workCenter = await ManufacturingService_1.manufacturingService.createWorkCenter(_req.body);
    res.status(201).json(workCenter);
}));
/**
 * GET /api/manufacturing/work-centers/overloaded
 * Get overloaded work centers
 */
router.get('/work-centers/load/overloaded', manufacturingAuth, (0, middleware_1.asyncHandler)(async (_req, res) => {
    const overloaded = await ManufacturingService_1.manufacturingService.getOverloadedWorkCenters();
    res.json(overloaded);
}));
// ============================================================================
// ROUTINGS
// ============================================================================
/**
 * GET /api/manufacturing/routings
 * Get all routings with optional filters
 */
router.get('/routings', manufacturingAuth, (0, middleware_1.asyncHandler)(async (req, res) => {
    const filters = {
        entity_id: req.query.entity_id,
        sku: req.query.sku,
        routing_status: req.query.routing_status,
        search: req.query.search,
    };
    const routings = await ManufacturingService_1.manufacturingService.getRoutings(filters);
    res.json(routings);
}));
/**
 * GET /api/manufacturing/routings/:id
 * Get routing with details
 */
router.get('/routings/:id', manufacturingAuth, (0, middleware_1.asyncHandler)(async (req, res) => {
    const routing = await ManufacturingService_1.manufacturingService.getRoutingWithDetails(req.params.id);
    if (!routing) {
        res.status(404).json({ error: 'Routing not found' });
        return;
    }
    res.json(routing);
}));
/**
 * POST /api/manufacturing/routings
 * Create a new routing
 */
router.post('/routings', manufacturingAuth, (0, middleware_1.asyncHandler)(async (req, res) => {
    const routing = await ManufacturingService_1.manufacturingService.createRouting(req.body);
    res.status(201).json(routing);
}));
/**
 * GET /api/manufacturing/routings/sku/:sku
 * Get routings for a specific SKU
 */
router.get('/routings/sku/:sku', manufacturingAuth, (0, middleware_1.asyncHandler)(async (req, res) => {
    const routings = await ManufacturingService_1.manufacturingService.getRoutings({
        sku: req.params.sku,
        routing_status: shared_1.RoutingStatus.ACTIVE,
    });
    res.json(routings);
}));
// ============================================================================
// PRODUCTION ORDERS
// ============================================================================
/**
 * GET /api/manufacturing/production-orders
 * Get all production orders with optional filters
 */
router.get('/production-orders', manufacturingAuth, (0, middleware_1.asyncHandler)(async (req, res) => {
    const filters = {
        entity_id: req.query.entity_id,
        sku: req.query.sku,
        order_status: req.query.order_status,
        order_type: req.query.order_type,
        start_date_from: req.query.start_date_from
            ? new Date(req.query.start_date_from)
            : undefined,
        start_date_to: req.query.start_date_to
            ? new Date(req.query.start_date_to)
            : undefined,
        due_date_from: req.query.due_date_from
            ? new Date(req.query.due_date_from)
            : undefined,
        due_date_to: req.query.due_date_to ? new Date(req.query.due_date_to) : undefined,
        customer_id: req.query.customer_id,
        sales_order_id: req.query.sales_order_id,
        job_number: req.query.job_number,
        search: req.query.search,
    };
    const orders = await ManufacturingService_1.manufacturingService.getProductionOrders(filters);
    res.json(orders);
}));
/**
 * GET /api/manufacturing/production-orders/active
 * Get active production orders
 */
router.get('/production-orders/active', manufacturingAuth, (0, middleware_1.asyncHandler)(async (_req, res) => {
    const orders = await ManufacturingService_1.manufacturingService.getActiveProductionOrders();
    res.json(orders);
}));
/**
 * GET /api/manufacturing/production-orders/past-due
 * Get past due production orders
 */
router.get('/production-orders/past-due', manufacturingAuth, (0, middleware_1.asyncHandler)(async (_req, res) => {
    const orders = await ManufacturingService_1.manufacturingService.getProductionOrders({});
    // Filter for past due would be done in service
    res.json(orders.filter((o) => o.due_date < new Date() && o.order_status !== 'COMPLETED'));
}));
/**
 * GET /api/manufacturing/production-orders/:id
 * Get production order with details
 */
router.get('/production-orders/:id', manufacturingAuth, (0, middleware_1.asyncHandler)(async (req, res) => {
    const order = await ManufacturingService_1.manufacturingService.getProductionOrderWithDetails(req.params.id);
    if (!order) {
        res.status(404).json({ error: 'Production order not found' });
        return;
    }
    res.json(order);
}));
/**
 * POST /api/manufacturing/production-orders
 * Create a new production order
 */
router.post('/production-orders', manufacturingAuth, (0, middleware_1.asyncHandler)(async (req, res) => {
    const dto = {
        ...req.body,
        created_by: req.user.userId,
    };
    const order = await ManufacturingService_1.manufacturingService.createProductionOrder(dto);
    res.status(201).json(order);
}));
/**
 * PUT /api/manufacturing/production-orders/:id/release
 * Release production order
 */
router.put('/production-orders/:id/release', manufacturingAuth, (0, middleware_1.asyncHandler)(async (req, res) => {
    const dto = {
        order_id: req.params.id,
        release_date: req.body.release_date ? new Date(req.body.release_date) : undefined,
    };
    const order = await ManufacturingService_1.manufacturingService.releaseProductionOrder(dto);
    res.json(order);
}));
// ============================================================================
// SHOP FLOOR TRANSACTIONS
// ============================================================================
/**
 * GET /api/manufacturing/shop-floor/transactions
 * Get shop floor transactions
 */
router.get('/shop-floor/transactions', shopFloorAuth, (0, middleware_1.asyncHandler)(async (_req, res) => {
    // Would implement query in service
    res.json({ message: 'Shop floor transactions endpoint' });
}));
/**
 * POST /api/manufacturing/shop-floor/transactions
 * Create shop floor transaction
 */
router.post('/shop-floor/transactions', shopFloorAuth, (0, middleware_1.asyncHandler)(async (req, res) => {
    const dto = {
        ...req.body,
    };
    const transaction = await ManufacturingService_1.manufacturingService.createShopFloorTransaction(dto);
    res.status(201).json(transaction);
}));
/**
 * POST /api/manufacturing/shop/report-quantity
 * Report quantity completion
 */
router.post('/shop/report-quantity', shopFloorAuth, (0, middleware_1.asyncHandler)(async (req, res) => {
    const result = await ManufacturingService_1.manufacturingService.recordQuantityCompletion(req.body.production_order_id, req.body.operation_id, req.body.quantity, req.body.scrap || 0, req.user.userId);
    res.json(result);
}));
// ============================================================================
// MRP
// ============================================================================
/**
 * GET /api/manufacturing/mrp/plans
 * Get MRP plans
 */
router.get('/mrp/plans', manufacturingAuth, (0, middleware_1.asyncHandler)(async (req, res) => {
    const filters = {
        entity_id: req.query.entity_id,
        plan_status: req.query.plan_status,
        created_by: req.query.created_by,
    };
    const plans = await ManufacturingService_1.manufacturingService.getMRPPlans(filters);
    res.json(plans);
}));
/**
 * POST /api/manufacturing/mrp/plans
 * Create MRP plan
 */
router.post('/mrp/plans', manufacturingAuth, (0, middleware_1.asyncHandler)(async (_req, res) => {
    const plan = await ManufacturingService_1.manufacturingService.createMRPPlan(_req.body);
    res.status(201).json(plan);
}));
/**
 * GET /api/manufacturing/mrp/actions/pending
 * Get pending MRP action messages
 */
router.get('/mrp/actions/pending', manufacturingAuth, (0, middleware_1.asyncHandler)(async (req, res) => {
    const planId = req.query.plan_id;
    const actions = await ManufacturingService_1.manufacturingService.getPendingMRPActions(planId);
    res.json(actions);
}));
// ============================================================================
// CAPACITY PLANNING
// ============================================================================
/**
 * GET /api/manufacturing/capacity/plans
 * Get capacity plans
 */
router.get('/capacity/plans', manufacturingAuth, (0, middleware_1.asyncHandler)(async (req, res) => {
    const filters = {
        entity_id: req.query.entity_id,
        plan_status: req.query.plan_status,
    };
    const plans = await ManufacturingService_1.manufacturingService.getCapacityPlans(filters);
    res.json(plans);
}));
/**
 * POST /api/manufacturing/capacity/plans
 * Create capacity plan
 */
router.post('/capacity/plans', manufacturingAuth, (0, middleware_1.asyncHandler)(async (_req, res) => {
    const plan = await ManufacturingService_1.manufacturingService.createCapacityPlan(_req.body);
    res.status(201).json(plan);
}));
/**
 * GET /api/manufacturing/capacity/overloaded
 * Get overloaded work centers
 */
router.get('/capacity/overloaded', manufacturingAuth, (0, middleware_1.asyncHandler)(async (_req, res) => {
    const overloaded = await ManufacturingService_1.manufacturingService.getOverloadedWorkCenters();
    res.json(overloaded);
}));
exports.default = router;
//# sourceMappingURL=manufacturing.js.map