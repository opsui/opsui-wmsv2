"use strict";
/**
 * Variance Severity Routes
 *
 * API endpoints for managing variance severity configurations
 */
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const VarianceSeverityService_1 = require("../services/VarianceSeverityService");
const middleware_1 = require("../middleware");
const permissions_1 = require("../middleware/permissions");
const shared_1 = require("@opsui/shared");
const router = (0, express_1.Router)();
// All routes require authentication
router.use(middleware_1.authenticate);
/**
 * GET /api/cycle-count/severity/configs
 * Get all variance severity configurations
 */
router.get('/configs', (0, middleware_1.asyncHandler)(async (req, res) => {
    const includeInactive = req.query.includeInactive === 'true';
    const configs = await VarianceSeverityService_1.varianceSeverityService.getAllSeverityConfigs(includeInactive);
    res.json(configs);
}));
/**
 * GET /api/cycle-count/severity/configs/:configId
 * Get a specific severity configuration
 */
router.get('/configs/:configId', (0, middleware_1.asyncHandler)(async (req, res) => {
    const { configId } = req.params;
    const config = await VarianceSeverityService_1.varianceSeverityService.getSeverityConfig(configId);
    res.json(config);
}));
/**
 * POST /api/cycle-count/severity/configs
 * Create a new severity configuration
 * Requires MANAGE_BUSINESS_RULES permission
 */
router.post('/configs', (0, permissions_1.requirePermission)(shared_1.Permission.MANAGE_BUSINESS_RULES), (0, middleware_1.authorize)(shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { severityLevel, minVariancePercent, maxVariancePercent, requiresApproval, requiresManagerApproval, autoAdjust, colorCode, } = req.body;
    const config = await VarianceSeverityService_1.varianceSeverityService.createSeverityConfig({
        severityLevel,
        minVariancePercent,
        maxVariancePercent,
        requiresApproval,
        requiresManagerApproval,
        autoAdjust,
        colorCode,
    });
    res.status(201).json(config);
}));
/**
 * PUT /api/cycle-count/severity/configs/:configId
 * Update a severity configuration
 * Requires MANAGE_BUSINESS_RULES permission
 */
router.put('/configs/:configId', (0, permissions_1.requirePermission)(shared_1.Permission.MANAGE_BUSINESS_RULES), (0, middleware_1.authorize)(shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { configId } = req.params;
    const updates = req.body;
    const config = await VarianceSeverityService_1.varianceSeverityService.updateSeverityConfig(configId, updates);
    res.json(config);
}));
/**
 * DELETE /api/cycle-count/severity/configs/:configId
 * Delete (soft-delete) a severity configuration
 * Requires MANAGE_BUSINESS_RULES permission
 */
router.delete('/configs/:configId', (0, permissions_1.requirePermission)(shared_1.Permission.MANAGE_BUSINESS_RULES), (0, middleware_1.authorize)(shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { configId } = req.params;
    await VarianceSeverityService_1.varianceSeverityService.deleteSeverityConfig(configId);
    res.status(204).send();
}));
/**
 * POST /api/cycle-count/severity/configs/reset
 * Reset to default severity configurations
 * Requires MANAGE_BUSINESS_RULES permission
 */
router.post('/configs/reset', (0, permissions_1.requirePermission)(shared_1.Permission.MANAGE_BUSINESS_RULES), (0, middleware_1.authorize)(shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (_req, res) => {
    await VarianceSeverityService_1.varianceSeverityService.resetToDefaults();
    res.json({ message: 'Severity configurations reset to defaults' });
}));
/**
 * GET /api/cycle-count/severity/determine
 * Determine severity for a given variance percentage
 */
router.get('/determine', (0, middleware_1.asyncHandler)(async (req, res) => {
    const variancePercent = parseFloat(req.query.variance);
    if (isNaN(variancePercent)) {
        res.status(400).json({
            error: 'Invalid variance_percent parameter',
            code: 'INVALID_PARAM',
        });
        return;
    }
    const determination = await VarianceSeverityService_1.varianceSeverityService.getSeverityForVariance(variancePercent);
    res.json(determination);
}));
exports.default = router;
//# sourceMappingURL=varianceSeverity.js.map