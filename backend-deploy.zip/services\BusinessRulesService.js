"use strict";
/**
 * Business Rules Engine Service
 *
 * Core service for evaluating and executing business rules.
 * Supports configurable allocation logic and automated decision making.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.businessRulesService = exports.BusinessRulesService = void 0;
const BusinessRulesRepository_1 = require("../repositories/BusinessRulesRepository");
const shared_1 = require("@opsui/shared");
// ============================================================================
// SERVICE
// ============================================================================
class BusinessRulesService {
    /**
     * Trigger rule evaluation for an event
     */
    async triggerEvent(context) {
        if (!context) {
            return;
        }
        // Find all active rules for this event type
        const rules = await BusinessRulesRepository_1.businessRulesRepository.findActiveRulesByEventType(context.eventType);
        // Evaluate and execute rules in priority order
        for (const rule of rules) {
            await this.evaluateAndExecuteRule(rule, context);
        }
    }
    /**
     * Evaluate and execute a single rule
     */
    async evaluateAndExecuteRule(rule, context) {
        const startTime = Date.now();
        const executionResults = [];
        try {
            // Evaluate conditions
            const evaluationResult = this.evaluateRuleConditions(rule, context);
            // Create execution log
            const log = {
                ruleId: rule.ruleId,
                eventType: context.eventType,
                entityId: context.entityId,
                entityType: context.entityType,
                triggeredAt: new Date(),
                triggeredBy: context.userId,
                conditionsMet: evaluationResult.conditionsMet,
                executionTimeMs: Date.now() - startTime,
                executionResults: [],
            };
            // If conditions are met, execute actions
            if (evaluationResult.shouldExecute) {
                for (const action of rule.actions) {
                    try {
                        const result = await this.executeAction(action, context);
                        executionResults.push({
                            actionId: action.actionId,
                            actionType: action.actionType,
                            success: true,
                            result,
                        });
                    }
                    catch (error) {
                        executionResults.push({
                            actionId: action.actionId,
                            actionType: action.actionType,
                            success: false,
                            errorMessage: error.message,
                        });
                    }
                }
            }
            log.executionResults = executionResults;
            await BusinessRulesRepository_1.businessRulesRepository.createExecutionLog(log);
        }
        catch (error) {
            // Log execution error
            const errorTime = Date.now();
            await BusinessRulesRepository_1.businessRulesRepository.createExecutionLog({
                ruleId: rule.ruleId,
                eventType: context.eventType,
                entityId: context.entityId,
                entityType: context.entityType,
                triggeredAt: new Date(),
                triggeredBy: context.userId,
                conditionsMet: false,
                executionTimeMs: errorTime - startTime,
                executionResults: [],
                errorMessage: error.message,
            });
        }
    }
    /**
     * Evaluate all conditions for a rule
     */
    evaluateRuleConditions(rule, context) {
        if (rule.conditions.length === 0) {
            // No conditions = always execute
            return {
                rule,
                conditionsMet: true,
                conditionResults: [],
                shouldExecute: true,
            };
        }
        const conditionResults = [];
        let finalResult = true;
        let currentOperator = shared_1.LogicalOperator.AND;
        for (let i = 0; i < rule.conditions.length; i++) {
            const condition = rule.conditions[i];
            const result = this.evaluateCondition(condition, context);
            conditionResults.push(result);
            // Apply logical operator
            if (i === 0) {
                finalResult = result.result;
            }
            else {
                if (currentOperator === shared_1.LogicalOperator.AND) {
                    finalResult = finalResult && result.result;
                }
                else {
                    finalResult = finalResult || result.result;
                }
            }
            // Set operator for next iteration
            currentOperator = condition.logicalOperator || shared_1.LogicalOperator.AND;
        }
        const conditionsMet = conditionResults.every(r => r.result);
        return {
            rule,
            conditionsMet,
            conditionResults,
            shouldExecute: finalResult,
        };
    }
    /**
     * Evaluate a single condition
     */
    evaluateCondition(condition, context) {
        try {
            // Extract value from entity using dot notation
            const actualValue = this.getFieldValue(context.entity, condition.field);
            const expectedValue = condition.value;
            let result = false;
            switch (condition.operator) {
                case shared_1.ConditionOperator.EQUALS:
                    result = actualValue == expectedValue;
                    break;
                case shared_1.ConditionOperator.NOT_EQUALS:
                    result = actualValue != expectedValue;
                    break;
                case shared_1.ConditionOperator.GREATER_THAN:
                    result = this.compareValues(actualValue, expectedValue) > 0;
                    break;
                case shared_1.ConditionOperator.LESS_THAN:
                    result = this.compareValues(actualValue, expectedValue) < 0;
                    break;
                case shared_1.ConditionOperator.GREATER_THAN_OR_EQUAL:
                    result = this.compareValues(actualValue, expectedValue) >= 0;
                    break;
                case shared_1.ConditionOperator.LESS_THAN_OR_EQUAL:
                    result = this.compareValues(actualValue, expectedValue) <= 0;
                    break;
                case shared_1.ConditionOperator.CONTAINS:
                    result = String(actualValue).toLowerCase().includes(String(expectedValue).toLowerCase());
                    break;
                case shared_1.ConditionOperator.NOT_CONTAINS:
                    result = !String(actualValue).toLowerCase().includes(String(expectedValue).toLowerCase());
                    break;
                case shared_1.ConditionOperator.STARTS_WITH:
                    result = String(actualValue)
                        .toLowerCase()
                        .startsWith(String(expectedValue).toLowerCase());
                    break;
                case shared_1.ConditionOperator.ENDS_WITH:
                    result = String(actualValue).toLowerCase().endsWith(String(expectedValue).toLowerCase());
                    break;
                case shared_1.ConditionOperator.IN:
                    result = Array.isArray(expectedValue) && expectedValue.includes(actualValue);
                    break;
                case shared_1.ConditionOperator.NOT_IN:
                    result = Array.isArray(expectedValue) && !expectedValue.includes(actualValue);
                    break;
                case shared_1.ConditionOperator.BETWEEN:
                    const min = expectedValue;
                    const max = condition.value2;
                    result =
                        this.compareValues(actualValue, min) >= 0 && this.compareValues(actualValue, max) <= 0;
                    break;
                case shared_1.ConditionOperator.IS_NULL:
                    result = actualValue === null || actualValue === undefined;
                    break;
                case shared_1.ConditionOperator.IS_NOT_NULL:
                    result = actualValue !== null && actualValue !== undefined;
                    break;
                case shared_1.ConditionOperator.MATCHES_REGEX:
                    try {
                        const regex = new RegExp(String(expectedValue));
                        result = regex.test(String(actualValue));
                    }
                    catch (e) {
                        result = false;
                    }
                    break;
                default:
                    result = false;
            }
            return {
                condition,
                result,
            };
        }
        catch (error) {
            return {
                condition,
                result: false,
                error: error.message,
            };
        }
    }
    /**
     * Execute a rule action
     */
    async executeAction(action, context) {
        switch (action.actionType) {
            case shared_1.ActionType.SET_PRIORITY:
                return this.actionSetPriority(action, context);
            case shared_1.ActionType.ASSIGN_USER:
                return this.actionAssignUser(action, context);
            case shared_1.ActionType.SEND_NOTIFICATION:
                return this.actionSendNotification(action, context);
            case shared_1.ActionType.BLOCK_ACTION:
                return this.actionBlockAction(action, context);
            case shared_1.ActionType.MODIFY_FIELD:
                return this.actionModifyField(action, context);
            default:
                throw new Error(`Unknown action type: ${action.actionType}`);
        }
    }
    // ==========================================================================
    // ACTION IMPLEMENTATIONS
    // ==========================================================================
    async actionSetPriority(action, _context) {
        const { field, value } = action.parameters;
        // This would typically update the entity in the database
        // For now, we return a marker indicating the action should be performed
        return {
            type: 'SET_PRIORITY',
            field: field || 'priority',
            value,
        };
    }
    async actionAssignUser(action, _context) {
        const { userId, role } = action.parameters;
        return {
            type: 'ASSIGN_USER',
            userId,
            role,
        };
    }
    async actionSendNotification(action, _context) {
        const { message, recipients, type } = action.parameters;
        // This would integrate with a notification service
        return {
            type: 'SEND_NOTIFICATION',
            message,
            recipients,
            notificationType: type,
        };
    }
    async actionBlockAction(action, _context) {
        const { reason } = action.parameters;
        // This would prevent an action from completing
        return {
            type: 'BLOCK_ACTION',
            blocked: true,
            reason,
        };
    }
    async actionModifyField(action, context) {
        const { field, value, operation } = action.parameters;
        let finalValue = value;
        if (operation === 'add') {
            const currentValue = this.getFieldValue(context.entity, String(field));
            finalValue = Number(currentValue) + Number(value);
        }
        else if (operation === 'multiply') {
            const currentValue = this.getFieldValue(context.entity, String(field));
            finalValue = Number(currentValue) * Number(value);
        }
        return {
            type: 'MODIFY_FIELD',
            field,
            value: finalValue,
        };
    }
    // ==========================================================================
    // UTILITY METHODS
    // ==========================================================================
    /**
     * Get field value from object using dot notation
     */
    getFieldValue(obj, fieldPath) {
        const keys = fieldPath.split('.');
        let value = obj;
        for (const key of keys) {
            if (value === null || value === undefined) {
                return null;
            }
            value = value[key];
        }
        return value;
    }
    /**
     * Compare two values for sorting
     */
    compareValues(a, b) {
        if (a === null || a === undefined)
            return -1;
        if (b === null || b === undefined)
            return 1;
        const numA = Number(a);
        const numB = Number(b);
        if (!isNaN(numA) && !isNaN(numB)) {
            return numA - numB;
        }
        const strA = String(a).toLowerCase();
        const strB = String(b).toLowerCase();
        if (strA < strB)
            return -1;
        if (strA > strB)
            return 1;
        return 0;
    }
}
exports.BusinessRulesService = BusinessRulesService;
exports.businessRulesService = new BusinessRulesService();
//# sourceMappingURL=BusinessRulesService.js.map