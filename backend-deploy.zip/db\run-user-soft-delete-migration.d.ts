/**
 * Run the add_user_soft_delete migration
 */
export {};
//# sourceMappingURL=run-user-soft-delete-migration.d.ts.map