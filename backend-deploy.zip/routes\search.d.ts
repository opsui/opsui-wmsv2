/**
 * Global Search routes
 *
 * Provides a unified search endpoint for orders, SKUs, users, and pages
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=search.d.ts.map