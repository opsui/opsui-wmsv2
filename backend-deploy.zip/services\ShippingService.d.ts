/**
 * Shipping Service
 *
 * Handles shipping carriers, shipments, labels, and tracking
 */
import { ShipmentStatus, Carrier, Shipment, ShippingLabel, ShipmentTrackingEvent, CreateShipmentDTO, CreateShippingLabelDTO, AddTrackingEventDTO } from '@opsui/shared';
export declare class ShippingService {
    /**
     * Get all active carriers
     */
    getActiveCarriers(): Promise<Carrier[]>;
    /**
     * Get carrier by ID
     */
    getCarrier(carrierId: string): Promise<Carrier>;
    /**
     * Get all shipped orders with filters and pagination
     */
    getShippedOrders(filters?: {
        status?: string;
        carrierId?: string;
        startDate?: string;
        endDate?: string;
        search?: string;
        sortBy?: string;
        sortOrder?: 'asc' | 'desc';
        page?: number;
        limit?: number;
    }): Promise<{
        orders: Array<{
            id: string;
            orderId: string;
            customerName: string;
            status: string;
            priority: string;
            itemCount: number;
            totalValue: number;
            shippedAt: string;
            deliveredAt?: string;
            trackingNumber?: string;
            carrier?: string;
            shippingAddress: string;
            shippedBy: string;
        }>;
        stats: {
            totalShipped: number;
            totalValue: number;
            delivered: number;
            pendingDelivery: number;
        };
        total: number;
        page: number;
        limit: number;
        totalPages: number;
    }>;
    /**
     * Export shipped orders to CSV
     */
    exportShippedOrdersToCSV(orderIds: string[]): Promise<string>;
    /**
     * Create a new shipment
     */
    createShipment(dto: CreateShipmentDTO): Promise<Shipment>;
    /**
     * Get shipment by ID
     */
    getShipment(shipmentId: string): Promise<Shipment>;
    /**
     * Get shipment by order ID
     */
    getShipmentByOrderId(orderId: string): Promise<Shipment | null>;
    /**
     * Get all shipments with optional filters
     */
    getAllShipments(filters?: {
        status?: ShipmentStatus;
        carrierId?: string;
        limit?: number;
        offset?: number;
    }): Promise<{
        shipments: Shipment[];
        total: number;
    }>;
    /**
     * Update shipment status
     */
    updateShipmentStatus(shipmentId: string, status: ShipmentStatus, userId?: string): Promise<Shipment>;
    /**
     * Add tracking number to shipment
     */
    addTrackingNumber(shipmentId: string, trackingNumber: string, trackingUrl?: string): Promise<Shipment>;
    /**
     * Create shipping labels for a shipment
     */
    createShippingLabel(dto: CreateShippingLabelDTO): Promise<ShippingLabel>;
    /**
     * Mark label as printed
     */
    markLabelPrinted(labelId: string): Promise<ShippingLabel>;
    /**
     * Update shipment status based on label completion
     */
    private updateShipmentLabelStatus;
    /**
     * Add tracking event to shipment
     */
    addTrackingEvent(dto: AddTrackingEventDTO): Promise<ShipmentTrackingEvent>;
    /**
     * Get tracking events for shipment
     */
    getTrackingEvents(shipmentId: string): Promise<ShipmentTrackingEvent[]>;
    private mapRowToCarrier;
    private mapRowToShipment;
    private mapRowToShippingLabel;
    private mapRowToTrackingEvent;
}
export declare const shippingService: ShippingService;
//# sourceMappingURL=ShippingService.d.ts.map