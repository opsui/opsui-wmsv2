/**
 * Shopify Platform Service
 *
 * Handles integration with Shopify's Admin API
 * Supports webhook processing, inventory sync, order import, and product sync
 */
import { EcommerceConnection, EcommerceProductMapping, TestConnectionResult, PlatformProductData, PlatformOrderData } from '@opsui/shared';
export declare class ShopifyService {
    private readonly BASE_API_VERSION;
    private readonly SHOPIFY_DOMAIN;
    /**
     * Build Shopify API URL
     */
    private buildApiUrl;
    /**
     * Make authenticated request to Shopify API
     */
    private apiRequest;
    /**
     * Test connection to Shopify
     */
    testConnection(connection: EcommerceConnection): Promise<TestConnectionResult & {
        rateLimitRemaining?: number;
        rateLimitResetAt?: Date;
    }>;
    /**
     * Fetch products from Shopify
     */
    fetchProducts(connection: EcommerceConnection, skus?: string[]): Promise<PlatformProductData[]>;
    /**
     * Fetch a single product by SKU
     */
    private fetchProductBySku;
    /**
     * Normalize Shopify product to standard format
     */
    private normalizeProduct;
    /**
     * Normalize multiple products
     */
    private normalizeProducts;
    /**
     * Update inventory in Shopify
     */
    updateInventory(connection: EcommerceConnection, mapping: EcommerceProductMapping, quantity: number): Promise<void>;
    /**
     * Get inventory from Shopify
     */
    getInventory(connection: EcommerceConnection, mapping: EcommerceProductMapping): Promise<number | undefined>;
    /**
     * Get inventory level ID for a variant
     */
    private getInventoryLevelId;
    /**
     * Get location ID for inventory tracking
     */
    private getLocationId;
    /**
     * Fetch orders from Shopify
     */
    fetchOrders(connection: EcommerceConnection, orderIds?: string[], daysToLookBack?: number): Promise<PlatformOrderData[]>;
    /**
     * Fetch a single order by ID
     */
    private fetchOrderById;
    /**
     * Normalize Shopify order to standard format
     */
    private normalizeOrder;
    /**
     * Verify Shopify webhook signature
     */
    verifyWebhook(connection: EcommerceConnection, payload: any): Promise<boolean>;
    /**
     * Handle order webhook from Shopify
     */
    handleOrderWebhook(connection: EcommerceConnection, payload: any): Promise<void>;
    /**
     * Handle product webhook from Shopify
     */
    handleProductWebhook(connection: EcommerceConnection, payload: any): Promise<void>;
    /**
     * Handle inventory webhook from Shopify
     */
    handleInventoryWebhook(connection: EcommerceConnection, payload: any): Promise<void>;
}
//# sourceMappingURL=ShopifyService.d.ts.map