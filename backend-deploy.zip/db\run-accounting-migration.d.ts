/**
 * Run the accounting tables migration
 */
export {};
//# sourceMappingURL=run-accounting-migration.d.ts.map