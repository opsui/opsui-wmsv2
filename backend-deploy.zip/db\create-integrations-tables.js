"use strict";
/**
 * Create integrations tables
 */
Object.defineProperty(exports, "__esModule", { value: true });
const client_1 = require("./client");
const fs_1 = require("fs");
const path_1 = require("path");
async function createIntegrationsTables() {
    console.log('Creating integrations tables...');
    try {
        const migrationPath = (0, path_1.join)(__dirname, 'migrations', '013_create_integrations.sql');
        let migrationSQL = (0, fs_1.readFileSync)(migrationPath, 'utf-8');
        // Remove comments and split by semicolon
        const statements = migrationSQL
            .split('\n')
            .filter(line => !line.trim().startsWith('--'))
            .join('\n')
            .split(';')
            .map(s => s.trim())
            .filter(s => s.length > 0);
        for (const statement of statements) {
            await (0, client_1.query)(statement, []);
        }
        console.log('✓ Created integrations tables');
        console.log('Migration completed successfully!');
    }
    catch (error) {
        console.error('✗ Migration failed:', error.message);
        throw error;
    }
}
createIntegrationsTables()
    .then(() => {
    console.log('Done! Exiting...');
    process.exit(0);
})
    .catch(error => {
    console.error('Fatal error:', error);
    process.exit(1);
});
//# sourceMappingURL=create-integrations-tables.js.map