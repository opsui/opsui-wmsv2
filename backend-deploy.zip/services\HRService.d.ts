/**
 * HR Service
 *
 * Business logic for HR & Payroll operations
 * Handles employee management, timesheet processing, payroll calculation,
 * NZ tax compliance (PAYE, KiwiSaver, ACC), and leave management
 */
import { HREmployee, HREmployeeWithDetails, HRTimesheet, HRTimesheetEntry, HRTimesheetStatus, HRPayrollRun, HRPayItem, HRPayrollPeriod, HRNZTaxCode, HRLeaveStatus, HRLeaveRequest, HRLeaveBalance, CreateEmployeeInput, UpdateEmployeeInput, SubmitTimesheetInput, ProcessPayrollInput } from '@opsui/shared';
export interface PayrollCalculationResult {
    periodId: string;
    employeeCount: number;
    totalGrossPay: number;
    totalNetPay: number;
    totalTax: number;
    totalKiwiSaver: number;
    totalACC: number;
    totalDeductions: number;
    totalEmployerContributions: number;
    payItems: PayItemCalculation[];
}
export interface PayItemCalculation {
    employeeId: string;
    employeeName: string;
    regularHours: number;
    regularRate: number;
    regularPay: number;
    overtime1_5Hours: number;
    overtime1_5Rate: number;
    overtime1_5Pay: number;
    overtime2_0Hours: number;
    overtime2_0Rate: number;
    overtime2_0Pay: number;
    grossPay: number;
    payeTax: number;
    kiwiSaverEmployee: number;
    accEarnersLevy: number;
    studentLoan: number;
    otherDeductions: number;
    totalDeductions: number;
    netPay: number;
    kiwiSaverEmployer: number;
    accEmployerLevy: number;
    totalEmployerContributions: number;
    totalCost: number;
}
declare class HRService {
    /**
     * Get all employees with optional filters
     */
    getEmployees(filters?: {
        status?: string;
        department?: string;
        search?: string;
    }): Promise<HREmployee[]>;
    /**
     * Get employee with all details
     */
    getEmployeeById(employeeId: string): Promise<HREmployeeWithDetails>;
    /**
     * Create a new employee
     */
    createEmployee(data: CreateEmployeeInput, createdBy: string): Promise<HREmployeeWithDetails>;
    /**
     * Update an existing employee
     */
    updateEmployee(employeeId: string, data: UpdateEmployeeInput): Promise<HREmployeeWithDetails>;
    /**
     * Delete (soft delete) an employee
     */
    deleteEmployee(employeeId: string): Promise<boolean>;
    /**
     * Get timesheet with entries
     */
    getTimesheet(timesheetId: string): Promise<HRTimesheet & {
        entries: HRTimesheetEntry[];
    }>;
    /**
     * Get timesheets for an employee
     */
    getEmployeeTimesheets(employeeId: string, limit?: number): Promise<HRTimesheet[]>;
    /**
     * Get timesheets by status
     */
    getTimesheetsByStatus(status: HRTimesheetStatus): Promise<HRTimesheet[]>;
    /**
     * Submit a timesheet
     */
    submitTimesheet(data: SubmitTimesheetInput, userId: string): Promise<HRTimesheet>;
    /**
     * Approve a timesheet
     */
    approveTimesheet(timesheetId: string, approvedBy: string): Promise<HRTimesheet>;
    /**
     * Reject a timesheet
     */
    rejectTimesheet(timesheetId: string, reason: string, rejectedBy: string): Promise<HRTimesheet>;
    /**
     * Calculate payroll for a period (preview)
     */
    calculatePayroll(periodId: string, options?: ProcessPayrollInput): Promise<PayrollCalculationResult>;
    /**
     * Process payroll run
     */
    processPayrollRun(periodId: string, options: ProcessPayrollInput | undefined, createdBy: string): Promise<HRPayrollRun>;
    /**
     * Get payroll runs
     */
    getPayrollRuns(limit?: number): Promise<HRPayrollRun[]>;
    /**
     * Get payroll run with pay items
     */
    getPayrollRun(payrollRunId: string): Promise<HRPayrollRun & {
        payItems: HRPayItem[];
    }>;
    /**
     * Calculate PAYE tax using IRD tax tables
     */
    calculatePAYE(taxableIncome: number, taxCode: HRNZTaxCode): Promise<number>;
    /**
     * Calculate ACC earners levy
     */
    calculateACCEarnersLevy(grossPay: number): Promise<number>;
    /**
     * Calculate KiwiSaver contribution
     */
    calculateKiwiSaver(grossPay: number, rate: string): Promise<{
        employee: number;
        employer: number;
    }>;
    /**
     * Calculate student loan repayment
     */
    calculateStudentLoan(grossPay: number): number;
    /**
     * Calculate pay for a single employee
     */
    private calculateEmployeePay;
    /**
     * Generate employee ID
     */
    private generateEmployeeId;
    /**
     * Generate employee number
     */
    private generateEmployeeNumber;
    /**
     * Get leave requests
     */
    getLeaveRequests(filters?: {
        status?: HRLeaveStatus;
        employeeId?: string;
    }): Promise<HRLeaveRequest[]>;
    /**
     * Create leave request
     */
    createLeaveRequest(data: {
        employeeId: string;
        leaveTypeId: string;
        startDate: string;
        endDate: string;
        totalHours: number;
        reason?: string;
    }): Promise<HRLeaveRequest>;
    /**
     * Approve leave request
     */
    approveLeaveRequest(requestId: string, approvedBy: string): Promise<HRLeaveRequest>;
    /**
     * Get leave balances for employee
     */
    getLeaveBalances(employeeId: string): Promise<HRLeaveBalance[]>;
    /**
     * Get active deduction types
     */
    getDeductionTypes(): Promise<any[]>;
    /**
     * Get active leave types
     */
    getLeaveTypes(): Promise<any[]>;
    /**
     * Get payroll periods
     */
    getPayrollPeriods(): Promise<HRPayrollPeriod[]>;
    /**
     * Get current payroll period
     */
    getCurrentPayrollPeriod(): Promise<HRPayrollPeriod | null>;
}
export declare const hrService: HRService;
export {};
//# sourceMappingURL=HRService.d.ts.map