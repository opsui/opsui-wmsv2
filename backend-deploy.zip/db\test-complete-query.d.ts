/**
 * Test complete getPickerOrders query
 */
export {};
//# sourceMappingURL=test-complete-query.d.ts.map