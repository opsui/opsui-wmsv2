"use strict";
/**
 * Global error handling middleware
 *
 * Catches all errors and formats them appropriately for the client
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.ValidationError = void 0;
exports.errorHandler = errorHandler;
exports.notFoundHandler = notFoundHandler;
exports.asyncHandler = asyncHandler;
exports.badRequest = badRequest;
exports.unauthorized = unauthorized;
exports.forbidden = forbidden;
exports.notFound = notFound;
exports.conflict = conflict;
exports.internalError = internalError;
const logger_1 = require("../config/logger");
const shared_1 = require("@opsui/shared");
// ============================================================================
// ERROR HANDLER MIDDLEWARE
// ============================================================================
function errorHandler(err, req, res, _next) {
    // Log the error
    logger_1.logger.error('Request error', {
        error: err.message,
        code: err.code,
        statusCode: err.statusCode,
        path: req.path,
        method: req.method,
        stack: err.stack,
    });
    // Determine status code
    const statusCode = err.statusCode || 500;
    const code = err.code || 'INTERNAL_ERROR';
    // Format error response
    const errorResponse = {
        error: err.message || 'An unexpected error occurred',
        code,
    };
    // Include details for WMSError
    if (err instanceof shared_1.WMSError) {
        errorResponse.details = err.details;
    }
    // Include stack trace in development
    if (process.env.NODE_ENV === 'development' && err.stack) {
        errorResponse.stack = err.stack;
    }
    res.status(statusCode).json(errorResponse);
}
// ============================================================================
// 404 HANDLER
// ============================================================================
function notFoundHandler(req, res) {
    res.status(404).json({
        error: `Route not found: ${req.method} ${req.path}`,
        code: 'NOT_FOUND',
    });
}
// ============================================================================
// ASYNC ERROR WRAPPER
// ============================================================================
/**
 * Wraps async route handlers to catch errors and pass them to error middleware
 */
function asyncHandler(fn) {
    return (req, res, next) => {
        Promise.resolve(fn(req, res, next)).catch(next);
    };
}
// ============================================================================
// VALIDATION ERROR FACTORY
// ============================================================================
class ValidationError extends Error {
    details;
    constructor(message, details) {
        super(message);
        this.details = details;
        this.name = 'ValidationError';
        this.statusCode = 400;
        this.code = 'VALIDATION_ERROR';
    }
    statusCode;
    code;
}
exports.ValidationError = ValidationError;
// ============================================================================
// HTTP ERROR FACTORIES
// ============================================================================
function badRequest(message, details) {
    const error = new Error(message);
    error.statusCode = 400;
    error.code = 'BAD_REQUEST';
    error.details = details;
    return error;
}
function unauthorized(message = 'Unauthorized') {
    const error = new Error(message);
    error.statusCode = 401;
    error.code = 'UNAUTHORIZED';
    return error;
}
function forbidden(message = 'Forbidden') {
    const error = new Error(message);
    error.statusCode = 403;
    error.code = 'FORBIDDEN';
    return error;
}
function notFound(resource, id) {
    const message = id ? `${resource} (${id}) not found` : `${resource} not found`;
    const error = new Error(message);
    error.statusCode = 404;
    error.code = 'NOT_FOUND';
    return error;
}
function conflict(message, details) {
    const error = new Error(message);
    error.statusCode = 409;
    error.code = 'CONFLICT';
    error.details = details;
    return error;
}
function internalError(message = 'Internal server error') {
    const error = new Error(message);
    error.statusCode = 500;
    error.code = 'INTERNAL_ERROR';
    return error;
}
//# sourceMappingURL=errorHandler.js.map