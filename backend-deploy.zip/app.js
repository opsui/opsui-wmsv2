"use strict";
/**
 * Express application configuration
 *
 * Sets up middleware, routes, and error handling
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getActiveConnections = getActiveConnections;
exports.getAllConnections = getAllConnections;
exports.waitForDrain = waitForDrain;
exports.createApp = createApp;
exports.startServer = startServer;
const express_1 = __importDefault(require("express"));
const cors_1 = __importDefault(require("cors"));
const helmet_1 = __importDefault(require("helmet"));
const compression_1 = __importDefault(require("compression"));
const config_1 = __importDefault(require("./config"));
const logger_1 = require("./config/logger");
const routes_1 = __importDefault(require("./routes"));
const middleware_1 = require("./middleware");
const security_1 = require("./middleware/security");
const client_1 = require("./db/client");
const swagger_1 = require("./docs/swagger");
const prometheus_1 = require("./observability/prometheus");
const AuditService_1 = require("./services/AuditService");
// ============================================================================
// CONNECTION TRACKING FOR HOT RELOAD
// ============================================================================
const activeConnections = new Set();
function trackConnections(req, res, next) {
    const connectionId = `${req.ip}-${Date.now()}-${Math.random()}`;
    activeConnections.add(connectionId);
    res.on('finish', () => {
        activeConnections.delete(connectionId);
    });
    res.on('close', () => {
        activeConnections.delete(connectionId);
    });
    next();
}
// Export for health checks and graceful shutdown
function getActiveConnections() {
    return activeConnections.size;
}
function getAllConnections() {
    return activeConnections;
}
// ============================================================================
// GRACEFUL SHUTDOWN
// ============================================================================
async function waitForDrain(timeoutMs = 30000) {
    const startTime = Date.now();
    const initialCount = activeConnections.size;
    if (initialCount === 0) {
        logger_1.logger.info('No active connections, immediate shutdown possible');
        return true;
    }
    logger_1.logger.info(`Waiting for ${initialCount} active connections to drain...`);
    while (activeConnections.size > 0) {
        const elapsed = Date.now() - startTime;
        if (elapsed >= timeoutMs) {
            logger_1.logger.warn(`Timeout waiting for connections to drain. ${activeConnections.size} remaining.`);
            return false;
        }
        // Log progress every 5 seconds
        if (elapsed % 5000 < 100) {
            logger_1.logger.info(`Still waiting for ${activeConnections.size} connections to drain...`);
        }
        await new Promise(resolve => setTimeout(resolve, 100));
    }
    const drainTime = Date.now() - startTime;
    logger_1.logger.info(`All connections drained in ${drainTime}ms`);
    return true;
}
// ============================================================================
// CREATE APP - HELPER FUNCTIONS
// ============================================================================
/**
 * Configure security middleware for the application
 */
function setupSecurityMiddleware(app) {
    // Custom security headers
    app.use(security_1.securityHeaders);
    // Helmet for additional security headers (with frameguard: deny to work with securityHeaders)
    app.use((0, helmet_1.default)({ frameguard: { action: 'deny' } }));
    // CORS configuration - use configured origins from environment
    // In production, this allows the frontend domain to access the API
    const corsOrigins = config_1.default.cors.origin;
    app.use((0, cors_1.default)({
        origin: (origin, callback) => {
            // Allow requests with no origin (like mobile apps or curl)
            if (!origin) {
                return callback(null, true);
            }
            // Check if origin is in allowed list
            const allowedOrigins = Array.isArray(corsOrigins)
                ? corsOrigins
                : [corsOrigins].filter(Boolean);
            if (allowedOrigins.includes(origin) || allowedOrigins.length === 0) {
                callback(null, true);
            }
            else {
                // In development, be permissive
                if (config_1.default.isDevelopment() &&
                    (origin.includes('localhost') || origin.includes('127.0.0.1'))) {
                    callback(null, true);
                }
                else {
                    callback(new Error('Not allowed by CORS'));
                }
            }
        },
        credentials: true,
        methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
        allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With', 'X-Request-Id'],
        exposedHeaders: ['X-Request-Id'],
        preflightContinue: false,
        optionsSuccessStatus: 204,
    }));
    // Request size limiting
    app.use(security_1.requestSizeLimit);
    // Input sanitization
    app.use(security_1.sanitizeInput);
    // CSRF protection for state-changing operations
    app.use('/api', security_1.csrfProtection);
    // Rate limiting (production only)
    if (config_1.default.isProduction()) {
        // Auth endpoints - stricter limits
        app.use('/api/auth/login', security_1.authRateLimiter);
        app.use('/api/auth/register', security_1.authRateLimiter);
        app.use('/api/auth/refresh', security_1.authRateLimiter);
        // General API rate limiting
        app.use('/api', security_1.apiRateLimiter);
        // Stricter limits for write operations
        app.use('/api', (req, res, next) => {
            if (['POST', 'PUT', 'DELETE', 'PATCH'].includes(req.method)) {
                return (0, security_1.writeOperationRateLimiter)(req, res, next);
            }
            next();
        });
    }
}
/**
 * Configure body parsing middleware
 */
function setupBodyParsing(app) {
    // Parse JSON bodies
    app.use(express_1.default.json({ limit: '10mb' }));
    // Parse URL-encoded bodies
    app.use(express_1.default.urlencoded({ extended: true, limit: '10mb' }));
}
/**
 * Configure compression middleware
 */
function setupCompression(app) {
    app.use((0, compression_1.default)());
}
/**
 * Configure rate limiting middleware
 */
function setupRateLimiting(app) {
    if (config_1.default.isProduction()) {
        app.use('/api/', middleware_1.rateLimiter);
    }
}
/**
 * Configure request tracking middleware
 */
function setupRequestTracking(app) {
    // Request ID tracking
    app.use(middleware_1.requestId);
    // Request logging
    app.use((req, _res, next) => {
        logger_1.logger.debug('Incoming request', {
            requestId: req.id,
            method: req.method,
            path: req.path,
            ip: req.ip,
            userAgent: req.get('user-agent'),
            activeConnections: activeConnections.size,
        });
        next();
    });
}
/**
 * Configure audit logging
 */
function setupAuditLogging(app) {
    // Log ALL API requests to audit logs
    app.use('/api', (req, res, next) => {
        (0, middleware_1.auditLoggingMiddleware)(req, res, next).catch(next);
    });
}
/**
 * Configure API routes
 */
function setupApiRoutes(app) {
    // API v1 routes
    app.use('/api/v1', routes_1.default);
    // Legacy API redirect (v1 is now current)
    app.get('/api', (_req, res) => {
        res.redirect(301, '/api/v1');
    });
    // Prometheus metrics endpoint (if enabled)
    if (config_1.default.prometheus.enabled) {
        app.get('/metrics', (req, res, next) => {
            (0, prometheus_1.metricsEndpoint)(req, res).catch(next);
        });
    }
}
/**
 * Configure documentation routes
 */
function setupDocumentationRoutes(app) {
    if (!config_1.default.isProduction()) {
        (0, swagger_1.setupSwagger)(app);
        logger_1.logger.info('Swagger UI available at http://localhost:3001/api/docs');
        logger_1.logger.info('API v1 endpoint: http://localhost:3001/api/v1');
    }
}
/**
 * Configure system endpoints
 */
function setupSystemEndpoints(app) {
    // Root endpoint
    app.get('/', (_req, res) => {
        res.json({
            name: 'WMS API',
            version: '1.0.0',
            environment: config_1.default.nodeEnv,
            timestamp: new Date().toISOString(),
            endpoints: {
                api: '/api',
                health: '/health',
                ready: '/ready',
                docs: !config_1.default.isProduction() ? '/api/docs' : undefined,
            },
        });
    });
    // Health endpoint with connection info
    app.get('/health', (_req, res) => {
        res.json({
            status: 'ok',
            activeConnections: activeConnections.size,
            timestamp: new Date().toISOString(),
        });
    });
    // Readiness check for orchestrators
    app.get('/ready', (_req, res) => {
        const isReady = activeConnections.size < 100;
        res.status(isReady ? 200 : 503).json({
            ready: isReady,
            activeConnections: activeConnections.size,
            timestamp: new Date().toISOString(),
        });
    });
}
/**
 * Configure routes and endpoints
 */
function setupRoutes(app) {
    setupApiRoutes(app);
    setupDocumentationRoutes(app);
    setupSystemEndpoints(app);
}
/**
 * Configure error handlers
 */
function setupErrorHandlers(app) {
    // 404 handler
    app.use(middleware_1.notFoundHandler);
    // Global error handler
    app.use(middleware_1.errorHandler);
}
// ============================================================================
// CREATE APP
// ============================================================================
function createApp() {
    const app = (0, express_1.default)();
    // Trust proxy for rate limiting behind Cloudflare/nginx
    app.set('trust proxy', 1);
    // Setup all middleware and routes
    setupSecurityMiddleware(app);
    setupBodyParsing(app);
    setupCompression(app);
    setupRateLimiting(app);
    // Connection tracking
    app.use(trackConnections);
    // Prometheus metrics (if enabled)
    if (config_1.default.prometheus.enabled) {
        app.use(prometheus_1.metricsMiddleware);
    }
    setupRequestTracking(app);
    setupAuditLogging(app);
    setupRoutes(app);
    setupErrorHandlers(app);
    return app;
}
// ============================================================================
// STARTUP
// ============================================================================
async function startServer() {
    logger_1.logger.info('Starting WMS Backend...', {
        environment: config_1.default.nodeEnv,
        port: config_1.default.port,
    });
    // Test database connection
    const dbConnected = await (0, client_1.testConnection)();
    if (!dbConnected) {
        logger_1.logger.error('Failed to connect to database');
        throw new Error('Database connection failed');
    }
    // Initialize Audit Service
    try {
        const auditService = (0, AuditService_1.getAuditService)();
        await auditService.initialize();
        logger_1.logger.info('Audit service initialized');
    }
    catch (error) {
        logger_1.logger.error('Failed to initialize audit service', { error });
        // Don't fail startup, just log the error
    }
    // Setup shutdown handlers
    (0, client_1.setupShutdownHandlers)();
    logger_1.logger.info('WMS Backend started successfully');
}
//# sourceMappingURL=app.js.map