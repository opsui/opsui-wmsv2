/**
 * E-commerce Integration Routes
 *
 * API endpoints for e-commerce platform integration
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=ecommerce.d.ts.map