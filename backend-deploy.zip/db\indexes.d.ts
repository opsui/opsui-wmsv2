/**
 * Database Indexes for Performance
 *
 * Run this script to create optimized indexes for the WMS database
 */
export declare function createIndexes(): Promise<void>;
//# sourceMappingURL=indexes.d.ts.map