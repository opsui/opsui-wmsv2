"use strict";
/**
 * Test Helper Functions
 *
 * Utility functions for writing tests.
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getTestDb = getTestDb;
exports.cleanDatabase = cleanDatabase;
exports.withTransaction = withTransaction;
exports.createTestUser = createTestUser;
exports.generateTestToken = generateTestToken;
exports.getTestAuthHeaders = getTestAuthHeaders;
exports.createTestOrder = createTestOrder;
exports.createTestProduct = createTestProduct;
exports.createTestLocation = createTestLocation;
exports.createTestInventory = createTestInventory;
exports.makeTestRequest = makeTestRequest;
exports.expectStatus = expectStatus;
exports.expectApiError = expectApiError;
exports.createMockResponse = createMockResponse;
exports.createMockRequest = createMockRequest;
exports.wait = wait;
exports.retry = retry;
const pg_1 = require("pg");
const crypto_1 = require("crypto");
const bcrypt_1 = __importDefault(require("bcrypt"));
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const index_js_1 = __importDefault(require("../config/index.js"));
// ============================================================================
// Database Helpers
// ============================================================================
/**
 * Get a test database connection
 */
function getTestDb() {
    return new pg_1.Pool({
        host: process.env.DB_HOST || 'localhost',
        port: parseInt(process.env.DB_PORT || '5432'),
        database: process.env.DB_NAME || 'test_db',
        user: process.env.DB_USER || 'test_user',
        password: process.env.DB_PASSWORD || 'test_password',
    });
}
/**
 * Clean all tables in the test database
 */
async function cleanDatabase(db) {
    const tables = [
        'inventory',
        'locations',
        'products',
        'users',
        'roles',
        'orders',
        'order_items',
        'audit_log',
    ];
    for (const table of tables) {
        try {
            await db.query(`DELETE FROM ${table} WHERE id LIKE '%-test-id' OR id LIKE '%-id'`);
        }
        catch (error) {
            // Table might not exist, ignore
        }
    }
}
/**
 * Run a database transaction that auto-rolls back
 */
async function withTransaction(db, callback) {
    await db.query('BEGIN');
    try {
        const result = await callback(db);
        await db.query('ROLLBACK');
        return result;
    }
    catch (error) {
        await db.query('ROLLBACK');
        throw error;
    }
}
async function createTestUser(db, overrides = {}) {
    const userId = overrides.id || `${(0, crypto_1.randomUUID)()}-test-id`;
    const email = overrides.email || `test-${userId}@example.com`;
    const password = overrides.password || 'TestPassword123!';
    const name = overrides.name || 'Test User';
    const roleId = overrides.role_id || 'admin-role-id';
    const hashedPassword = await bcrypt_1.default.hash(password, 10);
    await db.query(`INSERT INTO users (id, email, password_hash, name, role_id, is_active)
     VALUES ($1, $2, $3, $4, $5, true)
     ON CONFLICT (id) DO UPDATE SET email = EXCLUDED.email, password_hash = EXCLUDED.password_hash`, [userId, email, hashedPassword, name, roleId]);
    return {
        id: userId,
        email,
        password,
        name,
        role_id: roleId,
    };
}
function generateTestToken(userId, email, roleId, overrides = {}) {
    // @ts-expect-error - jwt.sign overload resolution issue with Secret type
    return jsonwebtoken_1.default.sign({
        userId,
        email,
        roleId,
    }, index_js_1.default.jwt.secret, {
        expiresIn: overrides.expiresIn || 3600,
    });
}
/**
 * Get auth headers for a test user
 */
async function getTestAuthHeaders(db, user) {
    const testUser = user || (await createTestUser(db));
    const token = generateTestToken(testUser.id, testUser.email, testUser.role_id);
    return { Authorization: `Bearer ${token}` };
}
async function createTestOrder(db, overrides = {}) {
    const orderId = overrides.id || `${(0, crypto_1.randomUUID)()}-test-id`;
    const customerId = overrides.customer_id || `${(0, crypto_1.randomUUID)()}-test-id`;
    const customerName = overrides.customer_name || 'Test Customer';
    const status = overrides.status || 'pending';
    const priority = overrides.priority || 'normal';
    await db.query(`INSERT INTO orders (id, customer_id, customer_name, status, priority, created_at, updated_at)
     VALUES ($1, $2, $3, $4, $5, NOW(), NOW())
     ON CONFLICT (id) DO UPDATE SET status = EXCLUDED.status`, [orderId, customerId, customerName, status, priority]);
    return {
        id: orderId,
        customer_id: customerId,
        customer_name: customerName,
        status,
        priority,
    };
}
async function createTestProduct(db, overrides = {}) {
    const productId = overrides.id || `${(0, crypto_1.randomUUID)()}-test-id`;
    const sku = overrides.sku || `SKU-${Math.random().toString(36).substring(7).toUpperCase()}`;
    const name = overrides.name || 'Test Product';
    const description = overrides.description || 'Test Description';
    const unitOfMeasure = overrides.unit_of_measure || 'EA';
    const weightLbs = overrides.weight_lbs || 1.0;
    await db.query(`INSERT INTO products (id, sku, name, description, unit_of_measure, weight_lbs)
     VALUES ($1, $2, $3, $4, $5, $6)
     ON CONFLICT (id) DO UPDATE SET sku = EXCLUDED.sku`, [productId, sku, name, description, unitOfMeasure, weightLbs]);
    return {
        id: productId,
        sku,
        name,
        description,
        unit_of_measure: unitOfMeasure,
        weight_lbs: weightLbs,
    };
}
async function createTestLocation(db, overrides = {}) {
    const locationId = overrides.id || `loc-${Math.random().toString(36).substring(7)}`;
    const zone = overrides.zone || 'A';
    const aisle = overrides.aisle || '01';
    const shelf = overrides.shelf || '01';
    const bin = overrides.bin || '01';
    const locationType = overrides.location_type || 'storage';
    await db.query(`INSERT INTO locations (id, zone, aisle, shelf, bin, location_type)
     VALUES ($1, $2, $3, $4, $5, $6)
     ON CONFLICT (id) DO NOTHING`, [locationId, zone, aisle, shelf, bin, locationType]);
    return {
        id: locationId,
        zone,
        aisle,
        shelf,
        bin,
        location_type: locationType,
    };
}
/**
 * Create test inventory
 */
async function createTestInventory(db, productId, locationId, quantity = 100) {
    const inventoryId = `${(0, crypto_1.randomUUID)()}-test-id`;
    await db.query(`INSERT INTO inventory (id, product_id, location_id, quantity_available, quantity_allocated)
     VALUES ($1, $2, $3, $4, 0)
     ON CONFLICT (id) DO UPDATE SET quantity_available = EXCLUDED.quantity_available`, [inventoryId, productId, locationId, quantity]);
}
async function makeTestRequest(request) {
    const baseUrl = process.env.TEST_API_URL || 'http://localhost:3001';
    const headers = {
        'Content-Type': 'application/json',
        ...request.headers,
    };
    const options = {
        method: request.method,
        headers,
    };
    if (request.body) {
        options.body = JSON.stringify(request.body);
    }
    const response = await fetch(`${baseUrl}${request.path}`, options);
    const data = await response.json().catch(() => null);
    return {
        status: response.status,
        data,
        headers: response.headers,
    };
}
// ============================================================================
// Assertion Helpers
// ============================================================================
/**
 * Assert that an API response has the expected status
 */
function expectStatus(response, expectedStatus) {
    expect(response.status).toBe(expectedStatus);
}
/**
 * Assert that an API response has a specific error
 */
function expectApiError(response, expectedError) {
    expect(response.status).toBeGreaterThanOrEqual(400);
    if (expectedError.code) {
        expect(response.data.code).toBe(expectedError.code);
    }
    if (expectedError.message) {
        expect(response.data.message).toContain(expectedError.message);
    }
}
// ============================================================================
// Mock Helpers
// ============================================================================
/**
 * Create a mock response object
 */
function createMockResponse() {
    const res = {
        status: jest.fn().mockReturnThis(),
        json: jest.fn().mockReturnThis(),
        send: jest.fn().mockReturnThis(),
        setHeader: jest.fn().mockReturnThis(),
        getHeader: jest.fn(),
    };
    return res;
}
/**
 * Create a mock request object
 */
function createMockRequest(overrides = {}) {
    return {
        headers: {},
        query: {},
        params: {},
        body: {},
        user: null,
        ...overrides,
    };
}
// ============================================================================
// Async Helpers
// ============================================================================
/**
 * Wait for a specified amount of time
 */
function wait(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}
/**
 * Retry a function until it succeeds or times out
 */
async function retry(fn, options = {}) {
    const { maxAttempts = 5, delay = 100, timeout = 5000 } = options;
    const startTime = Date.now();
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
        try {
            return await fn();
        }
        catch (error) {
            if (attempt === maxAttempts || Date.now() - startTime > timeout) {
                throw error;
            }
            await wait(delay * attempt);
        }
    }
    throw new Error('Retry failed');
}
//# sourceMappingURL=helpers.js.map