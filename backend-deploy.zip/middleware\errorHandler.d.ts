/**
 * Global error handling middleware
 *
 * Catches all errors and formats them appropriately for the client
 */
import { Request, Response, NextFunction } from 'express';
interface AppError extends Error {
    statusCode?: number;
    code?: string;
    details?: unknown;
    stack?: string;
}
export declare function errorHandler(err: AppError, req: Request, res: Response, _next: NextFunction): void;
export declare function notFoundHandler(req: Request, res: Response): void;
/**
 * Wraps async route handlers to catch errors and pass them to error middleware
 */
export declare function asyncHandler<T extends Request = Request>(fn: (req: T, res: Response, next: NextFunction) => Promise<void> | void): (req: T, res: Response, next: NextFunction) => void;
export declare class ValidationError extends Error {
    details?: unknown | undefined;
    constructor(message: string, details?: unknown | undefined);
    statusCode?: number;
    code?: string;
}
export declare function badRequest(message: string, details?: unknown): AppError;
export declare function unauthorized(message?: string): AppError;
export declare function forbidden(message?: string): AppError;
export declare function notFound(resource: string, id?: string): AppError;
export declare function conflict(message: string, details?: unknown): AppError;
export declare function internalError(message?: string): AppError;
export {};
//# sourceMappingURL=errorHandler.d.ts.map