"use strict";
/**
 * Migration: Add bin_locations column to skus table
 *
 * This migration adds a bin_locations array column to the skus table
 * to store the list of bin locations where each SKU is stored.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.addBinLocationsToSkus = addBinLocationsToSkus;
const client_1 = require("./client");
async function addBinLocationsToSkus() {
    const pool = (0, client_1.getPool)();
    console.log('Adding bin_locations column to skus table...');
    try {
        // Check if column already exists
        const checkResult = await pool.query(`
      SELECT column_name 
      FROM information_schema.columns 
      WHERE table_name = 'skus' AND column_name = 'bin_locations'
    `);
        if (checkResult.rows.length > 0) {
            console.log('bin_locations column already exists in skus table');
            return;
        }
        // Add the bin_locations column as an array of VARCHAR
        await pool.query(`
      ALTER TABLE skus 
      ADD COLUMN bin_locations VARCHAR(20)[] DEFAULT '{}'
    `);
        console.log('Successfully added bin_locations column to skus table');
        // Populate bin_locations from inventory_units table
        console.log('Populating bin_locations from inventory_units...');
        await pool.query(`
      UPDATE skus s
      SET bin_locations = subq.locations
      FROM (
        SELECT sku, array_agg(DISTINCT bin_location) as locations
        FROM inventory_units
        WHERE quantity > 0
        GROUP BY sku
      ) subq
      WHERE s.sku = subq.sku
    `);
        console.log('Successfully populated bin_locations from inventory_units');
        // Create an index for the array column (GIN index for array operations)
        await pool.query(`
      CREATE INDEX IF NOT EXISTS idx_skus_bin_locations ON skus USING GIN(bin_locations)
    `);
        console.log('Migration completed successfully!');
    }
    catch (error) {
        console.error('Migration failed:', error);
        throw error;
    }
}
// Run migration if called directly
if (require.main === module) {
    addBinLocationsToSkus()
        .then(() => {
        console.log('Migration completed');
        process.exit(0);
    })
        .catch((error) => {
        console.error('Migration failed:', error);
        process.exit(1);
    });
}
//# sourceMappingURL=add-bin-locations-to-skus.js.map