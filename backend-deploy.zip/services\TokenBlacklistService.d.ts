/**
 * Token Blacklist Service
 *
 * Manages a blacklist of revoked JWT tokens for secure logout.
 * Uses in-memory storage with automatic cleanup of expired entries.
 *
 * @performance
 * - O(1) lookup time
 * - Automatic cleanup every 5 minutes
 * - Memory efficient with TTL-based expiration
 *
 * @security
 * - Prevents reuse of tokens after logout
 * - Tokens are blacklisted until their natural expiration
 */
declare class TokenBlacklistService {
    private blacklist;
    private cleanupInterval;
    private cleanupIntervalMs;
    /**
     * Initialize the blacklist service and start cleanup interval
     */
    initialize(): void;
    /**
     * Add a token to the blacklist
     * @param tokenId - Unique identifier for the token (e.g., "userId:iat")
     * @param expiresAt - Token expiration timestamp in milliseconds
     */
    blacklistToken(tokenId: string, expiresAt: number): void;
    /**
     * Check if a token is blacklisted
     * @param tokenId - Unique identifier for the token
     * @returns true if token is blacklisted and not expired
     */
    isBlacklisted(tokenId: string): boolean;
    /**
     * Remove expired entries from the blacklist
     */
    private cleanup;
    /**
     * Get the current size of the blacklist
     */
    get size(): number;
    /**
     * Shutdown the service
     */
    shutdown(): void;
}
export declare const tokenBlacklistService: TokenBlacklistService;
export {};
//# sourceMappingURL=TokenBlacklistService.d.ts.map