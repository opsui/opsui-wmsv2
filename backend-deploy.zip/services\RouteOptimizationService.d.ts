/**
 * Route Optimization Service
 *
 * Implements algorithms for optimizing warehouse picking routes:
 * - Traveling Salesman Problem (TSP) solver for optimal route
 * - Nearest Neighbor heuristic (fast approximation)
 * - Zone-based optimization
 * - Aisle-by-aisle traversal (S-shape)
 *
 * References:
 * - TSP for Warehouse Order Picking Optimization
 * - Meta-Heuristic Algorithms for Order Picking
 *
 * @see https://www.researchgate.net/publication/374910922_TSP_for_Warehouse_Order_Picking_Optimization_and_Simulation
 */
export interface BinLocation {
    location: string;
    zone: string;
    aisle: number;
    shelf: number;
    side?: 'L' | 'R';
}
export interface PickTask {
    taskId: string;
    orderId: string;
    sku: string;
    quantity: number;
    binLocation: string;
    priority: 'LOW' | 'NORMAL' | 'HIGH' | 'URGENT';
    weight?: number;
}
export interface OptimizedRoute {
    tasks: OptimizedPickTask[];
    totalDistance: number;
    estimatedTime: number;
    waypoints: Waypoint[];
    algorithm: string;
}
export interface OptimizedPickTask extends PickTask {
    sequence: number;
    fromLocation: string;
    toLocation: string;
    distance: number;
    estimatedTime: number;
}
export interface Waypoint {
    location: string;
    type: 'start' | 'pickup' | 'end';
    sequence: number;
    coordinates: {
        x: number;
        y: number;
        z?: number;
    };
}
export interface WarehouseConfig {
    aisleWidth: number;
    shelfDepth: number;
    shelfHeight: number;
    walkingSpeed: number;
    pickTime: number;
    zoneLayout: {
        [zone: string]: {
            startAisle: number;
            endAisle: number;
            x: number;
            y: number;
        };
    };
}
declare class RouteOptimizationService {
    private config;
    constructor(config?: Partial<WarehouseConfig>);
    /**
     * Optimize picking route using best available algorithm
     */
    optimizeRoute(tasks: PickTask[], startLocation?: string, options?: {
        algorithm?: 'tsp' | 'nearest' | 'aisle' | 'zone';
        maxTime?: number;
    }): OptimizedRoute;
    /**
     * Solve TSP using 2-opt local search (optimal for small n, good approximation for large n)
     */
    private solveTSP;
    /**
     * Nearest Neighbor heuristic (fast, good approximation)
     */
    private solveNearestNeighbor;
    /**
     * Aisle-by-aisle traversal (S-shape strategy)
     * Good for high-density picking in multiple aisles
     */
    private solveAisleByAisle;
    /**
     * Zone-based optimization
     * Groups picks by zone and optimizes within each zone
     */
    private solveZoneBased;
    /**
     * Select the best algorithm based on task count and characteristics
     */
    private selectAlgorithm;
    /**
     * Build distance matrix for all locations
     */
    private buildDistanceMatrix;
    /**
     * Calculate Manhattan distance between two warehouse locations
     */
    private calculateDistance;
    /**
     * Calculate travel time for a given distance
     */
    private calculateTravelTime;
    /**
     * Parse bin location string into components
     */
    private parseLocation;
    /**
     * Nearest neighbor TSP algorithm
     */
    private nearestNeighborTSP;
    /**
     * 2-opt swap for TSP improvement
     */
    private twoOptSwap;
    /**
     * Calculate total route distance
     */
    private calculateRouteDistance;
    /**
     * Build optimized route object from TSP solution
     */
    private buildOptimizedRoute;
    /**
     * Build waypoints array for navigation
     */
    private buildWaypoints;
    /**
     * Convert location string to coordinates (for display/mapping)
     */
    private locationToCoordinates;
    /**
     * Optimize order of zones to visit
     */
    private optimizeZoneOrder;
    /**
     * Get default zone layout
     */
    private getDefaultZoneLayout;
    /**
     * Update warehouse configuration
     */
    updateConfig(config: Partial<WarehouseConfig>): void;
    /**
     * Get current configuration
     */
    getConfig(): WarehouseConfig;
}
export declare const routeOptimizationService: RouteOptimizationService;
export default routeOptimizationService;
//# sourceMappingURL=RouteOptimizationService.d.ts.map