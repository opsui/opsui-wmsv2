/**
 * Purchasing API Routes
 *
 * REST API for purchasing operations
 * Handles purchase requisitions, RFQs, purchase orders, receipts,
 * three-way matching, vendor catalogs, and vendor performance
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=purchasing.d.ts.map