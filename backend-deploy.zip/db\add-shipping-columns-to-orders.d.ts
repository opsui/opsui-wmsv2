/**
 * Add shipping_carrier and shipping_method to orders table
 * This is needed for wave picking functionality
 */
export {};
//# sourceMappingURL=add-shipping-columns-to-orders.d.ts.map