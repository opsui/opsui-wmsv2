/**
 * NZC (NZ Couriers) routes
 *
 * Endpoints for NZC-specific operations including rates, shipments, and labels
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=nzc.d.ts.map