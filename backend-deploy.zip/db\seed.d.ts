/**
 * Database seed data
 *
 * Populates the database with sample data for development and testing.
 */
/**
 * Run all seed operations
 */
export declare function runSeed(): Promise<void>;
/**
 * Main function for running seed from command line
 */
declare function main(): Promise<void>;
export { main as seedCli };
//# sourceMappingURL=seed.d.ts.map