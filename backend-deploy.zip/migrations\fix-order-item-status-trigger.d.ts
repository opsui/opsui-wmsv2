/**
 * Migration: Fix order_items status trigger with explicit enum casting
 * Run this with: npm run migration:fix-trigger
 */
export declare function up(): Promise<void>;
export declare function down(): Promise<void>;
//# sourceMappingURL=fix-order-item-status-trigger.d.ts.map