"use strict";
/**
 * Inbound Receiving routes
 *
 * Endpoints for managing Advance Shipping Notices (ASN), receipts, and putaway tasks
 */
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const InboundReceivingService_1 = require("../services/InboundReceivingService");
const middleware_1 = require("../middleware");
const shared_1 = require("@opsui/shared");
const router = (0, express_1.Router)();
// All inbound routes require authentication
router.use(middleware_1.authenticate);
// ============================================================================
// DASHBOARD ROUTES
// ============================================================================
/**
 * GET /api/inbound/dashboard
 * Get inwards goods dashboard metrics
 */
router.get('/dashboard', (0, middleware_1.authorize)('INWARDS', shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (_req, res) => {
    const dashboard = await InboundReceivingService_1.inboundReceivingService.getDashboardMetrics();
    res.json(dashboard);
}));
// ============================================================================
// ASN ROUTES
// ============================================================================
/**
 * POST /api/inbound/asn
 * Create a new Advance Shipping Notice
 */
router.post('/asn', (0, middleware_1.authorize)('INWARDS', shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { supplierId, purchaseOrderNumber, expectedArrivalDate, carrier, trackingNumber, shipmentNotes, lineItems, } = req.body;
    // Validate required fields
    if (!supplierId ||
        !purchaseOrderNumber ||
        !expectedArrivalDate ||
        !lineItems ||
        lineItems.length === 0) {
        res.status(400).json({
            error: 'Missing required fields',
            code: 'MISSING_FIELDS',
        });
        return;
    }
    const asn = await InboundReceivingService_1.inboundReceivingService.createASN({
        supplierId,
        purchaseOrderNumber,
        expectedArrivalDate: new Date(expectedArrivalDate),
        carrier,
        trackingNumber,
        shipmentNotes,
        createdBy: req.user.userId,
        lineItems,
    });
    res.status(201).json(asn);
    return;
}));
/**
 * GET /api/inbound/asn
 * Get all ASNs with optional filters
 */
router.get('/asn', (0, middleware_1.authorize)('INWARDS', shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (req, res) => {
    const filters = {
        status: req.query.status,
        supplierId: req.query.supplierId,
        limit: req.query.limit ? parseInt(req.query.limit) : 50,
        offset: req.query.offset ? parseInt(req.query.offset) : 0,
    };
    const result = await InboundReceivingService_1.inboundReceivingService.getAllASNs(filters);
    res.json(result);
    return;
}));
/**
 * GET /api/inbound/asn/:asnId
 * Get a specific ASN by ID
 */
router.get('/asn/:asnId', (0, middleware_1.authorize)('INWARDS', shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { asnId } = req.params;
    const asn = await InboundReceivingService_1.inboundReceivingService.getASN(asnId);
    res.json(asn);
    return;
}));
/**
 * PATCH /api/inbound/asn/:asnId/status
 * Update ASN status
 */
router.patch('/asn/:asnId/status', (0, middleware_1.authorize)('INWARDS', shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { asnId } = req.params;
    const { status } = req.body;
    if (!status) {
        res.status(400).json({
            error: 'Status is required',
            code: 'MISSING_STATUS',
        });
        return;
    }
    const asn = await InboundReceivingService_1.inboundReceivingService.updateASNStatus(asnId, status);
    res.json(asn);
    return;
}));
// ============================================================================
// RECEIPT ROUTES
// ============================================================================
/**
 * POST /api/inbound/receipts
 * Create a new receipt
 */
router.post('/receipts', (0, middleware_1.authorize)('INWARDS', shared_1.UserRole.STOCK_CONTROLLER, shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { asnId, receiptType, lineItems } = req.body;
    // Validate required fields
    if (!receiptType || !lineItems || lineItems.length === 0) {
        res.status(400).json({
            error: 'Missing required fields',
            code: 'MISSING_FIELDS',
        });
        return;
    }
    const receipt = await InboundReceivingService_1.inboundReceivingService.createReceipt({
        asnId,
        receiptType,
        receivedBy: req.user.userId,
        lineItems,
    });
    res.status(201).json(receipt);
    return;
}));
/**
 * GET /api/inbound/receipts
 * Get all receipts with optional filters
 */
router.get('/receipts', (0, middleware_1.authorize)('INWARDS', shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN, shared_1.UserRole.STOCK_CONTROLLER), (0, middleware_1.asyncHandler)(async (req, res) => {
    const filters = {
        status: req.query.status,
        asnId: req.query.asnId,
        limit: req.query.limit ? parseInt(req.query.limit) : 50,
        offset: req.query.offset ? parseInt(req.query.offset) : 0,
    };
    const result = await InboundReceivingService_1.inboundReceivingService.getAllReceipts(filters);
    res.json(result);
    return;
}));
/**
 * GET /api/inbound/receipts/:receiptId
 * Get a specific receipt by ID
 */
router.get('/receipts/:receiptId', (0, middleware_1.authorize)('INWARDS', shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN, shared_1.UserRole.STOCK_CONTROLLER), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { receiptId } = req.params;
    const receipt = await InboundReceivingService_1.inboundReceivingService.getReceipt(receiptId);
    res.json(receipt);
    return;
}));
// ============================================================================
// PUTAWAY ROUTES
// ============================================================================
/**
 * GET /api/inbound/putaway
 * Get putaway tasks with optional filters
 */
router.get('/putaway', (0, middleware_1.authorize)('INWARDS', shared_1.UserRole.STOCK_CONTROLLER, shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (req, res) => {
    const filters = {
        status: req.query.status,
        assignedTo: req.query.assignedTo,
        limit: req.query.limit ? parseInt(req.query.limit) : 50,
        offset: req.query.offset ? parseInt(req.query.offset) : 0,
    };
    const result = await InboundReceivingService_1.inboundReceivingService.getPutawayTasks(filters);
    res.json(result);
    return;
}));
/**
 * POST /api/inbound/putaway/:putawayTaskId/assign
 * Assign putaway task to user
 */
router.post('/putaway/:putawayTaskId/assign', (0, middleware_1.authorize)('INWARDS', shared_1.UserRole.STOCK_CONTROLLER, shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { putawayTaskId } = req.params;
    const task = await InboundReceivingService_1.inboundReceivingService.assignPutawayTask(putawayTaskId, req.user.userId);
    res.json(task);
    return;
}));
/**
 * PATCH /api/inbound/putaway/:putawayTaskId
 * Update putaway task (complete or partial putaway)
 */
router.patch('/putaway/:putawayTaskId', (0, middleware_1.authorize)('INWARDS', shared_1.UserRole.STOCK_CONTROLLER, shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { putawayTaskId } = req.params;
    const { quantityPutaway, status } = req.body;
    if (quantityPutaway === undefined || quantityPutaway <= 0) {
        res.status(400).json({
            error: 'Valid quantityPutaway is required',
            code: 'INVALID_QUANTITY',
        });
        return;
    }
    const task = await InboundReceivingService_1.inboundReceivingService.updatePutawayTask({
        putawayTaskId,
        quantityPutaway: parseInt(quantityPutaway),
        userId: req.user.userId,
        status,
    });
    res.json(task);
    return;
}));
// ============================================================================
// LICENSE PLATE ROUTES
// ============================================================================
/**
 * GET /api/inbound/license-plates
 * Get all license plates with optional filters
 */
router.get('/license-plates', (0, middleware_1.authorize)('INWARDS', shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN, shared_1.UserRole.STOCK_CONTROLLER), (0, middleware_1.asyncHandler)(async (req, res) => {
    const filters = {
        status: req.query.status,
        limit: req.query.limit ? parseInt(req.query.limit) : 50,
        offset: req.query.offset ? parseInt(req.query.offset) : 0,
    };
    const result = await InboundReceivingService_1.inboundReceivingService.getLicensePlates(filters);
    res.json(result);
    return;
}));
/**
 * GET /api/inbound/license-plates/:licensePlateId
 * Get a specific license plate by ID
 */
router.get('/license-plates/:licensePlateId', (0, middleware_1.authorize)('INWARDS', shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN, shared_1.UserRole.STOCK_CONTROLLER), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { licensePlateId } = req.params;
    const licensePlate = await InboundReceivingService_1.inboundReceivingService.getLicensePlate(licensePlateId);
    res.json(licensePlate);
    return;
}));
/**
 * GET /api/inbound/license-plates/barcode/:barcode
 * Get a license plate by barcode
 */
router.get('/license-plates/barcode/:barcode', (0, middleware_1.authorize)('INWARDS', shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN, shared_1.UserRole.STOCK_CONTROLLER), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { barcode } = req.params;
    const licensePlate = await InboundReceivingService_1.inboundReceivingService.getLicensePlateByBarcode(barcode);
    res.json(licensePlate);
    return;
}));
/**
 * POST /api/inbound/license-plates
 * Create a new license plate
 */
router.post('/license-plates', (0, middleware_1.authorize)('INWARDS', shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (req, res) => {
    const licensePlate = await InboundReceivingService_1.inboundReceivingService.createLicensePlate({
        ...req.body,
        createdBy: req.user.userId,
    });
    res.status(201).json(licensePlate);
    return;
}));
/**
 * POST /api/inbound/license-plates/:licensePlateId/seal
 * Seal a license plate
 */
router.post('/license-plates/:licensePlateId/seal', (0, middleware_1.authorize)('INWARDS', shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { licensePlateId } = req.params;
    const licensePlate = await InboundReceivingService_1.inboundReceivingService.sealLicensePlate(licensePlateId);
    res.json(licensePlate);
    return;
}));
/**
 * PATCH /api/inbound/license-plates/:licensePlateId/status
 * Update license plate status
 */
router.patch('/license-plates/:licensePlateId/status', (0, middleware_1.authorize)('INWARDS', shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { licensePlateId } = req.params;
    const { status } = req.body;
    if (!status) {
        res.status(400).json({
            error: 'Status is required',
            code: 'MISSING_STATUS',
        });
        return;
    }
    const licensePlate = await InboundReceivingService_1.inboundReceivingService.updateLicensePlateStatus(licensePlateId, status);
    res.json(licensePlate);
    return;
}));
/**
 * GET /api/inbound/license-plates/suggest-staging/:sku
 * Get suggested staging location for SKU
 */
router.get('/license-plates/suggest-staging/:sku', (0, middleware_1.authorize)('INWARDS', shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN, shared_1.UserRole.STOCK_CONTROLLER), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { sku } = req.params;
    const suggestions = await InboundReceivingService_1.inboundReceivingService.getSuggestedStaging(sku);
    res.json(suggestions);
    return;
}));
// ============================================================================
// STAGING LOCATION ROUTES
// ============================================================================
/**
 * GET /api/inbound/staging-locations
 * Get all staging locations with optional filters
 */
router.get('/staging-locations', (0, middleware_1.authorize)('INWARDS', shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN, shared_1.UserRole.STOCK_CONTROLLER), (0, middleware_1.asyncHandler)(async (req, res) => {
    const filters = {
        zone: req.query.zone,
        status: req.query.status,
        limit: req.query.limit ? parseInt(req.query.limit) : 50,
        offset: req.query.offset ? parseInt(req.query.offset) : 0,
    };
    const result = await InboundReceivingService_1.inboundReceivingService.getStagingLocations(filters);
    res.json(result);
    return;
}));
/**
 * GET /api/inbound/staging-locations/:stagingLocationId
 * Get a specific staging location by ID
 */
router.get('/staging-locations/:stagingLocationId', (0, middleware_1.authorize)('INWARDS', shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN, shared_1.UserRole.STOCK_CONTROLLER), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { stagingLocationId } = req.params;
    const stagingLocation = await InboundReceivingService_1.inboundReceivingService.getStagingLocation(stagingLocationId);
    res.json(stagingLocation);
    return;
}));
/**
 * POST /api/inbound/staging-locations/assign
 * Assign a license plate to a staging location
 */
router.post('/staging-locations/assign', (0, middleware_1.authorize)('INWARDS', shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { licensePlateId, stagingLocationId } = req.body;
    if (!licensePlateId || !stagingLocationId) {
        res.status(400).json({
            error: 'licensePlateId and stagingLocationId are required',
            code: 'MISSING_FIELDS',
        });
        return;
    }
    const result = await InboundReceivingService_1.inboundReceivingService.assignToStagingLocation({
        licensePlateId,
        stagingLocationId,
        userId: req.user.userId,
    });
    res.json(result);
    return;
}));
/**
 * POST /api/inbound/staging-locations/release/:licensePlateId
 * Release a license plate from staging
 */
router.post('/staging-locations/release/:licensePlateId', (0, middleware_1.authorize)('INWARDS', shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { licensePlateId } = req.params;
    const result = await InboundReceivingService_1.inboundReceivingService.releaseFromStaging(licensePlateId);
    res.json(result);
    return;
}));
/**
 * GET /api/inbound/staging-locations/:stagingLocationId/contents
 * Get contents of a staging location
 */
router.get('/staging-locations/:stagingLocationId/contents', (0, middleware_1.authorize)('INWARDS', shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN, shared_1.UserRole.STOCK_CONTROLLER), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { stagingLocationId } = req.params;
    const contents = await InboundReceivingService_1.inboundReceivingService.getStagingLocationContents(stagingLocationId);
    res.json(contents);
    return;
}));
// ============================================================================
// RECEIVING EXCEPTION ROUTES
// ============================================================================
/**
 * GET /api/inbound/exceptions
 * Get all receiving exceptions with optional filters
 */
router.get('/exceptions', (0, middleware_1.authorize)('INWARDS', shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN, shared_1.UserRole.STOCK_CONTROLLER), (0, middleware_1.asyncHandler)(async (req, res) => {
    const filters = {
        status: req.query.status,
        exceptionType: req.query.exceptionType,
        limit: req.query.limit ? parseInt(req.query.limit) : 50,
        offset: req.query.offset ? parseInt(req.query.offset) : 0,
    };
    const result = await InboundReceivingService_1.inboundReceivingService.getReceivingExceptions(filters);
    res.json(result);
    return;
}));
/**
 * GET /api/inbound/exceptions/:exceptionId
 * Get a specific receiving exception by ID
 */
router.get('/exceptions/:exceptionId', (0, middleware_1.authorize)('INWARDS', shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN, shared_1.UserRole.STOCK_CONTROLLER), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { exceptionId } = req.params;
    const exception = await InboundReceivingService_1.inboundReceivingService.getReceivingException(exceptionId);
    res.json(exception);
    return;
}));
/**
 * POST /api/inbound/exceptions
 * Create a new receiving exception
 */
router.post('/exceptions', (0, middleware_1.authorize)('INWARDS', shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (req, res) => {
    const exception = await InboundReceivingService_1.inboundReceivingService.createReceivingException({
        ...req.body,
        createdBy: req.user.userId,
    });
    res.status(201).json(exception);
    return;
}));
/**
 * PATCH /api/inbound/exceptions/:exceptionId/status
 * Update exception status
 */
router.patch('/exceptions/:exceptionId/status', (0, middleware_1.authorize)('INWARDS', shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { exceptionId } = req.params;
    const { status } = req.body;
    if (!status) {
        res.status(400).json({
            error: 'Status is required',
            code: 'MISSING_STATUS',
        });
        return;
    }
    const exception = await InboundReceivingService_1.inboundReceivingService.updateReceivingExceptionStatus(exceptionId, status);
    res.json(exception);
    return;
}));
/**
 * POST /api/inbound/exceptions/:exceptionId/resolve
 * Resolve a receiving exception
 */
router.post('/exceptions/:exceptionId/resolve', (0, middleware_1.authorize)('INWARDS', shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { exceptionId } = req.params;
    const { resolution, resolutionNotes } = req.body;
    if (!resolution) {
        res.status(400).json({
            error: 'Resolution is required',
            code: 'MISSING_RESOLUTION',
        });
        return;
    }
    const exception = await InboundReceivingService_1.inboundReceivingService.resolveReceivingException({
        exceptionId,
        resolution,
        resolutionNotes,
        resolvedBy: req.user.userId,
    });
    res.json(exception);
    return;
}));
exports.default = router;
//# sourceMappingURL=inbound.js.map