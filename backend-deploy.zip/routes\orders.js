"use strict";
/**
 * Order routes
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const services_1 = require("../services");
const middleware_1 = require("../middleware");
const validation_1 = require("../middleware/validation");
const shared_1 = require("@opsui/shared");
const client_1 = require("../db/client");
const router = (0, express_1.Router)();
// All order routes require authentication
router.use(middleware_1.authenticate);
/**
 * POST /api/orders
 * Create a new order
 */
router.post('/', (0, middleware_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR), validation_1.validate.createOrder, (0, middleware_1.asyncHandler)(async (req, res) => {
    const order = await services_1.orderService.createOrder(req.body);
    res.status(201).json(order);
}));
/**
 * GET /api/orders
 * Get order queue with optional filters
 */
router.get('/', (0, middleware_1.asyncHandler)(async (req, res) => {
    const filters = {
        status: req.query.status,
        priority: req.query.priority,
        pickerId: req.query.pickerId,
        page: req.query.page ? parseInt(req.query.page) : undefined,
        limit: req.query.limit ? parseInt(req.query.limit) : undefined,
    };
    const result = await services_1.orderService.getOrderQueue(filters);
    // Add pagination metadata to response headers
    if (typeof result.total !== 'undefined') {
        res.setHeader('X-Total-Count', result.total.toString());
    }
    if (filters.page) {
        res.setHeader('X-Page', filters.page.toString());
    }
    if (filters.limit) {
        res.setHeader('X-Page-Size', filters.limit.toString());
    }
    res.json(result);
}));
/**
 * GET /api/orders/my-orders
 * Get current picker's active orders
 */
router.get('/my-orders', (0, middleware_1.authorize)(shared_1.UserRole.PICKER, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (req, res) => {
    if (!req.user) {
        res.status(401).json({ error: 'Not authenticated' });
        return;
    }
    const orders = await services_1.orderService.getPickerActiveOrders(req.user.userId);
    res.json(orders);
}));
/**
 * GET /api/orders/full
 * Get orders with full item details by status
 */
router.get('/full', (0, middleware_1.asyncHandler)(async (req, res) => {
    const filters = {
        status: req.query.status,
        packerId: req.query.packerId,
    };
    const result = await services_1.orderService.getOrdersWithItemsByStatus(filters);
    res.json(result);
}));
/**
 * GET /api/orders/:orderId
 * Get order details
 */
router.get('/:orderId', validation_1.validate.orderId, (0, middleware_1.asyncHandler)(async (req, res) => {
    const order = await services_1.orderService.getOrder(req.params.orderId);
    res.json(order);
}));
/**
 * POST /api/orders/:orderId/claim
 * Claim an order for picking
 */
router.post('/:orderId/claim', (0, middleware_1.authorize)(shared_1.UserRole.PICKER, shared_1.UserRole.ADMIN), validation_1.validate.orderId, (0, middleware_1.asyncHandler)(async (req, res) => {
    if (!req.user) {
        res.status(401).json({ error: 'Not authenticated' });
        return;
    }
    try {
        const order = await services_1.orderService.claimOrder(req.params.orderId, {
            pickerId: req.user.userId,
        });
        res.json(order);
    }
    catch (error) {
        // Ensure proper error propagation to frontend
        if (error?.message?.includes('cannot be claimed')) {
            res.status(409).json({
                error: error.message,
                code: 'ORDER_NOT_CLAIMABLE',
            });
            return;
        }
        if (error?.message?.includes('already claimed')) {
            res.status(409).json({
                error: error.message,
                code: 'ORDER_ALREADY_CLAIMED',
            });
            return;
        }
        if (error?.message?.includes('maximum limit')) {
            res.status(409).json({
                error: error.message,
                code: 'MAX_ACTIVE_ORDERS',
            });
            return;
        }
        // Generic conflict error
        if (error?.status === 409 || error?.code === 'CONFLICT') {
            res.status(409).json({
                error: error.message || 'Order cannot be claimed',
                code: 'CONFLICT',
            });
            return;
        }
        // Re-throw other errors
        throw error;
    }
}));
/**
 * POST /api/orders/:orderId/continue
 * Continue picking an already claimed order
 * This endpoint exists primarily to create an audit log when a picker continues working on their order
 */
router.post('/:orderId/continue', (0, middleware_1.authorize)(shared_1.UserRole.PICKER, shared_1.UserRole.ADMIN), validation_1.validate.orderId, (0, middleware_1.asyncHandler)(async (req, res) => {
    if (!req.user) {
        res.status(401).json({ error: 'Not authenticated' });
        return;
    }
    const result = await services_1.orderService.continueOrder(req.params.orderId, req.user.userId);
    res.json(result);
}));
/**
 * GET /api/orders/:orderId/next-task
 * Get next pick task for an order
 */
router.get('/:orderId/next-task', (0, middleware_1.authorize)(shared_1.UserRole.PICKER, shared_1.UserRole.ADMIN), validation_1.validate.orderId, (0, middleware_1.asyncHandler)(async (req, res) => {
    const task = await services_1.orderService.getNextPickTask(req.params.orderId);
    res.json(task);
}));
/**
 * PUT /api/orders/:orderId/picker-status
 * Update picker status (ACTIVE/IDLE) based on window visibility
 */
router.put('/:orderId/picker-status', (0, middleware_1.authorize)(shared_1.UserRole.PICKER, shared_1.UserRole.ADMIN), validation_1.validate.orderId, (0, middleware_1.asyncHandler)(async (req, res) => {
    const { query } = await Promise.resolve().then(() => __importStar(require('../db/client')));
    const { status } = req.body;
    if (!req.user) {
        res.status(401).json({ error: 'Not authenticated' });
        return;
    }
    if (!status || !['ACTIVE', 'IDLE'].includes(status)) {
        res.status(400).json({
            error: 'Invalid status. Must be ACTIVE or IDLE',
            code: 'INVALID_STATUS',
        });
        return;
    }
    // Update BOTH the order's timestamp AND the user's current_view_updated_at
    // This is critical for picker activity tracking to work correctly
    await query(`UPDATE orders 
       SET updated_at = NOW() 
       WHERE order_id = $1`, [req.params.orderId]);
    // Also update user's current_view_updated_at timestamp
    // This tells the system when picker was last actively working
    await query(`UPDATE users 
       SET current_view_updated_at = NOW() 
       WHERE user_id = $1`, [req.user.userId]);
    res.json({ success: true, status });
}));
/**
 * POST /api/orders/:orderId/pick
 * Process a pick action
 */
router.post('/:orderId/pick', (0, middleware_1.authorize)(shared_1.UserRole.PICKER, shared_1.UserRole.ADMIN), validation_1.validate.orderId, (0, middleware_1.asyncHandler)(async (req, res) => {
    if (!req.user) {
        res.status(401).json({ error: 'Not authenticated' });
        return;
    }
    const { query } = await Promise.resolve().then(() => __importStar(require('../db/client')));
    // Normalize snake_case to camelCase
    // Accept both 'barcode' and 'sku' - frontend may send either
    const barcode = req.body.barcode || req.body.sku;
    const quantity = req.body.quantity;
    const binLocation = req.body.binLocation || req.body.bin_location;
    const pickTaskId = req.body.pickTaskId || req.body.pick_task_id;
    // Manual validation
    if (!barcode) {
        res.status(400).json({
            error: 'Validation failed',
            details: [{ field: 'barcode', message: '"barcode" or "sku" is required' }],
        });
        return;
    }
    if (!binLocation) {
        res.status(400).json({
            error: 'Validation failed',
            details: [{ field: 'binLocation', message: '"binLocation" is required' }],
        });
        return;
    }
    if (!pickTaskId) {
        res.status(400).json({
            error: 'Validation failed',
            details: [{ field: 'pickTaskId', message: '"pickTaskId" is required' }],
        });
        return;
    }
    // The 'barcode' field now contains either a barcode OR an SKU code
    // Check if it's a valid SKU first
    let sku;
    // Try to look up by SKU or barcode (frontend sends barcode which might be barcode number or SKU code)
    const skuResult = await query(`SELECT sku FROM skus WHERE (sku = $1 OR barcode = $1) AND active = true`, [barcode]);
    if (skuResult.rows.length > 0) {
        // It's a valid SKU code or barcode
        sku = skuResult.rows[0].sku;
    }
    else {
        // Not found by SKU or barcode
        res.status(404).json({
            error: 'SKU or barcode not found',
            code: 'SKU_NOT_FOUND',
            value: barcode,
        });
        return;
    }
    const result = await services_1.orderService.pickItem(req.params.orderId, {
        sku,
        quantity,
        binLocation,
        pickTaskId,
    }, req.user.userId);
    res.json(result);
}));
/**
 * POST /api/orders/:orderId/cancel
 * Cancel an order
 */
router.post('/:orderId/cancel', validation_1.validate.orderId, validation_1.validate.cancelOrder, (0, middleware_1.asyncHandler)(async (req, res) => {
    if (!req.user) {
        res.status(401).json({ error: 'Not authenticated' });
        return;
    }
    const order = await services_1.orderService.cancelOrder(req.params.orderId, {
        orderId: req.params.orderId,
        userId: req.user.userId,
        reason: req.body.reason,
    });
    res.json(order);
}));
/**
 * POST /api/orders/:orderId/unclaim
 * Abandon/unclaim an order (for stuck orders)
 */
router.post('/:orderId/unclaim', (0, middleware_1.authorize)(shared_1.UserRole.PICKER, shared_1.UserRole.ADMIN), validation_1.validate.orderId, (0, middleware_1.asyncHandler)(async (req, res) => {
    if (!req.user) {
        res.status(401).json({ error: 'Not authenticated' });
        return;
    }
    // Accept reason from either query string or request body
    const reason = req.query.reason || req.body.reason || '';
    if (!reason || !reason.trim()) {
        res.status(400).json({
            error: 'Reason is required to unclaim an order',
            code: 'MISSING_REASON',
        });
        return;
    }
    try {
        const order = await services_1.orderService.unclaimOrder(req.params.orderId, req.user.userId, reason.trim());
        res.json(order);
    }
    catch (error) {
        if (error?.message?.includes('not assigned')) {
            res.status(409).json({
                error: error.message,
                code: 'NOT_ASSIGNED_TO_PICKER',
            });
            return;
        }
        if (error?.message?.includes('not in PICKING status')) {
            res.status(409).json({
                error: error.message,
                code: 'NOT_PICKING',
            });
            return;
        }
        throw error;
    }
}));
/**
 * POST /api/orders/:orderId/skip-task
 * Skip a pick task
 */
router.post('/:orderId/skip-task', (0, middleware_1.authorize)(shared_1.UserRole.PICKER, shared_1.UserRole.ADMIN), validation_1.validate.orderId, (0, middleware_1.asyncHandler)(async (req, res) => {
    if (!req.user) {
        res.status(401).json({ error: 'Not authenticated' });
        return;
    }
    const pickTaskId = req.body.pickTaskId || req.body.pick_task_id;
    const reason = req.body.reason;
    // Validate pickTaskId
    if (!pickTaskId) {
        res.status(400).json({
            error: 'pickTaskId is required',
            code: 'MISSING_PICK_TASK_ID',
        });
        return;
    }
    // Validate reason
    if (!reason || !reason.trim()) {
        res.status(400).json({
            error: 'Reason is required',
            code: 'MISSING_REASON',
        });
        return;
    }
    const order = await services_1.orderService.skipPickTask(pickTaskId, reason.trim(), req.user.userId);
    res.json(order);
}));
/**
 * GET /api/orders/:orderId/progress
 * Get picking progress for an order
 */
router.get('/:orderId/progress', validation_1.validate.orderId, (0, middleware_1.asyncHandler)(async (req, res) => {
    const progress = await services_1.orderService.getOrderPickingProgress(req.params.orderId);
    res.json(progress);
}));
/**
 * POST /api/orders/:orderId/complete
 * Complete an order (move from PICKING to PICKED status)
 */
router.post('/:orderId/complete', (0, middleware_1.authorize)(shared_1.UserRole.PICKER, shared_1.UserRole.ADMIN), validation_1.validate.orderId, (0, middleware_1.asyncHandler)(async (req, res) => {
    if (!req.user) {
        res.status(401).json({ error: 'Not authenticated' });
        return;
    }
    const order = await services_1.orderService.completeOrder(req.params.orderId, {
        orderId: req.params.orderId,
        pickerId: req.user.userId,
    });
    res.json(order);
}));
/**
 * PUT /api/orders/:orderId/pick-task/:pickTaskId
 * Update pick task status (e.g., to revert skip)
 */
router.put('/:orderId/pick-task/:pickTaskId', (0, middleware_1.authorize)(shared_1.UserRole.PICKER, shared_1.UserRole.ADMIN), validation_1.validate.orderId, (0, middleware_1.asyncHandler)(async (req, res) => {
    console.log('=== PUT route handler ===');
    console.log('Full URL:', req.url);
    console.log('Original URL:', req.originalUrl);
    console.log('req.params:', JSON.stringify(req.params));
    console.log('req.body:', JSON.stringify(req.body));
    // Extract pickTaskId from URL manually since Express isn't parsing it
    const urlParts = req.url.split('/');
    const pickTaskId = urlParts[urlParts.length - 1];
    const { status } = req.body;
    if (!status || !['PENDING', 'IN_PROGRESS', 'COMPLETED', 'SKIPPED'].includes(status)) {
        res.status(400).json({
            error: 'Invalid status',
            code: 'INVALID_STATUS',
        });
        return;
    }
    try {
        // Update pick task status directly
        const result = await services_1.orderService.updatePickTaskStatus(pickTaskId, status);
        res.json(result);
    }
    catch (error) {
        if (error?.message?.includes('not found')) {
            res.status(404).json({
                error: error.message,
                code: 'PICK_TASK_NOT_FOUND',
            });
            return;
        }
        throw error;
    }
}));
/**
 * POST /api/orders/:orderId/manual-override
 * Manual override of picked quantity for an item
 */
router.post('/:orderId/manual-override', (0, middleware_1.authorize)(shared_1.UserRole.PICKER, shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR), validation_1.validate.orderId, (0, middleware_1.asyncHandler)(async (req, res) => {
    if (!req.user) {
        res.status(401).json({ error: 'Not authenticated' });
        return;
    }
    const { pickTaskId, newQuantity, reason, notes } = req.body;
    // Validate required fields
    if (!pickTaskId) {
        res.status(400).json({
            error: 'pickTaskId is required',
            code: 'MISSING_PICK_TASK_ID',
        });
        return;
    }
    if (newQuantity === undefined || newQuantity === null) {
        res.status(400).json({
            error: 'newQuantity is required',
            code: 'MISSING_QUANTITY',
        });
        return;
    }
    if (!reason || !reason.trim()) {
        res.status(400).json({
            error: 'Reason is required for manual override',
            code: 'MISSING_REASON',
        });
        return;
    }
    try {
        const result = await services_1.orderService.manualOverride(pickTaskId, newQuantity, reason.trim(), notes, req.user.userId);
        res.json(result);
    }
    catch (error) {
        if (error?.message?.includes('not found')) {
            res.status(404).json({
                error: error.message,
                code: 'PICK_TASK_NOT_FOUND',
            });
            return;
        }
        if (error?.message?.includes('exceeds required')) {
            res.status(400).json({
                error: error.message,
                code: 'QUANTITY_EXCEEDS_REQUIRED',
            });
            return;
        }
        throw error;
    }
}));
/**
 * POST /api/orders/:orderId/skip-item
 * Temporary skip for an item
 */
router.post('/:orderId/skip-item', (0, middleware_1.authorize)(shared_1.UserRole.PICKER, shared_1.UserRole.ADMIN), validation_1.validate.orderId, (0, middleware_1.asyncHandler)(async (req, res) => {
    if (!req.user) {
        res.status(401).json({ error: 'Not authenticated' });
        return;
    }
    const { pickTaskId, reason } = req.body;
    if (!pickTaskId) {
        res.status(400).json({
            error: 'pickTaskId is required',
            code: 'MISSING_PICK_TASK_ID',
        });
        return;
    }
    if (!reason || !reason.trim()) {
        res.status(400).json({
            error: 'Reason is required for skipping an item',
            code: 'MISSING_REASON',
        });
        return;
    }
    try {
        const order = await services_1.orderService.skipPickTask(pickTaskId, `TEMP_SKIP: ${reason.trim()}`, req.user.userId);
        res.json(order);
    }
    catch (error) {
        if (error?.message?.includes('not found')) {
            res.status(404).json({
                error: error.message,
                code: 'PICK_TASK_NOT_FOUND',
            });
            return;
        }
        throw error;
    }
}));
/**
 * POST /api/orders/:orderId/undo-pick
 * Undo a pick action (decrement picked quantity)
 */
router.post('/:orderId/undo-pick', (0, middleware_1.authorize)(shared_1.UserRole.PICKER, shared_1.UserRole.ADMIN), validation_1.validate.orderId, (0, middleware_1.asyncHandler)(async (req, res) => {
    if (!req.user) {
        res.status(401).json({ error: 'Not authenticated' });
        return;
    }
    const pickTaskId = req.body.pickTaskId || req.body.pick_task_id;
    const reason = req.body.reason;
    const quantity = req.body.quantity || 1;
    if (!pickTaskId) {
        res.status(400).json({
            error: 'pickTaskId is required',
            code: 'MISSING_FIELDS',
        });
        return;
    }
    if (!reason || !reason.trim()) {
        res.status(400).json({
            error: 'Reason is required for undoing a pick',
            code: 'MISSING_REASON',
        });
        return;
    }
    try {
        const order = await services_1.orderService.undoPick(pickTaskId, quantity, reason.trim());
        // Create an UNDO_PICK exception for tracking (async, don't wait for it)
        (async () => {
            try {
                const pool = (0, client_1.getPool)();
                // Get pick task details for the exception
                const pickTaskResult = await pool.query(`SELECT pt.sku, pt.order_id, pt.quantity, pt.picked_quantity
             FROM pick_tasks pt
             WHERE pt.pick_task_id = $1`, [pickTaskId]);
                if (pickTaskResult.rows.length > 0) {
                    const pickTask = pickTaskResult.rows[0];
                    // Calculate quantity difference (what was reduced)
                    const quantityReduced = quantity;
                    await pool.query(`INSERT INTO order_exceptions (
                order_id, order_item_id, sku, type,
                quantity_expected, quantity_actual, reason,
                reported_by, status, created_at
              ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, NOW())`, [
                        pickTask.order_id,
                        pickTaskId,
                        pickTask.sku,
                        shared_1.ExceptionType.UNDO_PICK,
                        pickTask.picked_quantity + quantityReduced, // original quantity before undo
                        pickTask.picked_quantity, // new quantity after undo
                        `${reason} (reduced by ${quantityReduced})`,
                        req.user?.userId || 'system',
                        'OPEN',
                    ]);
                }
            }
            catch (exceptionError) {
                // Log the error but don't fail the undo operation
                console.error('Failed to create exception for undo-pick:', exceptionError);
            }
        })();
        res.json(order);
    }
    catch (error) {
        if (error?.message?.includes('not found')) {
            res.status(404).json({
                error: error.message,
                code: 'PICK_TASK_NOT_FOUND',
            });
            return;
        }
        if (error?.message?.includes('cannot be decremented')) {
            res.status(409).json({
                error: error.message,
                code: 'CANNOT_DECREMENT',
            });
            return;
        }
        throw error;
    }
}));
/**
 * POST /api/orders/:orderId/claim-for-packing
 * Claim an order for packing
 */
router.post('/:orderId/claim-for-packing', (0, middleware_1.authorize)(shared_1.UserRole.PACKER, shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR), validation_1.validate.orderId, (0, middleware_1.asyncHandler)(async (req, res) => {
    if (!req.user) {
        res.status(401).json({ error: 'Not authenticated' });
        return;
    }
    const { packer_id } = req.body;
    if (!packer_id) {
        res.status(400).json({
            error: 'packer_id is required',
            code: 'MISSING_PACKER_ID',
        });
        return;
    }
    try {
        const order = await services_1.orderService.claimOrderForPacking(req.params.orderId, packer_id);
        res.json(order);
    }
    catch (error) {
        if (error?.message?.includes('cannot be claimed')) {
            res.status(409).json({
                error: error.message,
                code: 'ORDER_NOT_CLAIMABLE',
            });
            return;
        }
        if (error?.message?.includes('already claimed')) {
            res.status(409).json({
                error: error.message,
                code: 'ORDER_ALREADY_CLAIMED',
            });
            return;
        }
        throw error;
    }
}));
/**
 * POST /api/orders/:orderId/complete-packing
 * Complete packing for an order
 */
router.post('/:orderId/complete-packing', (0, middleware_1.authorize)(shared_1.UserRole.PACKER, shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR), validation_1.validate.orderId, (0, middleware_1.asyncHandler)(async (req, res) => {
    if (!req.user) {
        res.status(401).json({ error: 'Not authenticated' });
        return;
    }
    const { packer_id } = req.body;
    if (!packer_id) {
        res.status(400).json({
            error: 'packer_id is required',
            code: 'MISSING_PACKER_ID',
        });
        return;
    }
    try {
        const order = await services_1.orderService.completePacking(req.params.orderId, packer_id);
        res.json(order);
    }
    catch (error) {
        if (error?.message?.includes('not assigned')) {
            res.status(409).json({
                error: error.message,
                code: 'NOT_ASSIGNED_TO_PACKER',
            });
            return;
        }
        if (error?.message?.includes('not in PACKING status')) {
            res.status(409).json({
                error: error.message,
                code: 'NOT_PACKING',
            });
            return;
        }
        throw error;
    }
}));
/**
 * POST /api/orders/:orderId/unclaim-packing
 * Unclaim/abandon a packing order (returns order to PICKED status)
 */
router.post('/:orderId/unclaim-packing', (0, middleware_1.authorize)(shared_1.UserRole.PACKER, shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR), validation_1.validate.orderId, (0, middleware_1.asyncHandler)(async (req, res) => {
    if (!req.user) {
        res.status(401).json({ error: 'Not authenticated' });
        return;
    }
    const { packer_id, reason } = req.body;
    if (!packer_id) {
        res.status(400).json({
            error: 'packer_id is required',
            code: 'MISSING_PACKER_ID',
        });
        return;
    }
    if (!reason || !reason.trim()) {
        res.status(400).json({
            error: 'Reason is required to unclaim an order',
            code: 'MISSING_REASON',
        });
        return;
    }
    try {
        const order = await services_1.orderService.unclaimPackingOrder(req.params.orderId, packer_id, reason.trim());
        res.json(order);
    }
    catch (error) {
        if (error?.message?.includes('not assigned')) {
            res.status(409).json({
                error: error.message,
                code: 'NOT_ASSIGNED_TO_PACKER',
            });
            return;
        }
        if (error?.message?.includes('not in PACKING status')) {
            res.status(409).json({
                error: error.message,
                code: 'NOT_PACKING',
            });
            return;
        }
        throw error;
    }
}));
/**
 * GET /api/orders/packing-queue
 * Get orders ready for packing
 */
router.get('/packing-queue', (0, middleware_1.authorize)(shared_1.UserRole.PACKER, shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR), (0, middleware_1.asyncHandler)(async (_req, res) => {
    const orders = await services_1.orderService.getPackingQueue();
    res.json(orders);
}));
/**
 * POST /api/orders/:orderId/verify-packing
 * Verify a packing item by scanning barcode
 */
router.post('/:orderId/verify-packing', (0, middleware_1.authorize)(shared_1.UserRole.PACKER, shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR), validation_1.validate.orderId, (0, middleware_1.asyncHandler)(async (req, res) => {
    const { order_item_id, quantity } = req.body;
    if (!order_item_id) {
        res.status(400).json({
            error: 'order_item_id is required',
            code: 'MISSING_ORDER_ITEM_ID',
        });
        return;
    }
    try {
        const order = await services_1.orderService.verifyPackingItem(req.params.orderId, order_item_id, quantity || 1);
        res.json(order);
    }
    catch (error) {
        if (error?.message?.includes('not in PACKING status')) {
            res.status(409).json({
                error: error.message,
                code: 'NOT_PACKING',
            });
            return;
        }
        throw error;
    }
}));
/**
 * POST /api/orders/:orderId/skip-packing-item
 * Skip a packing item
 */
router.post('/:orderId/skip-packing-item', (0, middleware_1.authorize)(shared_1.UserRole.PACKER, shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR), validation_1.validate.orderId, (0, middleware_1.asyncHandler)(async (req, res) => {
    const { order_item_id, reason } = req.body;
    if (!order_item_id) {
        res.status(400).json({
            error: 'order_item_id is required',
            code: 'MISSING_ORDER_ITEM_ID',
        });
        return;
    }
    if (!reason) {
        res.status(400).json({
            error: 'reason is required',
            code: 'MISSING_REASON',
        });
        return;
    }
    try {
        const order = await services_1.orderService.skipPackingItem(req.params.orderId, order_item_id, reason);
        res.json(order);
    }
    catch (error) {
        if (error?.message?.includes('not in PACKING status')) {
            res.status(409).json({
                error: error.message,
                code: 'NOT_PACKING',
            });
            return;
        }
        throw error;
    }
}));
/**
 * POST /api/orders/:orderId/undo-packing-verification
 * Undo a packing verification
 */
router.post('/:orderId/undo-packing-verification', (0, middleware_1.authorize)(shared_1.UserRole.PACKER, shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR), validation_1.validate.orderId, (0, middleware_1.asyncHandler)(async (req, res) => {
    const { order_item_id, quantity, reason } = req.body;
    if (!order_item_id) {
        res.status(400).json({
            error: 'order_item_id is required',
            code: 'MISSING_ORDER_ITEM_ID',
        });
        return;
    }
    if (!reason) {
        res.status(400).json({
            error: 'reason is required',
            code: 'MISSING_REASON',
        });
        return;
    }
    try {
        const order = await services_1.orderService.undoPackingVerification(req.params.orderId, order_item_id, quantity || 1, reason);
        res.json(order);
    }
    catch (error) {
        if (error?.message?.includes('not in PACKING status')) {
            res.status(409).json({
                error: error.message,
                code: 'NOT_PACKING',
            });
            return;
        }
        throw error;
    }
}));
exports.default = router;
//# sourceMappingURL=orders.js.map