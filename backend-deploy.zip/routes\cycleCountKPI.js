"use strict";
/**
 * Cycle Count KPI routes
 *
 * Endpoints for cycle count analytics and dashboards
 */
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const CycleCountKPIService_1 = require("../services/CycleCountKPIService");
const middleware_1 = require("../middleware");
const router = (0, express_1.Router)();
// All KPI routes require authentication
router.use(middleware_1.authenticate);
/**
 * GET /api/cycle-count/kpi/overall
 * Get overall KPIs for cycle counting
 */
router.get('/overall', (0, middleware_1.asyncHandler)(async (req, res) => {
    const filters = {
        startDate: req.query.startDate ? new Date(req.query.startDate) : undefined,
        endDate: req.query.endDate ? new Date(req.query.endDate) : undefined,
        location: req.query.location,
        countType: req.query.countType,
    };
    const kpis = await CycleCountKPIService_1.cycleCountKPIService.getOverallKPIs(filters);
    res.json(kpis);
}));
/**
 * GET /api/cycle-count/kpi/accuracy-trend
 * Get accuracy trends over time
 */
router.get('/accuracy-trend', (0, middleware_1.asyncHandler)(async (req, res) => {
    const days = req.query.days ? parseInt(req.query.days) : 30;
    const trend = await CycleCountKPIService_1.cycleCountKPIService.getAccuracyTrend(days);
    res.json(trend);
}));
/**
 * GET /api/cycle-count/kpi/top-discrepancies
 * Get SKUs with most discrepancies
 */
router.get('/top-discrepancies', (0, middleware_1.asyncHandler)(async (req, res) => {
    const limit = req.query.limit ? parseInt(req.query.limit) : 10;
    const days = req.query.days ? parseInt(req.query.days) : 30;
    const discrepancies = await CycleCountKPIService_1.cycleCountKPIService.getTopDiscrepancySKUs(limit, days);
    res.json(discrepancies);
}));
/**
 * GET /api/cycle-count/kpi/user-performance
 * Get performance by user
 */
router.get('/user-performance', (0, middleware_1.asyncHandler)(async (req, res) => {
    const days = req.query.days ? parseInt(req.query.days) : 30;
    const performance = await CycleCountKPIService_1.cycleCountKPIService.getCountByUser(days);
    res.json(performance);
}));
/**
 * GET /api/cycle-count/kpi/zone-performance
 * Get performance by zone
 */
router.get('/zone-performance', (0, middleware_1.asyncHandler)(async (req, res) => {
    const days = req.query.days ? parseInt(req.query.days) : 30;
    const performance = await CycleCountKPIService_1.cycleCountKPIService.getZonePerformance(days);
    res.json(performance);
}));
/**
 * GET /api/cycle-count/kpi/count-type-effectiveness
 * Get effectiveness by count type
 */
router.get('/count-type-effectiveness', (0, middleware_1.asyncHandler)(async (req, res) => {
    const days = req.query.days ? parseInt(req.query.days) : 90;
    const effectiveness = await CycleCountKPIService_1.cycleCountKPIService.getCountTypeEffectiveness(days);
    res.json(effectiveness);
}));
/**
 * GET /api/cycle-count/kpi/daily-stats
 * Get daily statistics for charts
 */
router.get('/daily-stats', (0, middleware_1.asyncHandler)(async (req, res) => {
    const days = req.query.days ? parseInt(req.query.days) : 30;
    const stats = await CycleCountKPIService_1.cycleCountKPIService.getDailyStats(days);
    res.json(stats);
}));
/**
 * GET /api/cycle-count/kpi/dashboard
 * Get real-time dashboard data (aggregates all KPIs)
 */
router.get('/dashboard', (0, middleware_1.asyncHandler)(async (req, res) => {
    const filters = {
        startDate: req.query.startDate ? new Date(req.query.startDate) : undefined,
        endDate: req.query.endDate ? new Date(req.query.endDate) : undefined,
        location: req.query.location,
        countType: req.query.countType,
    };
    const dashboard = await CycleCountKPIService_1.cycleCountKPIService.getRealTimeDashboard(filters);
    res.json(dashboard);
}));
exports.default = router;
//# sourceMappingURL=cycleCountKPI.js.map