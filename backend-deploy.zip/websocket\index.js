"use strict";
/**
 * WebSocket Server Setup
 *
 * Provides real-time bidirectional communication between clients and server
 * Uses Socket.IO for WebSocket functionality with JWT authentication
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.broadcastEvent = void 0;
const socket_io_1 = require("socket.io");
const config_1 = __importDefault(require("../config"));
const logger_1 = require("../config/logger");
const broadcaster_1 = require("./broadcaster");
Object.defineProperty(exports, "broadcastEvent", { enumerable: true, get: function () { return broadcaster_1.broadcastEvent; } });
const auth_1 = require("../middleware/auth");
class WebSocketServer {
    io = null;
    broadcaster = null;
    // Rate limiting configuration
    rateLimiters = new Map();
    rateLimitWindowMs = 1000; // 1 second window
    rateLimitMaxRequests = 20; // Max 20 events per second per user
    /**
     * Initialize WebSocket server with HTTP server
     */
    initialize(httpServer) {
        if (this.io) {
            logger_1.logger.warn('WebSocket server already initialized');
            return;
        }
        // Create Socket.IO server with CORS configuration and compression
        this.io = new socket_io_1.Server(httpServer, {
            cors: {
                origin: config_1.default.cors.origin,
                credentials: true,
            },
            transports: ['websocket', 'polling'],
            pingTimeout: 60000,
            pingInterval: 25000,
            // Enable per-message compression for messages > 256 bytes
            perMessageDeflate: {
                threshold: 256,
                zlibDeflateOptions: {
                    level: 3, // Fast compression
                },
            },
        });
        // Initialize broadcaster
        this.broadcaster = new broadcaster_1.WebSocketBroadcaster(this.io);
        // Set up authentication middleware
        this.io.use((socket, next) => {
            this.authenticateSocket(socket, next);
        });
        // Set up rate limiting middleware
        this.io.use((socket, next) => {
            this.checkRateLimit(socket, next);
        });
        // Set up connection handling
        this.io.on('connection', (socket) => {
            this.handleConnection(socket);
        });
        // Start periodic cleanup of rate limiters
        this.startRateLimitCleanup();
        logger_1.logger.info('WebSocket server initialized', {
            compression: 'enabled (threshold: 256 bytes)',
            rateLimit: `${this.rateLimitMaxRequests} events/${this.rateLimitWindowMs}ms per user`,
        });
    }
    /**
     * Check rate limit for a socket connection
     */
    checkRateLimit(socket, next) {
        const userId = socket.userId;
        if (!userId) {
            return next();
        }
        const now = Date.now();
        const limiter = this.rateLimiters.get(userId);
        if (!limiter || limiter.resetAt < now) {
            // New window
            this.rateLimiters.set(userId, { count: 1, resetAt: now + this.rateLimitWindowMs });
            return next();
        }
        if (limiter.count >= this.rateLimitMaxRequests) {
            logger_1.logger.warn('WebSocket rate limit exceeded', { userId, count: limiter.count });
            return next(new Error('Rate limit exceeded. Please slow down.'));
        }
        limiter.count++;
        next();
    }
    /**
     * Periodic cleanup of stale rate limiters
     */
    startRateLimitCleanup() {
        setInterval(() => {
            const now = Date.now();
            let cleaned = 0;
            // Use Array.from to avoid iterator issues
            const entries = Array.from(this.rateLimiters.entries());
            for (const [userId, limiter] of entries) {
                if (limiter.resetAt < now) {
                    this.rateLimiters.delete(userId);
                    cleaned++;
                }
            }
            if (cleaned > 0) {
                logger_1.logger.debug('Rate limiter cleanup', { cleaned, remaining: this.rateLimiters.size });
            }
        }, 60000); // Cleanup every minute
    }
    /**
     * Authenticate WebSocket connection using JWT
     * Handles both compact (new) and legacy (old) token formats
     */
    authenticateSocket(socket, next) {
        try {
            const token = socket.handshake.auth.token ||
                socket.handshake.headers.authorization?.replace('Bearer ', '');
            if (!token) {
                return next(new Error('Authentication error: No token provided'));
            }
            // Verify JWT token (handles both compact and legacy formats)
            const decoded = (0, auth_1.verifyToken)(token);
            socket.userId = decoded.userId;
            socket.userRole = decoded.role;
            logger_1.logger.info('WebSocket authenticated', {
                socketId: socket.id,
                userId: decoded.userId,
                role: decoded.role,
            });
            next();
        }
        catch (error) {
            logger_1.logger.error('WebSocket authentication failed', { error });
            next(new Error('Authentication error: Invalid token'));
        }
    }
    /**
     * Handle new WebSocket connection
     */
    handleConnection(socket) {
        const userId = socket.userId;
        const userRole = socket.userRole;
        logger_1.logger.info('WebSocket connected', {
            socketId: socket.id,
            userId,
            role: userRole,
        });
        // Join user-specific room
        socket.join(`user:${userId}`);
        // Send welcome message
        socket.emit('connected', { message: 'WebSocket connection established' });
        // Set up event handlers for this socket
        this.setupSocketHandlers(socket);
        // Handle disconnection
        socket.on('disconnect', reason => {
            logger_1.logger.info('WebSocket disconnected', {
                socketId: socket.id,
                userId,
                reason,
            });
        });
        // Handle errors
        socket.on('error', error => {
            logger_1.logger.error('WebSocket error', {
                socketId: socket.id,
                userId,
                error,
            });
        });
    }
    /**
     * Set up event handlers for socket events from client
     */
    setupSocketHandlers(socket) {
        // Subscribe to order updates
        socket.on('subscribe:orders', () => {
            socket.join('orders');
            logger_1.logger.debug('Socket subscribed to orders', { socketId: socket.id });
        });
        // Subscribe to specific zone updates
        socket.on('subscribe:zone', (zoneId) => {
            socket.join(`zone:${zoneId}`);
            logger_1.logger.debug('Socket subscribed to zone', { socketId: socket.id, zoneId });
        });
        // Unsubscribe from zone updates
        socket.on('unsubscribe:zone', (zoneId) => {
            socket.leave(`zone:${zoneId}`);
            logger_1.logger.debug('Socket unsubscribed from zone', { socketId: socket.id, zoneId });
        });
        // Subscribe to inventory updates
        socket.on('subscribe:inventory', () => {
            socket.join('inventory');
            logger_1.logger.debug('Socket subscribed to inventory', { socketId: socket.id });
        });
        // Handle user activity updates
        socket.on('update:activity', data => {
            const userId = socket.userId;
            // Broadcast activity to admin/supervisor users
            (this.io?.to('user:activity')).emit('user:activity', {
                userId,
                ...data,
            });
        });
        // Handle ping/pong
        socket.on('ping', () => {
            socket.emit('pong');
        });
    }
    /**
     * Get the Socket.IO server instance
     */
    getIO() {
        return this.io;
    }
    /**
     * Get the broadcaster instance
     */
    getBroadcaster() {
        return this.broadcaster;
    }
    /**
     * Broadcast an event (convenience method)
     */
    broadcast(event, data, room) {
        if (!this.io)
            return;
        if (room) {
            this.io.to(room).emit(event, data);
        }
        else {
            this.io.emit(event, data);
        }
    }
    /**
     * Get connected clients count
     */
    getConnectedCount() {
        return this.io?.sockets.sockets.size || 0;
    }
    /**
     * Disconnect all clients
     */
    disconnectAll() {
        if (!this.io)
            return;
        this.io.disconnectSockets();
        logger_1.logger.info('Disconnected all WebSocket clients');
    }
    /**
     * Close WebSocket server
     */
    close() {
        if (!this.io)
            return;
        this.io.close();
        this.io = null;
        this.broadcaster = null;
        logger_1.logger.info('WebSocket server closed');
    }
}
// ============================================================================
// SINGLETON INSTANCE
// ============================================================================
const wsServer = new WebSocketServer();
exports.default = wsServer;
//# sourceMappingURL=index.js.map