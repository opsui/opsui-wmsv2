/**
 * Winston logger configuration
 *
 * Provides structured logging with different levels and transports
 */
import winston from 'winston';
export declare const logger: winston.Logger;
declare const _default: {
    debug: (message: string, meta?: object) => winston.Logger;
    info: (message: string, meta?: object) => winston.Logger;
    warn: (message: string, meta?: object) => winston.Logger;
    error: (message: string, meta?: object) => winston.Logger;
    logger: winston.Logger;
};
export default _default;
//# sourceMappingURL=logger.d.ts.map