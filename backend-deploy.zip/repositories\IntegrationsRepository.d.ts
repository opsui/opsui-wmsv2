/**
 * Integrations Repository
 *
 * Handles database operations for external integrations (ERP, e-commerce, carriers)
 */
import { Pool } from 'pg';
import { Integration, IntegrationType, IntegrationProvider, IntegrationStatus, SyncJob, SyncLogEntry, WebhookEvent, WebhookEventType, CarrierAccount } from '@opsui/shared';
export declare class IntegrationsRepository {
    private pool;
    constructor(pool: Pool);
    findAll(filters?: {
        type?: IntegrationType;
        provider?: IntegrationProvider;
        status?: IntegrationStatus;
    }): Promise<Integration[]>;
    findById(integrationId: string): Promise<Integration | null>;
    create(integration: Omit<Integration, 'integrationId' | 'createdAt' | 'updatedAt'>): Promise<Integration>;
    update(integrationId: string, updates: Partial<Omit<Integration, 'integrationId' | 'createdAt' | 'updatedAt' | 'type' | 'provider'>>): Promise<Integration | null>;
    delete(integrationId: string): Promise<boolean>;
    createSyncJob(job: Omit<SyncJob, 'jobId' | 'logEntries'>): Promise<SyncJob>;
    findSyncJobs(integrationId?: string, limit?: number): Promise<SyncJob[]>;
    findSyncJobById(jobId: string): Promise<SyncJob | null>;
    updateSyncJob(jobId: string, updates: Partial<Omit<SyncJob, 'jobId' | 'integrationId' | 'jobType' | 'createdAt' | 'startedAt' | 'triggeredBy'>>): Promise<SyncJob | null>;
    createSyncLogEntry(jobId: string, log: Omit<SyncLogEntry, 'logId' | 'timestamp'>): Promise<SyncLogEntry>;
    findSyncLogEntrys(jobId: string, limit?: number): Promise<SyncLogEntry[]>;
    createWebhookEvent(event: Omit<WebhookEvent, 'eventId' | 'receivedAt' | 'processedAt'>): Promise<WebhookEvent>;
    findWebhookEvents(filters?: {
        integrationId?: string;
        status?: string;
        eventType?: WebhookEventType;
    }, limit?: number): Promise<WebhookEvent[]>;
    updateWebhookEvent(eventId: string, updates: Partial<Omit<WebhookEvent, 'eventId' | 'integrationId' | 'eventType' | 'payload' | 'receivedAt'>>): Promise<WebhookEvent | null>;
    findCarrierAccounts(integrationId?: string): Promise<CarrierAccount[]>;
    createCarrierAccount(account: Omit<CarrierAccount, 'accountId' | 'createdAt'>): Promise<CarrierAccount>;
    updateCarrierAccount(carrierAccountId: string, updates: Partial<Omit<CarrierAccount, 'accountId' | 'createdAt'>>): Promise<CarrierAccount | null>;
    deleteCarrierAccount(carrierAccountId: string): Promise<boolean>;
    private mapRowToIntegration;
    private mapRowToSyncJob;
    private mapRowToSyncLogEntry;
    private mapRowToWebhookEvent;
    private mapRowToCarrierAccount;
}
//# sourceMappingURL=IntegrationsRepository.d.ts.map