/**
 * Run the add_active_role migration
 */
export {};
//# sourceMappingURL=run-migration.d.ts.map