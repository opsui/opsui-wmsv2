"use strict";
/**
 * Stock Control routes
 *
 * Routes for stock controllers to manage inventory, perform stock counts,
 * transfers, and adjustments
 */
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const StockControlService_1 = require("../services/StockControlService");
const middleware_1 = require("../middleware");
const shared_1 = require("@opsui/shared");
const router = (0, express_1.Router)();
// All stock control routes require authentication
router.use(middleware_1.authenticate);
// Only stock controllers, supervisors, and admins can access these routes
router.use((0, middleware_1.authorize)(shared_1.UserRole.STOCK_CONTROLLER, shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN));
/**
 * GET /api/stock-control/dashboard
 * Get stock control dashboard with overview statistics
 */
router.get('/dashboard', (0, middleware_1.asyncHandler)(async (_req, res) => {
    const dashboard = await StockControlService_1.stockControlService.getDashboard();
    res.json(dashboard);
}));
/**
 * GET /api/stock-control/inventory
 * Get paginated inventory list with filters
 */
router.get('/inventory', (0, middleware_1.asyncHandler)(async (req, res) => {
    const filters = {
        name: req.query.name,
        sku: req.query.sku,
        category: req.query.category,
        binLocation: req.query.binLocation,
        lowStock: req.query.lowStock === 'true',
        outOfStock: req.query.outOfStock === 'true',
        page: req.query.page ? parseInt(req.query.page) : 1,
        limit: req.query.limit ? parseInt(req.query.limit) : 50,
    };
    const result = await StockControlService_1.stockControlService.getInventoryList(filters);
    res.json(result);
}));
/**
 * GET /api/stock-control/inventory/:sku
 * Get detailed inventory information for a specific SKU
 */
router.get('/inventory/:sku', (0, middleware_1.asyncHandler)(async (req, res) => {
    (0, shared_1.validateSKU)(req.params.sku);
    const inventory = await StockControlService_1.stockControlService.getSKUInventoryDetail(req.params.sku);
    res.json(inventory);
}));
/**
 * POST /api/stock-control/stock-count
 * Create a new stock count
 */
router.post('/stock-count', (0, middleware_1.asyncHandler)(async (req, res) => {
    if (!req.user) {
        res.status(401).json({ error: 'Not authenticated' });
        return;
    }
    const { binLocation, type } = req.body;
    (0, shared_1.validateBinLocation)(binLocation);
    if (!['FULL', 'CYCLIC', 'SPOT'].includes(type)) {
        res.status(400).json({
            error: 'Invalid count type. Must be FULL, CYCLIC, or SPOT',
            code: 'INVALID_TYPE',
        });
        return;
    }
    const stockCount = await StockControlService_1.stockControlService.createStockCount(binLocation, type, req.user.userId);
    res.json(stockCount);
}));
/**
 * POST /api/stock-control/stock-count/:countId/submit
 * Submit stock count results
 */
router.post('/stock-count/:countId/submit', (0, middleware_1.asyncHandler)(async (req, res) => {
    if (!req.user) {
        res.status(401).json({ error: 'Not authenticated' });
        return;
    }
    const { countId } = req.params;
    const { items } = req.body;
    if (!Array.isArray(items)) {
        res.status(400).json({
            error: 'Items must be an array',
            code: 'INVALID_ITEMS',
        });
        return;
    }
    const result = await StockControlService_1.stockControlService.submitStockCount(countId, items, req.user.userId);
    res.json(result);
}));
/**
 * GET /api/stock-control/stock-counts
 * Get list of stock counts
 */
router.get('/stock-counts', (0, middleware_1.asyncHandler)(async (req, res) => {
    const filters = {
        status: req.query.status,
        limit: req.query.limit ? parseInt(req.query.limit) : 50,
        offset: req.query.offset ? parseInt(req.query.offset) : 0,
    };
    const result = await StockControlService_1.stockControlService.getStockCounts(filters);
    res.json(result);
}));
/**
 * POST /api/stock-control/transfer
 * Transfer stock between bin locations
 */
router.post('/transfer', (0, middleware_1.asyncHandler)(async (req, res) => {
    if (!req.user) {
        res.status(401).json({ error: 'Not authenticated' });
        return;
    }
    const { sku, fromBin, toBin, quantity, reason } = req.body;
    (0, shared_1.validateSKU)(sku);
    (0, shared_1.validateBinLocation)(fromBin);
    (0, shared_1.validateBinLocation)(toBin);
    if (typeof quantity !== 'number' || quantity <= 0) {
        res.status(400).json({
            error: 'Quantity must be a positive number',
            code: 'INVALID_QUANTITY',
        });
        return;
    }
    if (!reason || typeof reason !== 'string') {
        res.status(400).json({
            error: 'Reason is required',
            code: 'MISSING_REASON',
        });
        return;
    }
    const transfer = await StockControlService_1.stockControlService.transferStock(sku, fromBin, toBin, quantity, reason, req.user.userId);
    res.json(transfer);
}));
/**
 * POST /api/stock-control/adjust
 * Adjust inventory quantities
 */
router.post('/adjust', (0, middleware_1.asyncHandler)(async (req, res) => {
    if (!req.user) {
        res.status(401).json({ error: 'Not authenticated' });
        return;
    }
    const { sku, binLocation, quantity, reason } = req.body;
    (0, shared_1.validateSKU)(sku);
    (0, shared_1.validateBinLocation)(binLocation);
    if (typeof quantity !== 'number') {
        res.status(400).json({
            error: 'Quantity must be a number (positive to add, negative to remove)',
            code: 'INVALID_QUANTITY',
        });
        return;
    }
    if (!reason || typeof reason !== 'string') {
        res.status(400).json({
            error: 'Reason is required',
            code: 'MISSING_REASON',
        });
        return;
    }
    const adjustment = await StockControlService_1.stockControlService.adjustInventory(sku, binLocation, quantity, reason, req.user.userId);
    res.json(adjustment);
}));
/**
 * GET /api/stock-control/transactions
 * Get transaction history with detailed filters
 */
router.get('/transactions', (0, middleware_1.asyncHandler)(async (req, res) => {
    const filters = {
        sku: req.query.sku,
        binLocation: req.query.binLocation,
        type: req.query.type,
        userId: req.query.userId,
        startDate: req.query.startDate,
        endDate: req.query.endDate,
        limit: req.query.limit ? parseInt(req.query.limit) : 100,
        offset: req.query.offset ? parseInt(req.query.offset) : 0,
    };
    const result = await StockControlService_1.stockControlService.getTransactionHistory(filters);
    res.json(result);
}));
/**
 * GET /api/stock-control/reports/low-stock
 * Get low stock report
 */
router.get('/reports/low-stock', (0, middleware_1.asyncHandler)(async (req, res) => {
    const threshold = req.query.threshold ? parseInt(req.query.threshold) : 10;
    const report = await StockControlService_1.stockControlService.getLowStockReport(threshold);
    res.json(report);
}));
/**
 * GET /api/stock-control/reports/movements
 * Get stock movement report
 */
router.get('/reports/movements', (0, middleware_1.asyncHandler)(async (req, res) => {
    const filters = {
        startDate: req.query.startDate,
        endDate: req.query.endDate,
        sku: req.query.sku,
    };
    const report = await StockControlService_1.stockControlService.getMovementReport(filters);
    res.json(report);
}));
/**
 * POST /api/stock-control/reconcile
 * Reconcile inventory discrepancies
 */
router.post('/reconcile', (0, middleware_1.asyncHandler)(async (req, res) => {
    if (!req.user) {
        res.status(401).json({ error: 'Not authenticated' });
        return;
    }
    const { discrepancies } = req.body;
    if (!Array.isArray(discrepancies)) {
        res.status(400).json({
            error: 'Discrepancies must be an array',
            code: 'INVALID_DISCREPANCIES',
        });
        return;
    }
    const result = await StockControlService_1.stockControlService.reconcileDiscrepancies(discrepancies, req.user.userId);
    res.json(result);
}));
/**
 * GET /api/stock-control/bins
 * Get list of all bin locations
 */
router.get('/bins', (0, middleware_1.asyncHandler)(async (req, res) => {
    const filters = {
        zone: req.query.zone,
        active: req.query.active === 'true' ? true : req.query.active === 'false' ? false : undefined,
    };
    const bins = await StockControlService_1.stockControlService.getBinLocations(filters);
    res.json(bins);
}));
// ============================================================================
// ANALYTICS ROUTES
// ============================================================================
/**
 * GET /api/stock-control/analytics/aging
 * Get inventory aging report
 */
router.get('/analytics/aging', (0, middleware_1.asyncHandler)(async (req, res) => {
    const filters = {
        sku: req.query.sku,
        binLocation: req.query.binLocation,
        minDays: req.query.minDays ? parseInt(req.query.minDays) : undefined,
    };
    const report = await StockControlService_1.stockControlService.getInventoryAgingReport(filters);
    res.json(report);
}));
/**
 * GET /api/stock-control/analytics/turnover
 * Get inventory turnover metrics
 */
router.get('/analytics/turnover', (0, middleware_1.asyncHandler)(async (req, res) => {
    const period = req.query.period || 'month';
    const turnover = await StockControlService_1.stockControlService.getInventoryTurnover(period);
    res.json(turnover);
}));
/**
 * GET /api/stock-control/analytics/bin-utilization
 * Get bin capacity utilization report
 */
router.get('/analytics/bin-utilization', (0, middleware_1.asyncHandler)(async (req, res) => {
    const filters = {
        zone: req.query.zone,
        status: req.query.status,
    };
    const report = await StockControlService_1.stockControlService.getBinUtilizationReport(filters);
    res.json(report);
}));
// ============================================================================
// LOT TRACKING ROUTES
// ============================================================================
/**
 * GET /api/stock-control/lots/:sku
 * Get lot tracking information for an SKU
 */
router.get('/lots/:sku', (0, middleware_1.asyncHandler)(async (req, res) => {
    (0, shared_1.validateSKU)(req.params.sku);
    const lotInfo = await StockControlService_1.stockControlService.getLotTracking(req.params.sku);
    res.json(lotInfo);
}));
/**
 * GET /api/stock-control/expiring
 * Get expiring inventory report (FEFO)
 */
router.get('/expiring', (0, middleware_1.asyncHandler)(async (req, res) => {
    const days = req.query.days ? parseInt(req.query.days) : 30;
    const report = await StockControlService_1.stockControlService.getExpiringInventory(days);
    res.json(report);
}));
exports.default = router;
//# sourceMappingURL=stockControl.js.map