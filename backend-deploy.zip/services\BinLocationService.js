"use strict";
/**
 * Bin Location Service
 *
 * Manages warehouse bin location CRUD operations
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.binLocationService = exports.BinLocationService = void 0;
const client_1 = require("../db/client");
const logger_1 = require("../config/logger");
// ============================================================================
// BIN LOCATION SERVICE
// ============================================================================
class BinLocationService {
    /**
     * Create a new bin location
     */
    async createBinLocation(dto) {
        const client = await (0, client_1.getPool)();
        // Validate bin_id format: Z-A-S (e.g., A-12-03)
        const binIdPattern = /^[A-Z]-\d{1,3}-\d{2}$/;
        if (!binIdPattern.test(dto.binId)) {
            throw new Error('Invalid bin ID format. Expected format: Zone-Aisle-Shelf (e.g., A-12-03)');
        }
        // Check if bin location already exists
        const existingResult = await client.query(`SELECT bin_id FROM bin_locations WHERE bin_id = $1`, [dto.binId]);
        if (existingResult.rows.length > 0) {
            throw new Error(`Bin location ${dto.binId} already exists`);
        }
        // Insert new bin location
        await client.query(`INSERT INTO bin_locations (bin_id, zone, aisle, shelf, type, active)
       VALUES ($1, $2, $3, $4, $5, true)`, [dto.binId, dto.zone, dto.aisle, dto.shelf, dto.type]);
        logger_1.logger.info('Bin location created', { binId: dto.binId });
        return await this.getBinLocation(dto.binId);
    }
    /**
     * Get all bin locations
     */
    async getAllBinLocations(filters) {
        const client = await (0, client_1.getPool)();
        const conditions = [];
        const params = [];
        let paramCount = 1;
        if (filters?.zone) {
            conditions.push(`zone = $${paramCount}`);
            params.push(filters.zone);
            paramCount++;
        }
        if (filters?.type) {
            conditions.push(`type = $${paramCount}`);
            params.push(filters.type);
            paramCount++;
        }
        if (filters?.active !== undefined) {
            conditions.push(`active = $${paramCount}`);
            params.push(filters.active);
            paramCount++;
        }
        const whereClause = conditions.length > 0 ? conditions.join(' AND ') : '1=1';
        // Get total count
        const countResult = await client.query(`SELECT COUNT(*) as count FROM bin_locations WHERE ${whereClause}`, params);
        const total = parseInt(countResult.rows[0].count, 10);
        // Get paginated results
        const limit = filters?.limit || 100;
        const offset = filters?.offset || 0;
        const result = await client.query(`SELECT * FROM bin_locations
       WHERE ${whereClause}
       ORDER BY zone, aisle, shelf
       LIMIT $${paramCount} OFFSET $${paramCount + 1}`, [...params, limit, offset]);
        const locations = result.rows.map(row => this.mapRowToBinLocation(row));
        return { locations, total };
    }
    /**
     * Get a specific bin location by ID
     */
    async getBinLocation(binId) {
        const client = await (0, client_1.getPool)();
        const result = await client.query(`SELECT * FROM bin_locations WHERE bin_id = $1`, [binId]);
        if (result.rows.length === 0) {
            throw new Error(`Bin location ${binId} not found`);
        }
        return this.mapRowToBinLocation(result.rows[0]);
    }
    /**
     * Update a bin location
     */
    async updateBinLocation(binId, updates) {
        const client = await (0, client_1.getPool)();
        const updateFields = [];
        const updateParams = [];
        let paramCount = 1;
        if (updates.zone !== undefined) {
            updateFields.push(`zone = $${paramCount}`);
            updateParams.push(updates.zone);
            paramCount++;
        }
        if (updates.aisle !== undefined) {
            updateFields.push(`aisle = $${paramCount}`);
            updateParams.push(updates.aisle);
            paramCount++;
        }
        if (updates.shelf !== undefined) {
            updateFields.push(`shelf = $${paramCount}`);
            updateParams.push(updates.shelf);
            paramCount++;
        }
        if (updates.type !== undefined) {
            updateFields.push(`type = $${paramCount}`);
            updateParams.push(updates.type);
            paramCount++;
        }
        if (updates.active !== undefined) {
            updateFields.push(`active = $${paramCount}`);
            updateParams.push(updates.active);
            paramCount++;
        }
        if (updateFields.length === 0) {
            return await this.getBinLocation(binId);
        }
        updateParams.push(binId);
        const result = await client.query(`UPDATE bin_locations
       SET ${updateFields.join(', ')}
       WHERE bin_id = $${paramCount}
       RETURNING *`, updateParams);
        if (result.rows.length === 0) {
            throw new Error(`Bin location ${binId} not found`);
        }
        logger_1.logger.info('Bin location updated', { binId });
        return this.mapRowToBinLocation(result.rows[0]);
    }
    /**
     * Delete a bin location
     */
    async deleteBinLocation(binId) {
        const client = await (0, client_1.getPool)();
        // Check if location has inventory
        const inventoryResult = await client.query(`SELECT COUNT(*) as count FROM inventory_units WHERE bin_location = $1`, [binId]);
        const inventoryCount = parseInt(inventoryResult.rows[0].count, 10);
        if (inventoryCount > 0) {
            throw new Error(`Cannot delete bin location ${binId} because it has ${inventoryCount} inventory units`);
        }
        await client.query(`DELETE FROM bin_locations WHERE bin_id = $1`, [binId]);
        logger_1.logger.info('Bin location deleted', { binId });
    }
    /**
     * Batch create bin locations
     */
    async batchCreateBinLocations(dtos) {
        const created = [];
        const failed = [];
        for (const dto of dtos) {
            try {
                const location = await this.createBinLocation(dto);
                created.push(location);
            }
            catch (error) {
                failed.push({ dto, error: error instanceof Error ? error.message : 'Unknown error' });
            }
        }
        logger_1.logger.info('Batch bin location creation completed', {
            total: dtos.length,
            created: created.length,
            failed: failed.length,
        });
        return { created, failed };
    }
    /**
     * Get available zones
     */
    async getZones() {
        const client = await (0, client_1.getPool)();
        const result = await client.query(`SELECT DISTINCT zone FROM bin_locations WHERE active = true ORDER BY zone`);
        return result.rows.map(row => row.zone);
    }
    /**
     * Get bin locations by zone
     */
    async getBinLocationsByZone(zone) {
        const client = await (0, client_1.getPool)();
        const result = await client.query(`SELECT * FROM bin_locations WHERE zone = $1 AND active = true ORDER BY aisle, shelf`, [zone]);
        return result.rows.map(row => this.mapRowToBinLocation(row));
    }
    // ==========================================================================
    // MAPPING METHODS
    // ==========================================================================
    mapRowToBinLocation(row) {
        return {
            binId: row.bin_id,
            zone: row.zone,
            aisle: row.aisle,
            shelf: row.shelf,
            type: row.type,
            active: row.active,
        };
    }
}
exports.BinLocationService = BinLocationService;
// Singleton instance
exports.binLocationService = new BinLocationService();
//# sourceMappingURL=BinLocationService.js.map