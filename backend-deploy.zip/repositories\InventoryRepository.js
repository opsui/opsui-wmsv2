"use strict";
/**
 * Inventory repository
 *
 * Handles all database operations for inventory units and transactions
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.inventoryRepository = exports.InventoryRepository = void 0;
const BaseRepository_1 = require("./BaseRepository");
const client_1 = require("../db/client");
const shared_1 = require("@opsui/shared");
// ============================================================================
// INVENTORY REPOSITORY
// ============================================================================
class InventoryRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super('inventory_units', 'unit_id');
    }
    // --------------------------------------------------------------------------
    // FIND BY SKU
    // --------------------------------------------------------------------------
    async findBySKU(sku) {
        const result = await (0, client_1.query)(`SELECT * FROM inventory_units WHERE sku = $1 ORDER BY bin_location`, [sku]);
        return result.rows;
    }
    // --------------------------------------------------------------------------
    // FIND BY BIN LOCATION
    // --------------------------------------------------------------------------
    async findByBinLocation(binLocation) {
        const result = await (0, client_1.query)(`SELECT * FROM inventory_units WHERE bin_location = $1`, [binLocation]);
        return result.rows;
    }
    // --------------------------------------------------------------------------
    // GET AVAILABLE INVENTORY FOR SKU
    // --------------------------------------------------------------------------
    async getAvailableInventory(sku) {
        const result = await (0, client_1.query)(`SELECT bin_location, available
       FROM inventory_units
       WHERE sku = $1 AND available > 0
       ORDER BY available DESC`, [sku]);
        return result.rows.map((row) => ({
            binLocation: row.bin_location,
            available: row.available,
        }));
    }
    // --------------------------------------------------------------------------
    // GET TOTAL AVAILABLE FOR SKU
    // --------------------------------------------------------------------------
    async getTotalAvailable(sku) {
        const result = await (0, client_1.query)(`SELECT COALESCE(SUM(available), 0) as total
       FROM inventory_units
       WHERE sku = $1`, [sku]);
        return parseInt(result.rows[0].total, 10);
    }
    // --------------------------------------------------------------------------
    // RESERVE INVENTORY
    // --------------------------------------------------------------------------
    async reserveInventory(sku, binLocation, quantity, orderId) {
        return this.withTransaction(async (client) => {
            // Check availability
            const checkResult = await client.query(`SELECT available FROM inventory_units
         WHERE sku = $1 AND bin_location = $2 FOR UPDATE`, [sku, binLocation]);
            if (checkResult.rows.length === 0) {
                throw new shared_1.NotFoundError('Inventory unit', `${sku} at ${binLocation}`);
            }
            const available = parseInt(checkResult.rows[0].available, 10);
            if (available < quantity) {
                throw new shared_1.ConflictError(`Insufficient inventory at ${binLocation}. Available: ${available}, requested: ${quantity}`);
            }
            // Reserve the inventory
            const result = await client.query(`UPDATE inventory_units
         SET reserved = reserved + $1, last_updated = NOW()
         WHERE sku = $2 AND bin_location = $3
         RETURNING *`, [quantity, sku, binLocation]);
            // Log the reservation
            await client.query(`INSERT INTO inventory_transactions (transaction_id, type, sku, quantity, order_id, reason, bin_location)
         VALUES ($1, 'RESERVATION', $2, $3, $4, 'Order allocation', $5)`, [`TXN-RES-${orderId}-${sku}-${Date.now()}`, sku, quantity, orderId, binLocation]);
            return result.rows[0];
        });
    }
    // --------------------------------------------------------------------------
    // RELEASE RESERVATION
    // --------------------------------------------------------------------------
    async releaseReservation(sku, binLocation, quantity, orderId) {
        const result = await (0, client_1.query)(`UPDATE inventory_units
       SET reserved = GREATEST(0, reserved - $1), last_updated = NOW()
       WHERE sku = $2 AND bin_location = $3
       RETURNING *`, [quantity, sku, binLocation]);
        if (result.rows.length === 0) {
            throw new shared_1.NotFoundError('Inventory unit', `${sku} at ${binLocation}`);
        }
        // Log the release
        await (0, client_1.query)(`INSERT INTO inventory_transactions (transaction_id, type, sku, quantity, order_id, reason, bin_location)
       VALUES ($1, 'CANCELLATION', $2, $3, $4, 'Reservation released', $5)`, [`TXN-REL-${orderId}-${sku}-${Date.now()}`, sku, quantity, orderId, binLocation]);
        return result.rows[0];
    }
    // --------------------------------------------------------------------------
    // DEDUCT INVENTORY (at shipping)
    // --------------------------------------------------------------------------
    async deductInventory(sku, binLocation, quantity, orderId) {
        return this.withTransaction(async (client) => {
            // Check sufficient quantity
            const checkResult = await client.query(`SELECT quantity, reserved FROM inventory_units
         WHERE sku = $1 AND bin_location = $2 FOR UPDATE`, [sku, binLocation]);
            if (checkResult.rows.length === 0) {
                throw new shared_1.NotFoundError('Inventory unit', `${sku} at ${binLocation}`);
            }
            const { quantity: currentQty } = checkResult.rows[0];
            if (currentQty < quantity) {
                throw new shared_1.ConflictError(`Insufficient inventory to deduct. Current: ${currentQty}, requested: ${quantity}`);
            }
            // Deduct from both quantity and reserved
            const result = await client.query(`UPDATE inventory_units
         SET quantity = quantity - $1,
             reserved = GREATEST(0, reserved - $1),
             last_updated = NOW()
         WHERE sku = $2 AND bin_location = $3
         RETURNING *`, [quantity, sku, binLocation]);
            // Log the deduction
            await client.query(`INSERT INTO inventory_transactions (transaction_id, type, sku, quantity, order_id, reason, bin_location)
         VALUES ($1, 'DEDUCTION', $2, $3, $4, 'Order shipped', $5)`, [`TXN-DED-${orderId}-${sku}-${Date.now()}`, sku, -quantity, orderId, binLocation]);
            return result.rows[0];
        });
    }
    // --------------------------------------------------------------------------
    // ADJUST INVENTORY (manual correction)
    // --------------------------------------------------------------------------
    async adjustInventory(sku, binLocation, quantity, userId, reason) {
        return this.withTransaction(async (client) => {
            const result = await client.query(`INSERT INTO inventory_units (unit_id, sku, bin_location, quantity, reserved, last_updated)
         VALUES ($1, $2, $3, $4, 0, NOW())
         ON CONFLICT (sku, bin_location)
         DO UPDATE SET
           quantity = inventory_units.quantity + $4,
           last_updated = NOW()
         RETURNING *`, [`IU-${sku}-${binLocation}`, sku, binLocation, quantity]);
            // Log the adjustment
            await client.query(`INSERT INTO inventory_transactions (transaction_id, type, sku, quantity, user_id, reason, bin_location)
         VALUES ($1, 'ADJUSTMENT', $2, $3, $4, $5, $6)`, [`TXN-ADJ-${sku}-${Date.now()}`, sku, quantity, userId, reason, binLocation]);
            return result.rows[0];
        });
    }
    // --------------------------------------------------------------------------
    // GET TRANSACTION HISTORY
    // --------------------------------------------------------------------------
    async getTransactionHistory(filters = {}) {
        const conditions = [];
        const params = [];
        let paramIndex = 1;
        if (filters.sku) {
            conditions.push(`sku = $${paramIndex++}`);
            params.push(filters.sku);
        }
        if (filters.orderId) {
            conditions.push(`order_id = $${paramIndex++}`);
            params.push(filters.orderId);
        }
        if (filters.type) {
            conditions.push(`type = $${paramIndex++}`);
            params.push(filters.type);
        }
        const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';
        const limit = filters.limit || 50;
        const offset = filters.offset || 0;
        // Count total
        const countResult = await (0, client_1.query)(`SELECT COUNT(*) FROM inventory_transactions ${whereClause}`, params);
        const total = parseInt(countResult.rows[0].count, 10);
        // Fetch transactions
        const transactionsResult = await (0, client_1.query)(`SELECT * FROM inventory_transactions
       ${whereClause}
       ORDER BY timestamp DESC
       LIMIT $${paramIndex++} OFFSET $${paramIndex++}`, [...params, limit, offset]);
        return {
            transactions: transactionsResult.rows,
            total,
        };
    }
    // --------------------------------------------------------------------------
    // GET LOW STOCK ALERTS
    // --------------------------------------------------------------------------
    async getLowStock(threshold = 10) {
        const result = await (0, client_1.query)(`SELECT sku, bin_location, available, quantity
       FROM inventory_units
       WHERE available < $1
       ORDER BY available ASC`, [threshold]);
        return result.rows.map((row) => ({
            sku: row.sku,
            binLocation: row.bin_location,
            available: row.available,
            quantity: row.quantity,
        }));
    }
    // --------------------------------------------------------------------------
    // RECONCILE INVENTORY
    // --------------------------------------------------------------------------
    async reconcileInventory(sku) {
        // Calculate expected from orders
        const expectedResult = await (0, client_1.query)(`SELECT SUM(quantity) as total FROM order_items oi
       INNER JOIN orders o ON oi.order_id = o.order_id
       WHERE oi.sku = $1 AND o.status NOT IN ('CANCELLED', 'SHIPPED')`, [sku]);
        const expected = parseInt(expectedResult.rows[0].total || '0', 10);
        // Get actual inventory
        const actualResult = await (0, client_1.query)(`SELECT SUM(quantity - reserved) as total FROM inventory_units WHERE sku = $1`, [sku]);
        const actual = parseInt(actualResult.rows[0].total || '0', 10);
        // Get per-bin discrepancies
        const discrepanciesResult = await (0, client_1.query)(`SELECT bin_location,
         SUM(quantity - reserved) as actual,
         0 as expected
       FROM inventory_units
       WHERE sku = $1
       GROUP BY bin_location`, [sku]);
        return {
            expected,
            actual,
            discrepancies: discrepanciesResult.rows.map(row => ({
                binLocation: row.bin_location,
                expected: parseInt(row.expected, 10),
                actual: parseInt(row.actual, 10),
                difference: parseInt(row.actual, 10) - parseInt(row.expected, 10),
            })),
        };
    }
}
exports.InventoryRepository = InventoryRepository;
// Singleton instance
exports.inventoryRepository = new InventoryRepository();
//# sourceMappingURL=InventoryRepository.js.map