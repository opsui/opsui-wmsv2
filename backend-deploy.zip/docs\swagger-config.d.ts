/**
 * OpenAPI/Swagger Configuration
 *
 * This file configures Swagger UI for API documentation
 */
export declare const swaggerSpec: object;
//# sourceMappingURL=swagger-config.d.ts.map