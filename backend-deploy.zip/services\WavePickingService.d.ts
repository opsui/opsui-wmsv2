/**
 * Wave Picking Service
 *
 * Implements wave picking optimization for warehouse operations.
 * Wave picking groups orders into "waves" based on criteria like:
 * - Shipping carrier/cutoff
 * - Order priority
 * - SKU compatibility
 * - Zone proximity
 * - Delivery deadlines
 *
 * Benefits:
 * - Reduced travel distance by picking similar orders together
 * - Better warehouse flow management
 * - Improved picker efficiency
 * - Enhanced carrier compliance
 *
 * References:
 * - Wave vs Batch Picking Comparison
 * - Dynamic Order Batching for WMS
 */
import { PickTask } from './RouteOptimizationService';
interface UserContext {
    userId?: string | number;
    userEmail?: string;
    userRole?: string;
    ipAddress?: string;
    userAgent?: string;
    requestId?: string;
}
export declare enum WaveStrategy {
    CARRIER = "CARRIER",// Group by shipping carrier
    PRIORITY = "PRIORITY",// Group by order priority
    ZONE = "ZONE",// Group by warehouse zone
    DEADLINE = "DEADLINE",// Group by delivery deadline
    SKU_COMPATIBILITY = "SKU_COMPATIBILITY",// Group by shared SKUs
    BALANCED = "BALANCED"
}
export declare enum WaveStatus {
    PLANNED = "PLANNED",
    RELEASED = "RELEASED",
    IN_PROGRESS = "IN_PROGRESS",
    COMPLETED = "COMPLETED",
    CANCELLED = "CANCELLED"
}
export interface WaveCriteria {
    strategy: WaveStrategy;
    maxOrdersPerWave?: number;
    maxOrdersPerPicker?: number;
    carrierCutoff?: Date;
    priority?: ('LOW' | 'NORMAL' | 'HIGH' | 'URGENT')[];
    zones?: string[];
    deadline?: Date;
    minSkuOverlap?: number;
}
export interface Wave {
    waveId: string;
    name: string;
    status: WaveStatus;
    criteria: WaveCriteria;
    orderIds: string[];
    pickTasks: PickTask[];
    assignedPickers: string[];
    estimatedTime: number;
    estimatedDistance: number;
    startedAt?: Date;
    completedAt?: Date;
    createdAt: Date;
    createdBy: string;
}
export interface WaveSummary {
    waveId: string;
    name: string;
    status: WaveStatus;
    orderCount: number;
    itemCount: number;
    pickerCount: number;
    progress: number;
    estimatedTimeRemaining: number;
}
export declare class WavePickingService {
    private pool;
    constructor();
    /**
     * Create a new wave based on criteria
     */
    createWave(criteria: WaveCriteria, context: UserContext): Promise<Wave>;
    /**
     * Release a wave (make it active for picking)
     */
    releaseWave(waveId: string, context: UserContext): Promise<Wave>;
    /**
     * Get wave status and progress
     */
    getWaveStatus(waveId: string): Promise<WaveSummary | null>;
    /**
     * Get active waves for a picker
     */
    getActiveWavesForPicker(pickerId: string): Promise<WaveSummary[]>;
    /**
     * Complete a wave
     */
    completeWave(waveId: string, context: UserContext): Promise<void>;
    /**
     * Fetch orders that match wave criteria
     */
    private fetchOrdersForWave;
    /**
     * Extract pick tasks from orders
     */
    private extractPickTasks;
    /**
     * Assign pickers to a wave
     */
    private assignPickers;
    /**
     * Assign tasks to specific pickers
     */
    private assignTasksToPickers;
    /**
     * Get completed pick count for a wave
     */
    private getCompletedPickCount;
    /**
     * Get wave from database
     */
    private getWave;
    /**
     * Save wave to database
     */
    private saveWave;
    /**
     * Update wave in database
     */
    private updateWave;
    /**
     * Generate a unique wave ID
     */
    private generateWaveId;
    /**
     * Generate a human-readable wave name
     */
    private generateWaveName;
}
export declare const wavePickingService: WavePickingService;
export default wavePickingService;
//# sourceMappingURL=WavePickingService.d.ts.map