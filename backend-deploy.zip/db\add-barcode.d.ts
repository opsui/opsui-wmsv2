/**
 * Add barcode field to SKUs
 */
declare function addBarcodes(): Promise<void>;
export { addBarcodes };
//# sourceMappingURL=add-barcode.d.ts.map