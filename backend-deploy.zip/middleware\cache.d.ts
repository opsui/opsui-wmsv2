/**
 * Response Caching Middleware
 *
 * Provides simple in-memory response caching for GET requests
 * to reduce database load and improve response times
 */
import { Request, Response, NextFunction } from 'express';
interface CacheOptions {
    ttl?: number;
    varyBy?: string[];
}
export declare let cacheCleanupInterval: null;
/**
 * Cache middleware factory
 *
 * @param options - Cache configuration options
 * @returns Express middleware function
 *
 * @example
 * ```ts
 * app.get('/api/orders', cache({ ttl: 60000 }), getOrders);
 * ```
 */
export declare function cache(options?: CacheOptions): (req: Request, res: Response, next: NextFunction) => void;
/**
 * Invalidate cache entries by pattern
 *
 * @param pattern - Cache key pattern to match (supports simple string matching)
 */
export declare function invalidateCache(pattern: string): void;
/**
 * Clear all cache entries
 */
export declare function clearCache(): void;
/**
 * Get cache statistics
 */
export declare function getCacheStats(): {
    size: number;
    keys: string[];
};
/**
 * Decorator to mark a route for caching
 *
 * @example
 * ```ts
 * router.get('/orders', cacheResponse({ ttl: 60000 }), async (req, res) => {
 *   const orders = await getOrders();
 *   res.json(orders);
 * });
 * ```
 */
export declare function cacheResponse(options?: CacheOptions): (req: Request, res: Response, next: NextFunction) => void;
export {};
//# sourceMappingURL=cache.d.ts.map