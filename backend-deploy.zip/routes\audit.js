"use strict";
/**
 * Audit Logs Routes
 *
 * Provides access to comprehensive audit logs for SOC2/ISO27001 compliance
 */
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const AuditService_1 = require("../services/AuditService");
const auth_1 = require("../middleware/auth");
const shared_1 = require("@opsui/shared");
const middleware_1 = require("../middleware");
const router = (0, express_1.Router)();
/**
 * GET /api/audit/logs
 * Get audit logs with optional filters
 * Requires ADMIN or SUPERVISOR role
 */
router.get('/logs', auth_1.authenticate, (0, auth_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR), (0, middleware_1.asyncHandler)(async (req, res) => {
    const auditService = (0, AuditService_1.getAuditService)();
    // Parse query parameters
    const options = {};
    if (req.query.userId) {
        options.userId = String(req.query.userId);
    }
    if (req.query.username) {
        options.username = req.query.username;
    }
    if (req.query.category) {
        options.category = req.query.category;
    }
    if (req.query.action) {
        options.action = req.query.action;
    }
    if (req.query.resourceType) {
        options.resourceType = req.query.resourceType;
    }
    if (req.query.resourceId) {
        options.resourceId = req.query.resourceId;
    }
    if (req.query.startDate) {
        options.startDate = new Date(req.query.startDate);
    }
    if (req.query.endDate) {
        options.endDate = new Date(req.query.endDate);
    }
    if (req.query.limit) {
        options.limit = parseInt(req.query.limit);
    }
    if (req.query.offset) {
        options.offset = parseInt(req.query.offset);
    }
    const logs = await auditService.query(options);
    res.json(logs);
}));
/**
 * GET /api/audit/logs/:id
 * Get a specific audit log by ID
 * Requires ADMIN or SUPERVISOR role
 */
router.get('/logs/:id', auth_1.authenticate, (0, auth_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR), (0, middleware_1.asyncHandler)(async (req, res) => {
    const auditService = (0, AuditService_1.getAuditService)();
    const id = parseInt(req.params.id);
    const log = await auditService.getById(id);
    if (!log) {
        res.status(404).json({ error: 'Audit log not found' });
        return;
    }
    res.json(log);
}));
/**
 * GET /api/audit/statistics
 * Get audit log statistics
 * Requires ADMIN or SUPERVISOR role
 */
router.get('/statistics', auth_1.authenticate, (0, auth_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR), (0, middleware_1.asyncHandler)(async (req, res) => {
    const auditService = (0, AuditService_1.getAuditService)();
    // Parse date range (default to last 30 days)
    const startDate = req.query.startDate
        ? new Date(req.query.startDate)
        : new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
    const endDate = req.query.endDate ? new Date(req.query.endDate) : new Date();
    const stats = await auditService.getStatistics(startDate, endDate);
    res.json(stats);
}));
/**
 * GET /api/audit/resource/:resourceType/:resourceId
 * Get audit history for a specific resource
 * Requires ADMIN or SUPERVISOR role
 */
router.get('/resource/:resourceType/:resourceId', auth_1.authenticate, (0, auth_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR), (0, middleware_1.asyncHandler)(async (req, res) => {
    const auditService = (0, AuditService_1.getAuditService)();
    const { resourceType, resourceId } = req.params;
    const limit = req.query.limit ? parseInt(req.query.limit) : 50;
    const logs = await auditService.getResourceHistory(resourceType, resourceId, limit);
    res.json(logs);
}));
/**
 * GET /api/audit/user/:userId
 * Get audit history for a specific user
 * Requires ADMIN or SUPERVISOR role
 */
router.get('/user/:userId', auth_1.authenticate, (0, auth_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR), (0, middleware_1.asyncHandler)(async (req, res) => {
    const auditService = (0, AuditService_1.getAuditService)();
    const userId = String(req.params.userId);
    const limit = req.query.limit ? parseInt(req.query.limit) : 100;
    const logs = await auditService.getUserActivity(userId, limit);
    res.json(logs);
}));
/**
 * GET /api/audit/security-events
 * Get security-related events (failed logins, suspicious activity, etc.)
 * Requires ADMIN or SUPERVISOR role
 */
router.get('/security-events', auth_1.authenticate, (0, auth_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR), (0, middleware_1.asyncHandler)(async (req, res) => {
    const auditService = (0, AuditService_1.getAuditService)();
    // Parse date range (default to last 7 days)
    const startDate = req.query.startDate
        ? new Date(req.query.startDate)
        : new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
    const endDate = req.query.endDate ? new Date(req.query.endDate) : new Date();
    const logs = await auditService.getSecurityEvents(startDate, endDate);
    res.json(logs);
}));
/**
 * GET /api/audit/categories
 * Get all available audit categories
 * Requires ADMIN or SUPERVISOR role
 */
router.get('/categories', auth_1.authenticate, (0, auth_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR), (0, middleware_1.asyncHandler)(async (_req, res) => {
    const categories = Object.values(AuditService_1.AuditCategory);
    res.json(categories);
}));
/**
 * GET /api/audit/actions
 * Get all available audit event types
 * Requires ADMIN or SUPERVISOR role
 */
router.get('/actions', auth_1.authenticate, (0, auth_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR), (0, middleware_1.asyncHandler)(async (_req, res) => {
    const actions = Object.values(AuditService_1.AuditEventType);
    res.json(actions);
}));
/**
 * GET /api/audit/users
 * Get all unique user emails from audit logs
 * Requires ADMIN or SUPERVISOR role
 */
router.get('/users', auth_1.authenticate, (0, auth_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR), (0, middleware_1.asyncHandler)(async (_req, res) => {
    const auditService = (0, AuditService_1.getAuditService)();
    const logs = await auditService.query({ limit: 10000 });
    // Extract unique user emails
    const userEmails = Array.from(new Set(logs.map(log => log.userEmail).filter(Boolean))).sort();
    res.json(userEmails);
}));
/**
 * GET /api/audit/resource-types
 * Get all unique resource types from audit logs
 * Requires ADMIN or SUPERVISOR role
 */
router.get('/resource-types', auth_1.authenticate, (0, auth_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR), (0, middleware_1.asyncHandler)(async (_req, res) => {
    const auditService = (0, AuditService_1.getAuditService)();
    const logs = await auditService.query({ limit: 10000 });
    // Extract unique resource types
    const resourceTypes = Array.from(new Set(logs.map(log => log.resourceType).filter(Boolean))).sort();
    res.json(resourceTypes);
}));
exports.default = router;
//# sourceMappingURL=audit.js.map