"use strict";
/**
 * User management routes
 *
 * Provides endpoints for listing users (admin only)
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const UserRepository_1 = require("../repositories/UserRepository");
const middleware_1 = require("../middleware");
const shared_1 = require("@opsui/shared");
const router = (0, express_1.Router)();
const userRepo = new UserRepository_1.UserRepository();
// Helper middleware to check if user is admin
// ADMIN base role always has access (same as authorize middleware)
const requireAdmin = (req, res, next) => {
    if (req.user?.baseRole !== shared_1.UserRole.ADMIN) {
        res.status(403).json({
            error: 'Admin access required',
            code: 'FORBIDDEN',
        });
        return;
    }
    next();
};
/**
 * GET /api/users
 * Get all users (admin only)
 */
router.get('/', middleware_1.authenticate, requireAdmin, (0, middleware_1.asyncHandler)(async (_req, res) => {
    const users = await userRepo.getAllUsers();
    res.json(users);
}));
/**
 * GET /api/users/assignable
 * Get users that can be assigned tasks (authenticated users)
 * Returns basic info (userId, name, role) for active users who can perform work
 */
router.get('/assignable', middleware_1.authenticate, (0, middleware_1.asyncHandler)(async (_req, res) => {
    const assignableRoles = [
        shared_1.UserRole.PICKER,
        shared_1.UserRole.PACKER,
        shared_1.UserRole.STOCK_CONTROLLER,
        shared_1.UserRole.SUPERVISOR,
        shared_1.UserRole.ADMIN,
        shared_1.UserRole.INWARDS,
    ];
    const assignableUsers = await userRepo.getAssignableUsers(assignableRoles);
    res.json(assignableUsers);
}));
/**
 * POST /api/users
 * Create a new user (admin only)
 */
router.post('/', middleware_1.authenticate, requireAdmin, (0, middleware_1.asyncHandler)(async (req, res) => {
    const { name, email, password, role } = req.body;
    // Validate required fields
    if (!name || !email || !password) {
        res.status(400).json({
            error: 'name, email, and password are required',
            code: 'MISSING_FIELDS',
        });
        return;
    }
    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        res.status(400).json({
            error: 'Invalid email format',
            code: 'INVALID_EMAIL',
        });
        return;
    }
    // Validate password (minimum 6 characters)
    if (password.length < 6) {
        res.status(400).json({
            error: 'Password must be at least 6 characters long',
            code: 'INVALID_PASSWORD',
        });
        return;
    }
    // Validate role
    if (!role || !Object.values(shared_1.UserRole).includes(role)) {
        res.status(400).json({
            error: 'Invalid role',
            code: 'INVALID_ROLE',
        });
        return;
    }
    // Generate user ID
    const { generateUserId } = await Promise.resolve().then(() => __importStar(require('@opsui/shared')));
    const userId = generateUserId();
    const newUser = await userRepo.createUserWithPassword({
        userId,
        name,
        email,
        password,
        role,
    });
    console.log('[POST /users] User created:', newUser);
    res.status(201).json(newUser);
}));
/**
 * DELETE /api/users/:userId
 * Soft delete a user (mark for deletion, admin only)
 *
 * User will be marked as deleted and inaccessible for 3 days.
 * After 3 days, the user will be permanently deleted.
 * Admin can restore the user during the 3-day grace period.
 */
router.delete('/:userId', middleware_1.authenticate, requireAdmin, (0, middleware_1.asyncHandler)(async (req, res) => {
    const { userId } = req.params;
    console.log('[DELETE /users/:userId] Soft deleting user:', userId);
    // Use soft delete - marks user for deletion
    const deletedUser = await userRepo.softDeleteUser(userId);
    console.log('[DELETE /users/:userId] User marked for deletion:', deletedUser);
    // Return the user object with deleted_at timestamp
    res.json(deletedUser);
}));
/**
 * POST /api/users/:userId/restore
 * Restore a soft-deleted user (admin only)
 *
 * Clears the deleted_at timestamp, preventing permanent deletion.
 * User will be accessible and editable again.
 */
router.post('/:userId/restore', middleware_1.authenticate, requireAdmin, (0, middleware_1.asyncHandler)(async (req, res) => {
    const { userId } = req.params;
    console.log('[POST /users/:userId/restore] Restoring user:', userId);
    // Restore user - clears deleted_at timestamp
    const restoredUser = await userRepo.restoreUser(userId);
    console.log('[POST /users/:userId/restore] User restored:', restoredUser);
    // Return the restored user object
    res.json(restoredUser);
}));
/**
 * PATCH /api/users/:userId
 * Update a user (admin only)
 */
router.patch('/:userId', middleware_1.authenticate, requireAdmin, (0, middleware_1.asyncHandler)(async (req, res) => {
    const { userId } = req.params;
    const { name, email, role, active } = req.body;
    const updatedUser = await userRepo.updateUser(userId, {
        name,
        email,
        role,
        active,
    });
    res.json(updatedUser);
}));
exports.default = router;
//# sourceMappingURL=users.js.map