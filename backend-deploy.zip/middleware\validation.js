"use strict";
/**
 * Request validation middleware using Joi
 *
 * Validates request bodies, query parameters, and route parameters
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.validate = exports.schemas = exports.commonSchemas = void 0;
exports.validateBody = validateBody;
exports.validateQuery = validateQuery;
exports.validateParams = validateParams;
const joi_1 = __importDefault(require("joi"));
const shared_1 = require("@opsui/shared");
const logger_1 = require("../config/logger");
// ============================================================================
// VALIDATION MIDDLEWARE
// ============================================================================
/**
 * Validate request body against a Joi schema
 */
function validateBody(schema) {
    return (req, _res, next) => {
        const { error, value } = schema.validate(req.body, {
            abortEarly: false,
            stripUnknown: true,
        });
        if (error) {
            const details = error.details.map(detail => ({
                field: detail.path.join('.'),
                message: detail.message,
            }));
            logger_1.logger.debug('Validation failed', { details });
            throw new shared_1.ValidationError('Validation failed', details);
        }
        // Replace request body with validated and sanitized value
        req.body = value;
        next();
    };
}
/**
 * Validate request query parameters against a Joi schema
 */
function validateQuery(schema) {
    return (req, _res, next) => {
        const { error, value } = schema.validate(req.query, {
            abortEarly: false,
            stripUnknown: true,
        });
        if (error) {
            const details = error.details.map(detail => ({
                field: detail.path.join('.'),
                message: detail.message,
            }));
            logger_1.logger.debug('Query validation failed', { details });
            throw new shared_1.ValidationError('Query validation failed', details);
        }
        req.query = value;
        next();
    };
}
/**
 * Validate request route parameters against a Joi schema
 */
function validateParams(schema) {
    return (req, _res, next) => {
        const { error, value } = schema.validate(req.params, {
            abortEarly: false,
            stripUnknown: true,
        });
        if (error) {
            const details = error.details.map(detail => ({
                field: detail.path.join('.'),
                message: detail.message,
            }));
            logger_1.logger.debug('Params validation failed', { details });
            throw new shared_1.ValidationError('Params validation failed', details);
        }
        req.params = value;
        next();
    };
}
// ============================================================================
// COMMON VALIDATION SCHEMAS
// ============================================================================
exports.commonSchemas = {
    // ID validation
    id: joi_1.default.string().required().min(1).max(100),
    // Order ID - accepts SO{number}, ORD-XXX, ORD-YYYY-XXX, and ORD-YYYYMMDD-XXX formats
    orderId: joi_1.default.string()
        .pattern(/^(SO[1-9][0-9]{3,4}|ORD-[0-9]{3}|ORD-[0-9]{4}-[0-9]{3}|ORD-[0-9]{8}-[0-9]{3})$/)
        .required()
        .messages({
        'string.pattern.base': 'Order ID must match format SO{number}, ORD-XXX, ORD-YYYY-XXX, or ORD-YYYYMMDD-XXX',
    }),
    // SKU
    sku: joi_1.default.string()
        .pattern(/^[A-Z0-9-]{2,50}$/)
        .required()
        .messages({
        'string.pattern.base': 'SKU must be 2-50 alphanumeric characters (A-Z, 0-9, hyphens)',
    }),
    // Bin location
    binLocation: joi_1.default.string()
        .pattern(/^[A-Z]-[0-9]{1,3}-[0-9]{2}$/)
        .required()
        .messages({
        'string.pattern.base': 'Bin location must match format ZONE-AISLE-SHELF (e.g., A-12-03)',
    }),
    // Email
    email: joi_1.default.string()
        .pattern(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)
        .required()
        .messages({
        'string.pattern.base': 'Must be a valid email address',
    }),
    // Quantity
    quantity: joi_1.default.number().integer().positive().required().messages({
        'number.base': 'Quantity must be a number',
        'number.integer': 'Quantity must be a whole number',
        'number.positive': 'Quantity must be greater than 0',
    }),
    // Priority
    priority: joi_1.default.string().valid('LOW', 'NORMAL', 'HIGH', 'URGENT').required(),
    // Status
    status: joi_1.default.string()
        .valid('PENDING', 'PICKING', 'PICKED', 'PACKING', 'PACKED', 'SHIPPED', 'CANCELLED', 'BACKORDER')
        .required(),
    // Pagination
    pagination: {
        page: joi_1.default.number().integer().min(1).default(1),
        limit: joi_1.default.number().integer().min(1).max(100).default(20),
        sortBy: joi_1.default.string().default('createdAt'),
        sortOrder: joi_1.default.string().valid('asc', 'desc').default('desc'),
    },
};
// ============================================================================
// SPECIFIC VALIDATION SCHEMAS
// ============================================================================
exports.schemas = {
    // Create order
    createOrder: joi_1.default.object({
        customerId: joi_1.default.string().required(),
        customerName: joi_1.default.string().required().min(2).max(255),
        priority: exports.commonSchemas.priority,
        items: joi_1.default.array()
            .items(joi_1.default.object({
            sku: exports.commonSchemas.sku,
            quantity: exports.commonSchemas.quantity,
        }))
            .min(1)
            .required()
            .messages({
            'array.min': 'Order must have at least one item',
        }),
    }),
    // Claim order
    claimOrder: joi_1.default.object({
        pickerId: exports.commonSchemas.id,
    }),
    // Pick item
    pickItem: joi_1.default.object({
        sku: exports.commonSchemas.sku,
        quantity: exports.commonSchemas.quantity,
        binLocation: exports.commonSchemas.binLocation,
        pickTaskId: exports.commonSchemas.id,
    }).custom((value, helpers) => {
        // Handle both camelCase and snake_case
        const binLocation = value.binLocation || value.bin_location;
        const pickTaskId = value.pickTaskId || value.pick_task_id;
        if (!binLocation) {
            return helpers.error('binLocation is required');
        }
        if (!pickTaskId) {
            return helpers.error('pickTaskId is required');
        }
        return value;
    }),
    // Complete order
    completeOrder: joi_1.default.object({
        orderId: exports.commonSchemas.orderId,
        pickerId: exports.commonSchemas.id,
    }),
    // Cancel order
    cancelOrder: joi_1.default.object({
        orderId: exports.commonSchemas.orderId,
        userId: exports.commonSchemas.id,
        reason: joi_1.default.string().required().min(5).max(500),
    }),
    // Create user
    createUser: joi_1.default.object({
        name: joi_1.default.string().required().min(2).max(100),
        email: exports.commonSchemas.email,
        password: joi_1.default.string().required().min(8).max(100),
        role: joi_1.default.string().valid('PICKER', 'PACKER', 'SUPERVISOR', 'ADMIN').required(),
    }),
    // Update user
    updateUser: joi_1.default.object({
        name: joi_1.default.string().min(2).max(100),
        email: exports.commonSchemas.email,
        role: joi_1.default.string().valid('PICKER', 'PACKER', 'SUPERVISOR', 'ADMIN'),
        active: joi_1.default.boolean(),
    }),
    // Login
    login: joi_1.default.object({
        email: exports.commonSchemas.email,
        password: joi_1.default.string().required(),
    }),
    // Query params for order list
    orderQuery: joi_1.default.object({
        status: exports.commonSchemas.status,
        priority: exports.commonSchemas.priority,
        pickerId: exports.commonSchemas.id,
        page: joi_1.default.number().integer().min(1).default(1),
        limit: joi_1.default.number().integer().min(1).max(100).default(20),
    }),
    // Query params for SKU list
    skuQuery: joi_1.default.object({
        category: joi_1.default.string(),
        active: joi_1.default.boolean(),
        page: joi_1.default.number().integer().min(1).default(1),
        limit: joi_1.default.number().integer().min(1).max(100).default(20),
    }),
};
// ============================================================================
// VALIDATION MIDDLEWARE FACTORIES
// ============================================================================
exports.validate = {
    createOrder: validateBody(exports.schemas.createOrder),
    claimOrder: validateBody(exports.schemas.claimOrder),
    pickItem: validateBody(exports.schemas.pickItem),
    completeOrder: validateBody(exports.schemas.completeOrder),
    cancelOrder: validateBody(exports.schemas.cancelOrder),
    createUser: validateBody(exports.schemas.createUser),
    updateUser: validateBody(exports.schemas.updateUser),
    login: validateBody(exports.schemas.login),
    orderQuery: validateQuery(exports.schemas.orderQuery),
    skuQuery: validateQuery(exports.schemas.skuQuery),
    orderId: validateParams(joi_1.default.object({ orderId: exports.commonSchemas.orderId })),
    sku: validateParams(joi_1.default.object({ sku: exports.commonSchemas.sku })),
    userId: validateParams(joi_1.default.object({ userId: exports.commonSchemas.id })),
};
//# sourceMappingURL=validation.js.map