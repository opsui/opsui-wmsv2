/**
 * Manufacturing Service
 *
 * Business logic for manufacturing operations
 * Handles work centers, routings, MPS, MRP, production orders,
 * shop floor control, quality, and capacity planning
 */
import type { WorkCenter, WorkCenterQueue, CreateWorkCenterDTO, Routing, RoutingWithDetails, CreateRoutingDTO, MRPPlan, CreateMRPPlanDTO, ManufacturingOrder, ManufacturingOrderWithDetails, CreateManufacturingOrderDTO, ReleaseProductionOrderDTO, ShopFloorTransaction, CreateShopFloorTransactionDTO, CapacityPlan, CreateCapacityPlanDTO, ManufacturingDashboardMetrics, WorkCenterQueryFilters, RoutingQueryFilters, ProductionOrderQueryFilters, MRPPlanQueryFilters, CapacityPlanQueryFilters, ProductionOrderOperation } from '@opsui/shared';
export declare class ManufacturingService {
    /**
     * Create a new work center
     */
    createWorkCenter(dto: CreateWorkCenterDTO): Promise<WorkCenter>;
    /**
     * Get work centers with filters
     */
    getWorkCenters(filters?: WorkCenterQueryFilters): Promise<WorkCenter[]>;
    /**
     * Get work center with queue
     */
    getWorkCenterWithQueue(workCenterId: string): Promise<(WorkCenter & {
        queue: WorkCenterQueue | null;
    }) | null>;
    /**
     * Create a new routing
     */
    createRouting(dto: CreateRoutingDTO): Promise<RoutingWithDetails>;
    /**
     * Generate unique routing number
     */
    private generateUniqueRoutingNumber;
    /**
     * Get routings with filters
     */
    getRoutings(filters?: RoutingQueryFilters): Promise<Routing[]>;
    /**
     * Get routing with details
     */
    getRoutingWithDetails(routingId: string): Promise<RoutingWithDetails | null>;
    /**
     * Create a production order
     */
    createProductionOrder(dto: CreateManufacturingOrderDTO): Promise<ManufacturingOrderWithDetails>;
    /**
     * Generate unique production order number
     */
    private generateUniqueProductionOrderNumber;
    /**
     * Release production order
     */
    releaseProductionOrder(dto: ReleaseProductionOrderDTO): Promise<ManufacturingOrder>;
    /**
     * Get production orders with filters
     */
    getProductionOrders(filters?: ProductionOrderQueryFilters): Promise<ManufacturingOrder[]>;
    /**
     * Get production order with details
     */
    getProductionOrderWithDetails(orderId: string): Promise<ManufacturingOrderWithDetails | null>;
    /**
     * Get active production orders
     */
    getActiveProductionOrders(): Promise<ManufacturingOrder[]>;
    /**
     * Create shop floor transaction
     */
    createShopFloorTransaction(dto: CreateShopFloorTransactionDTO): Promise<ShopFloorTransaction>;
    /**
     * Record quantity completion
     */
    recordQuantityCompletion(productionOrderId: string, operationId: string, quantity: number, scrap: number, userId: string): Promise<ProductionOrderOperation>;
    /**
     * Create MRP plan
     */
    createMRPPlan(dto: CreateMRPPlanDTO): Promise<MRPPlan>;
    /**
     * Generate unique MRP plan number
     */
    private generateUniqueMRPPlanNumber;
    /**
     * Get MRP plans with filters
     */
    getMRPPlans(filters?: MRPPlanQueryFilters): Promise<MRPPlan[]>;
    /**
     * Get pending MRP actions
     */
    getPendingMRPActions(planId?: string): Promise<any[]>;
    /**
     * Create capacity plan
     */
    createCapacityPlan(dto: CreateCapacityPlanDTO): Promise<CapacityPlan>;
    /**
     * Generate unique capacity plan number
     */
    private generateUniqueCapacityPlanNumber;
    /**
     * Get capacity plans with filters
     */
    getCapacityPlans(filters?: CapacityPlanQueryFilters): Promise<CapacityPlan[]>;
    /**
     * Get overloaded work centers
     */
    getOverloadedWorkCenters(): Promise<any[]>;
    /**
     * Get manufacturing dashboard metrics
     */
    getDashboardMetrics(entityId?: string): Promise<ManufacturingDashboardMetrics>;
}
export declare const manufacturingService: ManufacturingService;
//# sourceMappingURL=ManufacturingService.d.ts.map