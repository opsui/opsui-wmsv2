/**
 * Run the feature_flags migration (010)
 */
export {};
//# sourceMappingURL=run-feature-flags-migration.d.ts.map