/**
 * Developer Routes
 *
 * Development and debugging tools
 * Only available in development environment
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=developer.d.ts.map