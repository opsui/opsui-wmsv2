/**
 * Barcode Scanning Routes
 *
 * API endpoints for barcode/QR code scanning operations in the warehouse.
 * Supports:
 * - SKU barcode lookup
 * - Bin location scanning
 * - Pick confirmation via barcode
 * - Inventory verification via barcode
 * - Mobile warehouse operations
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=barcode.d.ts.map