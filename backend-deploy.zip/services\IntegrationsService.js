"use strict";
/**
 * Integrations Service
 *
 * Business logic for managing external system integrations (ERP, e-commerce, carriers)
 * Handles sync jobs, webhook processing, and carrier account management
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.IntegrationsService = void 0;
const shared_1 = require("@opsui/shared");
// ============================================================================
// SERVICE
// ============================================================================
class IntegrationsService {
    repository;
    constructor(repository) {
        this.repository = repository;
    }
    // ========================================================================
    // INTEGRATION MANAGEMENT
    // ========================================================================
    async createIntegration(integration) {
        // Validate configuration based on provider
        this.validateConfiguration(integration.provider, integration.configuration);
        // For carrier integrations, require webhook settings for shipment updates
        if (integration.type === shared_1.IntegrationType.CARRIER && !integration.webhookSettings) {
            throw new Error('Carrier integrations require webhook settings for shipment updates');
        }
        const created = await this.repository.create(integration);
        // Create initial sync job to test connection
        await this.createSyncJob(created.integrationId, 'FULL', 'system');
        return created;
    }
    async updateIntegration(integrationId, updates) {
        const existing = await this.repository.findById(integrationId);
        if (!existing) {
            throw new Error('Integration not found');
        }
        // Validate configuration if being updated
        if (updates.configuration && updates.provider) {
            this.validateConfiguration(updates.provider, updates.configuration);
        }
        return this.repository.update(integrationId, updates);
    }
    async deleteIntegration(integrationId) {
        return this.repository.delete(integrationId);
    }
    async testConnection(integrationId) {
        const integration = await this.repository.findById(integrationId);
        if (!integration) {
            throw new Error('Integration not found');
        }
        const startTime = Date.now();
        try {
            // Simulate connection test based on provider type
            await this.performProviderConnectionTest(integration);
            const latency = Date.now() - startTime;
            return {
                success: true,
                message: 'Connection successful',
                latency,
            };
        }
        catch (error) {
            return {
                success: false,
                message: error.message || 'Connection failed',
            };
        }
    }
    // ========================================================================
    // SYNC JOB MANAGEMENT
    // ========================================================================
    async createSyncJob(integrationId, syncType, triggeredBy) {
        const integration = await this.repository.findById(integrationId);
        if (!integration) {
            throw new Error('Integration not found');
        }
        if (integration.status !== shared_1.IntegrationStatus.CONNECTED) {
            throw new Error('Integration must be connected to run sync jobs');
        }
        const job = await this.repository.createSyncJob({
            integrationId,
            syncType,
            direction: integration.syncSettings.direction,
            status: shared_1.SyncStatus.PENDING,
            startedAt: new Date(),
            startedBy: triggeredBy,
            recordsProcessed: 0,
            recordsSucceeded: 0,
            recordsFailed: 0,
        });
        // Start the sync job asynchronously
        this.executeSyncJob(job.jobId, integration).catch(error => {
            console.error(`Failed to execute sync job ${job.jobId}:`, error);
        });
        return job;
    }
    async executeSyncJob(jobId, integration) {
        try {
            // Update status to running
            await this.repository.updateSyncJob(jobId, {
                status: shared_1.SyncStatus.RUNNING,
            });
            await this.repository.createSyncLogEntry(jobId, {
                level: 'INFO',
                message: `Starting ${integration.type} sync job`,
                errorDetails: { provider: integration.provider },
            });
            // Execute sync based on integration type
            const result = await this.performSync(integration);
            // Update job with results
            await this.repository.updateSyncJob(jobId, {
                status: shared_1.SyncStatus.COMPLETED,
                recordsProcessed: result.totalProcessed,
                recordsSucceeded: result.succeeded,
                recordsFailed: result.failed,
                completedAt: new Date(),
            });
            // Update integration last sync
            await this.repository.update(integration.integrationId, {
                lastSyncAt: new Date(),
            });
            await this.repository.createSyncLogEntry(jobId, {
                level: result.failed > 0 ? 'WARN' : 'INFO',
                message: `Sync completed: ${result.succeeded} succeeded, ${result.failed} failed`,
                errorDetails: result,
            });
        }
        catch (error) {
            // Update job with error
            await this.repository.updateSyncJob(jobId, {
                status: shared_1.SyncStatus.FAILED,
                completedAt: new Date(),
                errorMessage: error.message,
            });
            await this.repository.createSyncLogEntry(jobId, {
                level: 'ERROR',
                message: 'Sync job failed',
                errorDetails: { error: error.message },
            });
            // Update integration last sync
            await this.repository.update(integration.integrationId, {
                lastSyncAt: new Date(),
                lastError: error.message,
            });
        }
    }
    async performSync(integration) {
        // Provider-specific sync implementation
        switch (integration.provider) {
            case shared_1.IntegrationProvider.SAP:
            case shared_1.IntegrationProvider.ORACLE:
                return this.syncErpSystem(integration);
            case shared_1.IntegrationProvider.SHOPIFY:
            case shared_1.IntegrationProvider.WOOCOMMERCE:
            case shared_1.IntegrationProvider.MAGENTO:
                return this.syncEcommercePlatform(integration);
            case shared_1.IntegrationProvider.FEDEX:
            case shared_1.IntegrationProvider.UPS:
            case shared_1.IntegrationProvider.DHL:
            case shared_1.IntegrationProvider.USPS:
                return this.syncCarrierSystem(integration);
            default:
                throw new Error(`Unsupported provider: ${integration.provider}`);
        }
    }
    async syncErpSystem(_integration) {
        // ERP sync implementation
        // This would connect to SAP/Oracle APIs and sync inventory, orders, etc.
        return {
            totalProcessed: 0,
            succeeded: 0,
            failed: 0,
            details: { message: 'ERP sync not yet implemented' },
        };
    }
    async syncEcommercePlatform(_integration) {
        // E-commerce sync implementation
        // This would connect to Shopify/WooCommerce APIs and sync orders, products
        return {
            totalProcessed: 0,
            succeeded: 0,
            failed: 0,
            details: { message: 'E-commerce sync not yet implemented' },
        };
    }
    async syncCarrierSystem(_integration) {
        // Carrier sync implementation
        // This would connect to carrier APIs and sync shipment statuses
        return {
            totalProcessed: 0,
            succeeded: 0,
            failed: 0,
            details: { message: 'Carrier sync not yet implemented' },
        };
    }
    // ========================================================================
    // WEBHOOK HANDLING
    // ========================================================================
    async handleWebhook(integrationId, eventType, payload) {
        const integration = await this.repository.findById(integrationId);
        if (!integration) {
            throw new Error('Integration not found');
        }
        // Create webhook event record
        const event = await this.repository.createWebhookEvent({
            integrationId,
            eventType,
            payload,
            status: 'PENDING',
            processingAttempts: 0,
        });
        // Process webhook asynchronously
        this.processWebhookEvent(event.eventId, integration).catch(error => {
            console.error(`Failed to process webhook event ${event.eventId}:`, error);
        });
        return event;
    }
    async processWebhookEvent(eventId, integration) {
        try {
            const event = await this.findWebhookEvent(eventId);
            if (!event || event.status === 'PROCESSED') {
                return;
            }
            // Process based on event type
            await this.executeWebhookAction(event, integration);
            // Mark as processed
            await this.repository.updateWebhookEvent(eventId, {
                status: 'PROCESSED',
                processedAt: new Date(),
                processingAttempts: (event.processingAttempts || 0) + 1,
            });
        }
        catch (error) {
            // Check if we should retry
            const event = await this.findWebhookEvent(eventId);
            if (event && event.processingAttempts < 3) {
                await this.repository.updateWebhookEvent(eventId, {
                    status: 'PENDING',
                    processingAttempts: event.processingAttempts + 1,
                    errorMessage: error.message,
                });
                // Schedule retry with exponential backoff
                const delay = Math.pow(2, event.processingAttempts) * 1000;
                setTimeout(() => {
                    this.processWebhookEvent(eventId, integration).catch(() => { });
                }, delay);
            }
            else {
                // Max retries reached, mark as failed
                await this.repository.updateWebhookEvent(eventId, {
                    status: 'FAILED',
                    errorMessage: `Max retries exceeded: ${error.message}`,
                });
            }
        }
    }
    async executeWebhookAction(event, integration) {
        switch (event.eventType) {
            case shared_1.WebhookEventType.ORDER_CREATED:
                await this.handleOrderCreated(event.payload, integration);
                break;
            case shared_1.WebhookEventType.ORDER_UPDATED:
                await this.handleOrderUpdated(event.payload, integration);
                break;
            case shared_1.WebhookEventType.ORDER_CANCELLED:
                await this.handleOrderCancelled(event.payload, integration);
                break;
            case shared_1.WebhookEventType.PRODUCT_UPDATED:
                await this.handleProductUpdated(event.payload, integration);
                break;
            case shared_1.WebhookEventType.INVENTORY_UPDATED:
                await this.handleInventoryUpdated(event.payload, integration);
                break;
            case shared_1.WebhookEventType.TRACKING_UPDATED:
                await this.handleShipmentStatusUpdate(event.payload, integration);
                break;
            default:
                throw new Error(`Unsupported webhook event type: ${event.eventType}`);
        }
    }
    async handleOrderCreated(payload, _integration) {
        // Handle order creation from e-commerce platform
        console.log('Handling order created webhook:', payload.orderId);
    }
    async handleOrderUpdated(payload, _integration) {
        // Handle order update from e-commerce platform
        console.log('Handling order updated webhook:', payload.orderId);
    }
    async handleOrderCancelled(payload, _integration) {
        // Handle order cancellation from e-commerce platform
        console.log('Handling order cancelled webhook:', payload.orderId);
    }
    async handleProductUpdated(payload, _integration) {
        // Handle product update from e-commerce platform
        console.log('Handling product updated webhook:', payload.productId);
    }
    async handleInventoryUpdated(payload, _integration) {
        // Handle inventory update from ERP system
        console.log('Handling inventory updated webhook:', payload.sku);
    }
    async handleShipmentStatusUpdate(payload, _integration) {
        // Handle shipment status update from carrier
        console.log('Handling shipment status update webhook:', payload.trackingNumber);
    }
    async findWebhookEvent(eventId) {
        const events = await this.repository.findWebhookEvents({}, 1);
        return events.find(e => e.eventId === eventId) || null;
    }
    // ========================================================================
    // CARRIER ACCOUNT MANAGEMENT
    // ========================================================================
    async createCarrierAccount(integrationId, account) {
        const integration = await this.repository.findById(integrationId);
        if (!integration) {
            throw new Error('Integration not found');
        }
        if (integration.type !== shared_1.IntegrationType.CARRIER) {
            throw new Error('Carrier accounts can only be added to carrier integrations');
        }
        return this.repository.createCarrierAccount(account);
    }
    async updateCarrierAccount(carrierAccountId, updates) {
        return this.repository.updateCarrierAccount(carrierAccountId, updates);
    }
    async deleteCarrierAccount(carrierAccountId) {
        return this.repository.deleteCarrierAccount(carrierAccountId);
    }
    // ========================================================================
    // PRIVATE HELPER METHODS
    // ========================================================================
    validateConfiguration(provider, configuration) {
        const requiredAuthFields = this.getRequiredFieldsForProvider(provider);
        const missingFields = requiredAuthFields.filter(field => !configuration.auth?.[field]);
        if (missingFields.length > 0) {
            throw new Error(`Missing required auth configuration fields for ${provider}: ${missingFields.join(', ')}`);
        }
    }
    getRequiredFieldsForProvider(provider) {
        switch (provider) {
            case shared_1.IntegrationProvider.SAP:
                return ['host', 'port', 'username', 'client'];
            case shared_1.IntegrationProvider.ORACLE:
                return ['host', 'port', 'service', 'username'];
            case shared_1.IntegrationProvider.SHOPIFY:
                return ['shopDomain', 'accessToken'];
            case shared_1.IntegrationProvider.WOOCOMMERCE:
                return ['storeUrl', 'consumerKey', 'consumerSecret'];
            case shared_1.IntegrationProvider.MAGENTO:
                return ['storeUrl', 'apiToken'];
            case shared_1.IntegrationProvider.FEDEX:
                return ['apiKey', 'secretKey', 'accountNumber'];
            case shared_1.IntegrationProvider.UPS:
                return ['accessLicenseNumber', 'userId', 'password'];
            case shared_1.IntegrationProvider.DHL:
                return ['siteId', 'password'];
            case shared_1.IntegrationProvider.USPS:
                return ['userId'];
            default:
                return [];
        }
    }
    async performProviderConnectionTest(integration) {
        // Simulate connection test
        // In production, this would make actual API calls to verify credentials
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                if (integration.configuration.auth.apiKey === 'invalid') {
                    reject(new Error('Invalid API credentials'));
                }
                else {
                    resolve();
                }
            }, 500);
        });
    }
}
exports.IntegrationsService = IntegrationsService;
//# sourceMappingURL=IntegrationsService.js.map