/**
 * @purpose: Email provider service - multi-provider email delivery with fallback
 * @domain: Notifications
 * @tested: No tests yet (0% coverage)
 * @last-change: 2025-01-25 - Initial implementation
 * @dependencies: @sendgrid/mail, postmark, @aws-sdk/client-ses, logger
 * @description: Sends emails via SendGrid (primary), Postmark (fallback), or SES (backup)
 * @invariants: All emails have valid recipient(s), subject, and body
 * @performance: Rate limiting and connection pooling for bulk sends
 * @security: API keys stored in environment variables, templates sanitized
 */
import { EmailParams } from '@opsui/shared';
export type EmailProviderType = 'sendgrid' | 'postmark' | 'ses';
export interface EmailResult {
    success: boolean;
    messageId?: string;
    provider: EmailProviderType;
    error?: string;
    errorCode?: string;
}
export interface EmailProviderConfig {
    sendgrid?: {
        apiKey: string;
        from?: string;
        replyTo?: string;
    };
    postmark?: {
        apiKey: string;
        from?: string;
        replyTo?: string;
    };
    ses?: {
        region: string;
        accessKeyId: string;
        secretAccessKey: string;
        from?: string;
    };
}
export declare class EmailProvider {
    private providers;
    private config;
    private preferredOrder;
    constructor(config: EmailProviderConfig);
    private initializeProviders;
    sendEmail(params: EmailParams): Promise<EmailResult>;
    private sendWithProvider;
    private sendWithSendGrid;
    private sendWithPostmark;
    private sendWithSES;
    bulkSend(emails: EmailParams[], rateLimitMs?: number): Promise<EmailResult[]>;
    renderTemplate(template: string, variables: Record<string, any>): string;
    private isValidEmail;
    private getDefaultFrom;
    private getDefaultReplyTo;
    private sleep;
    healthCheck(): Promise<Record<EmailProviderType, boolean>>;
    getAvailableProviders(): EmailProviderType[];
}
export declare function getEmailProvider(): EmailProvider;
//# sourceMappingURL=EmailProvider.d.ts.map