/**
 * Run the add_dispatch_and_accounting_roles migration
 */
export {};
//# sourceMappingURL=run-dispatch-accounting-migration.d.ts.map