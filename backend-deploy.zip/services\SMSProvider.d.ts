/**
 * @purpose: SMS provider service - Twilio integration for SMS notifications
 * @domain: Notifications
 * @tested: No tests yet (0% coverage)
 * @last-change: 2025-01-25 - Initial implementation
 * @dependencies: twilio, logger
 * @description: Sends SMS messages via Twilio with phone validation and rate limiting
 * @invariants: All SMS messages have valid recipient phone numbers and non-empty content
 * @performance: Rate limiting and cost tracking for bulk sends
 * @security: API keys stored in environment variables, phone numbers validated
 */
import { SMSParams } from '@opsui/shared';
export interface SMSResult {
    success: boolean;
    messageId?: string;
    error?: string;
    errorCode?: string;
    cost?: number;
}
export interface SMSProviderConfig {
    accountSid: string;
    authToken: string;
    from?: string;
    rateLimitPerSecond?: number;
}
export interface SMSStats {
    sent: number;
    failed: number;
    totalCost: number;
}
export declare class SMSProvider {
    private client;
    private config;
    private sendTimes;
    private stats;
    constructor(config: SMSProviderConfig);
    private initializeClient;
    sendSMS(params: SMSParams): Promise<SMSResult>;
    bulkSend(messages: SMSParams[], rateLimitMs?: number): Promise<SMSResult[]>;
    isValidPhoneNumber(phone: string): boolean;
    normalizePhoneNumber(phone: string): string | null;
    private enforceRateLimit;
    private calculateRateLimitMs;
    lookupPhoneNumber(phone: string): Promise<{
        valid: boolean;
        phoneNumber?: string;
        carrier?: string;
        type?: string;
        error?: string;
    }>;
    getStats(): SMSStats;
    resetStats(): void;
    healthCheck(): Promise<boolean>;
    private maskPhoneNumber;
    private sleep;
    calculateSegments(message: string): number;
    private isGSMEncoding;
    estimateCost(message: string, destinationCountry?: string): number;
}
export declare function getSMSProvider(): SMSProvider | null;
//# sourceMappingURL=SMSProvider.d.ts.map