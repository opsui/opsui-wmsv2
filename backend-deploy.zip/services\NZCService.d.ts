/**
 * NZC (NZ Couriers) API Service
 *
 * Handles integration with the NZC Sweetspot API for shipping rates,
 * shipment creation, and label generation.
 *
 * API Documentation: https://api.gosweetspot.com
 */
/**
 * NZC Destination Address
 */
export interface NZCDestination {
    Name: string;
    NameDisplay?: string;
    Address: {
        StreetAddress: string;
        Suburb: string;
        Postcode: string;
        Country: string;
        State?: string;
    };
    ContactPerson?: string;
    PhoneNumber?: string;
    Email?: string;
}
/**
 * NZC Package dimensions
 */
export interface NZCPackage {
    Length: number;
    Width: number;
    Height: number;
    Kg: number;
    Units: number;
}
/**
 * NZC Rate Request
 */
export interface NZCRateRequest {
    Destination: NZCDestination;
    Packages: NZCPackage[];
    Origin?: {
        Name: string;
        Address: {
            StreetAddress: string;
            Suburb: string;
            Postcode: string;
            Country: string;
        };
    };
}
/**
 * NZC Quote response
 */
export interface NZCQuote {
    QuoteId: string;
    Carrier: string;
    Service: string;
    TotalPrice: number;
    TransitDays?: number;
    Description?: string;
}
/**
 * NZC Rate Response
 */
export interface NZCRateResponse {
    Quotes: NZCQuote[];
    Suppressed: any[];
    Rejected: Array<{
        Carrier: string;
        Reason: string;
    }>;
    ValidationErrors: Record<string, string>;
}
/**
 * NZC Shipment Request (same as rate request + QuoteId)
 */
export interface NZCShipmentRequest extends NZCRateRequest {
    QuoteId: string;
}
/**
 * NZC Shipment Response
 */
export interface NZCShipmentResponse {
    ConsignmentNo: string;
    ConsignmentId: string;
    Packages: Array<{
        ConsignmentNo: string;
        ConsignmentId: string;
    }>;
}
/**
 * NZC Label Format options
 */
export declare enum NZCLabelFormat {
    PNG_100X175 = "LABEL_PNG_100X175",
    PNG_100X150 = "LABEL_PNG_100X150",
    PDF_100X175 = "LABEL_PDF_100X175",
    PDF = "LABEL_PDF"
}
export declare class NZCService {
    private readonly baseUrl;
    private readonly apiKey;
    private readonly siteId;
    private readonly supportEmail;
    constructor();
    /**
     * Get request headers for NZC API
     */
    private getHeaders;
    /**
     * Convert WMS Address to NZC Destination format
     * Note: Unused private method kept for API completeness
     */
    private _addressToNZCDestination;
    /**
     * Convert weight from lbs to kg (NZC uses kg)
     * Note: Unused private method kept for API completeness
     */
    private _lbsToKg;
    /**
     * Convert dimensions from inches to cm (NZC uses cm)
     * Note: Unused private method kept for API completeness
     */
    private _inchesToCm;
    /**
     * Get shipping rates from NZC
     */
    getRates(destination: NZCDestination, packages: NZCPackage[]): Promise<NZCRateResponse>;
    /**
     * Create a shipment with NZC
     */
    createShipment(destination: NZCDestination, packages: NZCPackage[], quoteId: string): Promise<NZCShipmentResponse>;
    /**
     * Get shipping label as base64 data
     */
    getLabel(connote: string, format?: NZCLabelFormat): Promise<{
        data: string;
        contentType: string;
        format: string;
    }>;
    /**
     * Requeue shipment for printing (simpler print method)
     */
    reprintLabel(connote: string, copies?: number, printerName?: string): Promise<void>;
    /**
     * Get available printers from NZC
     */
    getPrinters(): Promise<any[]>;
    /**
     * Get available stock sizes from NZC
     */
    getStockSizes(): Promise<any[]>;
}
export declare const nzcService: NZCService;
//# sourceMappingURL=NZCService.d.ts.map