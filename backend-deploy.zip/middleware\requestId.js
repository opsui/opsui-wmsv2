"use strict";
/**
 * Request ID Middleware
 *
 * Generates and tracks unique request IDs for log correlation and debugging
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.requestId = requestId;
exports.enhanceLoggerWithRequestId = enhanceLoggerWithRequestId;
const uuid_1 = require("uuid");
const logger_1 = require("../config/logger");
// ============================================================================
// REQUEST ID MIDDLEWARE
// ============================================================================
/**
 * Generate and attach unique request ID to each request
 *
 * Request IDs are used for:
 * - Log correlation across services
 * - Debugging and troubleshooting
 * - Tracing request flow through the system
 * - Client-side error reporting
 */
function requestId(req, res, next) {
    // Get request ID from header or generate new one
    const requestId = req.get('X-Request-ID') || (0, uuid_1.v4)();
    // Attach to request
    req.id = requestId;
    // Set response header for client reference
    res.setHeader('X-Request-ID', requestId);
    // Log request ID for correlation
    logger_1.logger.debug('Request started', {
        requestId,
        method: req.method,
        path: req.path,
        ip: req.ip,
    });
    next();
}
// ============================================================================
// REQUEST ID LOGGING ENHANCER
// ============================================================================
/**
 * Enhance logger to include request ID automatically
 * This ensures all logs for a request are correlated
 */
function enhanceLoggerWithRequestId(req, _res, next) {
    if (req.id) {
        // Add request ID to all log context
        logger_1.logger.defaultMeta = {
            ...logger_1.logger.defaultMeta,
            requestId: req.id,
        };
    }
    next();
}
//# sourceMappingURL=requestId.js.map