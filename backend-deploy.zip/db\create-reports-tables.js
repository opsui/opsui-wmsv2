"use strict";
/**
 * Create reports tables
 */
Object.defineProperty(exports, "__esModule", { value: true });
const client_1 = require("./client");
const fs_1 = require("fs");
const path_1 = require("path");
async function createReportsTables() {
    console.log('Creating reports tables...');
    try {
        const migrationPath = (0, path_1.join)(__dirname, 'migrations', '014_create_reports.sql');
        const migrationSQL = (0, fs_1.readFileSync)(migrationPath, 'utf-8');
        // Remove comment lines
        const cleanedSQL = migrationSQL
            .split('\n')
            .filter(line => !line.trim().startsWith('--'))
            .join('\n');
        // Use pool directly for DDL statements (avoids row mapping issues)
        const pool = (0, client_1.getPool)();
        await pool.query(cleanedSQL);
        console.log('✓ Created reports tables');
        console.log('Migration completed successfully!');
    }
    catch (error) {
        console.error('✗ Migration failed:', error.message);
        throw error;
    }
}
createReportsTables()
    .then(() => {
    console.log('Done! Exiting...');
    process.exit(0);
})
    .catch(error => {
    console.error('Fatal error:', error);
    process.exit(1);
});
//# sourceMappingURL=create-reports-tables.js.map