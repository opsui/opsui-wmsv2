/**
 * Location Capacity Service
 *
 * Manages location capacity rules, utilization tracking, and alerts
 */
import { LocationCapacity, CapacityRule, CapacityAlert, CreateCapacityRuleDTO, AcknowledgeCapacityAlertDTO, CapacityType, CapacityRuleStatus } from '@opsui/shared';
export declare class LocationCapacityService {
    /**
     * Create a new capacity rule
     */
    createCapacityRule(dto: CreateCapacityRuleDTO): Promise<CapacityRule>;
    /**
     * Get all capacity rules
     */
    getAllCapacityRules(): Promise<CapacityRule[]>;
    /**
     * Get capacity rule by ID
     */
    getCapacityRule(ruleId: string): Promise<CapacityRule>;
    /**
     * Update capacity rule
     */
    updateCapacityRule(ruleId: string, updates: Partial<CreateCapacityRuleDTO> & {
        isActive?: boolean;
    }): Promise<CapacityRule>;
    /**
     * Delete capacity rule
     */
    deleteCapacityRule(ruleId: string): Promise<void>;
    /**
     * Get capacity for a specific location
     */
    getLocationCapacity(binLocation: string): Promise<LocationCapacity>;
    /**
     * Get all location capacities with optional filters
     */
    getAllLocationCapacities(filters?: {
        capacityType?: CapacityType;
        status?: CapacityRuleStatus;
        showAlertsOnly?: boolean;
        limit?: number;
        offset?: number;
    }): Promise<{
        capacities: LocationCapacity[];
        total: number;
    }>;
    /**
     * Recalculate capacity utilization for a location
     */
    recalculateLocationCapacity(binLocation: string): Promise<LocationCapacity>;
    /**
     * Update location capacity for a specific rule
     */
    private updateLocationCapacityForRule;
    /**
     * Create default location capacity
     */
    private createDefaultLocationCapacity;
    /**
     * Get all capacity alerts
     */
    getAllCapacityAlerts(filters?: {
        acknowledged?: boolean;
        alertType?: 'WARNING' | 'EXCEEDED' | 'CRITICAL';
        limit?: number;
        offset?: number;
    }): Promise<{
        alerts: CapacityAlert[];
        total: number;
    }>;
    /**
     * Acknowledge a capacity alert
     */
    acknowledgeCapacityAlert(dto: AcknowledgeCapacityAlertDTO): Promise<CapacityAlert>;
    /**
     * Create a capacity alert
     */
    private createCapacityAlert;
    /**
     * Apply capacity rule to matching locations
     */
    private applyCapacityRuleToLocations;
    /**
     * Get applicable capacity rules for a location
     */
    private getApplicableCapacityRules;
    private mapRowToCapacityRule;
    private mapRowToLocationCapacity;
    private mapRowToCapacityAlert;
}
export declare const locationCapacityService: LocationCapacityService;
//# sourceMappingURL=LocationCapacityService.d.ts.map