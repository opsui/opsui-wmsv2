/**
 * Automation Service
 *
 * Handles integration with ASRS, robots, drones, and other automation systems
 * for cycle counting and inventory management
 */
import { AutomationTask, CreateAutomationTaskDTO, AutomationTaskType, AutomationTaskStatus, RFIDScanResult } from '@opsui/shared';
export declare class AutomationService {
    /**
     * Create an automation task for cycle counting
     */
    createAutomationTask(dto: CreateAutomationTaskDTO): Promise<AutomationTask>;
    /**
     * Get automation task by ID
     */
    getAutomationTask(taskId: string): Promise<AutomationTask>;
    /**
     * Get pending tasks for a robot/system
     */
    getPendingTasks(assignedTo: string, taskType?: AutomationTaskType): Promise<AutomationTask[]>;
    /**
     * Update task status and result
     */
    updateTaskResult(taskId: string, status: AutomationTaskStatus, result?: {
        countedQuantity?: number;
        variance?: number;
        notes?: string;
    }): Promise<AutomationTask>;
    /**
     * Process cycle count result from automation
     */
    private processCycleCountResult;
    /**
     * Get or create a cycle count plan for automation counts
     */
    private getOrCreateAutomationCycleCountPlan;
    /**
     * Process RFID scan results
     */
    processRFIDScan(scanResult: RFIDScanResult): Promise<{
        matchedTags: number;
        unmatchedTags: string[];
    }>;
    /**
     * Get RFID scan summary for a location
     */
    getRFIDScanSummary(location: string): Promise<{
        totalTags: number;
        matchedSKUs: number;
        uniqueSKUs: string[];
        lastScan?: Date;
    }>;
    /**
     * Map database row to AutomationTask
     */
    private mapRowToAutomationTask;
}
export declare const automationService: AutomationService;
//# sourceMappingURL=AutomationService.d.ts.map