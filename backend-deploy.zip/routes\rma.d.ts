/**
 * RMA (Return Merchandise Authorization) Routes
 *
 * API endpoints for managing customer returns, warranty claims, and refurbishments
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=rma.d.ts.map