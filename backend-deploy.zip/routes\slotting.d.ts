/**
 * Warehouse Slotting Routes
 *
 * API endpoints for warehouse slotting optimization and ABC analysis
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=slotting.d.ts.map