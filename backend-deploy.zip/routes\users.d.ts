/**
 * User management routes
 *
 * Provides endpoints for listing users (admin only)
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=users.d.ts.map