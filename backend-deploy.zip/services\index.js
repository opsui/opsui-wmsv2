"use strict";
/**
 * Service index
 *
 * Exports all services for easy importing
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.authService = exports.metricsService = exports.inventoryService = exports.orderService = void 0;
__exportStar(require("./OrderService"), exports);
__exportStar(require("./InventoryService"), exports);
__exportStar(require("./MetricsService"), exports);
__exportStar(require("./AuthService"), exports);
__exportStar(require("./ModuleSubscriptionService"), exports);
// Re-export singleton instances
var OrderService_1 = require("./OrderService");
Object.defineProperty(exports, "orderService", { enumerable: true, get: function () { return OrderService_1.orderService; } });
var InventoryService_1 = require("./InventoryService");
Object.defineProperty(exports, "inventoryService", { enumerable: true, get: function () { return InventoryService_1.inventoryService; } });
var MetricsService_1 = require("./MetricsService");
Object.defineProperty(exports, "metricsService", { enumerable: true, get: function () { return MetricsService_1.metricsService; } });
var AuthService_1 = require("./AuthService");
Object.defineProperty(exports, "authService", { enumerable: true, get: function () { return AuthService_1.authService; } });
//# sourceMappingURL=index.js.map