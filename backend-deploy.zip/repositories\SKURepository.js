"use strict";
/**
 * SKU repository
 *
 * Handles all database operations for SKU catalog
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.skuRepository = exports.SKURepository = void 0;
const BaseRepository_1 = require("./BaseRepository");
const client_1 = require("../db/client");
const shared_1 = require("@opsui/shared");
// ============================================================================
// SKU REPOSITORY
// ============================================================================
class SKURepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super('skus', 'sku');
    }
    // --------------------------------------------------------------------------
    // FIND BY CATEGORY
    // --------------------------------------------------------------------------
    async findByCategory(category, activeOnly = true) {
        const result = await (0, client_1.query)(`SELECT * FROM skus
       WHERE category = $1 ${activeOnly ? 'AND active = true' : ''}
       ORDER BY name`, [category]);
        return result.rows;
    }
    // --------------------------------------------------------------------------
    // GET ALL SKUS
    // --------------------------------------------------------------------------
    async getAllSKUs(activeOnly = true, limit = 100) {
        const result = await (0, client_1.query)(`SELECT * FROM skus
       ${activeOnly ? 'WHERE active = true' : ''}
       ORDER BY name
       LIMIT $1`, [limit]);
        return result.rows;
    }
    // --------------------------------------------------------------------------
    // SEARCH SKUS
    // --------------------------------------------------------------------------
    async search(searchTerm, activeOnly = true) {
        const result = await (0, client_1.query)(`SELECT * FROM skus
       WHERE (sku ILIKE $1 OR name ILIKE $1 OR description ILIKE $1)
       ${activeOnly ? 'AND active = true' : ''}
       ORDER BY name
       LIMIT 50`, [`%${searchTerm}%`]);
        return result.rows;
    }
    // --------------------------------------------------------------------------
    // GET CATEGORIES
    // --------------------------------------------------------------------------
    async getCategories() {
        const result = await (0, client_1.query)(`SELECT DISTINCT category FROM skus WHERE active = true ORDER BY category`);
        return result.rows.map(row => row.category);
    }
    // --------------------------------------------------------------------------
    // CREATE SKU
    // --------------------------------------------------------------------------
    async createSKU(data) {
        // Check if SKU already exists
        const existing = await this.findById(data.sku);
        if (existing) {
            throw new shared_1.ConflictError('SKU already exists');
        }
        return this.withTransaction(async (client) => {
            // Create SKU
            await client.query(`INSERT INTO skus (sku, name, description, image, category, bin_locations, active)
         VALUES ($1, $2, $3, $4, $5, $6, true)
         RETURNING *`, [
                data.sku,
                data.name,
                data.description,
                data.image || null,
                data.category,
                data.binLocations,
            ]);
            // Create inventory units for each bin location
            for (const binLocation of data.binLocations) {
                await client.query(`INSERT INTO inventory_units (unit_id, sku, bin_location, quantity, reserved)
           VALUES ($1, $2, $3, 0, 0)
           ON CONFLICT (unit_id) DO NOTHING`, [`IU-${data.sku}-${binLocation}`, data.sku, binLocation]);
            }
            return this.findByIdOrThrow(data.sku);
        });
    }
    // --------------------------------------------------------------------------
    // UPDATE SKU
    // --------------------------------------------------------------------------
    async updateSKU(sku, data) {
        const updates = [];
        const params = [];
        let paramIndex = 1;
        if (data.name !== undefined) {
            updates.push(`name = $${paramIndex++}`);
            params.push(data.name);
        }
        if (data.description !== undefined) {
            updates.push(`description = $${paramIndex++}`);
            params.push(data.description);
        }
        if (data.image !== undefined) {
            updates.push(`image = $${paramIndex++}`);
            params.push(data.image);
        }
        if (data.category !== undefined) {
            updates.push(`category = $${paramIndex++}`);
            params.push(data.category);
        }
        if (data.binLocations !== undefined) {
            updates.push(`bin_locations = $${paramIndex++}`);
            params.push(data.binLocations);
        }
        if (data.active !== undefined) {
            updates.push(`active = $${paramIndex++}`);
            params.push(data.active);
        }
        if (updates.length === 0) {
            return this.findByIdOrThrow(sku);
        }
        updates.push(`updated_at = NOW()`);
        params.push(sku);
        const result = await (0, client_1.query)(`UPDATE skus SET ${updates.join(', ')} WHERE sku = $${paramIndex} RETURNING *`, params);
        if (result.rows.length === 0) {
            throw new shared_1.NotFoundError('SKU', sku);
        }
        return result.rows[0];
    }
    // --------------------------------------------------------------------------
    // DEACTIVATE SKU
    // --------------------------------------------------------------------------
    async deactivateSKU(sku) {
        return this.updateSKU(sku, { active: false });
    }
    // --------------------------------------------------------------------------
    // ACTIVATE SKU
    // --------------------------------------------------------------------------
    async activateSKU(sku) {
        return this.updateSKU(sku, { active: true });
    }
    // --------------------------------------------------------------------------
    // GET SKU WITH INVENTORY
    // --------------------------------------------------------------------------
    async getSKUWithInventory(sku) {
        const skuData = await this.findByIdOrThrow(sku);
        const inventoryResult = await (0, client_1.query)(`SELECT bin_location, quantity, available
       FROM inventory_units
       WHERE sku = $1
       ORDER BY bin_location`, [sku]);
        return {
            ...skuData,
            inventory: inventoryResult.rows,
        };
    }
}
exports.SKURepository = SKURepository;
// Singleton instance
exports.skuRepository = new SKURepository();
//# sourceMappingURL=SKURepository.js.map