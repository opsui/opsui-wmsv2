/**
 * Zone Picking Service
 *
 * Implements zone-based picking optimization for large warehouses.
 * Zone picking assigns pickers to specific zones to minimize travel
 * and increase throughput.
 *
 * Benefits:
 * - Reduced picker congestion
 * - Specialized picking per zone
 * - Better inventory organization
 * - Improved picker productivity
 *
 * References:
 * - Zone Picking vs Wave vs Batch
 * - Warehouse Zone Optimization
 */
interface UserContext {
    userId?: string | number;
    userEmail?: string;
    userRole?: string;
    ipAddress?: string;
    userAgent?: string;
    requestId?: string;
}
export interface Zone {
    zoneId: string;
    name: string;
    aisleStart: number;
    aisleEnd: number;
    zoneType: 'FAST_MOVING' | 'SLOW_MOVING' | 'BULK' | 'COLD_STORAGE' | 'HAZARDOUS' | 'REVERSE_LOGISTICS';
    locationCount: number;
    activePickers: number;
    currentUtilization: number;
}
export interface ZoneAssignment {
    pickerId: string;
    zoneId: string;
    assignedAt: Date;
    assignedBy: string;
    status: 'ACTIVE' | 'ON_BREAK' | 'COMPLETED';
    tasksCompleted: number;
    tasksRemaining: number;
}
export interface ZonePickTask {
    taskId: string;
    orderId: string;
    sku: string;
    quantity: number;
    binLocation: string;
    zone: string;
    priority: 'LOW' | 'NORMAL' | 'HIGH' | 'URGENT';
    status: 'PENDING' | 'IN_PROGRESS' | 'COMPLETED' | 'SKIPPED';
    assignedPicker?: string;
}
export interface ZoneStats {
    zoneId: string;
    pendingTasks: number;
    inProgressTasks: number;
    completedTasks: number;
    totalItems: number;
    estimatedTimeRemaining: number;
    activePickers: number;
    averageTimePerTask: number;
}
export declare class ZonePickingService {
    private pool;
    constructor();
    /**
     * Get all zones in the warehouse
     */
    getZones(): Promise<Zone[]>;
    /**
     * Get zone statistics
     */
    getZoneStats(zoneId: string): Promise<ZoneStats | null>;
    /**
     * Get all zone statistics
     */
    getAllZoneStats(): Promise<ZoneStats[]>;
    /**
     * Assign picker to zone
     */
    assignPickerToZone(pickerId: string, zoneId: string, context: UserContext): Promise<ZoneAssignment>;
    /**
     * Get pick tasks for a zone
     */
    getZonePickTasks(zoneId: string, status?: ('PENDING' | 'IN_PROGRESS' | 'COMPLETED' | 'SKIPPED')[]): Promise<ZonePickTask[]>;
    /**
     * Rebalance pickers across zones
     * Assigns pickers to zones with the most pending tasks
     */
    rebalancePickers(context: UserContext): Promise<void>;
    /**
     * Get zone by ID
     */
    private getZoneById;
    /**
     * Get human-readable zone name
     */
    private getZoneName;
    /**
     * Infer zone type based on zone ID
     */
    private inferZoneType;
    /**
     * Release picker from zone
     */
    releasePickerFromZone(pickerId: string, context: UserContext): Promise<void>;
}
export declare const zonePickingService: ZonePickingService;
export default zonePickingService;
//# sourceMappingURL=ZonePickingService.d.ts.map