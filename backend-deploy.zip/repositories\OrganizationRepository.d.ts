/**
 * Organization Repository
 *
 * Data access layer for multi-tenant organization management.
 * Handles organizations, memberships, invitations, and settings.
 */
import type { AssignOrganizationUserDTO, CreateInvitationDTO, CreateOrganizationDTO, Organization, OrganizationInvitation, OrganizationInvitationWithDetails, OrganizationQueryFilters, OrganizationSetting, OrganizationUser, OrganizationUserQueryFilters, OrganizationUserWithDetails, OrganizationWithStats, UpdateOrganizationDTO, UpdateOrganizationUserDTO } from '@opsui/shared';
import { OrganizationStatus, OrganizationTier } from '@opsui/shared';
import { BaseRepository } from './BaseRepository';
export declare class OrganizationRepository extends BaseRepository<Organization> {
    constructor();
    findBySlug(slug: string): Promise<Organization | null>;
    findByCode(code: string): Promise<Organization | null>;
    findByCustomDomain(domain: string): Promise<Organization | null>;
    findByIdWithStats(organizationId: string): Promise<OrganizationWithStats | null>;
    findAllWithFilters(filters: OrganizationQueryFilters, page?: number, pageSize?: number): Promise<{
        organizations: OrganizationWithStats[];
        total: number;
    }>;
    createOrganization(data: CreateOrganizationDTO): Promise<Organization>;
    updateOrganization(organizationId: string, data: UpdateOrganizationDTO, userId: string): Promise<Organization | null>;
    updateStatus(organizationId: string, status: OrganizationStatus, userId: string): Promise<Organization | null>;
    updateTier(organizationId: string, tier: OrganizationTier, userId: string): Promise<Organization | null>;
    private getTierLimits;
    private logAuditEvent;
}
export declare class OrganizationUserRepository extends BaseRepository<OrganizationUser> {
    constructor();
    findByOrganizationAndUser(organizationId: string, userId: string): Promise<OrganizationUser | null>;
    findUserOrganizations(userId: string): Promise<OrganizationUserWithDetails[]>;
    findOrganizationMembers(organizationId: string, filters?: OrganizationUserQueryFilters, page?: number, pageSize?: number): Promise<{
        members: OrganizationUserWithDetails[];
        total: number;
    }>;
    assignUser(data: AssignOrganizationUserDTO): Promise<OrganizationUser>;
    updateUserMembership(organizationId: string, userId: string, data: UpdateOrganizationUserDTO): Promise<OrganizationUser | null>;
    removeUser(organizationId: string, userId: string): Promise<boolean>;
    setPrimaryOrganization(userId: string, organizationId: string): Promise<void>;
    checkUserAccess(userId: string, organizationId: string): Promise<boolean>;
    getMemberCount(organizationId: string): Promise<number>;
}
export declare class OrganizationInvitationRepository extends BaseRepository<OrganizationInvitation> {
    constructor();
    findByToken(token: string): Promise<OrganizationInvitationWithDetails | null>;
    findPendingByEmail(email: string): Promise<OrganizationInvitationWithDetails[]>;
    findOrganizationInvitations(organizationId: string): Promise<OrganizationInvitation[]>;
    createInvitation(data: CreateInvitationDTO, invitedBy: string): Promise<OrganizationInvitation>;
    acceptInvitation(token: string, userId: string): Promise<{
        invitation: OrganizationInvitation;
        membership: OrganizationUser;
    } | null>;
    declineInvitation(token: string): Promise<OrganizationInvitation | null>;
    cancelInvitation(invitationId: string): Promise<boolean>;
    cleanupExpired(): Promise<number>;
}
export declare class OrganizationSettingRepository extends BaseRepository<OrganizationSetting> {
    constructor();
    getSetting(organizationId: string, key: string): Promise<OrganizationSetting | null>;
    getAllSettings(organizationId: string): Promise<OrganizationSetting[]>;
    upsertSetting(organizationId: string, key: string, value: string, type: "STRING" | "NUMBER" | "BOOLEAN" | "JSON" | undefined, userId: string): Promise<OrganizationSetting>;
    deleteSetting(organizationId: string, key: string): Promise<boolean>;
}
export declare const organizationRepository: OrganizationRepository;
export declare const organizationUserRepository: OrganizationUserRepository;
export declare const organizationInvitationRepository: OrganizationInvitationRepository;
export declare const organizationSettingRepository: OrganizationSettingRepository;
//# sourceMappingURL=OrganizationRepository.d.ts.map