/**
 * Purchasing Service
 *
 * Business logic for purchasing operations
 * Handles purchase requisitions, RFQs, purchase orders, receipts,
 * three-way matching, vendor catalogs, and vendor performance
 */
import type { PurchaseRequisition, PurchaseRequisitionWithDetails, CreatePurchaseRequisitionDTO, RequisitionApprovalDTO, RequisitionQueryFilters, RFQHeader, RFQHeaderWithDetails, RFQVendorResponse, CreateRFQDTO, AwardRFQDTO, VendorItemCatalog, CreateVendorCatalogItemDTO, PurchaseOrderHeader, PurchaseOrderWithDetails, CreatePurchaseOrderDTO, ConvertRequisitionToPODTO, PurchaseReceiptWithDetails, PurchaseReceiptLine, CreatePurchaseReceiptDTO, UpdateReceiptQualityDTO, ThreeWayMatchDetails, ThreeWayMatchSummary, ResolveVarianceDTO, VendorPerformanceSummary, VendorPerformanceEvent, CreateVendorEventDTO, VendorScorecard, CreateVendorScorecardDTO, PurchasingDashboardMetrics } from '@opsui/shared';
export declare class PurchasingService {
    /**
     * Create a new purchase requisition
     */
    createRequisition(dto: CreatePurchaseRequisitionDTO): Promise<PurchaseRequisitionWithDetails>;
    /**
     * Generate unique requisition number
     */
    private generateUniqueRequisitionNumber;
    /**
     * Submit requisition for approval
     */
    submitRequisition(requisitionId: string): Promise<PurchaseRequisition>;
    /**
     * Approve or reject requisition
     */
    processRequisitionApproval(dto: RequisitionApprovalDTO): Promise<PurchaseRequisition>;
    /**
     * Convert requisition to purchase order
     */
    convertRequisitionToPO(dto: ConvertRequisitionToPODTO): Promise<PurchaseOrderWithDetails>;
    /**
     * Query requisitions with filters
     */
    queryRequisitions(filters: RequisitionQueryFilters): Promise<PurchaseRequisition[]>;
    /**
     * Get requisition with details
     */
    getRequisitionWithDetails(requisitionId: string): Promise<PurchaseRequisitionWithDetails | null>;
    /**
     * Get pending approvals
     */
    getPendingApprovals(): Promise<PurchaseRequisitionWithDetails[]>;
    /**
     * Create RFQ from requisition or manually
     */
    createRFQ(dto: CreateRFQDTO): Promise<RFQHeaderWithDetails>;
    /**
     * Generate unique RFQ number
     */
    private generateUniqueRFQNumber;
    /**
     * Send RFQ to vendors
     */
    sendRFQ(rfqId: string): Promise<RFQHeader>;
    /**
     * Record vendor response to RFQ
     */
    recordVendorResponse(rfqVendorId: string, response: {
        quote_number?: string;
        quote_valid_until?: Date;
        contact_person?: string;
        contact_email?: string;
        contact_phone?: string;
        total_amount: number;
        total_tax: number;
        total_freight: number;
        payment_terms?: string;
        delivery_terms?: string;
        estimated_delivery_date?: Date;
        lead_time_days?: number;
        quote_document_url?: string;
        notes?: string;
        lines: Array<{
            rfq_line_id: string;
            vendor_item_code?: string;
            item_description: string;
            quantity: number;
            unit_price: number;
            discount_percent?: number;
            lead_time_days?: number;
            notes?: string;
        }>;
    }): Promise<RFQVendorResponse>;
    /**
     * Award RFQ to vendor and optionally convert to PO
     */
    awardRFQ(dto: AwardRFQDTO): Promise<{
        rfq: RFQHeader;
        po?: PurchaseOrderWithDetails;
    }>;
    /**
     * Get RFQ with details
     */
    getRFQWithDetails(rfqId: string): Promise<RFQHeaderWithDetails | null>;
    /**
     * Get RFQs awaiting response
     */
    getRFQsAwaitingResponse(): Promise<RFQHeaderWithDetails[]>;
    /**
     * Add item to vendor catalog
     */
    addVendorCatalogItem(dto: CreateVendorCatalogItemDTO): Promise<VendorItemCatalog>;
    /**
     * Get vendor catalog
     */
    getVendorCatalog(vendorId: string, activeOnly?: boolean): Promise<VendorItemCatalog[]>;
    /**
     * Find vendors for SKU
     */
    findVendorsForSKU(sku: string): Promise<VendorItemCatalog[]>;
    /**
     * Create purchase order
     */
    createPurchaseOrder(dto: CreatePurchaseOrderDTO): Promise<PurchaseOrderWithDetails>;
    /**
     * Generate unique PO number
     */
    private generateUniquePONumber;
    /**
     * Submit PO for approval
     */
    submitPurchaseOrder(poId: string): Promise<PurchaseOrderHeader>;
    /**
     * Approve PO
     */
    approvePurchaseOrder(poId: string, approvedBy: string): Promise<PurchaseOrderHeader>;
    /**
     * Get PO with details
     */
    getPurchaseOrderWithDetails(poId: string): Promise<PurchaseOrderWithDetails | null>;
    /**
     * Get open POs
     */
    getOpenPurchaseOrders(): Promise<PurchaseOrderHeader[]>;
    /**
     * Create purchase receipt
     */
    createPurchaseReceipt(dto: CreatePurchaseReceiptDTO): Promise<PurchaseReceiptWithDetails>;
    /**
     * Generate unique receipt number
     */
    private generateUniqueReceiptNumber;
    /**
     * Update receipt line quality
     */
    updateReceiptQuality(dto: UpdateReceiptQualityDTO): Promise<PurchaseReceiptLine>;
    /**
     * Get receipt with details
     */
    getReceiptWithDetails(receiptId: string): Promise<PurchaseReceiptWithDetails | null>;
    /**
     * Get three-way match summary for PO
     */
    getThreeWayMatchSummary(poId: string): Promise<ThreeWayMatchSummary>;
    /**
     * Resolve variance
     */
    resolveVariance(dto: ResolveVarianceDTO): Promise<ThreeWayMatchDetails>;
    /**
     * Get match exceptions
     */
    getMatchExceptions(): Promise<ThreeWayMatchDetails[]>;
    /**
     * Create vendor performance event
     */
    createVendorEvent(dto: CreateVendorEventDTO): Promise<VendorPerformanceEvent>;
    /**
     * Get vendor performance summary
     */
    getVendorPerformance(vendorId: string): Promise<VendorPerformanceSummary | null>;
    /**
     * Get vendor ranking
     */
    getVendorRanking(limit?: number): Promise<VendorPerformanceSummary[]>;
    /**
     * Get vendors at risk
     */
    getVendorsAtRisk(): Promise<VendorPerformanceSummary[]>;
    /**
     * Create vendor scorecard
     */
    createVendorScorecard(dto: CreateVendorScorecardDTO): Promise<VendorScorecard>;
    /**
     * Get dashboard metrics
     */
    getDashboardMetrics(entityId?: string): Promise<PurchasingDashboardMetrics>;
}
export declare const purchasingService: PurchasingService;
//# sourceMappingURL=PurchasingService.d.ts.map