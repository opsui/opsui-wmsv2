/**
 * Sales & CRM Repository
 *
 * Data access layer for customer relationship management and sales functionality
 */
import { Customer, Lead, Opportunity, Quote, CustomerInteraction, CustomerStatus, LeadStatus, OpportunityStage, QuoteStatus } from '@opsui/shared';
export declare class SalesRepository {
    createCustomer(customer: Omit<Customer, 'customerId' | 'createdAt' | 'updatedAt' | 'lastContactDate'>): Promise<Customer>;
    findCustomerById(customerId: string): Promise<Customer | null>;
    findCustomerByNumber(customerNumber: string): Promise<Customer | null>;
    findAllCustomers(filters?: {
        status?: CustomerStatus;
        assignedTo?: string;
        limit?: number;
        offset?: number;
    }): Promise<{
        customers: Customer[];
        total: number;
    }>;
    updateCustomer(customerId: string, updates: Partial<Customer>): Promise<Customer | null>;
    createLead(lead: Omit<Lead, 'leadId' | 'createdAt' | 'updatedAt' | 'lastContactDate' | 'nextFollowUpDate'>): Promise<Lead>;
    findLeadById(leadId: string): Promise<Lead | null>;
    findAllLeads(filters?: {
        status?: LeadStatus;
        assignedTo?: string;
        limit?: number;
        offset?: number;
    }): Promise<{
        leads: Lead[];
        total: number;
    }>;
    updateLead(leadId: string, updates: Partial<Lead>): Promise<Lead | null>;
    createOpportunity(opp: Omit<Opportunity, 'opportunityId' | 'opportunityNumber' | 'createdAt' | 'updatedAt' | 'closedAt' | 'closedBy'>): Promise<Opportunity>;
    findOpportunityById(opportunityId: string): Promise<Opportunity | null>;
    findAllOpportunities(filters?: {
        stage?: OpportunityStage;
        customerId?: string;
        assignedTo?: string;
        limit?: number;
        offset?: number;
    }): Promise<{
        opportunities: Opportunity[];
        total: number;
    }>;
    updateOpportunity(opportunityId: string, updates: Partial<Opportunity>): Promise<Opportunity | null>;
    createQuote(quote: Omit<Quote, 'quoteId' | 'quoteNumber' | 'createdAt' | 'updatedAt' | 'sentAt' | 'acceptedAt' | 'rejectedAt' | 'subtotal' | 'taxAmount' | 'discountAmount' | 'totalAmount'>): Promise<Quote>;
    findQuoteById(quoteId: string): Promise<Quote | null>;
    findAllQuotes(filters?: {
        customerId?: string;
        status?: QuoteStatus;
        limit?: number;
        offset?: number;
    }): Promise<{
        quotes: Quote[];
        total: number;
    }>;
    updateQuote(quoteId: string, updates: Partial<Quote>): Promise<Quote | null>;
    createInteraction(interaction: Omit<CustomerInteraction, 'interactionId' | 'createdAt'>): Promise<CustomerInteraction>;
    findInteractionsByCustomer(customerId: string, limit?: number): Promise<CustomerInteraction[]>;
    createSalesOrder(order: any): Promise<any>;
    createSalesOrderLine(line: any): Promise<any>;
    findSalesOrderById(orderId: string): Promise<any | null>;
    findAllSalesOrders(filters?: any): Promise<{
        orders: any[];
        total: number;
    }>;
    updateSalesOrder(orderId: string, updates: any): Promise<any | null>;
    deleteSalesOrder(orderId: string): Promise<void>;
    get_next_sales_order_number(): Promise<string>;
    update_sales_order_totals(orderId: string): Promise<void>;
    calculate_sales_commission(orderId: string): Promise<number>;
    create_backorder_from_line(lineId: string, quantity: number): Promise<string>;
    findBackorderById(backorderId: string): Promise<any | null>;
    findAllBackorders(filters?: any): Promise<any[]>;
    fulfillBackorder(backorderId: string, quantity: number, _userId: string): Promise<void>;
    findAllCommissions(filters?: any): Promise<any[]>;
    payCommission(commissionId: string, paymentDate: Date, _userId: string): Promise<void>;
    createTerritory(territory: any): Promise<any>;
    findTerritoryById(territoryId: string): Promise<any | null>;
    findTerritoryByCode(territoryCode: string): Promise<any | null>;
    findAllTerritories(): Promise<any[]>;
    getTerritoryMetrics(territoryId: string): Promise<any>;
    assignTerritoryCustomer(assignment: any): Promise<any>;
    createTerritoryQuota(quota: any): Promise<any>;
    getSalesOrderMetrics(): Promise<any>;
    findOrderActivity(orderId: string, limit?: number): Promise<any[]>;
    private mapRowToSalesOrder;
    private mapRowToBackorder;
    private mapRowToCommission;
    private mapRowToTerritory;
    private mapRowToTerritoryQuota;
    private mapRowToCustomer;
    private mapRowToLead;
    private mapRowToOpportunity;
    private mapRowToQuote;
    private camelToSnake;
}
export declare const salesRepository: SalesRepository;
//# sourceMappingURL=SalesRepository.d.ts.map