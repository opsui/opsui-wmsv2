"use strict";
/**
 * Health check routes
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const client_1 = require("../db/client");
const config_1 = __importDefault(require("../config"));
const router = (0, express_1.Router)();
/**
 * GET /health
 * Basic health check (doesn't require DB)
 */
router.get('/', (_req, res) => {
    res.json({
        status: 'ok',
        timestamp: new Date().toISOString(),
        uptime: process.uptime(),
        environment: config_1.default.nodeEnv,
    });
});
/**
 * GET /health/detailed
 * Detailed health check (includes DB status)
 */
router.get('/detailed', async (_req, res) => {
    const dbHealth = await (0, client_1.getHealthStatus)();
    const health = {
        status: dbHealth.healthy ? 'ok' : 'degraded',
        timestamp: new Date().toISOString(),
        uptime: process.uptime(),
        environment: config_1.default.nodeEnv,
        database: {
            healthy: dbHealth.healthy,
            connections: dbHealth.connections,
            waiting: dbHealth.waiting,
            max: dbHealth.max,
        },
        features: {
            websocket: config_1.default.features.websocket,
            redisCache: config_1.default.features.redisCache,
            auditLog: config_1.default.features.auditLog,
        },
    };
    res.status(dbHealth.healthy ? 200 : 503).json(health);
});
/**
 * GET /health/ready
 * Readiness probe (for Kubernetes)
 */
router.get('/ready', async (_req, res) => {
    const dbHealth = await (0, client_1.getHealthStatus)();
    if (dbHealth.healthy) {
        res.status(200).json({ status: 'ready' });
    }
    else {
        res.status(503).json({ status: 'not ready', database: 'unhealthy' });
    }
});
/**
 * GET /health/live
 * Liveness probe (for Kubernetes)
 */
router.get('/live', (_req, res) => {
    res.status(200).json({ status: 'alive' });
});
exports.default = router;
//# sourceMappingURL=health.js.map