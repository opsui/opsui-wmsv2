/**
 * Maintenance & Assets Routes
 *
 * API endpoints for asset management and maintenance workflows
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=maintenance.d.ts.map