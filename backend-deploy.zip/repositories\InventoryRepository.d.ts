/**
 * Inventory repository
 *
 * Handles all database operations for inventory units and transactions
 */
import { BaseRepository } from './BaseRepository';
import { InventoryUnit, TransactionType, InventoryTransaction } from '@opsui/shared';
export declare class InventoryRepository extends BaseRepository<InventoryUnit> {
    constructor();
    findBySKU(sku: string): Promise<InventoryUnit[]>;
    findByBinLocation(binLocation: string): Promise<InventoryUnit[]>;
    getAvailableInventory(sku: string): Promise<Array<{
        binLocation: string;
        available: number;
    }>>;
    getTotalAvailable(sku: string): Promise<number>;
    reserveInventory(sku: string, binLocation: string, quantity: number, orderId: string): Promise<InventoryUnit>;
    releaseReservation(sku: string, binLocation: string, quantity: number, orderId: string): Promise<InventoryUnit>;
    deductInventory(sku: string, binLocation: string, quantity: number, orderId: string): Promise<InventoryUnit>;
    adjustInventory(sku: string, binLocation: string, quantity: number, userId: string, reason: string): Promise<InventoryUnit>;
    getTransactionHistory(filters?: {
        sku?: string;
        orderId?: string;
        type?: TransactionType;
        limit?: number;
        offset?: number;
    }): Promise<{
        transactions: InventoryTransaction[];
        total: number;
    }>;
    getLowStock(threshold?: number): Promise<Array<{
        sku: string;
        binLocation: string;
        available: number;
        quantity: number;
    }>>;
    reconcileInventory(sku: string): Promise<{
        expected: number;
        actual: number;
        discrepancies: Array<{
            binLocation: string;
            expected: number;
            actual: number;
            difference: number;
        }>;
    }>;
}
export declare const inventoryRepository: InventoryRepository;
//# sourceMappingURL=InventoryRepository.d.ts.map