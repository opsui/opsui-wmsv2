/**
 * Pick task repository
 *
 * Handles all database operations for pick tasks
 */
import { BaseRepository } from './BaseRepository';
import { PickTask, TaskStatus } from '@opsui/shared';
export declare class PickTaskRepository extends BaseRepository<PickTask> {
    constructor();
    getByOrder(orderId: string): Promise<PickTask[]>;
    getPickerActiveTasks(pickerId: string): Promise<PickTask[]>;
    getNextPickTask(orderId: string): Promise<PickTask | null>;
    startPickTask(pickTaskId: string, pickerId: string): Promise<PickTask>;
    updatePickedQuantity(pickTaskId: string, quantity: number): Promise<PickTask>;
    completePickTask(pickTaskId: string): Promise<PickTask>;
    decrementPickedQuantity(pickTaskId: string, quantity?: number): Promise<PickTask>;
    skipPickTask(pickTaskId: string, reason: string): Promise<PickTask>;
    updateStatus(pickTaskId: string, status: TaskStatus): Promise<PickTask>;
    getOrderPickingProgress(orderId: string): Promise<{
        total: number;
        completed: number;
        skipped: number;
        inProgress: number;
        pending: number;
        percentage: number;
    }>;
    getPickerPerformance(pickerId: string, startDate: Date, endDate: Date): Promise<{
        tasksCompleted: number;
        tasksTotal: number;
        averageTimePerTask: number;
        totalItemsPicked: number;
    }>;
}
export declare const pickTaskRepository: PickTaskRepository;
//# sourceMappingURL=PickTaskRepository.d.ts.map