"use strict";
/**
 * Manufacturing Repository
 *
 * Data access layer for manufacturing operations
 * Handles work centers, routings, MPS, MRP, production orders,
 * shop floor control, quality, and capacity planning
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.capacityPlanDetailRepository = exports.capacityPlanRepository = exports.productionDefectRepository = exports.productionInspectionRepository = exports.shopFloorTransactionRepository = exports.productionOrderOperationRepository = exports.productionOrderRepository = exports.mrpActionMessageRepository = exports.mrpPlanDetailRepository = exports.mrpPlanRepository = exports.mrpParametersRepository = exports.mspItemRepository = exports.mspPeriodRepository = exports.routingBOMRepository = exports.routingOperationRepository = exports.routingRepository = exports.workCenterQueueRepository = exports.workCenterRepository = exports.CapacityPlanDetailRepository = exports.CapacityPlanRepository = exports.ProductionDefectRepository = exports.ProductionInspectionRepository = exports.ShopFloorTransactionRepository = exports.ProductionOrderOperationRepository = exports.ProductionOrderRepository = exports.MRPActionMessageRepository = exports.MRPPlanDetailRepository = exports.MRPPlanRepository = exports.MRPParametersRepository = exports.MPSItemRepository = exports.MSPPeriodRepository = exports.RoutingBOMRepository = exports.RoutingOperationRepository = exports.RoutingRepository = exports.WorkCenterQueueRepository = exports.WorkCenterRepository = void 0;
const client_1 = require("../db/client");
const BaseRepository_1 = require("./BaseRepository");
const shared_1 = require("@opsui/shared");
// ============================================================================
// WORK CENTER REPOSITORY
// ============================================================================
class WorkCenterRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super('work_centers', 'work_center_id');
    }
    // Find by code
    async findByCode(workCenterCode) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE work_center_code = $1`, [workCenterCode]);
        return result.rows[0] || null;
    }
    // Find active work centers
    async findActive() {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE work_center_status = $1 AND active = true ORDER BY work_center_code`, [shared_1.WorkCenterStatus.ACTIVE]);
        return result.rows;
    }
    // Find by department
    async findByDepartment(department) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE department = $1 ORDER BY work_center_code`, [department]);
        return result.rows;
    }
    // Find by site
    async findBySite(siteId) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE site_id = $1 ORDER BY work_center_code`, [siteId]);
        return result.rows;
    }
    // Query with filters
    async queryWithFilters(filters) {
        const conditions = [];
        const params = [];
        let paramIndex = 1;
        if (filters.entity_id) {
            conditions.push(`entity_id = $${paramIndex++}`);
            params.push(filters.entity_id);
        }
        if (filters.department) {
            conditions.push(`department = $${paramIndex++}`);
            params.push(filters.department);
        }
        if (filters.work_center_status) {
            conditions.push(`work_center_status = $${paramIndex++}`);
            params.push(filters.work_center_status);
        }
        if (filters.site_id) {
            conditions.push(`site_id = $${paramIndex++}`);
            params.push(filters.site_id);
        }
        if (filters.search) {
            conditions.push(`(work_center_code ILIKE $${paramIndex++} OR work_center_name ILIKE $${paramIndex++})`);
            params.push(`%${filters.search}%`, `%${filters.search}%`);
        }
        const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';
        const sql = `SELECT * FROM ${this.tableName} ${whereClause} ORDER BY work_center_code`;
        const result = await (0, client_1.query)(sql, params);
        return result.rows;
    }
}
exports.WorkCenterRepository = WorkCenterRepository;
// ============================================================================
// WORK CENTER QUEUE REPOSITORY
// ============================================================================
class WorkCenterQueueRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super('work_center_queues', 'queue_id');
    }
    // Find by work center
    async findByWorkCenter(workCenterId) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE work_center_id = $1`, [workCenterId]);
        return result.rows[0] || null;
    }
    // Find overloaded work centers
    async findOverloaded() {
        const result = await (0, client_1.query)(`SELECT wcq.*, wc.work_center_code
       FROM ${this.tableName} wcq
       JOIN work_centers wc ON wc.work_center_id = wcq.work_center_id
       WHERE (wcq.current_hours + wcq.queued_hours) > wc.available_capacity
         AND wc.work_center_status = 'ACTIVE'
       ORDER BY ((wcq.current_hours + wcq.queued_hours) / wc.available_capacity) DESC`);
        return result.rows;
    }
}
exports.WorkCenterQueueRepository = WorkCenterQueueRepository;
// ============================================================================
// ROUTING REPOSITORY
// ============================================================================
class RoutingRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super('routings', 'routing_id');
    }
    // Find by number
    async findByNumber(routingNumber) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE routing_number = $1`, [routingNumber]);
        return result.rows[0] || null;
    }
    // Find by SKU (active routing)
    async findBySKU(sku, activeOnly = true) {
        const condition = activeOnly ? "AND routing_status = 'ACTIVE'" : '';
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE sku = $1 ${condition} ORDER BY version_number DESC`, [sku]);
        return result.rows;
    }
    // Find with details
    async findByIdWithDetails(routingId) {
        const routing = await this.findById(routingId);
        if (!routing)
            return null;
        const [operations, bom] = await Promise.all([
            (0, client_1.query)(`SELECT * FROM routing_operations WHERE routing_id = $1 ORDER BY sequence_step, operation_number`, [routingId]),
            (0, client_1.query)(`SELECT * FROM routing_bom WHERE routing_id = $1 ORDER BY component_sku`, [routingId]),
        ]);
        return {
            ...routing,
            operations: operations.rows,
            bom: bom.rows,
        };
    }
    // Query with filters
    async queryWithFilters(filters) {
        const conditions = [];
        const params = [];
        let paramIndex = 1;
        if (filters.entity_id) {
            conditions.push(`entity_id = $${paramIndex++}`);
            params.push(filters.entity_id);
        }
        if (filters.sku) {
            conditions.push(`sku = $${paramIndex++}`);
            params.push(filters.sku);
        }
        if (filters.routing_status) {
            conditions.push(`routing_status = $${paramIndex++}`);
            params.push(filters.routing_status);
        }
        if (filters.search) {
            conditions.push(`(routing_number ILIKE $${paramIndex++} OR routing_name ILIKE $${paramIndex++})`);
            params.push(`%${filters.search}%`, `%${filters.search}%`);
        }
        const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';
        const sql = `SELECT * FROM ${this.tableName} ${whereClause} ORDER BY routing_number DESC`;
        const result = await (0, client_1.query)(sql, params);
        return result.rows;
    }
}
exports.RoutingRepository = RoutingRepository;
// ============================================================================
// ROUTING OPERATION REPOSITORY
// ============================================================================
class RoutingOperationRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super('routing_operations', 'operation_id');
    }
    // Find by routing
    async findByRouting(routingId) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE routing_id = $1 ORDER BY sequence_step, operation_number`, [routingId]);
        return result.rows;
    }
    // Find by work center
    async findByWorkCenter(workCenterId) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE work_center_id = $1`, [workCenterId]);
        return result.rows;
    }
}
exports.RoutingOperationRepository = RoutingOperationRepository;
// ============================================================================
// ROUTING BOM REPOSITORY
// ============================================================================
class RoutingBOMRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super('routing_bom', 'bom_component_id');
    }
    // Find by routing
    async findByRouting(routingId) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE routing_id = $1 ORDER BY component_sku`, [routingId]);
        return result.rows;
    }
    // Find by operation
    async findByOperation(operationId) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE operation_id = $1 ORDER BY component_sku`, [operationId]);
        return result.rows;
    }
    // Find by component SKU
    async findByComponentSKU(sku) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE component_sku = $1`, [sku]);
        return result.rows;
    }
}
exports.RoutingBOMRepository = RoutingBOMRepository;
// ============================================================================
// MPS PERIOD REPOSITORY
// ============================================================================
class MSPPeriodRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super('mps_periods', 'period_id');
    }
    // Find by entity
    async findByEntity(entityId) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE entity_id = $1 ORDER BY start_date`, [entityId]);
        return result.rows;
    }
    // Find current period
    async findCurrentPeriod(entityId) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName}
       WHERE entity_id = $1
       AND start_date <= CURRENT_DATE
       AND end_date >= CURRENT_DATE
       ORDER BY start_date DESC
       LIMIT 1`, [entityId]);
        return result.rows[0] || null;
    }
    // Find by date range
    async findByDateRange(startDate, endDate, entityId) {
        const condition = entityId ? 'AND entity_id = $3' : '';
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName}
       WHERE start_date <= $2 AND end_date >= $1 ${condition}
       ORDER BY start_date`, entityId ? [startDate, endDate, entityId] : [startDate, endDate]);
        return result.rows;
    }
}
exports.MSPPeriodRepository = MSPPeriodRepository;
// ============================================================================
// MPS ITEM REPOSITORY
// ============================================================================
class MPSItemRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super('mps_items', 'mps_item_id');
    }
    // Find by period
    async findByPeriod(periodId) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE period_id = $1 ORDER BY sku`, [periodId]);
        return result.rows;
    }
    // Find by SKU
    async findBySKU(sku) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE sku = $1 ORDER BY period_start_date DESC`, [sku]);
        return result.rows;
    }
    // Find pending release
    async findPendingRelease() {
        const result = await (0, client_1.query)(`SELECT mi.* FROM ${this.tableName} mi
       JOIN mps_periods mp ON mp.period_id = mi.period_id
       WHERE mi.mps_status IN ('APPROVED', 'FIRM')
       AND mi.planned_production_quantity > 0
       AND mi.production_order_id IS NULL
       AND mp.is_frozen = false
       ORDER BY mi.order_due_date ASC`);
        return result.rows;
    }
}
exports.MPSItemRepository = MPSItemRepository;
// ============================================================================
// MRP PARAMETERS REPOSITORY
// ============================================================================
class MRPParametersRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super('mrp_parameters', 'parameter_id');
    }
    // Find by entity
    async findByEntity(entityId) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE entity_id = $1`, [entityId]);
        return result.rows[0] || null;
    }
}
exports.MRPParametersRepository = MRPParametersRepository;
// ============================================================================
// MRP PLAN REPOSITORY
// ============================================================================
class MRPPlanRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super('mrp_plans', 'plan_id');
    }
    // Find by number
    async findByNumber(planNumber) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE plan_number = $1`, [
            planNumber,
        ]);
        return result.rows[0] || null;
    }
    // Find by entity
    async findByEntity(entityId) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE entity_id = $1 ORDER BY plan_date DESC`, [entityId]);
        return result.rows;
    }
    // Find latest completed
    async findLatestCompleted(entityId) {
        const condition = entityId
            ? 'WHERE entity_id = $1 AND plan_status = $2'
            : 'WHERE plan_status = $1';
        const params = entityId ? [entityId, shared_1.MRPPlanStatus.COMPLETED] : [shared_1.MRPPlanStatus.COMPLETED];
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} ${condition} ORDER BY plan_date DESC LIMIT 1`, params);
        return result.rows[0] || null;
    }
    // Query with filters
    async queryWithFilters(filters) {
        const conditions = [];
        const params = [];
        let paramIndex = 1;
        if (filters.entity_id) {
            conditions.push(`entity_id = $${paramIndex++}`);
            params.push(filters.entity_id);
        }
        if (filters.plan_status) {
            conditions.push(`plan_status = $${paramIndex++}`);
            params.push(filters.plan_status);
        }
        if (filters.plan_date_from) {
            conditions.push(`plan_date >= $${paramIndex++}`);
            params.push(filters.plan_date_from);
        }
        if (filters.plan_date_to) {
            conditions.push(`plan_date <= $${paramIndex++}`);
            params.push(filters.plan_date_to);
        }
        if (filters.created_by) {
            conditions.push(`created_by = $${paramIndex++}`);
            params.push(filters.created_by);
        }
        if (filters.search) {
            conditions.push(`(plan_number ILIKE $${paramIndex++} OR plan_name ILIKE $${paramIndex++})`);
            params.push(`%${filters.search}%`, `%${filters.search}%`);
        }
        const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';
        const sql = `SELECT * FROM ${this.tableName} ${whereClause} ORDER BY plan_date DESC`;
        const result = await (0, client_1.query)(sql, params);
        return result.rows;
    }
}
exports.MRPPlanRepository = MRPPlanRepository;
// ============================================================================
// MRP PLAN DETAIL REPOSITORY
// ============================================================================
class MRPPlanDetailRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super('mrp_plan_details', 'detail_id');
    }
    // Find by plan
    async findByPlan(planId) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE plan_id = $1 ORDER BY sku`, [planId]);
        return result.rows;
    }
    // Find by SKU
    async findBySKU(sku) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE sku = $1 ORDER BY created_at DESC`, [sku]);
        return result.rows;
    }
    // Find items with action messages
    async findWithActionMessages(planId) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName}
       WHERE plan_id = $1 AND action_message_count > 0
       ORDER BY sku`, [planId]);
        return result.rows;
    }
}
exports.MRPPlanDetailRepository = MRPPlanDetailRepository;
// ============================================================================
// MRP ACTION MESSAGE REPOSITORY
// ============================================================================
class MRPActionMessageRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super('mrp_action_messages', 'action_id');
    }
    // Find by plan
    async findByPlan(planId) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE plan_id = $1 ORDER BY action_priority ASC, action_due_date ASC`, [planId]);
        return result.rows;
    }
    // Find pending review
    async findPendingReview(planId) {
        const condition = planId ? 'AND plan_id = $1' : '';
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE is_reviewed = false ${condition} ORDER BY action_priority ASC, action_due_date ASC`, planId ? [planId] : []);
        return result.rows;
    }
    // Find by SKU
    async findBySKU(sku) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE sku = $1 AND is_implemented = false ORDER BY action_due_date ASC`, [sku]);
        return result.rows;
    }
    // Find by action type
    async findByActionType(actionType) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE action_type = $1 AND is_implemented = false ORDER BY action_due_date ASC`, [actionType]);
        return result.rows;
    }
}
exports.MRPActionMessageRepository = MRPActionMessageRepository;
// ============================================================================
// PRODUCTION ORDER REPOSITORY
// ============================================================================
class ProductionOrderRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super('production_orders', 'order_id');
    }
    // Find by number
    async findByNumber(orderNumber) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE order_number = $1`, [orderNumber]);
        return result.rows[0] || null;
    }
    // Find with details
    async findByIdWithDetails(orderId) {
        const order = await this.findById(orderId);
        if (!order)
            return null;
        const [operations, routing] = await Promise.all([
            (0, client_1.query)(`SELECT * FROM production_order_operations WHERE production_order_id = $1 ORDER BY operation_number`, [orderId]),
            order.routing_id
                ? (0, client_1.query)(`SELECT r.*, ro.*, rb.*
             FROM routings r
             LEFT JOIN routing_operations ro ON ro.routing_id = r.routing_id
             LEFT JOIN routing_bom rb ON rb.routing_id = r.routing_id
             WHERE r.routing_id = $1`, [order.routing_id])
                : Promise.resolve({ rows: [] }),
        ]);
        // Build routing object if exists
        let routingObj;
        if (routing.rows.length > 0) {
            const firstRow = routing.rows[0];
            routingObj = {
                routing_id: firstRow.routing_id,
                routing_number: firstRow.routing_number,
                entity_id: firstRow.entity_id,
                sku: firstRow.sku,
                item_description: firstRow.item_description,
                routing_name: firstRow.routing_name,
                routing_type: firstRow.routing_type,
                routing_status: firstRow.routing_status,
                version_number: firstRow.version_number,
                effective_date: firstRow.effective_date,
                expiration_date: firstRow.expiration_date,
                supersedes_routing_id: firstRow.supersedes_routing_id,
                standard_lot_size: firstRow.standard_lot_size,
                scrap_percent: firstRow.scrap_percent,
                yield_percent: firstRow.yield_percent,
                standard_labor_hours: firstRow.standard_labor_hours,
                standard_machine_hours: firstRow.standard_machine_hours,
                standard_cost: firstRow.standard_cost,
                approved_by: firstRow.approved_by,
                approved_at: firstRow.approved_at,
                engineered_by: firstRow.engineered_by,
                engineered_at: firstRow.engineered_at,
                notes: firstRow.notes,
                created_at: firstRow.created_at,
                updated_at: firstRow.updated_at,
                operations: routing.rows
                    .filter((r) => r.operation_id)
                    .map((r) => ({
                    operation_id: r.operation_id,
                    routing_id: r.routing_id,
                    operation_number: r.operation_number,
                    operation_code: r.operation_code,
                    operation_name: r.operation_name,
                    operation_type: r.operation_type,
                    description: r.description,
                    work_center_id: r.work_center_id,
                    work_center_description: r.work_center_description,
                    sequence: r.sequence,
                    sequence_step: r.sequence_step,
                    send_ahead_quantity: r.send_ahead_quantity,
                    overlap_percent: r.overlap_percent,
                    setup_hours: r.setup_hours,
                    run_hours_per_unit: r.run_hours_per_unit,
                    fixed_hours: r.fixed_hours,
                    labor_hours_per_unit: r.labor_hours_per_unit,
                    machine_hours_per_unit: r.machine_hours_per_unit,
                    minimum_crew_size: r.minimum_crew_size,
                    maximum_crew_size: r.maximum_crew_size,
                    labor_burden_rate: r.labor_burden_rate,
                    machine_burden_rate: r.machine_burden_rate,
                    inspection_required: r.inspection_required,
                    inspection_percent: r.inspection_percent,
                    control_point: r.control_point,
                    tooling_required: r.tooling_required,
                    fixtures_required: r.fixtures_required,
                    outside_process_vendor_id: r.outside_process_vendor_id,
                    outside_process_cost: r.outside_process_cost,
                    outside_process_lead_time_days: r.outside_process_lead_time_days,
                    standard_operations: r.standard_operations,
                    operator_instructions: r.operator_instructions,
                    setup_instructions: r.setup_instructions,
                    backflush_report_point: r.backflush_report_point,
                    created_at: r.created_at,
                    updated_at: r.updated_at,
                })),
                bom: routing.rows
                    .filter((r) => r.bom_component_id)
                    .map((r) => ({
                    bom_component_id: r.bom_component_id,
                    routing_id: r.routing_id,
                    operation_id: r.operation_id,
                    component_sku: r.component_sku,
                    component_description: r.component_description,
                    component_type: r.component_type,
                    quantity_per_assembly: r.quantity_per_assembly,
                    scrap_percent: r.scrap_percent,
                    effective_quantity: r.effective_quantity,
                    substitute_sku: r.substitute_sku,
                    substitute_priority: r.substitute_priority,
                    optional: r.optional,
                    phantom: r.phantom,
                    sourcing_rule: r.sourcing_rule,
                    vendor_id: r.vendor_id,
                    component_cost: r.component_cost,
                    overhead_percent: r.overhead_percent,
                    effective_from_date: r.effective_from_date,
                    effective_to_date: r.effective_to_date,
                    effectivity_quantity: r.effectivity_quantity,
                    notes: r.notes,
                    created_at: r.created_at,
                })),
            };
        }
        return {
            ...order,
            operations: operations.rows,
            routing: routingObj,
        };
    }
    // Query with filters
    async queryWithFilters(filters) {
        const conditions = [];
        const params = [];
        let paramIndex = 1;
        if (filters.entity_id) {
            conditions.push(`entity_id = $${paramIndex++}`);
            params.push(filters.entity_id);
        }
        if (filters.sku) {
            conditions.push(`sku = $${paramIndex++}`);
            params.push(filters.sku);
        }
        if (filters.order_status) {
            conditions.push(`order_status = $${paramIndex++}`);
            params.push(filters.order_status);
        }
        if (filters.order_type) {
            conditions.push(`order_type = $${paramIndex++}`);
            params.push(filters.order_type);
        }
        if (filters.start_date_from) {
            conditions.push(`start_date >= $${paramIndex++}`);
            params.push(filters.start_date_from);
        }
        if (filters.start_date_to) {
            conditions.push(`start_date <= $${paramIndex++}`);
            params.push(filters.start_date_to);
        }
        if (filters.due_date_from) {
            conditions.push(`due_date >= $${paramIndex++}`);
            params.push(filters.due_date_from);
        }
        if (filters.due_date_to) {
            conditions.push(`due_date <= $${paramIndex++}`);
            params.push(filters.due_date_to);
        }
        if (filters.customer_id) {
            conditions.push(`customer_id = $${paramIndex++}`);
            params.push(filters.customer_id);
        }
        if (filters.sales_order_id) {
            conditions.push(`sales_order_id = $${paramIndex++}`);
            params.push(filters.sales_order_id);
        }
        if (filters.job_number) {
            conditions.push(`job_number = $${paramIndex++}`);
            params.push(filters.job_number);
        }
        if (filters.search) {
            conditions.push(`(order_number ILIKE $${paramIndex++} OR sku ILIKE $${paramIndex++})`);
            params.push(`%${filters.search}%`, `%${filters.search}%`);
        }
        const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';
        const sql = `SELECT * FROM ${this.tableName} ${whereClause} ORDER BY order_date DESC`;
        const result = await (0, client_1.query)(sql, params);
        return result.rows;
    }
    // Find active orders
    async findActive() {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE order_status IN ('RELEASED', 'IN_PROGRESS') ORDER BY due_date ASC`);
        return result.rows;
    }
    // Find past due
    async findPastDue() {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName}
       WHERE order_status IN ('RELEASED', 'IN_PROGRESS')
       AND due_date < CURRENT_DATE
       ORDER BY due_date ASC`);
        return result.rows;
    }
    // Find by sales order
    async findBySalesOrder(salesOrderId) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE sales_order_id = $1 ORDER BY order_date DESC`, [salesOrderId]);
        return result.rows;
    }
}
exports.ProductionOrderRepository = ProductionOrderRepository;
// ============================================================================
// PRODUCTION ORDER OPERATION REPOSITORY
// ============================================================================
class ProductionOrderOperationRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super('production_order_operations', 'operation_id');
    }
    // Find by production order
    async findByProductionOrder(orderId) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE production_order_id = $1 ORDER BY operation_number`, [orderId]);
        return result.rows;
    }
    // Find by work center
    async findByWorkCenter(workCenterId) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName}
       WHERE work_center_id = $1
       AND operation_status IN ('PENDING', 'IN_PROGRESS')
       ORDER BY scheduled_start_date ASC`, [workCenterId]);
        return result.rows;
    }
    // Find next operation for production order
    async findNextOperation(orderId) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName}
       WHERE production_order_id = $1
       AND operation_status = 'PENDING'
       ORDER BY operation_number ASC
       LIMIT 1`, [orderId]);
        return result.rows[0] || null;
    }
    // Find in-progress operations
    async findInProgress() {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName}
       WHERE operation_status = 'IN_PROGRESS'
       ORDER BY actual_start_date ASC`);
        return result.rows;
    }
}
exports.ProductionOrderOperationRepository = ProductionOrderOperationRepository;
// ============================================================================
// SHOP FLOOR TRANSACTION REPOSITORY
// ============================================================================
class ShopFloorTransactionRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super('shop_floor_transactions', 'transaction_id');
    }
    // Find by production order
    async findByProductionOrder(orderId) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE production_order_id = $1 ORDER BY transaction_date DESC`, [orderId]);
        return result.rows;
    }
    // Find by operation
    async findByOperation(operationId) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE operation_id = $1 ORDER BY transaction_date DESC`, [operationId]);
        return result.rows;
    }
    // Find by user
    async findByUser(userId, limit = 100) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE user_id = $1 ORDER BY transaction_date DESC LIMIT $2`, [userId, limit]);
        return result.rows;
    }
    // Find by transaction type
    async findByTransactionType(transactionType, limit = 100) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE transaction_type = $1 ORDER BY transaction_date DESC LIMIT $2`, [transactionType, limit]);
        return result.rows;
    }
}
exports.ShopFloorTransactionRepository = ShopFloorTransactionRepository;
// ============================================================================
// PRODUCTION INSPECTION REPOSITORY
// ============================================================================
class ProductionInspectionRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super('production_inspections', 'inspection_id');
    }
    // Find by number
    async findByNumber(inspectionNumber) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE inspection_number = $1`, [inspectionNumber]);
        return result.rows[0] || null;
    }
    // Find by production order
    async findByProductionOrder(orderId) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE production_order_id = $1 ORDER BY inspection_date DESC`, [orderId]);
        return result.rows;
    }
    // Find by operation
    async findByOperation(operationId) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE operation_id = $1 ORDER BY inspection_date DESC`, [operationId]);
        return result.rows;
    }
    // Find pending
    async findPending() {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE inspection_result = 'PENDING' ORDER BY inspection_date ASC`);
        return result.rows;
    }
}
exports.ProductionInspectionRepository = ProductionInspectionRepository;
// ============================================================================
// PRODUCTION DEFECT REPOSITORY
// ============================================================================
class ProductionDefectRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super('production_defects', 'defect_id');
    }
    // Find by inspection
    async findByInspection(inspectionId) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE inspection_id = $1 ORDER BY defect_severity DESC`, [inspectionId]);
        return result.rows;
    }
    // Find by production order
    async findByProductionOrder(orderId) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE production_order_id = $1 ORDER BY created_at DESC`, [orderId]);
        return result.rows;
    }
    // Find unresolved
    async findUnresolved() {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE corrective_action_completed = false ORDER BY defect_severity DESC, created_at DESC`);
        return result.rows;
    }
    // Find by severity
    async findBySeverity(severity) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE defect_severity = $1 AND corrective_action_completed = false ORDER BY created_at DESC`, [severity]);
        return result.rows;
    }
    // Find by SKU
    async findBySKU(sku, limit = 100) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE sku = $1 ORDER BY created_at DESC LIMIT $2`, [sku, limit]);
        return result.rows;
    }
}
exports.ProductionDefectRepository = ProductionDefectRepository;
// ============================================================================
// CAPACITY PLAN REPOSITORY
// ============================================================================
class CapacityPlanRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super('capacity_plans', 'plan_id');
    }
    // Find by number
    async findByNumber(planNumber) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE plan_number = $1`, [planNumber]);
        return result.rows[0] || null;
    }
    // Find by entity
    async findByEntity(entityId) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE entity_id = $1 ORDER BY start_date DESC`, [entityId]);
        return result.rows;
    }
    // Find active
    async findActive() {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE plan_status = $1 ORDER BY start_date ASC`, [shared_1.CapacityPlanStatus.ACTIVE]);
        return result.rows;
    }
    // Query with filters
    async queryWithFilters(filters) {
        const conditions = [];
        const params = [];
        let paramIndex = 1;
        if (filters.entity_id) {
            conditions.push(`entity_id = $${paramIndex++}`);
            params.push(filters.entity_id);
        }
        if (filters.plan_status) {
            conditions.push(`plan_status = $${paramIndex++}`);
            params.push(filters.plan_status);
        }
        if (filters.start_date_from) {
            conditions.push(`start_date >= $${paramIndex++}`);
            params.push(filters.start_date_from);
        }
        if (filters.start_date_to) {
            conditions.push(`start_date <= $${paramIndex++}`);
            params.push(filters.start_date_to);
        }
        if (filters.end_date_from) {
            conditions.push(`end_date >= $${paramIndex++}`);
            params.push(filters.end_date_from);
        }
        if (filters.end_date_to) {
            conditions.push(`end_date <= $${paramIndex++}`);
            params.push(filters.end_date_to);
        }
        if (filters.search) {
            conditions.push(`(plan_number ILIKE $${paramIndex++} OR plan_name ILIKE $${paramIndex++})`);
            params.push(`%${filters.search}%`, `%${filters.search}%`);
        }
        const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';
        const sql = `SELECT * FROM ${this.tableName} ${whereClause} ORDER BY start_date DESC`;
        const result = await (0, client_1.query)(sql, params);
        return result.rows;
    }
}
exports.CapacityPlanRepository = CapacityPlanRepository;
// ============================================================================
// CAPACITY PLAN DETAIL REPOSITORY
// ============================================================================
class CapacityPlanDetailRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super('capacity_plan_details', 'detail_id');
    }
    // Find by plan
    async findByPlan(planId) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE plan_id = $1 ORDER BY work_center_id, period_start_date`, [planId]);
        return result.rows;
    }
    // Find by work center
    async findByWorkCenter(workCenterId) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE work_center_id = $1 ORDER BY period_start_date DESC`, [workCenterId]);
        return result.rows;
    }
    // Find overloaded
    async findOverloaded(planId) {
        const condition = planId
            ? 'WHERE plan_id = $1 AND is_overloaded = true'
            : 'WHERE is_overloaded = true';
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} ${condition} ORDER BY overload_quantity DESC`, planId ? [planId] : []);
        return result.rows;
    }
}
exports.CapacityPlanDetailRepository = CapacityPlanDetailRepository;
// ============================================================================
// REPOSITORY INSTANCES
// ============================================================================
exports.workCenterRepository = new WorkCenterRepository();
exports.workCenterQueueRepository = new WorkCenterQueueRepository();
exports.routingRepository = new RoutingRepository();
exports.routingOperationRepository = new RoutingOperationRepository();
exports.routingBOMRepository = new RoutingBOMRepository();
exports.mspPeriodRepository = new MSPPeriodRepository();
exports.mspItemRepository = new MPSItemRepository();
exports.mrpParametersRepository = new MRPParametersRepository();
exports.mrpPlanRepository = new MRPPlanRepository();
exports.mrpPlanDetailRepository = new MRPPlanDetailRepository();
exports.mrpActionMessageRepository = new MRPActionMessageRepository();
exports.productionOrderRepository = new ProductionOrderRepository();
exports.productionOrderOperationRepository = new ProductionOrderOperationRepository();
exports.shopFloorTransactionRepository = new ShopFloorTransactionRepository();
exports.productionInspectionRepository = new ProductionInspectionRepository();
exports.productionDefectRepository = new ProductionDefectRepository();
exports.capacityPlanRepository = new CapacityPlanRepository();
exports.capacityPlanDetailRepository = new CapacityPlanDetailRepository();
//# sourceMappingURL=ManufacturingRepository.js.map