/**
 * Reset ALL Tables in the Database
 *
 * This script clears ALL data from ALL tables in the database
 */
export {};
//# sourceMappingURL=reset-all-tables.d.ts.map