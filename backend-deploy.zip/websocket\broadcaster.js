"use strict";
/**
 * WebSocket Broadcaster
 *
 * Provides typed methods for broadcasting events to connected WebSocket clients
 * Handles event validation and room-based targeting
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.WebSocketBroadcaster = void 0;
exports.broadcastEvent = broadcastEvent;
const logger_1 = require("../config/logger");
// ============================================================================
// WEBSOCKET BROADCASTER CLASS
// ============================================================================
class WebSocketBroadcaster {
    io;
    constructor(io) {
        this.io = io;
    }
    /**
     * Broadcast to all connected clients
     */
    broadcastAll(event, data) {
        try {
            this.io.emit(event, data);
            logger_1.logger.debug('Broadcast to all', { event, data });
        }
        catch (error) {
            logger_1.logger.error('Failed to broadcast to all', { event, error });
        }
    }
    /**
     * Broadcast to a specific room
     */
    broadcastToRoom(room, event, data) {
        try {
            this.io.to(room).emit(event, data);
            logger_1.logger.debug('Broadcast to room', { room, event, data });
        }
        catch (error) {
            logger_1.logger.error('Failed to broadcast to room', { room, event, error });
        }
    }
    /**
     * Broadcast to a specific user
     */
    broadcastToUser(userId, event, data) {
        try {
            this.io.to(`user:${userId}`).emit(event, data);
            logger_1.logger.debug('Broadcast to user', { userId, event, data });
        }
        catch (error) {
            logger_1.logger.error('Failed to broadcast to user', { userId, event, error });
        }
    }
    // ==========================================================================
    // ORDER EVENTS
    // ==========================================================================
    /**
     * Broadcast when an order is claimed by a picker
     */
    broadcastOrderClaimed(data) {
        this.broadcastAll('order:claimed', {
            orderId: data.orderId,
            pickerId: data.pickerId,
            pickerName: data.pickerName,
        });
    }
    /**
     * Broadcast when an order is completed
     */
    broadcastOrderCompleted(data) {
        this.broadcastAll('order:completed', {
            orderId: data.orderId,
            pickerId: data.pickerId,
        });
    }
    /**
     * Broadcast when an order is cancelled
     */
    broadcastOrderCancelled(data) {
        this.broadcastAll('order:cancelled', data);
    }
    // ==========================================================================
    // PICK EVENTS
    // ==========================================================================
    /**
     * Broadcast when a pick is updated
     */
    broadcastPickUpdated(data) {
        // Broadcast to all users subscribed to orders
        this.broadcastToRoom('orders', 'pick:updated', {
            orderId: data.orderId,
            orderItemId: data.orderItemId,
            pickedQuantity: data.pickedQuantity,
        });
        // Also broadcast to the specific picker
        this.broadcastToUser(data.pickerId, 'pick:updated', {
            orderId: data.orderId,
            orderItemId: data.orderItemId,
            pickedQuantity: data.pickedQuantity,
        });
    }
    /**
     * Broadcast when a pick is completed
     */
    broadcastPickCompleted(data) {
        this.broadcastAll('pick:completed', {
            orderId: data.orderId,
            orderItemId: data.orderItemId,
        });
    }
    // ==========================================================================
    // ZONE EVENTS
    // ==========================================================================
    /**
     * Broadcast zone updates to users subscribed to that zone
     */
    broadcastZoneUpdated(data) {
        this.broadcastToRoom(`zone:${data.zoneId}`, 'zone:updated', {
            zoneId: data.zoneId,
            taskCount: data.taskCount,
            pickerCount: data.pickerCount,
        });
    }
    /**
     * Broadcast picker assignment/unassignment from zone
     */
    broadcastZoneAssignment(data) {
        this.broadcastToRoom(`zone:${data.zoneId}`, 'zone:assignment', data);
    }
    // ==========================================================================
    // INVENTORY EVENTS
    // ==========================================================================
    /**
     * Broadcast inventory updates
     */
    broadcastInventoryUpdated(data) {
        this.broadcastToRoom('inventory', 'inventory:updated', data);
    }
    /**
     * Broadcast low stock alerts
     */
    broadcastInventoryLow(data) {
        this.broadcastAll('inventory:low', {
            sku: data.sku,
            quantity: data.quantity,
            minThreshold: data.minThreshold,
        });
    }
    // ==========================================================================
    // NOTIFICATION EVENTS
    // ==========================================================================
    /**
     * Broadcast a notification to a specific user
     */
    broadcastNotification(data) {
        this.broadcastToUser(data.userId, 'notification:new', {
            notificationId: data.notificationId,
            title: data.title,
            message: data.message,
        });
    }
    /**
     * Broadcast a notification to all users
     */
    broadcastGlobalNotification(data) {
        this.broadcastAll('notification:new', {
            notificationId: data.notificationId,
            title: data.title,
            message: data.message,
        });
    }
    // ==========================================================================
    // USER ACTIVITY EVENTS
    // ==========================================================================
    /**
     * Broadcast user activity updates
     */
    broadcastUserActivity(data) {
        this.broadcastToRoom('user:activity', 'user:activity', data);
    }
    // ==========================================================================
    // UTILITY METHODS
    // ==========================================================================
    /**
     * Get number of connected clients
     */
    getConnectedCount() {
        return this.io.sockets.sockets.size;
    }
    /**
     * Get number of clients in a specific room
     */
    getRoomCount(room) {
        return this.io.sockets.adapter.rooms.get(room)?.size || 0;
    }
    /**
     * Get all room names and their client counts
     */
    getAllRoomCounts() {
        const roomCounts = new Map();
        const rooms = this.io.sockets.adapter.rooms;
        rooms.forEach((sockets, roomName) => {
            roomCounts.set(roomName, sockets.size);
        });
        return roomCounts;
    }
}
exports.WebSocketBroadcaster = WebSocketBroadcaster;
// ============================================================================
// CONVENIENCE FUNCTION
// ============================================================================
/**
 * Broadcast an event without accessing the broadcaster instance
 * This is useful for calling from services that don't have direct access to the WebSocket server
 */
function broadcastEvent(_event, _data, _room) {
    // This will be called from the singleton wsServer instance
    // The actual implementation is in the WebSocketServer class
    // This is a type-safe wrapper for external use
}
//# sourceMappingURL=broadcaster.js.map