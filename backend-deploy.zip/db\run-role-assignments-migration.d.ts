/**
 * Run the user_role_assignments table migration
 */
declare function runMigration(): Promise<void>;
export { runMigration };
//# sourceMappingURL=run-role-assignments-migration.d.ts.map