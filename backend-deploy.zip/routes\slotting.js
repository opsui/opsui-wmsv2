"use strict";
/**
 * Warehouse Slotting Routes
 *
 * API endpoints for warehouse slotting optimization and ABC analysis
 */
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const auth_1 = require("../middleware/auth");
const auth_2 = require("../middleware/auth");
const SlottingOptimizationService_1 = require("../services/SlottingOptimizationService");
const logger_1 = require("../config/logger");
const shared_1 = require("@opsui/shared");
const router = (0, express_1.Router)();
/**
 * GET /api/v1/slotting/analysis
 * Run ABC analysis for all SKUs
 */
router.get('/analysis', auth_1.authenticate, async (req, res) => {
    try {
        const { days } = req.query;
        const analysis = await SlottingOptimizationService_1.slottingOptimizationService.runABCAnalysis(days ? parseInt(days) : 90);
        res.json({
            success: true,
            data: analysis,
            meta: {
                totalSKUs: analysis.length,
                analysisDays: days || 90,
            },
        });
    }
    catch (error) {
        logger_1.logger.error('Slotting analysis error', { error });
        res.status(500).json({
            error: 'Analysis failed',
            message: error.message,
        });
    }
});
/**
 * GET /api/v1/slotting/recommendations
 * Get slotting recommendations for implementation
 */
router.get('/recommendations', auth_1.authenticate, async (req, res) => {
    try {
        const { minPriority, maxRecommendations } = req.query;
        const recommendations = await SlottingOptimizationService_1.slottingOptimizationService.getSlottingRecommendations({
            minPriority: minPriority,
            maxRecommendations: maxRecommendations ? parseInt(maxRecommendations) : undefined,
        });
        res.json({
            success: true,
            data: recommendations,
            meta: {
                totalRecommendations: recommendations.length,
            },
        });
    }
    catch (error) {
        logger_1.logger.error('Get recommendations error', { error });
        res.status(500).json({
            error: 'Failed to get recommendations',
            message: error.message,
        });
    }
});
/**
 * POST /api/v1/slotting/implement
 * Implement a slotting recommendation
 */
router.post('/implement', auth_1.authenticate, (0, auth_2.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR), async (req, res) => {
    try {
        const { sku, fromLocation, toLocation } = req.body;
        if (!sku || !fromLocation || !toLocation) {
            res.status(400).json({
                error: 'Missing required fields',
                message: 'sku, fromLocation, and toLocation are required',
            });
            return;
        }
        const context = {
            userId: req.user?.userId,
            userEmail: req.user?.email,
            userRole: req.user?.role,
            ipAddress: req.ip,
            userAgent: req.get('user-agent'),
            requestId: req.id,
        };
        await SlottingOptimizationService_1.slottingOptimizationService.implementRecommendation({
            sku,
            fromLocation,
            toLocation,
            estimatedBenefit: { travelTimeReduction: 0, annualSavings: 0 },
            effort: 'LOW',
            priority: 1,
        }, context);
        res.json({
            success: true,
            message: 'Slotting recommendation implemented',
        });
    }
    catch (error) {
        logger_1.logger.error('Implement recommendation error', { error });
        res.status(500).json({
            error: 'Implementation failed',
            message: error.message,
        });
    }
});
/**
 * GET /api/v1/slotting/velocity/:sku
 * Get velocity data for a specific SKU
 */
router.get('/velocity/:sku', auth_1.authenticate, async (req, res) => {
    try {
        const { sku } = req.params;
        const { days } = req.query;
        const velocity = await SlottingOptimizationService_1.slottingOptimizationService.getVelocityData(sku, days ? parseInt(days) : 90);
        if (!velocity) {
            res.status(404).json({
                error: 'SKU not found',
                message: `No velocity data found for SKU: ${sku}`,
            });
            return;
        }
        res.json({
            success: true,
            data: velocity,
        });
    }
    catch (error) {
        logger_1.logger.error('Get velocity error', { error });
        res.status(500).json({
            error: 'Failed to get velocity data',
            message: error.message,
        });
    }
});
/**
 * GET /api/v1/slotting/stats
 * Get overall slotting statistics
 */
router.get('/stats', auth_1.authenticate, async (_req, res) => {
    try {
        const stats = await SlottingOptimizationService_1.slottingOptimizationService.getSlottingStats();
        res.json({
            success: true,
            data: stats,
        });
    }
    catch (error) {
        logger_1.logger.error('Get slotting stats error', { error });
        res.status(500).json({
            error: 'Failed to get slotting stats',
            message: error.message,
        });
    }
});
/**
 * GET /api/v1/slotting/classes
 * Get ABC class definitions
 */
router.get('/classes', auth_1.authenticate, (_req, res) => {
    res.json({
        success: true,
        data: {
            classes: [
                {
                    class: SlottingOptimizationService_1.ABCClass.A,
                    name: 'Class A - High Velocity',
                    description: 'Fast-moving items (top 20% by velocity, 80% of movement)',
                    color: '#10b981', // green
                    recommendedZones: ['A', 'B'],
                    placementStrategy: 'Near depot, easy access',
                },
                {
                    class: SlottingOptimizationService_1.ABCClass.B,
                    name: 'Class B - Medium Velocity',
                    description: 'Medium-moving items (next 30% by velocity, 15% of movement)',
                    color: '#f59e0b', // amber
                    recommendedZones: ['B', 'C'],
                    placementStrategy: 'Moderate access',
                },
                {
                    class: SlottingOptimizationService_1.ABCClass.C,
                    name: 'Class C - Low Velocity',
                    description: 'Slow-moving items (bottom 50% by velocity, 5% of movement)',
                    color: '#6b7280', // gray
                    recommendedZones: ['C', 'D', 'E'],
                    placementStrategy: 'Further from depot, bulk storage',
                },
            ],
        },
    });
});
exports.default = router;
//# sourceMappingURL=slotting.js.map