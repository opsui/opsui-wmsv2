/**
 * @purpose: Push notification provider service - Web Push API (VAPID) integration
 * @domain: Notifications
 * @tested: No tests yet (0% coverage)
 * @last-change: 2025-01-25 - Initial implementation
 * @dependencies: web-push, logger
 * @description: Sends web push notifications using VAPID keys for browser push
 * @invariants: All push notifications have valid subscription and payload
 * @performance: Batch sending for multiple subscribers
 * @security: VAPID keys stored in environment variables, subscriptions validated
 */
import { PushParams, PushSubscription } from '@opsui/shared';
export interface PushResult {
    success: boolean;
    messageId?: string;
    error?: string;
    endpoint?: string;
}
export interface PushProviderConfig {
    vapidPublicKey: string;
    vapidPrivateKey: string;
    vapidSubject?: string;
    gcmAPIKey?: string;
}
export interface PushStats {
    sent: number;
    failed: number;
    byEndpoint: Record<string, {
        sent: number;
        failed: number;
    }>;
}
export declare class PushProvider {
    private webPush;
    private config;
    private stats;
    constructor(config: PushProviderConfig);
    private initializeProvider;
    sendPush(params: PushParams): Promise<PushResult>;
    private sendToSubscriptions;
    bulkSend(params: PushParams[], rateLimitMs?: number): Promise<PushResult[]>;
    isValidSubscription(subscription: PushSubscription): boolean;
    static generateVapidKeys(): {
        publicKey: string;
        privateKey: string;
    };
    private getUserSubscriptions;
    registerSubscription(userId: string, subscription: PushSubscription): Promise<{
        success: boolean;
        error?: string;
    }>;
    unregisterSubscription(userId: string, endpoint?: string): Promise<{
        success: boolean;
        error?: string;
    }>;
    getStats(): PushStats;
    resetStats(): void;
    healthCheck(): Promise<boolean>;
    private getEndpointDomain;
    private sleep;
    getVapidPublicKey(): string;
}
export declare function getPushProvider(): PushProvider | null;
//# sourceMappingURL=PushProvider.d.ts.map