/**
 * Developer Metrics Service
 *
 * Provides metrics and monitoring data for the developer panel
 */
export interface RequestLog {
    timestamp: Date;
    method: string;
    path: string;
    status: number;
    duration_ms: number;
    user_id?: string;
    user_role?: string;
}
export interface RequestStats {
    total: number;
    byStatus: Record<string, number>;
    byMethod: Record<string, number>;
    avgDuration: number;
    slowest: RequestLog;
    fastest: RequestLog;
}
export interface LogEntry {
    timestamp: Date;
    level: 'info' | 'warn' | 'error';
    message: string;
    context?: Record<string, any>;
}
export interface MetricsSummary {
    requests: {
        total: number;
        successRate: number;
        avgDuration: number;
    };
    database: {
        size: string;
        connections: number;
        latency: string;
    };
    system: {
        uptime: number;
        memory: NodeJS.MemoryUsage;
    };
}
/**
 * Get recent API request logs from audit_logs
 */
export declare function getRecentRequests(limit?: number): Promise<RequestLog[]>;
/**
 * Get request statistics for a time period
 */
export declare function getRequestStats(duration?: string): Promise<RequestStats>;
/**
 * Get logs from audit_logs table
 */
export declare function getLogs(limit?: number, level?: string): Promise<LogEntry[]>;
/**
 * Get metrics summary for dashboard
 */
export declare function getMetricsSummary(): Promise<MetricsSummary>;
/**
 * Get performance metrics over time
 */
export declare function getPerformanceMetrics(duration?: string): Promise<any[]>;
//# sourceMappingURL=DeveloperMetricsService.d.ts.map