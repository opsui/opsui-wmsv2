"use strict";
/**
 * @purpose: Push notification provider service - Web Push API (VAPID) integration
 * @domain: Notifications
 * @tested: No tests yet (0% coverage)
 * @last-change: 2025-01-25 - Initial implementation
 * @dependencies: web-push, logger
 * @description: Sends web push notifications using VAPID keys for browser push
 * @invariants: All push notifications have valid subscription and payload
 * @performance: Batch sending for multiple subscribers
 * @security: VAPID keys stored in environment variables, subscriptions validated
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.PushProvider = void 0;
exports.getPushProvider = getPushProvider;
const logger_1 = require("../config/logger");
const NotificationRepository_1 = require("../repositories/NotificationRepository");
// ============================================================================
// PUSH PROVIDER CLASS
// ============================================================================
class PushProvider {
    webPush;
    config;
    stats = {
        sent: 0,
        failed: 0,
        byEndpoint: {},
    };
    constructor(config) {
        this.config = config;
        this.initializeProvider();
    }
    // --------------------------------------------------------------------------
    // INITIALIZATION
    // --------------------------------------------------------------------------
    initializeProvider() {
        try {
            this.webPush = require('web-push');
            // Set VAPID credentials
            this.webPush.setVapidDetails(this.config.vapidSubject || 'mailto:admin@wms.local', this.config.vapidPublicKey, this.config.vapidPrivateKey);
            // Set GCM API key if provided (for FCM fallback)
            if (this.config.gcmAPIKey) {
                this.webPush.setGCMAPIKey(this.config.gcmAPIKey);
            }
            logger_1.logger.info('Web Push provider initialized');
        }
        catch (error) {
            logger_1.logger.error('Failed to initialize Web Push provider', { error });
            throw new Error('Failed to initialize Web Push: package not installed or invalid VAPID keys');
        }
    }
    // --------------------------------------------------------------------------
    // SEND PUSH NOTIFICATION
    // --------------------------------------------------------------------------
    async sendPush(params) {
        // Validate required fields
        if (!params.userId || !params.title || !params.message) {
            return {
                success: false,
                error: 'Missing required fields: userId, title, and message',
            };
        }
        // Get user's push subscriptions
        const subscriptions = await this.getUserSubscriptions(params.userId);
        if (subscriptions.length === 0) {
            return {
                success: false,
                error: 'No push subscriptions found for user',
            };
        }
        // Prepare payload
        const payload = JSON.stringify({
            notification: {
                title: params.title,
                body: params.message,
                data: params.data || {},
                icon: '/icon-192.png',
                badge: '/badge-72.png',
                vibrate: [200, 100, 200],
                timestamp: Date.now(),
            },
        });
        // Send to all subscriptions
        const results = await this.sendToSubscriptions(subscriptions, payload);
        // Count successes
        const successCount = results.filter(r => r.success).length;
        if (successCount > 0) {
            logger_1.logger.info('Push notification sent', {
                userId: params.userId,
                title: params.title,
                sentTo: successCount,
                total: results.length,
            });
            return {
                success: true,
                messageId: `push-${Date.now()}`,
            };
        }
        return {
            success: false,
            error: 'Failed to send to all subscriptions',
        };
    }
    // --------------------------------------------------------------------------
    // SEND TO SUBSCRIPTIONS
    // --------------------------------------------------------------------------
    async sendToSubscriptions(subscriptions, payload) {
        const results = [];
        for (const subscription of subscriptions) {
            try {
                // Convert subscription format to web-push format
                const pushSubscription = {
                    endpoint: subscription.endpoint,
                    keys: {
                        p256dh: subscription.keys.p256dh,
                        auth: subscription.keys.auth,
                    },
                };
                // Send push notification
                await this.webPush.sendNotification(pushSubscription, payload);
                // Update stats
                const endpoint = this.getEndpointDomain(subscription.endpoint);
                this.stats.sent++;
                this.stats.byEndpoint[endpoint] = this.stats.byEndpoint[endpoint] || { sent: 0, failed: 0 };
                this.stats.byEndpoint[endpoint].sent++;
                results.push({
                    success: true,
                    endpoint: subscription.endpoint,
                });
            }
            catch (error) {
                // Update stats
                const endpoint = this.getEndpointDomain(subscription.endpoint);
                this.stats.failed++;
                this.stats.byEndpoint[endpoint] = this.stats.byEndpoint[endpoint] || { sent: 0, failed: 0 };
                this.stats.byEndpoint[endpoint].failed++;
                // Check if subscription is invalid/expired
                if (error.statusCode === 410 || error.statusCode === 404) {
                    logger_1.logger.warn('Push subscription expired, should be removed', {
                        endpoint: subscription.endpoint,
                    });
                }
                results.push({
                    success: false,
                    endpoint: subscription.endpoint,
                    error: error.message || 'Push send failed',
                });
            }
        }
        return results;
    }
    // --------------------------------------------------------------------------
    // BULK SEND
    // --------------------------------------------------------------------------
    async bulkSend(params, rateLimitMs = 50) {
        const results = [];
        for (let i = 0; i < params.length; i++) {
            const result = await this.sendPush(params[i]);
            results.push(result);
            // Rate limiting
            if (i < params.length - 1) {
                await this.sleep(rateLimitMs);
            }
        }
        return results;
    }
    // --------------------------------------------------------------------------
    // VALIDATE SUBSCRIPTION
    // --------------------------------------------------------------------------
    isValidSubscription(subscription) {
        if (!subscription.endpoint || !subscription.keys) {
            return false;
        }
        const { p256dh, auth } = subscription.keys;
        if (!p256dh || !auth) {
            return false;
        }
        // Validate endpoint URL
        try {
            const url = new URL(subscription.endpoint);
            return url.protocol === 'https:';
        }
        catch {
            return false;
        }
    }
    // --------------------------------------------------------------------------
    // GENERATE VAPID KEYS
    // --------------------------------------------------------------------------
    static generateVapidKeys() {
        try {
            const webPush = require('web-push');
            return webPush.generateVAPIDKeys();
        }
        catch (error) {
            throw new Error('Failed to generate VAPID keys: web-push package not installed');
        }
    }
    // --------------------------------------------------------------------------
    // GET USER SUBSCRIPTIONS
    // --------------------------------------------------------------------------
    async getUserSubscriptions(userId) {
        try {
            // Query notification_preferences table for push_subscription
            const preferences = await NotificationRepository_1.notificationRepository.getPreferences(userId);
            if (preferences?.pushSubscription) {
                // Validate the subscription before returning
                if (this.isValidSubscription(preferences.pushSubscription)) {
                    return [preferences.pushSubscription];
                }
                else {
                    logger_1.logger.warn('Invalid push subscription found for user', { userId });
                    return [];
                }
            }
            return [];
        }
        catch (error) {
            logger_1.logger.error('Failed to get user push subscriptions', { userId, error });
            return [];
        }
    }
    // --------------------------------------------------------------------------
    // REGISTER PUSH SUBSCRIPTION
    // --------------------------------------------------------------------------
    async registerSubscription(userId, subscription) {
        try {
            // Validate subscription
            if (!this.isValidSubscription(subscription)) {
                return {
                    success: false,
                    error: 'Invalid push subscription',
                };
            }
            // Save to database
            await NotificationRepository_1.notificationRepository.updatePushSubscription(userId, subscription);
            logger_1.logger.info('Push subscription registered', {
                userId,
                endpoint: subscription.endpoint,
            });
            return { success: true };
        }
        catch (error) {
            logger_1.logger.error('Failed to register push subscription', {
                userId,
                error: error.message,
            });
            return {
                success: false,
                error: error.message || 'Failed to register subscription',
            };
        }
    }
    // --------------------------------------------------------------------------
    // UNREGISTER PUSH SUBSCRIPTION
    // --------------------------------------------------------------------------
    async unregisterSubscription(userId, endpoint) {
        try {
            const preferences = await NotificationRepository_1.notificationRepository.getPreferences(userId);
            if (!preferences?.pushSubscription) {
                return {
                    success: false,
                    error: 'No subscription found for user',
                };
            }
            // If endpoint provided, verify it matches
            if (endpoint && preferences.pushSubscription.endpoint !== endpoint) {
                return {
                    success: false,
                    error: 'Subscription endpoint does not match',
                };
            }
            // Remove from database
            await NotificationRepository_1.notificationRepository.removePushSubscription(userId);
            logger_1.logger.info('Push subscription unregistered', {
                userId,
                endpoint: preferences.pushSubscription.endpoint,
            });
            return { success: true };
        }
        catch (error) {
            logger_1.logger.error('Failed to unregister push subscription', {
                userId,
                error: error.message,
            });
            return {
                success: false,
                error: error.message || 'Failed to unregister subscription',
            };
        }
    }
    // --------------------------------------------------------------------------
    // STATS AND HEALTH CHECK
    // --------------------------------------------------------------------------
    getStats() {
        return { ...this.stats, byEndpoint: { ...this.stats.byEndpoint } };
    }
    resetStats() {
        this.stats = {
            sent: 0,
            failed: 0,
            byEndpoint: {},
        };
    }
    async healthCheck() {
        try {
            // Basic check: verify VAPID keys are set
            if (!this.config.vapidPublicKey || !this.config.vapidPrivateKey) {
                return false;
            }
            // Verify web-push is loaded
            if (!this.webPush) {
                return false;
            }
            return true;
        }
        catch (error) {
            logger_1.logger.error('Push provider health check failed', { error });
            return false;
        }
    }
    // --------------------------------------------------------------------------
    // HELPERS
    // --------------------------------------------------------------------------
    getEndpointDomain(endpoint) {
        try {
            const url = new URL(endpoint);
            return url.hostname;
        }
        catch {
            return 'unknown';
        }
    }
    sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
    // --------------------------------------------------------------------------
    // GET VAPID PUBLIC KEY
    // --------------------------------------------------------------------------
    getVapidPublicKey() {
        return this.config.vapidPublicKey;
    }
}
exports.PushProvider = PushProvider;
// ============================================================================
// SINGLETON INSTANCE
// ============================================================================
let pushProviderInstance = null;
function getPushProvider() {
    if (!pushProviderInstance && process.env.VAPID_PUBLIC_KEY && process.env.VAPID_PRIVATE_KEY) {
        pushProviderInstance = new PushProvider({
            vapidPublicKey: process.env.VAPID_PUBLIC_KEY,
            vapidPrivateKey: process.env.VAPID_PRIVATE_KEY,
            vapidSubject: process.env.VAPID_SUBJECT || 'mailto:admin@wms.local',
            gcmAPIKey: process.env.GCM_API_KEY,
        });
        logger_1.logger.info('Web Push provider singleton created');
    }
    return pushProviderInstance;
}
//# sourceMappingURL=PushProvider.js.map