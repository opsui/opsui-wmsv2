"use strict";
/**
 * Variance Severity Service
 *
 * Manages configurable variance severity thresholds for cycle counting.
 * Provides severity determination based on variance percentage.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.varianceSeverityService = exports.VarianceSeverityService = void 0;
const client_1 = require("../db/client");
const logger_1 = require("../config/logger");
const nanoid_1 = require("nanoid");
// ============================================================================
// VARIANCE SEVERITY SERVICE
// ============================================================================
class VarianceSeverityService {
    /**
     * Get all active severity configurations
     */
    async getAllSeverityConfigs(includeInactive = false) {
        const client = await (0, client_1.getPool)();
        const result = await client.query(`SELECT * FROM variance_severity_config
       WHERE $1 OR is_active = true
       ORDER BY min_variance_percent ASC`, [includeInactive]);
        return result.rows.map(row => this.mapRowToConfig(row));
    }
    /**
     * Get severity configuration by ID
     */
    async getSeverityConfig(configId) {
        const client = await (0, client_1.getPool)();
        const result = await client.query(`SELECT * FROM variance_severity_config WHERE config_id = $1`, [configId]);
        if (result.rows.length === 0) {
            throw new Error(`Severity config ${configId} not found`);
        }
        return this.mapRowToConfig(result.rows[0]);
    }
    /**
     * Determine severity for a given variance percentage
     */
    async getSeverityForVariance(variancePercent) {
        const client = await (0, client_1.getPool)();
        const absVariance = Math.abs(variancePercent);
        const result = await client.query(`SELECT * FROM variance_severity_config
       WHERE is_active = true
         AND min_variance_percent <= $1
         AND max_variance_percent >= $1
       ORDER BY max_variance_percent ASC
       LIMIT 1`, [absVariance]);
        if (result.rows.length === 0) {
            // Default to CRITICAL if no matching config found
            logger_1.logger.warn(`No severity config found for variance ${variancePercent}%, defaulting to CRITICAL`);
            return {
                severity: 'CRITICAL',
                requiresApproval: true,
                canAutoAdjust: false,
                colorCode: '#EF4444',
                config: this.createDefaultCriticalConfig(),
            };
        }
        const config = this.mapRowToConfig(result.rows[0]);
        return {
            severity: config.severityLevel,
            requiresApproval: config.requiresApproval,
            canAutoAdjust: config.autoAdjust,
            colorCode: config.colorCode,
            config,
        };
    }
    /**
     * Create a new severity configuration
     */
    async createSeverityConfig(dto) {
        const client = await (0, client_1.getPool)();
        try {
            await client.query('BEGIN');
            const configId = `VSC-${(0, nanoid_1.nanoid)(10)}`.toUpperCase();
            // Validate variance range doesn't overlap with existing
            const overlapResult = await client.query(`SELECT COUNT(*) as count FROM variance_severity_config
         WHERE is_active = true
           AND (
             (min_variance_percent <= $1 AND max_variance_percent >= $1) OR
             (min_variance_percent <= $2 AND max_variance_percent >= $2) OR
             (min_variance_percent >= $1 AND max_variance_percent <= $2)
           )`, [
                dto.minVariancePercent,
                dto.maxVariancePercent,
                dto.minVariancePercent,
                dto.maxVariancePercent,
            ]);
            if (parseInt(overlapResult.rows[0].count) > 0) {
                throw new Error('Variance range overlaps with existing configuration');
            }
            const result = await client.query(`INSERT INTO variance_severity_config
          (config_id, severity_level, min_variance_percent, max_variance_percent,
           requires_approval, requires_manager_approval, auto_adjust, color_code)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
         RETURNING *`, [
                configId,
                dto.severityLevel,
                dto.minVariancePercent,
                dto.maxVariancePercent,
                dto.requiresApproval ?? true,
                dto.requiresManagerApproval ?? false,
                dto.autoAdjust ?? false,
                dto.colorCode || this.getDefaultColorCode(dto.severityLevel),
            ]);
            await client.query('COMMIT');
            logger_1.logger.info('Severity config created', { configId, severityLevel: dto.severityLevel });
            return this.mapRowToConfig(result.rows[0]);
        }
        catch (error) {
            await client.query('ROLLBACK');
            logger_1.logger.error('Error creating severity config', error);
            throw error;
        }
    }
    /**
     * Update an existing severity configuration
     */
    async updateSeverityConfig(configId, dto) {
        const client = await (0, client_1.getPool)();
        try {
            await client.query('BEGIN');
            // Get existing config
            const existingResult = await client.query(`SELECT * FROM variance_severity_config WHERE config_id = $1`, [configId]);
            if (existingResult.rows.length === 0) {
                throw new Error(`Severity config ${configId} not found`);
            }
            const existing = this.mapRowToConfig(existingResult.rows[0]);
            // Build update fields
            const updates = [];
            const values = [];
            let paramCount = 1;
            if (dto.minVariancePercent !== undefined) {
                updates.push(`min_variance_percent = $${paramCount}`);
                values.push(dto.minVariancePercent);
                paramCount++;
            }
            if (dto.maxVariancePercent !== undefined) {
                updates.push(`max_variance_percent = $${paramCount}`);
                values.push(dto.maxVariancePercent);
                paramCount++;
            }
            if (dto.requiresApproval !== undefined) {
                updates.push(`requires_approval = $${paramCount}`);
                values.push(dto.requiresApproval);
                paramCount++;
            }
            if (dto.requiresManagerApproval !== undefined) {
                updates.push(`requires_manager_approval = $${paramCount}`);
                values.push(dto.requiresManagerApproval);
                paramCount++;
            }
            if (dto.autoAdjust !== undefined) {
                updates.push(`auto_adjust = $${paramCount}`);
                values.push(dto.autoAdjust);
                paramCount++;
            }
            if (dto.colorCode !== undefined) {
                updates.push(`color_code = $${paramCount}`);
                values.push(dto.colorCode);
                paramCount++;
            }
            if (dto.isActive !== undefined) {
                updates.push(`is_active = $${paramCount}`);
                values.push(dto.isActive);
                paramCount++;
            }
            updates.push(`updated_at = NOW()`);
            values.push(configId);
            if (updates.length === 1) {
                await client.query('ROLLBACK');
                return existing;
            }
            const result = await client.query(`UPDATE variance_severity_config
         SET ${updates.join(', ')}
         WHERE config_id = $${values.length}
         RETURNING *`, values);
            await client.query('COMMIT');
            logger_1.logger.info('Severity config updated', { configId });
            return this.mapRowToConfig(result.rows[0]);
        }
        catch (error) {
            await client.query('ROLLBACK');
            logger_1.logger.error('Error updating severity config', error);
            throw error;
        }
    }
    /**
     * Delete a severity configuration (soft delete by setting inactive)
     */
    async deleteSeverityConfig(configId) {
        const client = await (0, client_1.getPool)();
        const result = await client.query(`UPDATE variance_severity_config
       SET is_active = false, updated_at = NOW()
       WHERE config_id = $1`, [configId]);
        if (result.rowCount === 0) {
            throw new Error(`Severity config ${configId} not found`);
        }
        logger_1.logger.info('Severity config deleted', { configId });
    }
    /**
     * Reset to default severity configurations
     */
    async resetToDefaults() {
        const client = await (0, client_1.getPool)();
        try {
            await client.query('BEGIN');
            // Delete all existing configs
            await client.query(`DELETE FROM variance_severity_config`);
            // Insert defaults
            await client.query(`INSERT INTO variance_severity_config
          (config_id, severity_level, min_variance_percent, max_variance_percent,
           requires_approval, auto_adjust, color_code) VALUES
          ('severity-low', 'LOW', 0, 2, false, true, '#10B981'),
          ('severity-medium', 'MEDIUM', 2, 5, true, false, '#F59E0B'),
          ('severity-high', 'HIGH', 5, 10, true, false, '#F97316'),
          ('severity-critical', 'CRITICAL', 10, 999999, true, false, '#EF4444')`);
            await client.query('COMMIT');
            logger_1.logger.info('Severity configs reset to defaults');
        }
        catch (error) {
            await client.query('ROLLBACK');
            logger_1.logger.error('Error resetting severity configs', error);
            throw error;
        }
    }
    /**
     * Initialize default severity configurations
     * Called during system setup
     */
    async createDefaultSeverityConfigs() {
        const client = await (0, client_1.getPool)();
        const result = await client.query(`SELECT COUNT(*) as count FROM variance_severity_config`);
        if (parseInt(result.rows[0].count) === 0) {
            await this.resetToDefaults();
        }
    }
    // ==========================================================================
    // PRIVATE METHODS
    // ==========================================================================
    mapRowToConfig(row) {
        return {
            configId: row.config_id,
            severityLevel: row.severity_level,
            minVariancePercent: parseFloat(row.min_variance_percent),
            maxVariancePercent: parseFloat(row.max_variance_percent),
            requiresApproval: row.requires_approval,
            requiresManagerApproval: row.requires_manager_approval,
            autoAdjust: row.auto_adjust,
            colorCode: row.color_code,
            isActive: row.is_active,
            createdAt: new Date(row.created_at),
            updatedAt: new Date(row.updated_at),
        };
    }
    createDefaultCriticalConfig() {
        return {
            configId: 'severity-critical-default',
            severityLevel: 'CRITICAL',
            minVariancePercent: 0,
            maxVariancePercent: 999999,
            requiresApproval: true,
            requiresManagerApproval: true,
            autoAdjust: false,
            colorCode: '#EF4444',
            isActive: true,
            createdAt: new Date(),
            updatedAt: new Date(),
        };
    }
    getDefaultColorCode(severityLevel) {
        const colors = {
            LOW: '#10B981',
            MEDIUM: '#F59E0B',
            HIGH: '#F97316',
            CRITICAL: '#EF4444',
        };
        return colors[severityLevel] || '#000000';
    }
}
exports.VarianceSeverityService = VarianceSeverityService;
// Singleton instance
exports.varianceSeverityService = new VarianceSeverityService();
//# sourceMappingURL=VarianceSeverityService.js.map