/**
 * Debug query column names
 */
export {};
//# sourceMappingURL=debug-query.d.ts.map