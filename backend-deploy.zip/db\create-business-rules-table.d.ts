/**
 * Create business_rules table
 */
export {};
//# sourceMappingURL=create-business-rules-table.d.ts.map