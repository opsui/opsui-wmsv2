/**
 * WooCommerce Platform Service
 *
 * Handles integration with WooCommerce's REST API
 * Supports webhook processing, inventory sync, order import, and product sync
 */
import { EcommerceConnection, EcommerceProductMapping, TestConnectionResult, PlatformProductData, PlatformOrderData } from '@opsui/shared';
export declare class WooCommerceService {
    private readonly DEFAULT_API_VERSION;
    /**
     * Build WooCommerce API URL
     */
    private buildApiUrl;
    /**
     * Make authenticated request to WooCommerce API
     */
    private apiRequest;
    /**
     * Test connection to WooCommerce
     */
    testConnection(connection: EcommerceConnection): Promise<TestConnectionResult>;
    /**
     * Fetch products from WooCommerce
     */
    fetchProducts(connection: EcommerceConnection, skus?: string[]): Promise<PlatformProductData[]>;
    /**
     * Fetch a single product by SKU
     */
    private fetchProductBySku;
    /**
     * Normalize WooCommerce product to standard format
     */
    private normalizeProduct;
    /**
     * Update inventory in WooCommerce
     */
    updateInventory(connection: EcommerceConnection, mapping: EcommerceProductMapping, quantity: number): Promise<void>;
    /**
     * Get inventory from WooCommerce
     */
    getInventory(connection: EcommerceConnection, mapping: EcommerceProductMapping): Promise<number | undefined>;
    /**
     * Fetch orders from WooCommerce
     */
    fetchOrders(connection: EcommerceConnection, orderIds?: string[], daysToLookBack?: number): Promise<PlatformOrderData[]>;
    /**
     * Fetch a single order by ID
     */
    private fetchOrderById;
    /**
     * Normalize WooCommerce order to standard format
     */
    private normalizeOrder;
    /**
     * Verify WooCommerce webhook signature
     */
    verifyWebhook(connection: EcommerceConnection, payload: any): Promise<boolean>;
    /**
     * Handle order webhook from WooCommerce
     */
    handleOrderWebhook(connection: EcommerceConnection, payload: any): Promise<void>;
    /**
     * Handle product webhook from WooCommerce
     */
    handleProductWebhook(connection: EcommerceConnection, payload: any): Promise<void>;
    /**
     * Handle inventory webhook from WooCommerce
     */
    handleInventoryWebhook(connection: EcommerceConnection, payload: any): Promise<void>;
}
//# sourceMappingURL=WooCommerceService.d.ts.map