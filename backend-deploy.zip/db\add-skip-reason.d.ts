/**
 * Migration: Add skip_reason column to order_items table
 *
 * This column stores the reason when an item is skipped during packing
 */
export {};
//# sourceMappingURL=add-skip-reason.d.ts.map