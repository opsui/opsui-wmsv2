/**
 * RMA Repository
 *
 * Data access layer for Return Merchandise Authorization functionality
 */
import { RMARequest, RMAInspection, RMAActivity, RMACommunication, RMAListFilters } from '@opsui/shared';
export declare class RMARepository {
    createRMARequest(rma: Omit<RMARequest, 'rmaId' | 'rmaNumber' | 'createdAt' | 'updatedAt'>): Promise<RMARequest>;
    findRMAById(rmaId: string): Promise<RMARequest | null>;
    findRMAByNumber(rmaNumber: string): Promise<RMARequest | null>;
    findAllRMAs(filters?: RMAListFilters): Promise<{
        requests: RMARequest[];
        total: number;
    }>;
    updateRMARequest(rmaId: string, updates: Partial<RMARequest>): Promise<RMARequest | null>;
    createInspection(inspection: Omit<RMAInspection, 'inspectionId' | 'createdAt'>): Promise<RMAInspection>;
    findInspectionsByRMA(rmaId: string): Promise<RMAInspection[]>;
    logActivity(activity: Omit<RMAActivity, 'activityId' | 'createdAt'>): Promise<RMAActivity>;
    findActivitiesByRMA(rmaId: string, limit?: number): Promise<RMAActivity[]>;
    addCommunication(communication: Omit<RMACommunication, 'communicationId' | 'createdAt'>): Promise<RMACommunication>;
    findCommunicationsByRMA(rmaId: string): Promise<RMACommunication[]>;
    getDashboardStats(): Promise<{
        pendingRequests: number;
        awaitingApproval: number;
        inProgress: number;
        completedToday: number;
        completedThisWeek: number;
        completedThisMonth: number;
        urgent: number;
        overdue: number;
        totalRefundValue: number;
        pendingRefundValue: number;
    }>;
    private mapRowToRMARequest;
    private camelToSnake;
}
export declare const rmaRepository: RMARepository;
//# sourceMappingURL=RMARepository.d.ts.map