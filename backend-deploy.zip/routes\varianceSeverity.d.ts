/**
 * Variance Severity Routes
 *
 * API endpoints for managing variance severity configurations
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=varianceSeverity.d.ts.map