/**
 * Custom Role repository
 *
 * Handles database operations for custom roles and permissions
 */
import { BaseRepository } from './BaseRepository';
import { CustomRole, Permission } from '@opsui/shared';
export interface RolePermissionRow {
    role_permission_id: string;
    role_id: string;
    permission: string;
    granted_at: Date;
    granted_by: string;
}
export declare class CustomRoleRepository extends BaseRepository<CustomRole> {
    constructor();
    getAllRolesWithPermissions(): Promise<Array<{
        roleId: string;
        name: string;
        permissions: Permission[];
    }>>;
    getCustomRoleById(roleId: string): Promise<CustomRole | null>;
    getCustomRoleByIdOrThrow(roleId: string): Promise<CustomRole>;
    createCustomRole(data: {
        roleId: string;
        name: string;
        description: string;
        permissions: Permission[];
        grantedBy: string;
    }): Promise<CustomRole>;
    updateCustomRole(roleId: string, data: {
        name?: string;
        description?: string;
        permissions?: Permission[];
        grantedBy: string;
    }): Promise<CustomRole>;
    deleteCustomRole(roleId: string): Promise<void>;
    getRolePermissions(roleId: string): Promise<Permission[]>;
    roleHasPermission(roleId: string, permission: Permission): Promise<boolean>;
    getUserPermissions(userId: string, userRole: string): Promise<Permission[]>;
    getSystemRoles(): Promise<Array<{
        roleId: string;
        name: string;
        permissions: Permission[];
        isSystem: boolean;
    }>>;
}
export declare const customRoleRepository: CustomRoleRepository;
//# sourceMappingURL=CustomRoleRepository.d.ts.map