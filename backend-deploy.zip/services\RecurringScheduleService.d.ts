/**
 * Recurring Schedule Service
 *
 * Manages automated recurring cycle count schedules.
 * Processes due schedules to generate cycle count plans automatically.
 */
import { CycleCountType } from '@opsui/shared';
export interface RecurringCountSchedule {
    scheduleId: string;
    scheduleName: string;
    countType: CycleCountType;
    frequencyType: 'DAILY' | 'WEEKLY' | 'MONTHLY' | 'QUARTERLY';
    frequencyInterval: number;
    location?: string;
    sku?: string;
    assignedTo: string;
    nextRunDate: Date;
    lastRunDate?: Date;
    isActive: boolean;
    createdBy: string;
    notes?: string;
    createdAt: Date;
    updatedAt: Date;
}
export interface CreateRecurringScheduleDTO {
    scheduleName: string;
    countType: CycleCountType;
    frequencyType: 'DAILY' | 'WEEKLY' | 'MONTHLY' | 'QUARTERLY';
    frequencyInterval?: number;
    location?: string;
    sku?: string;
    assignedTo: string;
    notes?: string;
    createdBy: string;
}
export interface UpdateRecurringScheduleDTO {
    scheduleName?: string;
    frequencyType?: 'DAILY' | 'WEEKLY' | 'MONTHLY' | 'QUARTERLY';
    frequencyInterval?: number;
    location?: string;
    sku?: string;
    assignedTo?: string;
    isActive?: boolean;
    notes?: string;
}
export interface ScheduleFilters {
    isActive?: boolean;
    assignedTo?: string;
    frequencyType?: string;
    countType?: CycleCountType;
    limit?: number;
    offset?: number;
}
export declare class RecurringScheduleService {
    /**
     * Create a new recurring schedule
     */
    createRecurringSchedule(dto: CreateRecurringScheduleDTO): Promise<RecurringCountSchedule>;
    /**
     * Get all recurring schedules with optional filters
     */
    getAllSchedules(filters?: ScheduleFilters): Promise<{
        schedules: RecurringCountSchedule[];
        total: number;
    }>;
    /**
     * Get a specific recurring schedule
     */
    getSchedule(scheduleId: string): Promise<RecurringCountSchedule>;
    /**
     * Update a recurring schedule
     */
    updateSchedule(scheduleId: string, dto: UpdateRecurringScheduleDTO): Promise<RecurringCountSchedule>;
    /**
     * Delete (cancel) a recurring schedule
     */
    deleteSchedule(scheduleId: string): Promise<void>;
    /**
     * Process all due schedules and generate cycle count plans
     * Called by cron job
     */
    processDueSchedules(): Promise<{
        processed: number;
        skipped: number;
        failed: number;
        details: Array<{
            scheduleId: string;
            scheduleName: string;
            planId?: string;
            error?: string;
        }>;
    }>;
    /**
     * Calculate next run date based on frequency type and interval
     */
    private calculateNextRunDate;
    private mapRowToSchedule;
}
export declare const recurringScheduleService: RecurringScheduleService;
//# sourceMappingURL=RecurringScheduleService.d.ts.map