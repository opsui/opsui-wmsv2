/**
 * Custom Roles routes
 *
 * Provides endpoints for managing custom roles with permissions
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=customRoles.d.ts.map