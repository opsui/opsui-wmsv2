"use strict";
/**
 * Integrations Routes
 *
 * REST API endpoints for managing external integrations (ERP, e-commerce, carriers)
 */
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const IntegrationsRepository_1 = require("../repositories/IntegrationsRepository");
const IntegrationsService_1 = require("../services/IntegrationsService");
const auth_1 = require("../middleware/auth");
const shared_1 = require("@opsui/shared");
const client_1 = require("../db/client");
const router = (0, express_1.Router)();
const repository = new IntegrationsRepository_1.IntegrationsRepository((0, client_1.getPool)());
const service = new IntegrationsService_1.IntegrationsService(repository);
// ============================================================================
// MIDDLEWARE
// ============================================================================
// Apply authentication to all routes
router.use(auth_1.authenticate);
// ============================================================================
// INTEGRATIONS CRUD
// ============================================================================
/**
 * GET /api/integrations
 * List all integrations with optional filtering
 * Access: ADMIN, SUPERVISOR (read-only)
 */
router.get('/', async (req, res, next) => {
    try {
        // Non-admins can only view active integrations
        const filters = {};
        if (req.query.type)
            filters.type = req.query.type;
        if (req.query.provider)
            filters.provider = req.query.provider;
        if (req.query.status)
            filters.status = req.query.status;
        const integrations = await repository.findAll(filters);
        res.json(integrations);
    }
    catch (error) {
        next(error);
    }
});
/**
 * GET /api/integrations/:integrationId
 * Get a specific integration by ID
 * Access: All authenticated users
 */
router.get('/:integrationId', async (req, res, next) => {
    try {
        const integration = await repository.findById(req.params.integrationId);
        if (!integration) {
            res.status(404).json({ error: 'Integration not found' });
            return;
        }
        res.json(integration);
    }
    catch (error) {
        next(error);
    }
});
/**
 * POST /api/integrations
 * Create a new integration
 * Access: ADMIN only
 */
router.post('/', (0, auth_1.authorize)(shared_1.UserRole.ADMIN), async (req, res, next) => {
    try {
        const integration = await service.createIntegration(req.body);
        res.status(201).json(integration);
    }
    catch (error) {
        if (error.message.includes('Missing required configuration fields')) {
            res.status(400).json({ error: error.message });
            return;
        }
        next(error);
    }
});
/**
 * PUT /api/integrations/:integrationId
 * Update an integration
 * Access: ADMIN only
 */
router.put('/:integrationId', (0, auth_1.authorize)(shared_1.UserRole.ADMIN), async (req, res, next) => {
    try {
        const integration = await service.updateIntegration(req.params.integrationId, req.body);
        if (!integration) {
            res.status(404).json({ error: 'Integration not found' });
            return;
        }
        res.json(integration);
    }
    catch (error) {
        next(error);
    }
});
/**
 * DELETE /api/integrations/:integrationId
 * Delete an integration
 * Access: ADMIN only
 */
router.delete('/:integrationId', (0, auth_1.authorize)(shared_1.UserRole.ADMIN), async (req, res, next) => {
    try {
        const deleted = await service.deleteIntegration(req.params.integrationId);
        if (!deleted) {
            res.status(404).json({ error: 'Integration not found' });
            return;
        }
        res.status(204).send();
    }
    catch (error) {
        next(error);
    }
});
// ============================================================================
// CONNECTION TESTING
// ============================================================================
/**
 * POST /api/integrations/:integrationId/test
 * Test connection to an external integration
 * Access: ADMIN, SUPERVISOR
 */
router.post('/:integrationId/test', (0, auth_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR), async (req, res, _next) => {
    try {
        const result = await service.testConnection(req.params.integrationId);
        res.json(result);
    }
    catch (error) {
        res.status(400).json({
            success: false,
            message: error.message,
        });
    }
});
// ============================================================================
// SYNC JOBS
// ============================================================================
/**
 * GET /api/integrations/:integrationId/sync-jobs
 * Get sync job history for an integration
 * Access: ADMIN, SUPERVISOR
 */
router.get('/:integrationId/sync-jobs', (0, auth_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR), async (req, res, next) => {
    try {
        const limit = parseInt(req.query.limit) || 50;
        const jobs = await repository.findSyncJobs(req.params.integrationId, limit);
        res.json(jobs);
    }
    catch (error) {
        next(error);
    }
});
/**
 * POST /api/integrations/:integrationId/sync
 * Trigger a manual sync job
 * Access: ADMIN, SUPERVISOR
 */
router.post('/:integrationId/sync', (0, auth_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR), async (req, res, next) => {
    try {
        const jobType = req.query.type || 'FULL_SYNC';
        const userId = req.user.userId;
        const job = await service.createSyncJob(req.params.integrationId, jobType, userId);
        res.status(201).json(job);
    }
    catch (error) {
        if (error.message.includes('must be active')) {
            res.status(400).json({ error: error.message });
            return;
        }
        next(error);
    }
});
/**
 * GET /api/integrations/sync-jobs/:jobId
 * Get details of a specific sync job
 * Access: ADMIN, SUPERVISOR
 */
router.get('/sync-jobs/:jobId', (0, auth_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR), async (req, res, next) => {
    try {
        const job = await repository.findSyncJobById(req.params.jobId);
        if (!job) {
            res.status(404).json({ error: 'Sync job not found' });
            return;
        }
        res.json(job);
    }
    catch (error) {
        next(error);
    }
});
/**
 * GET /api/integrations/sync-jobs/:jobId/logs
 * Get logs for a specific sync job
 * Access: ADMIN, SUPERVISOR
 */
router.get('/sync-jobs/:jobId/logs', (0, auth_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR), async (req, res, next) => {
    try {
        const limit = parseInt(req.query.limit) || 100;
        const logs = await repository.findSyncLogEntrys(req.params.jobId, limit);
        res.json(logs);
    }
    catch (error) {
        next(error);
    }
});
// ============================================================================
// WEBHOOKS
// ============================================================================
/**
 * POST /api/integrations/:integrationId/webhooks
 * Receive webhook from external system
 * Access: Public (with integration verification)
 */
router.post('/:integrationId/webhooks', async (req, res, next) => {
    try {
        const integration = await repository.findById(req.params.integrationId);
        if (!integration) {
            res.status(404).json({ error: 'Integration not found' });
            return;
        }
        // Verify webhook signature if configured
        // This is a simplified check - production should use HMAC signatures
        const signature = req.headers['x-webhook-signature'];
        if (integration.webhookSettings?.secretKey && !signature) {
            res.status(401).json({ error: 'Missing webhook signature' });
            return;
        }
        const eventType = req.headers['x-webhook-event'];
        if (!eventType) {
            res.status(400).json({ error: 'Missing event type header' });
            return;
        }
        const event = await service.handleWebhook(req.params.integrationId, eventType, req.body);
        res.status(202).json({
            message: 'Webhook received',
            eventId: event.eventId,
        });
    }
    catch (error) {
        next(error);
    }
});
/**
 * GET /api/integrations/:integrationId/webhooks
 * Get webhook event history for an integration
 * Access: ADMIN, SUPERVISOR
 */
router.get('/:integrationId/webhooks', (0, auth_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR), async (req, res, next) => {
    try {
        const limit = parseInt(req.query.limit) || 50;
        const filters = { integrationId: req.params.integrationId };
        if (req.query.status)
            filters.status = req.query.status;
        if (req.query.eventType)
            filters.eventType = req.query.eventType;
        const events = await repository.findWebhookEvents(filters, limit);
        res.json(events);
    }
    catch (error) {
        next(error);
    }
});
// ============================================================================
// CARRIER ACCOUNTS
// ============================================================================
/**
 * GET /api/integrations/:integrationId/carrier-accounts
 * Get carrier accounts for an integration
 * Access: ADMIN, SUPERVISOR
 */
router.get('/:integrationId/carrier-accounts', (0, auth_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR), async (req, res, next) => {
    try {
        const accounts = await repository.findCarrierAccounts(req.params.integrationId);
        res.json(accounts);
    }
    catch (error) {
        next(error);
    }
});
/**
 * POST /api/integrations/:integrationId/carrier-accounts
 * Create a new carrier account
 * Access: ADMIN
 */
router.post('/:integrationId/carrier-accounts', (0, auth_1.authorize)(shared_1.UserRole.ADMIN), async (req, res, next) => {
    try {
        const account = await service.createCarrierAccount(req.params.integrationId, req.body);
        res.status(201).json(account);
    }
    catch (error) {
        if (error.message.includes('can only be added to')) {
            res.status(400).json({ error: error.message });
            return;
        }
        next(error);
    }
});
/**
 * PUT /api/integrations/carrier-accounts/:carrierAccountId
 * Update a carrier account
 * Access: ADMIN
 */
router.put('/carrier-accounts/:carrierAccountId', (0, auth_1.authorize)(shared_1.UserRole.ADMIN), async (req, res, next) => {
    try {
        const account = await service.updateCarrierAccount(req.params.carrierAccountId, req.body);
        if (!account) {
            res.status(404).json({ error: 'Carrier account not found' });
            return;
        }
        res.json(account);
    }
    catch (error) {
        next(error);
    }
});
/**
 * DELETE /api/integrations/carrier-accounts/:carrierAccountId
 * Delete a carrier account
 * Access: ADMIN
 */
router.delete('/carrier-accounts/:carrierAccountId', (0, auth_1.authorize)(shared_1.UserRole.ADMIN), async (req, res, next) => {
    try {
        const deleted = await service.deleteCarrierAccount(req.params.carrierAccountId);
        if (!deleted) {
            res.status(404).json({ error: 'Carrier account not found' });
            return;
        }
        res.status(204).send();
    }
    catch (error) {
        next(error);
    }
});
exports.default = router;
//# sourceMappingURL=integrations.js.map