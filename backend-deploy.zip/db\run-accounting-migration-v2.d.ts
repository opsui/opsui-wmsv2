/**
 * Run the accounting tables migration v2
 * This version uses non-conflicting table names
 */
export {};
//# sourceMappingURL=run-accounting-migration-v2.d.ts.map