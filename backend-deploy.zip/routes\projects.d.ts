/**
 * Projects API Routes
 *
 * REST API for project management operations
 * Handles projects, tasks, milestones, time entries, expenses, billing, resources, and issues
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=projects.d.ts.map