"use strict";
/**
 * Jest Test Setup
 *
 * Configures the test environment for all test suites.
 */
Object.defineProperty(exports, "__esModule", { value: true });
const globals_1 = require("@jest/globals");
// ============================================================================
// Test Environment Configuration
// ============================================================================
// Set test environment variables
process.env.NODE_ENV = 'test';
process.env.DB_HOST = process.env.DB_HOST || 'localhost';
process.env.DB_PORT = process.env.DB_PORT || '5432';
process.env.DB_NAME = process.env.DB_NAME || 'test_db';
process.env.DB_USER = process.env.DB_USER || 'test_user';
process.env.DB_PASSWORD = process.env.DB_PASSWORD || 'test_password';
process.env.REDIS_HOST = process.env.REDIS_HOST || 'localhost';
process.env.REDIS_PORT = process.env.REDIS_PORT || '6379';
process.env.JWT_SECRET = 'test-secret-key-for-testing-only';
process.env.TEST_MODE = 'true';
// ============================================================================
// Mock External Services
// ============================================================================
// Mock Redis
globals_1.jest.mock('redis', () => ({
    createClient: globals_1.jest.fn(() => ({
        connect: globals_1.jest.fn().mockResolvedValue(undefined),
        disconnect: globals_1.jest.fn().mockResolvedValue(undefined),
        get: globals_1.jest.fn().mockResolvedValue(null),
        set: globals_1.jest.fn().mockResolvedValue('OK'),
        del: globals_1.jest.fn().mockResolvedValue(1),
        exists: globals_1.jest.fn().mockResolvedValue(0),
        expire: globals_1.jest.fn().mockResolvedValue(1),
        on: globals_1.jest.fn(),
    })),
}));
// Mock email services
globals_1.jest.mock('@sendgrid/mail', () => ({
    setApiKey: globals_1.jest.fn(),
    send: globals_1.jest.fn().mockResolvedValue([{ statusCode: 202 }]),
}));
globals_1.jest.mock('postmark', () => ({
    ServerClient: globals_1.jest.fn().mockImplementation(() => ({
        sendEmail: globals_1.jest.fn().mockResolvedValue({ ErrorCode: 0, MessageID: 'test-id' }),
    })),
}));
// Mock Twilio
globals_1.jest.mock('twilio', () => ({
    Twilio: globals_1.jest.fn().mockImplementation(() => ({
        messages: {
            create: globals_1.jest.fn().mockResolvedValue({ sid: 'test-sid' }),
        },
    })),
}));
// Mock web-push
globals_1.jest.mock('web-push', () => ({
    sendNotification: globals_1.jest.fn().mockResolvedValue(201),
    setVapidDetails: globals_1.jest.fn(),
}));
// Mock OpenTelemetry
globals_1.jest.mock('@opentelemetry/api', () => ({
    trace: {
        getTracer: globals_1.jest.fn().mockReturnValue({
            startSpan: globals_1.jest.fn().mockReturnValue({
                end: globals_1.jest.fn(),
                setAttributes: globals_1.jest.fn(),
                recordException: globals_1.jest.fn(),
                setStatus: globals_1.jest.fn(),
            }),
        }),
    },
    context: {
        active: globals_1.jest.fn(),
        bind: globals_1.jest.fn(),
    },
}));
// Custom matchers
expect.extend({
    toBeValidUUID(received) {
        const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
        const pass = uuidRegex.test(received);
        return {
            pass,
            message: () => pass
                ? `Expected ${received} not to be a valid UUID`
                : `Expected ${received} to be a valid UUID`,
        };
    },
    toBeValidISODate(received) {
        const date = new Date(received);
        const pass = !isNaN(date.getTime()) && date.toISOString() === received;
        return {
            pass,
            message: () => pass
                ? `Expected ${received} not to be a valid ISO date`
                : `Expected ${received} to be a valid ISO date`,
        };
    },
    toHaveErrorMessage(received, message) {
        const pass = received.message.includes(message);
        return {
            pass,
            message: () => pass
                ? `Expected error message not to contain "${message}"`
                : `Expected error message to contain "${message}", but got "${received.message}"`,
        };
    },
});
// ============================================================================
// Console Overrides
// ============================================================================
// Suppress console.log during tests unless debugging
const originalConsoleLog = console.log;
const originalConsoleError = console.error;
const originalConsoleWarn = console.warn;
if (process.env.DEBUG !== 'true') {
    console.log = (...args) => {
        if (typeof args[0] === 'string' && args[0].includes('[TEST]')) {
            originalConsoleLog(...args);
        }
    };
    console.error = (...args) => {
        if (typeof args[0] === 'string' && args[0].includes('[TEST]')) {
            originalConsoleError(...args);
        }
    };
    console.warn = (...args) => {
        if (typeof args[0] === 'string' && args[0].includes('[TEST]')) {
            originalConsoleWarn(...args);
        }
    };
}
// ============================================================================
// Test Timeout Configuration
// ============================================================================
// Increase timeout for integration tests
globals_1.jest.setTimeout(30000);
//# sourceMappingURL=setup.js.map