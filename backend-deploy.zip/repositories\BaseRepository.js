"use strict";
/**
 * Base repository
 *
 * Provides common CRUD operations for all repositories
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.BaseRepository = void 0;
exports.toCamelCase = toCamelCase;
const client_1 = require("../db/client");
const shared_1 = require("@opsui/shared");
// ============================================================================
// COLUMN NAME MAPPING
// ============================================================================
/**
 * Convert snake_case to camelCase
 */
function toCamelCase(str) {
    return str.replace(/_([a-z])/g, (_, letter) => letter.toUpperCase());
}
/**
 * Convert camelCase to snake_case
 */
function toSnakeCase(str) {
    return str.replace(/[A-Z]/g, letter => `_${letter.toLowerCase()}`);
}
// ============================================================================
// BASE REPOSITORY
// ============================================================================
class BaseRepository {
    tableName;
    primaryKey;
    constructor(tableName, primaryKey) {
        this.tableName = tableName;
        this.primaryKey = primaryKey;
    }
    // --------------------------------------------------------------------------
    // FIND BY ID
    // --------------------------------------------------------------------------
    async findById(id) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE ${this.primaryKey} = $1`, [
            id,
        ]);
        return result.rows[0] || null;
    }
    async findByIdOrThrow(id) {
        const entity = await this.findById(id);
        if (!entity) {
            throw new shared_1.NotFoundError(this.tableName, id);
        }
        return entity;
    }
    // --------------------------------------------------------------------------
    // FIND MANY
    // --------------------------------------------------------------------------
    async findAll(options = {}) {
        const { limit = 100, offset = 0, orderBy = this.primaryKey, orderDirection = 'ASC' } = options;
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName}
       ORDER BY ${orderBy} ${orderDirection}
       LIMIT $1 OFFSET $2`, [limit, offset]);
        return result.rows;
    }
    async findManyByColumn(column, value, options = {}) {
        const { limit = 100, offset = 0, orderBy = this.primaryKey, orderDirection = 'ASC' } = options;
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName}
       WHERE ${column} = $1
       ORDER BY ${orderBy} ${orderDirection}
       LIMIT $2 OFFSET $3`, [value, limit, offset]);
        return result.rows;
    }
    async findOneByColumn(column, value) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE ${column} = $1 LIMIT 1`, [value]);
        return result.rows[0] || null;
    }
    // --------------------------------------------------------------------------
    // COUNT
    // --------------------------------------------------------------------------
    async count(whereClause, params) {
        const sql = whereClause
            ? `SELECT COUNT(*) FROM ${this.tableName} WHERE ${whereClause}`
            : `SELECT COUNT(*) FROM ${this.tableName}`;
        const result = await (0, client_1.query)(sql, params);
        return parseInt(result.rows[0].count, 10);
    }
    async exists(whereClause, params) {
        const count = await this.count(whereClause, params);
        return count > 0;
    }
    // --------------------------------------------------------------------------
    // INSERT
    // --------------------------------------------------------------------------
    async insert(data, client) {
        const columns = Object.keys(data);
        const values = Object.values(data);
        const snakeColumns = columns.map(toSnakeCase);
        const placeholders = values.map((_, i) => `$${i + 1}`).join(', ');
        const sql = `
      INSERT INTO ${this.tableName} (${snakeColumns.join(', ')})
      VALUES (${placeholders})
      RETURNING *
    `;
        const result = client ? await client.query(sql, values) : await (0, client_1.query)(sql, values);
        return result.rows[0];
    }
    async insertMany(data, client) {
        if (data.length === 0)
            return [];
        const columns = Object.keys(data[0]);
        const snakeColumns = columns.map(toSnakeCase);
        const placeholders = data
            .map((_, i) => {
            const rowPlaceholders = columns.map((_, j) => `$${i * columns.length + j + 1}`).join(', ');
            return `(${rowPlaceholders})`;
        })
            .join(', ');
        const values = data.flatMap(Object.values);
        const sql = `
      INSERT INTO ${this.tableName} (${snakeColumns.join(', ')})
      VALUES ${placeholders}
      RETURNING *
    `;
        const result = client ? await client.query(sql, values) : await (0, client_1.query)(sql, values);
        return result.rows;
    }
    // --------------------------------------------------------------------------
    // UPDATE
    // --------------------------------------------------------------------------
    async update(id, data, client) {
        const columns = Object.keys(data);
        const values = Object.values(data);
        const setClause = columns.map((col, i) => `${toSnakeCase(col)} = $${i + 2}`).join(', ');
        const sql = `
      UPDATE ${this.tableName}
      SET ${setClause}
      WHERE ${this.primaryKey} = $1
      RETURNING *
    `;
        const result = client
            ? await client.query(sql, [id, ...values])
            : await (0, client_1.query)(sql, [id, ...values]);
        return result.rows[0] || null;
    }
    async updateOrThrow(id, data, client) {
        const entity = await this.update(id, data, client);
        if (!entity) {
            throw new shared_1.NotFoundError(this.tableName, id);
        }
        return entity;
    }
    // --------------------------------------------------------------------------
    // DELETE
    // --------------------------------------------------------------------------
    async delete(id, client) {
        const result = client
            ? await client.query(`DELETE FROM ${this.tableName} WHERE ${this.primaryKey} = $1`, [id])
            : await (0, client_1.query)(`DELETE FROM ${this.tableName} WHERE ${this.primaryKey} = $1`, [id]);
        return (result.rowCount || 0) > 0;
    }
    async deleteMany(ids, client) {
        if (ids.length === 0)
            return 0;
        const result = client
            ? await client.query(`DELETE FROM ${this.tableName} WHERE ${this.primaryKey} = ANY($1)`, [
                ids,
            ])
            : await (0, client_1.query)(`DELETE FROM ${this.tableName} WHERE ${this.primaryKey} = ANY($1)`, [ids]);
        return result.rowCount || 0;
    }
    // --------------------------------------------------------------------------
    // RAW QUERY
    // --------------------------------------------------------------------------
    async rawQuery(sql, params = []) {
        const result = await (0, client_1.query)(sql, params);
        return result.rows;
    }
    async rawQueryOne(sql, params = []) {
        const result = await (0, client_1.query)(sql, params);
        return result.rows[0] || null;
    }
    // --------------------------------------------------------------------------
    // TRANSACTION HELPERS
    // --------------------------------------------------------------------------
    async withTransaction(callback) {
        return (0, client_1.transaction)(callback);
    }
}
exports.BaseRepository = BaseRepository;
//# sourceMappingURL=BaseRepository.js.map