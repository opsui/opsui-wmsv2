/**
 * Migration Runner Script
 *
 * Runs database migrations and tracks which ones have been applied.
 * This solves the issue of migrations not being applied, which causes
 * 500 errors when services query tables that don't exist.
 *
 * Usage:
 *   npx tsx packages/backend/src/db/run-migrations.ts
 */
declare const REQUIRED_MIGRATIONS: {
    name: string;
    filename: string;
    description: string;
}[];
export declare class MigrationRunner {
    private pool;
    private migrationsDir;
    /**
     * Initialize the migrations tracking table
     */
    initialize(): Promise<void>;
    /**
     * Get list of applied migrations
     */
    getAppliedMigrations(): Promise<string[]>;
    /**
     * Get migration file content
     */
    private getMigrationFile;
    /**
     * Apply a single migration
     */
    applyMigration(migration: {
        name: string;
        filename: string;
        description: string;
    }): Promise<boolean>;
    /**
     * Get status of all migrations
     */
    getStatus(): Promise<{
        applied: string[];
        pending: string[];
        all: typeof REQUIRED_MIGRATIONS;
    }>;
    /**
     * Run all pending migrations
     */
    run(): Promise<void>;
    /**
     * Verify all required tables exist
     */
    verifyTables(): Promise<{
        exists: string[];
        missing: string[];
    }>;
}
export {};
//# sourceMappingURL=run-migrations.d.ts.map