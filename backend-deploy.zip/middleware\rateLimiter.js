"use strict";
/**
 * Rate limiting middleware
 *
 * Prevents abuse by limiting request rate per IP address
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.pickingRateLimiter = exports.authRateLimiterSimple = exports.rateLimiter = void 0;
const express_rate_limit_1 = __importDefault(require("express-rate-limit"));
const config_1 = __importDefault(require("../config"));
// ============================================================================
// RATE LIMITER
// ============================================================================
exports.rateLimiter = (0, express_rate_limit_1.default)({
    windowMs: config_1.default.rateLimit.windowMs,
    max: config_1.default.rateLimit.maxRequests,
    message: {
        error: 'Too many requests from this IP, please try again later',
        code: 'RATE_LIMIT_EXCEEDED',
    },
    standardHeaders: true, // Return rate limit info in `RateLimit-*` headers
    legacyHeaders: false, // Disable `X-RateLimit-*` headers
    validate: { trustProxy: false, xForwardedForHeader: false }, // Disable strict proxy validation
    // Skip rate limiting for health check endpoint, development mode, local requests, or when explicitly disabled
    skip: req => {
        return (req.path === '/health' ||
            process.env.NODE_ENV !== 'production' ||
            process.env.DISABLE_RATE_LIMIT === 'true' ||
            req.ip === '127.0.0.1' ||
            req.ip === '::1' ||
            req.ip === 'localhost');
    },
});
// ============================================================================
// STRICT RATE LIMITER (for auth endpoints)
// ============================================================================
exports.authRateLimiterSimple = (0, express_rate_limit_1.default)({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 100, // 100 attempts per window (increased for development)
    message: {
        error: 'Too many authentication attempts, please try again later',
        code: 'AUTH_RATE_LIMIT_EXCEEDED',
    },
    standardHeaders: true,
    legacyHeaders: false,
    validate: { trustProxy: false, xForwardedForHeader: false }, // Disable strict proxy validation
    // Skip in development or when explicitly disabled
    skip: req => {
        return (process.env.NODE_ENV !== 'production' ||
            process.env.DISABLE_RATE_LIMIT === 'true' ||
            req.ip === '127.0.0.1' ||
            req.ip === '::1' ||
            req.ip === 'localhost');
    },
});
// ============================================================================
// PICKING RATE LIMITER (for pick actions)
// ============================================================================
exports.pickingRateLimiter = (0, express_rate_limit_1.default)({
    windowMs: 60 * 1000, // 1 minute
    max: 100, // 100 pick actions per minute
    message: {
        error: 'Too many pick actions, please slow down',
        code: 'PICK_RATE_LIMIT_EXCEEDED',
    },
    standardHeaders: true,
    legacyHeaders: false,
    validate: { trustProxy: false, xForwardedForHeader: false }, // Disable strict proxy validation
    // Skip in development or when explicitly disabled
    skip: req => {
        return (process.env.NODE_ENV !== 'production' ||
            process.env.DISABLE_RATE_LIMIT === 'true' ||
            req.ip === '127.0.0.1' ||
            req.ip === '::1' ||
            req.ip === 'localhost');
    },
});
//# sourceMappingURL=rateLimiter.js.map