/**
 * Organization Service
 *
 * Business logic for multi-tenant organization management.
 * Handles organization CRUD, memberships, invitations, and access control.
 */
import type { AcceptInvitationDTO, AssignOrganizationUserDTO, CreateInvitationDTO, CreateOrganizationDTO, Organization, OrganizationInvitation, OrganizationInvitationWithDetails, OrganizationListResponse, OrganizationQueryFilters, OrganizationSetting, OrganizationStatus, OrganizationTier, OrganizationUser, OrganizationUserQueryFilters, OrganizationUserWithDetails, OrganizationWithStats, UpdateOrganizationDTO, UpdateOrganizationUserDTO, UserOrganizationsResponse } from '@opsui/shared';
declare class OrganizationService {
    private userRepository;
    constructor();
    /**
     * Create a new organization
     * The creator becomes the ORG_OWNER
     */
    createOrganization(data: CreateOrganizationDTO): Promise<Organization>;
    /**
     * Get organization by ID
     */
    getOrganization(organizationId: string): Promise<OrganizationWithStats>;
    /**
     * Get organization by slug
     */
    getOrganizationBySlug(slug: string): Promise<OrganizationWithStats>;
    /**
     * List organizations with filters
     */
    listOrganizations(filters: OrganizationQueryFilters, page?: number, pageSize?: number): Promise<OrganizationListResponse>;
    /**
     * Update organization
     */
    updateOrganization(organizationId: string, data: UpdateOrganizationDTO, userId: string): Promise<Organization>;
    /**
     * Update organization status
     */
    updateStatus(organizationId: string, status: OrganizationStatus, userId: string): Promise<Organization>;
    /**
     * Update organization tier
     */
    updateTier(organizationId: string, tier: OrganizationTier, userId: string): Promise<Organization>;
    /**
     * Get user's organizations
     */
    getUserOrganizations(userId: string): Promise<UserOrganizationsResponse>;
    /**
     * Set user's primary organization
     */
    setPrimaryOrganization(userId: string, organizationId: string): Promise<void>;
    /**
     * Get organization members
     */
    getMembers(organizationId: string, userId: string, filters?: OrganizationUserQueryFilters, page?: number, pageSize?: number): Promise<{
        members: OrganizationUserWithDetails[];
        total: number;
    }>;
    /**
     * Add user to organization
     */
    addMember(organizationId: string, data: AssignOrganizationUserDTO, addedBy: string): Promise<OrganizationUser>;
    /**
     * Update member role/permissions
     */
    updateMember(organizationId: string, targetUserId: string, data: UpdateOrganizationUserDTO, updatedBy: string): Promise<OrganizationUser>;
    /**
     * Remove member from organization
     */
    removeMember(organizationId: string, targetUserId: string, removedBy: string): Promise<void>;
    /**
     * Invite user to organization
     */
    inviteUser(organizationId: string, data: CreateInvitationDTO, invitedBy: string): Promise<OrganizationInvitation>;
    /**
     * Get pending invitations for organization
     */
    getInvitations(organizationId: string, userId: string): Promise<OrganizationInvitation[]>;
    /**
     * Get pending invitations for email
     */
    getPendingInvitations(email: string): Promise<OrganizationInvitationWithDetails[]>;
    /**
     * Get invitation by token
     */
    getInvitationByToken(token: string): Promise<OrganizationInvitationWithDetails>;
    /**
     * Accept invitation
     */
    acceptInvitation(data: AcceptInvitationDTO): Promise<OrganizationUser>;
    /**
     * Decline invitation
     */
    declineInvitation(token: string): Promise<void>;
    /**
     * Cancel invitation
     */
    cancelInvitation(invitationId: string, organizationId: string, cancelledBy: string): Promise<void>;
    /**
     * Get organization settings
     */
    getSettings(organizationId: string, userId: string): Promise<OrganizationSetting[]>;
    /**
     * Get specific setting
     */
    getSetting(organizationId: string, key: string, userId: string): Promise<OrganizationSetting | null>;
    /**
     * Set organization setting
     */
    setSetting(organizationId: string, key: string, value: string, type: 'STRING' | 'NUMBER' | 'BOOLEAN' | 'JSON', userId: string): Promise<OrganizationSetting>;
    /**
     * Delete organization setting
     */
    deleteSetting(organizationId: string, key: string, userId: string): Promise<void>;
    /**
     * Check if user has access to organization
     */
    checkAccess(organizationId: string, userId: string): Promise<OrganizationUser>;
    /**
     * Check if user has specific permission
     */
    checkPermission(organizationId: string, userId: string, permission: 'can_manage_users' | 'can_manage_billing' | 'can_manage_settings' | 'can_invite_users'): Promise<OrganizationUser>;
    /**
     * Check if user is organization owner
     */
    isOwner(organizationId: string, userId: string): Promise<boolean>;
    /**
     * Check if user is organization admin
     */
    isAdmin(organizationId: string, userId: string): Promise<boolean>;
    /**
     * Cleanup expired invitations
     */
    cleanupExpiredInvitations(): Promise<number>;
}
export declare const organizationService: OrganizationService;
export {};
//# sourceMappingURL=OrganizationService.d.ts.map