/**
 * Test Helper Functions
 *
 * Utility functions for writing tests.
 */
import { Pool } from 'pg';
/**
 * Get a test database connection
 */
export declare function getTestDb(): Pool;
/**
 * Clean all tables in the test database
 */
export declare function cleanDatabase(db: Pool): Promise<void>;
/**
 * Run a database transaction that auto-rolls back
 */
export declare function withTransaction<T>(db: Pool, callback: (db: Pool) => Promise<T>): Promise<T>;
/**
 * Create a test user
 */
export interface TestUser {
    id: string;
    email: string;
    password: string;
    name: string;
    role_id: string;
}
export declare function createTestUser(db: Pool, overrides?: Partial<TestUser>): Promise<TestUser>;
export declare function generateTestToken(userId: string, email: string, roleId: string, overrides?: {
    expiresIn?: string | number;
}): string;
/**
 * Get auth headers for a test user
 */
export declare function getTestAuthHeaders(db: Pool, user?: TestUser): Promise<{
    Authorization: string;
}>;
/**
 * Create a test order
 */
export interface TestOrder {
    id: string;
    customer_id: string;
    customer_name: string;
    status: string;
    priority: string;
}
export declare function createTestOrder(db: Pool, overrides?: Partial<TestOrder>): Promise<TestOrder>;
/**
 * Create a test product
 */
export interface TestProduct {
    id: string;
    sku: string;
    name: string;
    description: string;
    unit_of_measure: string;
    weight_lbs: number;
}
export declare function createTestProduct(db: Pool, overrides?: Partial<TestProduct>): Promise<TestProduct>;
/**
 * Create a test location
 */
export interface TestLocation {
    id: string;
    zone: string;
    aisle: string;
    shelf: string;
    bin: string;
    location_type: string;
}
export declare function createTestLocation(db: Pool, overrides?: Partial<TestLocation>): Promise<TestLocation>;
/**
 * Create test inventory
 */
export declare function createTestInventory(db: Pool, productId: string, locationId: string, quantity?: number): Promise<void>;
/**
 * Create a test API request with auth headers
 */
export interface TestApiRequest {
    method: string;
    path: string;
    body?: any;
    headers?: Record<string, string>;
    userId?: string;
}
export declare function makeTestRequest(request: TestApiRequest): Promise<{
    status: number;
    data: any;
    headers: Headers;
}>;
/**
 * Assert that an API response has the expected status
 */
export declare function expectStatus(response: {
    status: number;
}, expectedStatus: number): void;
/**
 * Assert that an API response has a specific error
 */
export declare function expectApiError(response: {
    status: number;
    data: any;
}, expectedError: {
    code?: string;
    message?: string;
}): void;
/**
 * Create a mock response object
 */
export declare function createMockResponse(): any;
/**
 * Create a mock request object
 */
export declare function createMockRequest(overrides?: any): any;
/**
 * Wait for a specified amount of time
 */
export declare function wait(ms: number): Promise<void>;
/**
 * Retry a function until it succeeds or times out
 */
export declare function retry<T>(fn: () => Promise<T>, options?: {
    maxAttempts?: number;
    delay?: number;
    timeout?: number;
}): Promise<T>;
//# sourceMappingURL=helpers.d.ts.map