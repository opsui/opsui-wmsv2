"use strict";
/**
 * Production Management Routes
 *
 * API endpoints for production orders, BOMs, and manufacturing workflows
 */
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const ProductionService_1 = require("../services/ProductionService");
const middleware_1 = require("../middleware");
const shared_1 = require("@opsui/shared");
const middleware_2 = require("../middleware");
const router = (0, express_1.Router)();
// All production routes require authentication
router.use(middleware_1.authenticate);
// ============================================================================
// DASHBOARD
// ============================================================================
/**
 * GET /api/production/dashboard
 * Get production dashboard metrics
 * Access: All authenticated users
 */
router.get('/dashboard', (0, middleware_2.asyncHandler)(async (_req, res) => {
    const metrics = await ProductionService_1.productionService.getDashboardMetrics();
    res.json(metrics);
}));
// ============================================================================
// BILLS OF MATERIALS
// ============================================================================
/**
 * POST /api/production/bom
 * Create a new Bill of Materials
 * Access: ADMIN, SUPERVISOR, PRODUCTION
 */
router.post('/bom', (0, middleware_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR, shared_1.UserRole.PRODUCTION), (0, middleware_2.asyncHandler)(async (req, res) => {
    const bom = await ProductionService_1.productionService.createBOM(req.body, req.user.userId);
    res.status(201).json(bom);
}));
/**
 * GET /api/production/bom
 * Get all Bills of Materials
 * Access: All authenticated users
 */
router.get('/bom', (0, middleware_2.asyncHandler)(async (req, res) => {
    const { productId, status } = req.query;
    const boms = await ProductionService_1.productionService.getAllBOMs({
        productId: productId,
        status: status,
    });
    res.json({ boms, count: boms.length });
}));
/**
 * GET /api/production/bom/:bomId
 * Get a specific BOM by ID
 * Access: All authenticated users
 */
router.get('/bom/:bomId', (0, middleware_2.asyncHandler)(async (req, res) => {
    const { bomId } = req.params;
    const bom = await ProductionService_1.productionService.getBOMById(bomId);
    res.json(bom);
}));
/**
 * PUT /api/production/bom/:bomId
 * Update a Bill of Materials
 * Access: ADMIN, SUPERVISOR, PRODUCTION
 */
router.put('/bom/:bomId', (0, middleware_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR, shared_1.UserRole.PRODUCTION), (0, middleware_2.asyncHandler)(async (req, res) => {
    const { bomId } = req.params;
    const bom = await ProductionService_1.productionService.updateBOM(bomId, req.body, req.user.userId);
    res.json(bom);
}));
/**
 * POST /api/production/bom/:bomId/activate
 * Activate a BOM (DRAFT → ACTIVE)
 * Access: ADMIN, SUPERVISOR, PRODUCTION
 */
router.post('/bom/:bomId/activate', (0, middleware_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR, shared_1.UserRole.PRODUCTION), (0, middleware_2.asyncHandler)(async (req, res) => {
    const { bomId } = req.params;
    const bom = await ProductionService_1.productionService.activateBOM(bomId, req.user.userId);
    res.json(bom);
}));
/**
 * DELETE /api/production/bom/:bomId
 * Delete a Bill of Materials
 * Access: ADMIN, SUPERVISOR
 */
router.delete('/bom/:bomId', (0, middleware_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR), (0, middleware_2.asyncHandler)(async (req, res) => {
    const { bomId } = req.params;
    await ProductionService_1.productionService.deleteBOM(bomId);
    res.status(204).send();
}));
// ============================================================================
// PRODUCTION ORDERS
// ============================================================================
/**
 * POST /api/production/orders
 * Create a new production order
 * Access: ADMIN, SUPERVISOR, PRODUCTION
 */
router.post('/orders', (0, middleware_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR, shared_1.UserRole.PRODUCTION), (0, middleware_2.asyncHandler)(async (req, res) => {
    const order = await ProductionService_1.productionService.createProductionOrder(req.body, req.user.userId);
    res.status(201).json(order);
}));
/**
 * GET /api/production/orders
 * Get all production orders with optional filtering
 * Access: All authenticated users
 */
router.get('/orders', (0, middleware_2.asyncHandler)(async (req, res) => {
    const { status, assignedTo, limit, offset } = req.query;
    const result = await ProductionService_1.productionService.getAllProductionOrders({
        status: status,
        assignedTo: assignedTo,
        limit: limit ? parseInt(limit) : undefined,
        offset: offset ? parseInt(offset) : undefined,
    });
    res.json(result);
}));
/**
 * GET /api/production/orders/:orderId
 * Get a specific production order by ID
 * Access: All authenticated users
 */
router.get('/orders/:orderId', (0, middleware_2.asyncHandler)(async (req, res) => {
    const { orderId } = req.params;
    const order = await ProductionService_1.productionService.getProductionOrderById(orderId);
    res.json(order);
}));
/**
 * PUT /api/production/orders/:orderId
 * Update a production order
 * Access: ADMIN, SUPERVISOR, PRODUCTION
 */
router.put('/orders/:orderId', (0, middleware_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR, shared_1.UserRole.PRODUCTION), (0, middleware_2.asyncHandler)(async (req, res) => {
    const { orderId } = req.params;
    const order = await ProductionService_1.productionService.updateProductionOrder(orderId, req.body, req.user.userId);
    res.json(order);
}));
/**
 * POST /api/production/orders/:orderId/release
 * Release a production order (PLANNED → RELEASED)
 * Access: ADMIN, SUPERVISOR, PRODUCTION
 */
router.post('/orders/:orderId/release', (0, middleware_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR, shared_1.UserRole.PRODUCTION), (0, middleware_2.asyncHandler)(async (req, res) => {
    const { orderId } = req.params;
    const order = await ProductionService_1.productionService.releaseProductionOrder(orderId, req.user.userId);
    res.json(order);
}));
/**
 * POST /api/production/orders/:orderId/start
 * Start a production order (RELEASED → IN_PROGRESS)
 * Access: PRODUCTION, ADMIN, SUPERVISOR
 */
router.post('/orders/:orderId/start', (0, middleware_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR, shared_1.UserRole.PRODUCTION), (0, middleware_2.asyncHandler)(async (req, res) => {
    const { orderId } = req.params;
    const order = await ProductionService_1.productionService.startProductionOrder(orderId, req.user.userId);
    res.json(order);
}));
/**
 * POST /api/production/orders/:orderId/output
 * Record production output
 * Access: PRODUCTION, ADMIN, SUPERVISOR
 */
router.post('/orders/:orderId/output', (0, middleware_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR, shared_1.UserRole.PRODUCTION), (0, middleware_2.asyncHandler)(async (req, res) => {
    const { orderId } = req.params;
    const output = await ProductionService_1.productionService.recordProductionOutput({
        ...req.body,
        orderId,
    }, req.user.userId);
    res.status(201).json(output);
}));
/**
 * GET /api/production/orders/:orderId/journal
 * Get production journal entries for an order
 * Access: All authenticated users
 */
router.get('/orders/:orderId/journal', (0, middleware_2.asyncHandler)(async (req, res) => {
    const { orderId } = req.params;
    const journal = await ProductionService_1.productionService.getProductionJournal(orderId);
    res.json({ journal, count: journal.length });
}));
/**
 * POST /api/production/orders/:orderId/cancel
 * Cancel a production order
 * Access: ADMIN, SUPERVISOR, PRODUCTION
 */
router.post('/orders/:orderId/cancel', (0, middleware_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR, shared_1.UserRole.PRODUCTION), (0, middleware_2.asyncHandler)(async (req, res) => {
    const { orderId } = req.params;
    const order = await ProductionService_1.productionService.cancelProductionOrder(orderId, req.user.userId);
    res.json(order);
}));
/**
 * POST /api/production/orders/:orderId/hold
 * Put a production order on hold
 * Access: ADMIN, SUPERVISOR, PRODUCTION
 */
router.post('/orders/:orderId/hold', (0, middleware_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR, shared_1.UserRole.PRODUCTION), (0, middleware_2.asyncHandler)(async (req, res) => {
    const { orderId } = req.params;
    const order = await ProductionService_1.productionService.holdProductionOrder(orderId, req.user.userId);
    res.json(order);
}));
/**
 * POST /api/production/orders/:orderId/resume
 * Resume a production order from hold
 * Access: ADMIN, SUPERVISOR, PRODUCTION
 */
router.post('/orders/:orderId/resume', (0, middleware_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR, shared_1.UserRole.PRODUCTION), (0, middleware_2.asyncHandler)(async (req, res) => {
    const { orderId } = req.params;
    const order = await ProductionService_1.productionService.resumeProductionOrder(orderId, req.user.userId);
    res.json(order);
}));
/**
 * POST /api/production/orders/:orderId/materials/issue
 * Issue materials to a production order
 * Access: PRODUCTION, ADMIN, SUPERVISOR
 */
router.post('/orders/:orderId/materials/issue', (0, middleware_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR, shared_1.UserRole.PRODUCTION), (0, middleware_2.asyncHandler)(async (req, res) => {
    const { orderId } = req.params;
    await ProductionService_1.productionService.issueMaterial({
        ...req.body,
        orderId,
    }, req.user.userId);
    res.status(204).send();
}));
/**
 * POST /api/production/orders/:orderId/materials/return
 * Return materials from a production order
 * Access: PRODUCTION, ADMIN, SUPERVISOR
 */
router.post('/orders/:orderId/materials/return', (0, middleware_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR, shared_1.UserRole.PRODUCTION), (0, middleware_2.asyncHandler)(async (req, res) => {
    const { orderId } = req.params;
    await ProductionService_1.productionService.returnMaterial({
        ...req.body,
        orderId,
    }, req.user.userId);
    res.status(204).send();
}));
exports.default = router;
//# sourceMappingURL=production.js.map