"use strict";
/**
 * Interleaved Count routes
 *
 * Endpoints for micro-counts performed during picking and other operations
 */
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const InterleavedCountService_1 = require("../services/InterleavedCountService");
const middleware_1 = require("../middleware");
const shared_1 = require("@opsui/shared");
const permissions_1 = require("../middleware/permissions");
const router = (0, express_1.Router)();
// All interleaved count routes require authentication
router.use(middleware_1.authenticate);
/**
 * POST /api/interleaved-count/micro
 * Create a micro-count (quick count during picking)
 * Requires PERFORM_CYCLE_COUNTS permission
 */
router.post('/micro', (0, permissions_1.requirePermission)(shared_1.Permission.PERFORM_CYCLE_COUNTS), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { sku, binLocation, countedQuantity, orderId, notes } = req.body;
    // Validate required fields
    if (!sku || !binLocation || countedQuantity === undefined) {
        res.status(400).json({
            error: 'Missing required fields',
            code: 'MISSING_FIELDS',
        });
        return;
    }
    const microCount = await InterleavedCountService_1.interleavedCountService.createMicroCount({
        sku,
        binLocation,
        countedQuantity: parseFloat(countedQuantity),
        userId: req.user.userId,
        orderId,
        notes,
    });
    res.status(201).json(microCount);
}));
/**
 * GET /api/interleaved-count/stats
 * Get micro-count statistics for the current user
 */
router.get('/stats', (0, middleware_1.asyncHandler)(async (req, res) => {
    const days = req.query.days ? parseInt(req.query.days) : 30;
    const stats = await InterleavedCountService_1.interleavedCountService.getMicroCountStats(req.user.userId, days);
    res.json(stats);
}));
exports.default = router;
//# sourceMappingURL=interleavedCount.js.map