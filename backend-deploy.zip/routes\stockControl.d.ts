/**
 * Stock Control routes
 *
 * Routes for stock controllers to manage inventory, perform stock counts,
 * transfers, and adjustments
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=stockControl.d.ts.map