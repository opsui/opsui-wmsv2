/**
 * Sales & CRM Service
 *
 * Business logic for customer management, leads, opportunities, and quotes
 */
import { Customer, Lead, Opportunity, Quote, CustomerInteraction, CreateCustomerDTO, CreateLeadDTO, CreateOpportunityDTO, CreateQuoteDTO, CustomerStatus, LeadStatus, OpportunityStage, QuoteStatus, SalesOrder, Backorder, SalesCommission, SalesTerritory, SalesTerritoryCustomer, SalesTerritoryQuota, SalesOrderActivity, CreateSalesOrderDTO, UpdateSalesOrderDTO, CreateBackorderDTO, CreateSalesTerritoryDTO, CreateTerritoryQuotaDTO, AssignTerritoryCustomerDTO, SalesOrderFilters, BackorderFilters, CommissionFilters, SalesOrderMetrics, TerritoryMetrics } from '@opsui/shared';
export declare class SalesService {
    createCustomer(dto: CreateCustomerDTO, createdBy: string): Promise<Customer>;
    getCustomerById(customerId: string): Promise<Customer>;
    getAllCustomers(filters?: {
        status?: CustomerStatus;
        assignedTo?: string;
        limit?: number;
        offset?: number;
    }): Promise<{
        customers: Customer[];
        total: number;
    }>;
    updateCustomer(customerId: string, dto: Partial<Customer>, userId: string): Promise<Customer>;
    createLead(dto: CreateLeadDTO, createdBy: string): Promise<Lead>;
    getLeadById(leadId: string): Promise<Lead>;
    getAllLeads(filters?: {
        status?: LeadStatus;
        assignedTo?: string;
        limit?: number;
        offset?: number;
    }): Promise<{
        leads: Lead[];
        total: number;
    }>;
    updateLead(leadId: string, dto: Partial<Lead>, userId: string): Promise<Lead>;
    convertLeadToCustomer(leadId: string, userId: string): Promise<Customer>;
    createOpportunity(dto: CreateOpportunityDTO, createdBy: string): Promise<Opportunity>;
    getOpportunityById(opportunityId: string): Promise<Opportunity>;
    getAllOpportunities(filters?: {
        stage?: OpportunityStage;
        customerId?: string;
        assignedTo?: string;
        limit?: number;
        offset?: number;
    }): Promise<{
        opportunities: Opportunity[];
        total: number;
    }>;
    updateOpportunityStage(opportunityId: string, stage: OpportunityStage, userId: string): Promise<Opportunity>;
    createQuote(dto: CreateQuoteDTO, createdBy: string): Promise<Quote>;
    getQuoteById(quoteId: string): Promise<Quote>;
    getAllQuotes(filters?: {
        customerId?: string;
        status?: QuoteStatus;
        limit?: number;
        offset?: number;
    }): Promise<{
        quotes: Quote[];
        total: number;
    }>;
    sendQuote(quoteId: string, userId: string): Promise<Quote>;
    acceptQuote(quoteId: string, userId: string): Promise<{
        quote: Quote;
        order?: any;
    }>;
    logInteraction(dto: Omit<CustomerInteraction, 'interactionId' | 'createdAt'>): Promise<CustomerInteraction>;
    getCustomerInteractions(customerId: string, limit?: number): Promise<CustomerInteraction[]>;
    getDashboard(): Promise<{
        totalCustomers: number;
        activeLeads: number;
        openOpportunities: number;
        pendingQuotes: number;
        totalPipeline: number;
    }>;
    createSalesOrder(dto: CreateSalesOrderDTO, createdBy: string): Promise<SalesOrder>;
    getSalesOrderById(orderId: string): Promise<SalesOrder>;
    getAllSalesOrders(filters?: SalesOrderFilters): Promise<{
        orders: SalesOrder[];
        total: number;
    }>;
    updateSalesOrder(orderId: string, dto: UpdateSalesOrderDTO, userId: string): Promise<SalesOrder>;
    deleteSalesOrder(orderId: string): Promise<void>;
    createBackorder(dto: CreateBackorderDTO, createdBy: string): Promise<Backorder>;
    getBackorderById(backorderId: string): Promise<Backorder>;
    getAllBackorders(filters?: BackorderFilters): Promise<Backorder[]>;
    fulfillBackorder(backorderId: string, quantity: number, userId: string): Promise<Backorder>;
    getAllCommissions(filters?: CommissionFilters): Promise<SalesCommission[]>;
    getCommissionSummary(salesPersonId: string, year?: number): Promise<{
        totalEarned: number;
        totalPaid: number;
        pendingPayment: number;
        transactionCount: number;
    }>;
    payCommissions(commissionIds: string[], paymentDate: Date, userId: string): Promise<void>;
    createTerritory(dto: CreateSalesTerritoryDTO): Promise<SalesTerritory>;
    getAllTerritories(): Promise<SalesTerritory[]>;
    getTerritoryById(territoryId: string): Promise<SalesTerritory>;
    getTerritoryMetrics(territoryId: string): Promise<TerritoryMetrics>;
    assignCustomerToTerritory(dto: AssignTerritoryCustomerDTO, userId: string): Promise<SalesTerritoryCustomer>;
    createTerritoryQuota(dto: CreateTerritoryQuotaDTO): Promise<SalesTerritoryQuota>;
    getSalesOrderMetrics(): Promise<SalesOrderMetrics>;
    getOrderActivity(orderId: string, limit?: number): Promise<SalesOrderActivity[]>;
}
export declare const salesService: SalesService;
//# sourceMappingURL=SalesService.d.ts.map