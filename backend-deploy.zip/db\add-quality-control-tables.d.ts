/**
 * Add Quality Control Tables Migration
 *
 * This script creates the quality control tables that were missing
 * from the database after the Phase 2 migration.
 */
export {};
//# sourceMappingURL=add-quality-control-tables.d.ts.map