/**
 * Manufacturing Repository
 *
 * Data access layer for manufacturing operations
 * Handles work centers, routings, MPS, MRP, production orders,
 * shop floor control, quality, and capacity planning
 */
import { BaseRepository } from './BaseRepository';
import type { WorkCenter, WorkCenterQueue, Routing, RoutingWithDetails, RoutingOperation, RoutingBOMComponent, MSPPeriod, MPSItem, MRPParameters, MRPPlan, MRPPlanDetail, MRPActionMessage, ManufacturingOrder, ManufacturingOrderWithDetails, ProductionOrderOperation, ShopFloorTransaction, ProductionInspection, ProductionDefect, CapacityPlan, CapacityPlanDetail, WorkCenterQueryFilters, RoutingQueryFilters, ProductionOrderQueryFilters, MRPPlanQueryFilters, CapacityPlanQueryFilters } from '@opsui/shared';
export declare class WorkCenterRepository extends BaseRepository<WorkCenter> {
    constructor();
    findByCode(workCenterCode: string): Promise<WorkCenter | null>;
    findActive(): Promise<WorkCenter[]>;
    findByDepartment(department: string): Promise<WorkCenter[]>;
    findBySite(siteId: string): Promise<WorkCenter[]>;
    queryWithFilters(filters: WorkCenterQueryFilters): Promise<WorkCenter[]>;
}
export declare class WorkCenterQueueRepository extends BaseRepository<WorkCenterQueue> {
    constructor();
    findByWorkCenter(workCenterId: string): Promise<WorkCenterQueue | null>;
    findOverloaded(): Promise<Array<WorkCenterQueue & {
        work_center_code: string;
    }>>;
}
export declare class RoutingRepository extends BaseRepository<Routing> {
    constructor();
    findByNumber(routingNumber: string): Promise<Routing | null>;
    findBySKU(sku: string, activeOnly?: boolean): Promise<Routing[]>;
    findByIdWithDetails(routingId: string): Promise<RoutingWithDetails | null>;
    queryWithFilters(filters: RoutingQueryFilters): Promise<Routing[]>;
}
export declare class RoutingOperationRepository extends BaseRepository<RoutingOperation> {
    constructor();
    findByRouting(routingId: string): Promise<RoutingOperation[]>;
    findByWorkCenter(workCenterId: string): Promise<RoutingOperation[]>;
}
export declare class RoutingBOMRepository extends BaseRepository<RoutingBOMComponent> {
    constructor();
    findByRouting(routingId: string): Promise<RoutingBOMComponent[]>;
    findByOperation(operationId: string): Promise<RoutingBOMComponent[]>;
    findByComponentSKU(sku: string): Promise<RoutingBOMComponent[]>;
}
export declare class MSPPeriodRepository extends BaseRepository<MSPPeriod> {
    constructor();
    findByEntity(entityId: string): Promise<MSPPeriod[]>;
    findCurrentPeriod(entityId: string): Promise<MSPPeriod | null>;
    findByDateRange(startDate: Date, endDate: Date, entityId?: string): Promise<MSPPeriod[]>;
}
export declare class MPSItemRepository extends BaseRepository<MPSItem> {
    constructor();
    findByPeriod(periodId: string): Promise<MPSItem[]>;
    findBySKU(sku: string): Promise<MPSItem[]>;
    findPendingRelease(): Promise<MPSItem[]>;
}
export declare class MRPParametersRepository extends BaseRepository<MRPParameters> {
    constructor();
    findByEntity(entityId: string): Promise<MRPParameters | null>;
}
export declare class MRPPlanRepository extends BaseRepository<MRPPlan> {
    constructor();
    findByNumber(planNumber: string): Promise<MRPPlan | null>;
    findByEntity(entityId: string): Promise<MRPPlan[]>;
    findLatestCompleted(entityId?: string): Promise<MRPPlan | null>;
    queryWithFilters(filters: MRPPlanQueryFilters): Promise<MRPPlan[]>;
}
export declare class MRPPlanDetailRepository extends BaseRepository<MRPPlanDetail> {
    constructor();
    findByPlan(planId: string): Promise<MRPPlanDetail[]>;
    findBySKU(sku: string): Promise<MRPPlanDetail[]>;
    findWithActionMessages(planId: string): Promise<MRPPlanDetail[]>;
}
export declare class MRPActionMessageRepository extends BaseRepository<MRPActionMessage> {
    constructor();
    findByPlan(planId: string): Promise<MRPActionMessage[]>;
    findPendingReview(planId?: string): Promise<MRPActionMessage[]>;
    findBySKU(sku: string): Promise<MRPActionMessage[]>;
    findByActionType(actionType: string): Promise<MRPActionMessage[]>;
}
export declare class ProductionOrderRepository extends BaseRepository<ManufacturingOrder> {
    constructor();
    findByNumber(orderNumber: string): Promise<ManufacturingOrder | null>;
    findByIdWithDetails(orderId: string): Promise<ManufacturingOrderWithDetails | null>;
    queryWithFilters(filters: ProductionOrderQueryFilters): Promise<ManufacturingOrder[]>;
    findActive(): Promise<ManufacturingOrder[]>;
    findPastDue(): Promise<ManufacturingOrder[]>;
    findBySalesOrder(salesOrderId: string): Promise<ManufacturingOrder[]>;
}
export declare class ProductionOrderOperationRepository extends BaseRepository<ProductionOrderOperation> {
    constructor();
    findByProductionOrder(orderId: string): Promise<ProductionOrderOperation[]>;
    findByWorkCenter(workCenterId: string): Promise<ProductionOrderOperation[]>;
    findNextOperation(orderId: string): Promise<ProductionOrderOperation | null>;
    findInProgress(): Promise<ProductionOrderOperation[]>;
}
export declare class ShopFloorTransactionRepository extends BaseRepository<ShopFloorTransaction> {
    constructor();
    findByProductionOrder(orderId: string): Promise<ShopFloorTransaction[]>;
    findByOperation(operationId: string): Promise<ShopFloorTransaction[]>;
    findByUser(userId: string, limit?: number): Promise<ShopFloorTransaction[]>;
    findByTransactionType(transactionType: string, limit?: number): Promise<ShopFloorTransaction[]>;
}
export declare class ProductionInspectionRepository extends BaseRepository<ProductionInspection> {
    constructor();
    findByNumber(inspectionNumber: string): Promise<ProductionInspection | null>;
    findByProductionOrder(orderId: string): Promise<ProductionInspection[]>;
    findByOperation(operationId: string): Promise<ProductionInspection[]>;
    findPending(): Promise<ProductionInspection[]>;
}
export declare class ProductionDefectRepository extends BaseRepository<ProductionDefect> {
    constructor();
    findByInspection(inspectionId: string): Promise<ProductionDefect[]>;
    findByProductionOrder(orderId: string): Promise<ProductionDefect[]>;
    findUnresolved(): Promise<ProductionDefect[]>;
    findBySeverity(severity: string): Promise<ProductionDefect[]>;
    findBySKU(sku: string, limit?: number): Promise<ProductionDefect[]>;
}
export declare class CapacityPlanRepository extends BaseRepository<CapacityPlan> {
    constructor();
    findByNumber(planNumber: string): Promise<CapacityPlan | null>;
    findByEntity(entityId: string): Promise<CapacityPlan[]>;
    findActive(): Promise<CapacityPlan[]>;
    queryWithFilters(filters: CapacityPlanQueryFilters): Promise<CapacityPlan[]>;
}
export declare class CapacityPlanDetailRepository extends BaseRepository<CapacityPlanDetail> {
    constructor();
    findByPlan(planId: string): Promise<CapacityPlanDetail[]>;
    findByWorkCenter(workCenterId: string): Promise<CapacityPlanDetail[]>;
    findOverloaded(planId?: string): Promise<CapacityPlanDetail[]>;
}
export declare const workCenterRepository: WorkCenterRepository;
export declare const workCenterQueueRepository: WorkCenterQueueRepository;
export declare const routingRepository: RoutingRepository;
export declare const routingOperationRepository: RoutingOperationRepository;
export declare const routingBOMRepository: RoutingBOMRepository;
export declare const mspPeriodRepository: MSPPeriodRepository;
export declare const mspItemRepository: MPSItemRepository;
export declare const mrpParametersRepository: MRPParametersRepository;
export declare const mrpPlanRepository: MRPPlanRepository;
export declare const mrpPlanDetailRepository: MRPPlanDetailRepository;
export declare const mrpActionMessageRepository: MRPActionMessageRepository;
export declare const productionOrderRepository: ProductionOrderRepository;
export declare const productionOrderOperationRepository: ProductionOrderOperationRepository;
export declare const shopFloorTransactionRepository: ShopFloorTransactionRepository;
export declare const productionInspectionRepository: ProductionInspectionRepository;
export declare const productionDefectRepository: ProductionDefectRepository;
export declare const capacityPlanRepository: CapacityPlanRepository;
export declare const capacityPlanDetailRepository: CapacityPlanDetailRepository;
//# sourceMappingURL=ManufacturingRepository.d.ts.map