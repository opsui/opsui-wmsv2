"use strict";
/**
 * Audit Service - SOC2/ISO27001 Compliant Audit Logging
 *
 * Provides comprehensive audit trail for:
 * - User authentication and authorization changes
 * - Data access and modifications
 * - Configuration changes
 * - Security events
 * - Admin actions
 *
 * Features:
 * - Immutable audit trail (records cannot be deleted or modified)
 * - Automatic retention management
 * - Structured event types and categories
 * - Integration with OpenTelemetry for distributed tracing
 *
 * @see https://www.aicpa.org/soc4so
 * @see https://www.iso.org/standard/27001
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuditService = exports.AuditEventType = exports.AuditCategory = void 0;
exports.getAuditService = getAuditService;
const client_1 = require("../db/client");
const logger_1 = require("../config/logger");
const telemetry_1 = require("../observability/telemetry");
// ============================================================================
// TYPES
// ============================================================================
/**
 * Audit event categories for organizing audit logs
 */
var AuditCategory;
(function (AuditCategory) {
    AuditCategory["AUTHENTICATION"] = "AUTHENTICATION";
    AuditCategory["AUTHORIZATION"] = "AUTHORIZATION";
    AuditCategory["USER_MANAGEMENT"] = "USER_MANAGEMENT";
    AuditCategory["DATA_ACCESS"] = "DATA_ACCESS";
    AuditCategory["DATA_MODIFICATION"] = "DATA_MODIFICATION";
    AuditCategory["CONFIGURATION"] = "CONFIGURATION";
    AuditCategory["SECURITY"] = "SECURITY";
    AuditCategory["API_ACCESS"] = "API_ACCESS";
    AuditCategory["SYSTEM"] = "SYSTEM";
})(AuditCategory || (exports.AuditCategory = AuditCategory = {}));
/**
 * Specific audit event types for detailed tracking
 */
var AuditEventType;
(function (AuditEventType) {
    // Authentication events
    AuditEventType["LOGIN_SUCCESS"] = "LOGIN_SUCCESS";
    AuditEventType["LOGIN_FAILED"] = "LOGIN_FAILED";
    AuditEventType["LOGOUT"] = "LOGOUT";
    AuditEventType["PASSWORD_CHANGE"] = "PASSWORD_CHANGE";
    AuditEventType["PASSWORD_RESET"] = "PASSWORD_RESET";
    AuditEventType["MFA_ENABLED"] = "MFA_ENABLED";
    AuditEventType["MFA_DISABLED"] = "MFA_DISABLED";
    // Authorization events
    AuditEventType["ROLE_GRANTED"] = "ROLE_GRANTED";
    AuditEventType["ROLE_REVOKED"] = "ROLE_REVOKED";
    AuditEventType["PERMISSION_GRANTED"] = "PERMISSION_GRANTED";
    AuditEventType["PERMISSION_REVOKED"] = "PERMISSION_REVOKED";
    AuditEventType["CUSTOM_ROLE_CREATED"] = "CUSTOM_ROLE_CREATED";
    AuditEventType["CUSTOM_ROLE_UPDATED"] = "CUSTOM_ROLE_UPDATED";
    AuditEventType["CUSTOM_ROLE_DELETED"] = "CUSTOM_ROLE_DELETED";
    // User management
    AuditEventType["USER_CREATED"] = "USER_CREATED";
    AuditEventType["USER_UPDATED"] = "USER_UPDATED";
    AuditEventType["USER_DELETED"] = "USER_DELETED";
    AuditEventType["USER_REACTIVATED"] = "USER_REACTIVATED";
    AuditEventType["USER_DEACTIVATED"] = "USER_DEACTIVATED";
    // Data access
    AuditEventType["ORDER_VIEWED"] = "ORDER_VIEWED";
    AuditEventType["ORDERS_EXPORTED"] = "ORDERS_EXPORTED";
    AuditEventType["INVENTORY_VIEWED"] = "INVENTORY_VIEWED";
    AuditEventType["INVENTORY_EXPORTED"] = "INVENTORY_EXPORTED";
    AuditEventType["REPORT_GENERATED"] = "REPORT_GENERATED";
    // Data modification
    AuditEventType["ORDER_CREATED"] = "ORDER_CREATED";
    AuditEventType["ORDER_UPDATED"] = "ORDER_UPDATED";
    AuditEventType["ORDER_CANCELLED"] = "ORDER_CANCELLED";
    AuditEventType["ORDER_CLAIMED"] = "ORDER_CLAIMED";
    AuditEventType["ORDER_UNCLAIMED"] = "ORDER_UNCLAIMED";
    AuditEventType["ORDER_CONTINUED"] = "ORDER_CONTINUED";
    AuditEventType["INVENTORY_ADJUSTED"] = "INVENTORY_ADJUSTED";
    AuditEventType["ITEM_SCANNED"] = "ITEM_SCANNED";
    AuditEventType["PICK_CONFIRMED"] = "PICK_CONFIRMED";
    AuditEventType["PACK_COMPLETED"] = "PACK_COMPLETED";
    AuditEventType["WAVE_CREATED"] = "WAVE_CREATED";
    AuditEventType["WAVE_RELEASED"] = "WAVE_RELEASED";
    AuditEventType["WAVE_COMPLETED"] = "WAVE_COMPLETED";
    AuditEventType["SLOTTING_IMPLEMENTED"] = "SLOTTING_IMPLEMENTED";
    AuditEventType["ZONE_ASSIGNED"] = "ZONE_ASSIGNED";
    AuditEventType["ZONE_RELEASED"] = "ZONE_RELEASED";
    AuditEventType["ZONE_REBALANCED"] = "ZONE_REBALANCED";
    AuditEventType["PUTAWAY_COMPLETED"] = "PUTAWAY_COMPLETED";
    AuditEventType["CYCLE_COUNT_PLAN_CREATED"] = "CYCLE_COUNT_PLAN_CREATED";
    AuditEventType["CYCLE_COUNT_STARTED"] = "CYCLE_COUNT_STARTED";
    AuditEventType["CYCLE_COUNT_COMPLETED"] = "CYCLE_COUNT_COMPLETED";
    AuditEventType["CYCLE_COUNT_RECONCILED"] = "CYCLE_COUNT_RECONCILED";
    AuditEventType["BIN_LOCATION_CREATED"] = "BIN_LOCATION_CREATED";
    AuditEventType["BIN_LOCATION_UPDATED"] = "BIN_LOCATION_UPDATED";
    AuditEventType["BIN_LOCATION_DELETED"] = "BIN_LOCATION_DELETED";
    // Configuration
    AuditEventType["CONFIG_UPDATED"] = "CONFIG_UPDATED";
    AuditEventType["FEATURE_FLAG_CHANGED"] = "FEATURE_FLAG_CHANGED";
    AuditEventType["RATE_LIMIT_CHANGED"] = "RATE_LIMIT_CHANGED";
    // Security
    AuditEventType["SUSPICIOUS_ACTIVITY"] = "SUSPICIOUS_ACTIVITY";
    AuditEventType["RATE_LIMIT_EXCEEDED"] = "RATE_LIMIT_EXCEEDED";
    AuditEventType["UNAUTHORIZED_ACCESS_ATTEMPT"] = "UNAUTHORIZED_ACCESS_ATTEMPT";
    AuditEventType["CSRF_DETECTED"] = "CSRF_DETECTED";
    // API access
    AuditEventType["API_KEY_CREATED"] = "API_KEY_CREATED";
    AuditEventType["API_KEY_DELETED"] = "API_KEY_DELETED";
    AuditEventType["WEBHOOK_CONFIGURED"] = "WEBHOOK_CONFIGURED";
    // System
    AuditEventType["SYSTEM_BACKUP"] = "SYSTEM_BACKUP";
    AuditEventType["SYSTEM_RESTORE"] = "SYSTEM_RESTORE";
    AuditEventType["MAINTENANCE_MODE"] = "MAINTENANCE_MODE";
    // API access
    AuditEventType["API_ACCESS"] = "API_ACCESS";
})(AuditEventType || (exports.AuditEventType = AuditEventType = {}));
// ============================================================================
// SERVICE
// ============================================================================
/**
 * Singleton instance for audit service
 */
let auditServiceInstance = null;
/**
 * Get the singleton audit service instance
 */
function getAuditService() {
    if (!auditServiceInstance) {
        auditServiceInstance = new AuditService();
    }
    return auditServiceInstance;
}
/**
 * Main Audit Service class
 *
 * Thread-safe audit logging with OpenTelemetry integration
 */
class AuditService {
    pool;
    isInitialized = false;
    constructor() {
        this.pool = (0, client_1.getPool)();
    }
    /**
     * Initialize audit service
     * Creates table if not exists and sets up retention policy
     */
    async initialize() {
        if (this.isInitialized) {
            return;
        }
        try {
            // Table is created by migration 008_create_audit_logs.sql
            // Just verify it exists
            const result = await this.pool.query(`
        SELECT EXISTS (
          SELECT FROM information_schema.tables
          WHERE table_name = 'audit_logs'
        );
      `);
            if (!result.rows[0].exists) {
                throw new Error('audit_logs table does not exist - please run migration 008');
            }
            this.isInitialized = true;
            logger_1.logger.info('AuditService initialized successfully');
        }
        catch (error) {
            logger_1.logger.error('Failed to initialize AuditService', { error });
            throw error;
        }
    }
    // ==========================================================================
    // LOGGING METHODS
    // ==========================================================================
    /**
     * Log an audit event
     *
     * @param auditLog - The audit log entry to record
     * @returns The created audit log ID
     */
    async log(auditLog) {
        if (!this.isInitialized) {
            await this.initialize();
        }
        try {
            // Add OpenTelemetry span attributes for tracing (with error handling)
            try {
                (0, telemetry_1.addSpanAttributes)({
                    'audit.category': auditLog.actionCategory,
                    'audit.action': auditLog.actionType,
                    'audit.resource_type': auditLog.resourceType,
                    'audit.user_id': auditLog.userId,
                });
            }
            catch (telemetryError) {
                // Silently ignore telemetry errors - don't let them break audit logging
                console.warn('[AuditService] Failed to add span attributes:', telemetryError);
            }
            // Generate audit_id if not provided
            const auditId = auditLog.auditId || `AUD-${Date.now()}-${Math.random().toString(36).substring(2, 11)}`;
            const query = `
        INSERT INTO audit_logs (
          audit_id,
          user_id,
          user_email,
          user_role,
          session_id,
          action_type,
          action_category,
          resource_type,
          resource_id,
          action_description,
          old_values,
          new_values,
          changed_fields,
          ip_address,
          user_agent,
          request_id,
          correlation_id,
          status,
          error_code,
          error_message,
          metadata,
          retention_until,
          occurred_at
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22, $23)
        RETURNING id
      `;
            // Calculate retention_until (2 years from now by default)
            const retentionUntil = new Date();
            retentionUntil.setFullYear(retentionUntil.getFullYear() + 2);
            const values = [
                auditId,
                auditLog.userId,
                auditLog.userEmail,
                auditLog.userRole,
                auditLog.sessionId || null,
                auditLog.actionType,
                auditLog.actionCategory,
                auditLog.resourceType,
                auditLog.resourceId,
                auditLog.actionDescription,
                auditLog.oldValues ? JSON.stringify(auditLog.oldValues) : null,
                auditLog.newValues ? JSON.stringify(auditLog.newValues) : null,
                auditLog.changedFields || null,
                auditLog.ipAddress,
                auditLog.userAgent,
                auditLog.requestId,
                auditLog.correlationId,
                auditLog.status || 'SUCCESS',
                auditLog.errorCode || null,
                auditLog.errorMessage || null,
                auditLog.metadata ? JSON.stringify(auditLog.metadata) : null,
                retentionUntil,
                auditLog.occurredAt || new Date(),
            ];
            const result = await this.pool.query(query, values);
            // Add span event for successful audit log (with error handling)
            try {
                (0, telemetry_1.addSpanEvent)('audit_logged', {
                    'audit.log_id': result.rows[0].id,
                    'audit.action': auditLog.actionType,
                });
            }
            catch (telemetryError) {
                // Silently ignore telemetry errors - don't let them break audit logging
                console.warn('[AuditService] Failed to add span event:', telemetryError);
            }
            logger_1.logger.debug('Audit log created', {
                auditLogId: result.rows[0].id,
                actionType: auditLog.actionType,
                actionCategory: auditLog.actionCategory,
            });
            return result.rows[0].id;
        }
        catch (error) {
            try {
                try {
                    (0, telemetry_1.recordException)(error);
                }
                catch {
                    /* ignore telemetry errors */
                }
            }
            catch (telemetryError) {
                // Silently ignore telemetry errors
                console.warn('[AuditService] Failed to record exception:', telemetryError);
            }
            logger_1.logger.error('Failed to create audit log', {
                error: error instanceof Error ? error.message : String(error),
                auditLog,
            });
            throw error;
        }
    }
    /**
     * Query audit logs with filters
     *
     * @param options - Query filters and pagination
     * @returns Array of audit logs
     */
    async query(options = {}) {
        if (!this.isInitialized) {
            await this.initialize();
        }
        try {
            const conditions = [];
            const values = [];
            let paramIndex = 1;
            if (options.userId !== undefined) {
                conditions.push(`user_id = $${paramIndex++}`);
                values.push(options.userId);
            }
            if (options.username) {
                conditions.push(`user_email = $${paramIndex++}`);
                values.push(options.username);
            }
            if (options.category) {
                conditions.push(`action_category = $${paramIndex++}`);
                values.push(options.category);
            }
            if (options.action) {
                conditions.push(`action_type = $${paramIndex++}`);
                values.push(options.action);
            }
            if (options.resourceType) {
                conditions.push(`resource_type = $${paramIndex++}`);
                values.push(options.resourceType);
            }
            if (options.resourceId) {
                conditions.push(`resource_id = $${paramIndex++}`);
                values.push(options.resourceId);
            }
            if (options.startDate) {
                conditions.push(`occurred_at >= $${paramIndex++}`);
                values.push(options.startDate);
            }
            if (options.endDate) {
                conditions.push(`occurred_at <= $${paramIndex++}`);
                values.push(options.endDate);
            }
            const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';
            const limit = options.limit || 100;
            const offset = options.offset || 0;
            const query = `
        SELECT
          id,
          audit_id as "auditId",
          occurred_at as "occurredAt",
          user_id as "userId",
          user_email as "userEmail",
          user_role as "userRole",
          session_id as "sessionId",
          action_type as "actionType",
          action_category as "actionCategory",
          resource_type as "resourceType",
          resource_id as "resourceId",
          action_description as "actionDescription",
          old_values as "oldValues",
          new_values as "newValues",
          changed_fields as "changedFields",
          ip_address as "ipAddress",
          user_agent as "userAgent",
          request_id as "requestId",
          correlation_id as "correlationId",
          status,
          error_code as "errorCode",
          error_message as "errorMessage",
          metadata,
          retention_until as "retentionUntil"
        FROM audit_logs
        ${whereClause}
        ORDER BY occurred_at DESC
        LIMIT $${paramIndex++} OFFSET $${paramIndex++}
      `;
            values.push(limit, offset);
            const result = await this.pool.query(query, values);
            return result.rows.map(row => ({
                id: row.id,
                auditId: row.auditId,
                occurredAt: row.occurredAt,
                userId: row.userId,
                userEmail: row.userEmail,
                userRole: row.userRole,
                sessionId: row.sessionId,
                actionType: row.actionType,
                actionCategory: row.actionCategory,
                resourceType: row.resourceType,
                resourceId: row.resourceId,
                actionDescription: row.actionDescription,
                oldValues: row.oldValues ?? null,
                newValues: row.newValues ?? null,
                changedFields: row.changedFields,
                ipAddress: row.ipAddress,
                userAgent: row.userAgent,
                requestId: row.requestId,
                correlationId: row.correlationId,
                status: row.status,
                errorCode: row.errorCode,
                errorMessage: row.errorMessage,
                metadata: row.metadata ?? null,
                retentionUntil: row.retentionUntil,
            }));
        }
        catch (error) {
            try {
                (0, telemetry_1.recordException)(error);
            }
            catch {
                /* ignore telemetry errors */
            }
            logger_1.logger.error('Failed to query audit logs', {
                error: error instanceof Error ? error.message : String(error),
                options,
            });
            throw error;
        }
    }
    /**
     * Get audit log by ID
     *
     * @param id - Audit log ID
     * @returns The audit log or null if not found
     */
    async getById(id) {
        if (!this.isInitialized) {
            await this.initialize();
        }
        try {
            const query = `
        SELECT
          id,
          audit_id as "auditId",
          occurred_at as "occurredAt",
          user_id as "userId",
          user_email as "userEmail",
          user_role as "userRole",
          session_id as "sessionId",
          action_type as "actionType",
          action_category as "actionCategory",
          resource_type as "resourceType",
          resource_id as "resourceId",
          action_description as "actionDescription",
          old_values as "oldValues",
          new_values as "newValues",
          changed_fields as "changedFields",
          ip_address as "ipAddress",
          user_agent as "userAgent",
          request_id as "requestId",
          correlation_id as "correlationId",
          status,
          error_code as "errorCode",
          error_message as "errorMessage",
          metadata,
          retention_until as "retentionUntil"
        FROM audit_logs
        WHERE id = $1
      `;
            const result = await this.pool.query(query, [id]);
            if (result.rows.length === 0) {
                return null;
            }
            const row = result.rows[0];
            return {
                id: row.id,
                auditId: row.auditId,
                occurredAt: row.occurredAt,
                userId: row.userId,
                userEmail: row.userEmail,
                userRole: row.userRole,
                sessionId: row.sessionId,
                actionType: row.actionType,
                actionCategory: row.actionCategory,
                resourceType: row.resourceType,
                resourceId: row.resourceId,
                actionDescription: row.actionDescription,
                oldValues: row.oldValues ?? null,
                newValues: row.newValues ?? null,
                changedFields: row.changedFields,
                ipAddress: row.ipAddress,
                userAgent: row.userAgent,
                requestId: row.requestId,
                correlationId: row.correlationId,
                status: row.status,
                errorCode: row.errorCode,
                errorMessage: row.errorMessage,
                metadata: row.metadata ?? null,
                retentionUntil: row.retentionUntil,
            };
        }
        catch (error) {
            try {
                (0, telemetry_1.recordException)(error);
            }
            catch {
                /* ignore telemetry errors */
            }
            logger_1.logger.error('Failed to get audit log by ID', {
                error: error instanceof Error ? error.message : String(error),
                id,
            });
            throw error;
        }
    }
    /**
     * Get audit history for a specific resource
     *
     * @param resourceType - Type of resource (e.g., 'order', 'user')
     * @param resourceId - ID of the resource
     * @param limit - Maximum number of records to return
     * @returns Array of audit logs for the resource
     */
    async getResourceHistory(resourceType, resourceId, limit = 50) {
        return this.query({
            resourceType,
            resourceId,
            limit,
        });
    }
    /**
     * Get user activity history
     *
     * @param userId - User ID (string)
     * @param limit - Maximum number of records to return
     * @returns Array of audit logs for the user
     */
    async getUserActivity(userId, limit = 100) {
        return this.query({
            userId,
            limit,
        });
    }
    /**
     * Get security events (failed logins, suspicious activity, etc.)
     *
     * @param startDate - Start date for query (default: 7 days ago)
     * @param endDate - End date for query (default: now)
     * @returns Array of security-related audit logs
     */
    async getSecurityEvents(startDate = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000), endDate = new Date()) {
        return this.query({
            category: AuditCategory.SECURITY,
            startDate,
            endDate,
            limit: 1000,
        });
    }
    /**
     * Get audit statistics
     *
     * @param startDate - Start date for statistics (default: 30 days ago)
     * @param endDate - End date for statistics (default: now)
     * @returns Statistics object with counts by category and action
     */
    async getStatistics(startDate = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000), endDate = new Date()) {
        if (!this.isInitialized) {
            await this.initialize();
        }
        try {
            // For simpler approach, use separate queries
            const categoryQuery = `
        SELECT action_category, COUNT(*) as count
        FROM audit_logs
        WHERE occurred_at >= $1 AND occurred_at <= $2
        GROUP BY action_category
        ORDER BY count DESC
      `;
            const actionQuery = `
        SELECT action_type, COUNT(*) as count
        FROM audit_logs
        WHERE occurred_at >= $1 AND occurred_at <= $2
        GROUP BY action_type
        ORDER BY count DESC
        LIMIT 20
      `;
            const userQuery = `
        SELECT user_email, COUNT(*) as count
        FROM audit_logs
        WHERE occurred_at >= $1 AND occurred_at <= $2
          AND user_email IS NOT NULL
        GROUP BY user_email
        ORDER BY count DESC
        LIMIT 10
      `;
            const totalQuery = `
        SELECT COUNT(*) as count
        FROM audit_logs
        WHERE occurred_at >= $1 AND occurred_at <= $2
      `;
            const [categoryResult, actionResult, userResult, totalResult] = await Promise.all([
                this.pool.query(categoryQuery, [startDate, endDate]),
                this.pool.query(actionQuery, [startDate, endDate]),
                this.pool.query(userQuery, [startDate, endDate]),
                this.pool.query(totalQuery, [startDate, endDate]),
            ]);
            const byCategory = {};
            categoryResult.rows.forEach(row => {
                byCategory[row.action_category] = parseInt(row.count);
            });
            const byAction = {};
            actionResult.rows.forEach(row => {
                byAction[row.action_type] = parseInt(row.count);
            });
            const topUsers = userResult.rows.map(row => ({
                userEmail: row.user_email,
                count: parseInt(row.count),
            }));
            return {
                totalLogs: parseInt(totalResult.rows[0].count),
                byCategory,
                byAction,
                topUsers,
            };
        }
        catch (error) {
            try {
                (0, telemetry_1.recordException)(error);
            }
            catch {
                /* ignore telemetry errors */
            }
            logger_1.logger.error('Failed to get audit statistics', {
                error: error instanceof Error ? error.message : String(error),
            });
            throw error;
        }
    }
    // ==========================================================================
    // CONVENIENCE METHODS
    // ==========================================================================
    /**
     * Log authentication event
     */
    async logAuth(actionType, userId, userEmail, ipAddress, userAgent, description, metadata) {
        return this.log({
            userId,
            userEmail,
            actionType,
            actionCategory: AuditCategory.AUTHENTICATION,
            actionDescription: description,
            resourceType: 'user_session',
            resourceId: userId || null,
            ipAddress,
            userAgent,
            metadata: metadata || null,
            oldValues: null,
            newValues: null,
            correlationId: this.getCurrentTraceId(),
        });
    }
    /**
     * Log authorization/role change event
     */
    async logAuthorization(actionType, userId, userEmail, userRole, resourceType, resourceId, description, oldValues, newValues, metadata, ipAddress, userAgent) {
        return this.log({
            userId,
            userEmail,
            userRole,
            actionType,
            actionCategory: AuditCategory.AUTHORIZATION,
            actionDescription: description,
            resourceType,
            resourceId,
            ipAddress,
            userAgent,
            metadata: metadata || null,
            oldValues: oldValues || null,
            newValues: newValues || null,
            correlationId: this.getCurrentTraceId(),
        });
    }
    /**
     * Log data modification event
     */
    async logDataModification(actionType, userId, userEmail, resourceType, resourceId, description, oldValues, newValues, ipAddress, userAgent) {
        return this.log({
            userId,
            userEmail,
            actionType,
            actionCategory: AuditCategory.DATA_MODIFICATION,
            actionDescription: description,
            resourceType,
            resourceId,
            ipAddress,
            userAgent,
            metadata: null,
            oldValues: oldValues || null,
            newValues: newValues || null,
            correlationId: this.getCurrentTraceId(),
        });
    }
    /**
     * Log security event
     */
    async logSecurityEvent(actionType, description, ipAddress, userAgent, metadata) {
        return this.log({
            userId: null,
            userEmail: null,
            actionType,
            actionCategory: AuditCategory.SECURITY,
            actionDescription: description,
            resourceType: 'system',
            resourceId: null,
            ipAddress,
            userAgent,
            metadata: metadata || null,
            oldValues: null,
            newValues: null,
            correlationId: this.getCurrentTraceId(),
        });
    }
    // ==========================================================================
    // UTILITY METHODS
    // ==========================================================================
    /**
     * Get current OpenTelemetry trace ID if available
     * Safely handles cases where telemetry is not available
     */
    getCurrentTraceId() {
        try {
            const api = require('@opentelemetry/api');
            const span = api.trace.getSpan();
            if (span) {
                const spanContext = span.spanContext();
                if (spanContext) {
                    return spanContext.traceId;
                }
            }
        }
        catch {
            // Silently ignore telemetry errors - return null if trace ID unavailable
        }
        return null;
    }
    /**
     * Clean up old audit logs based on retention policy
     * This should be called by a scheduled job
     *
     * @param retentionDays - Number of days to retain logs (default: 90 days)
     * @returns Number of logs deleted
     */
    async cleanupOldLogs(retentionDays = 90) {
        if (!this.isInitialized) {
            await this.initialize();
        }
        try {
            const cutoffDate = new Date(Date.now() - retentionDays * 24 * 60 * 60 * 1000);
            const query = `
        DELETE FROM audit_logs
        WHERE occurred_at < $1
      `;
            const result = await this.pool.query(query, [cutoffDate]);
            logger_1.logger.info('Cleaned up old audit logs', {
                deletedCount: result.rowCount,
                retentionDays,
                cutoffDate,
            });
            return result.rowCount || 0;
        }
        catch (error) {
            try {
                (0, telemetry_1.recordException)(error);
            }
            catch {
                /* ignore telemetry errors */
            }
            logger_1.logger.error('Failed to cleanup old audit logs', {
                error: error instanceof Error ? error.message : String(error),
                retentionDays,
            });
            throw error;
        }
    }
}
exports.AuditService = AuditService;
// ============================================================================
// EXPORTS
// ============================================================================
exports.default = AuditService;
//# sourceMappingURL=AuditService.js.map