/**
 * Request ID Middleware
 *
 * Generates and tracks unique request IDs for log correlation and debugging
 */
import { Request, Response, NextFunction } from 'express';
declare global {
    namespace Express {
        interface Request {
            id?: string;
        }
    }
}
/**
 * Generate and attach unique request ID to each request
 *
 * Request IDs are used for:
 * - Log correlation across services
 * - Debugging and troubleshooting
 * - Tracing request flow through the system
 * - Client-side error reporting
 */
export declare function requestId(req: Request, res: Response, next: NextFunction): void;
/**
 * Enhance logger to include request ID automatically
 * This ensures all logs for a request are correlated
 */
export declare function enhanceLoggerWithRequestId(req: Request, _res: Response, next: NextFunction): void;
//# sourceMappingURL=requestId.d.ts.map