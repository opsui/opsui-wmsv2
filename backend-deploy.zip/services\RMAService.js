"use strict";
/**
 * RMA (Return Merchandise Authorization) Service
 *
 * Business logic for handling customer returns, warranty claims, refurbishments, and exchanges
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.rmaService = exports.RMAService = void 0;
const RMARepository_1 = require("../repositories/RMARepository");
const shared_1 = require("@opsui/shared");
class RMAService {
    // ========================================================================
    // RMA REQUESTS
    // ========================================================================
    async createRMARequest(dto, createdBy) {
        // Validate RMA request
        if (!dto.orderId || dto.orderId.trim() === '') {
            throw new Error('Order ID is required');
        }
        if (!dto.orderItemId || dto.orderItemId.trim() === '') {
            throw new Error('Order Item ID is required');
        }
        if (!dto.sku || dto.sku.trim() === '') {
            throw new Error('SKU is required');
        }
        if (dto.quantity <= 0) {
            throw new Error('Quantity must be greater than 0');
        }
        if (!dto.reason || dto.reason.trim() === '') {
            throw new Error('Reason for return is required');
        }
        const rma = await RMARepository_1.rmaRepository.createRMARequest({
            ...dto,
            productName: '', // Will be populated from order item
            status: shared_1.RMAStatus.PENDING,
            priority: dto.priority || shared_1.RMAPriority.NORMAL,
            createdBy,
        });
        // Log the creation activity
        await RMARepository_1.rmaRepository.logActivity({
            rmaId: rma.rmaId,
            activityType: 'CREATED',
            description: `RMA request created for ${dto.sku} - ${dto.reason}`,
            userId: createdBy,
            userName: createdBy, // Will be updated to actual user name
        });
        return rma;
    }
    async getRMAById(rmaId) {
        const rma = await RMARepository_1.rmaRepository.findRMAById(rmaId);
        if (!rma) {
            throw new shared_1.NotFoundError('RMA Request', rmaId);
        }
        return rma;
    }
    async getRMAs(filters) {
        return await RMARepository_1.rmaRepository.findAllRMAs(filters);
    }
    async updateRMAStatus(rmaId, dto, userId) {
        const rma = await this.getRMAById(rmaId);
        const oldStatus = rma.status;
        // Validate status transitions
        if (!this.isValidStatusTransition(oldStatus, dto.status)) {
            throw new Error(`Invalid status transition from ${oldStatus} to ${dto.status}`);
        }
        // Update the RMA
        const updated = await RMARepository_1.rmaRepository.updateRMARequest(rmaId, {
            ...dto,
            updatedBy: userId,
        });
        if (updated) {
            // Log the status change
            await RMARepository_1.rmaRepository.logActivity({
                rmaId,
                activityType: 'STATUS_CHANGED',
                description: `Status changed from ${oldStatus} to ${dto.status}`,
                oldStatus,
                newStatus: dto.status,
                userId,
                userName: userId,
            });
            // Set timestamps based on status
            await this.updateStatusTimestamps(rmaId, dto.status, userId);
        }
        return updated;
    }
    async approveRMA(rmaId, userId) {
        return await this.updateRMAStatus(rmaId, { status: shared_1.RMAStatus.APPROVED }, userId);
    }
    async rejectRMA(rmaId, rejectionReason, userId) {
        const rma = await this.updateRMAStatus(rmaId, { status: shared_1.RMAStatus.REJECTED, rejectionReason }, userId);
        // Log rejection
        await RMARepository_1.rmaRepository.logActivity({
            rmaId,
            activityType: 'REJECTED',
            description: `RMA request rejected: ${rejectionReason}`,
            userId,
            userName: userId,
        });
        return rma;
    }
    async markAsReceived(rmaId, userId) {
        return await this.updateRMAStatus(rmaId, { status: shared_1.RMAStatus.RECEIVED }, userId);
    }
    async startInspection(rmaId, userId) {
        return await this.updateRMAStatus(rmaId, { status: shared_1.RMAStatus.INSPECTING }, userId);
    }
    // ========================================================================
    // RMA INSPECTIONS
    // ========================================================================
    async createInspection(rmaId, dto, userId) {
        const rma = await this.getRMAById(rmaId);
        if (rma.status !== shared_1.RMAStatus.RECEIVED && rma.status !== shared_1.RMAStatus.INSPECTING) {
            throw new Error('RMA must be received or in inspection to add inspection record');
        }
        const inspection = await RMARepository_1.rmaRepository.createInspection({
            ...dto,
            rmaId,
            inspectedBy: userId,
            inspectedAt: new Date(),
        });
        // Update RMA with inspection findings
        await RMARepository_1.rmaRepository.updateRMARequest(rmaId, {
            condition: dto.condition,
            disposition: dto.disposition,
            refundAmount: dto.estimatedRefund,
            updatedBy: userId,
        });
        // Log inspection
        await RMARepository_1.rmaRepository.logActivity({
            rmaId,
            activityType: 'INSPECTED',
            description: `Inspection completed: ${dto.condition} - ${dto.disposition}`,
            userId,
            userName: userId,
            metadata: { inspectionId: inspection.inspectionId },
        });
        return inspection;
    }
    async getInspections(rmaId) {
        await this.getRMAById(rmaId); // Verify RMA exists
        return await RMARepository_1.rmaRepository.findInspectionsByRMA(rmaId);
    }
    // ========================================================================
    // RESOLUTIONS
    // ========================================================================
    async processRefund(rmaId, dto, userId) {
        const rma = await this.getRMAById(rmaId);
        if (!rma.refundAmount) {
            throw new Error('No refund amount set for this RMA');
        }
        const updated = await RMARepository_1.rmaRepository.updateRMARequest(rmaId, {
            status: shared_1.RMAStatus.REFUNDED,
            refundMethod: dto.refundMethod,
            refundProcessedAt: new Date(),
            resolvedAt: new Date(),
            resolvedBy: userId,
            updatedBy: userId,
            resolutionNotes: dto.notes,
        });
        // Log refund processing
        await RMARepository_1.rmaRepository.logActivity({
            rmaId,
            activityType: 'REFUND_PROCESSED',
            description: `Refund processed: ${dto.refundMethod} - $${dto.amount || rma.refundAmount}`,
            userId,
            userName: userId,
        });
        return updated;
    }
    async sendReplacement(rmaId, dto, userId) {
        // In production, this would create a new order for the replacement
        // For now, just update the RMA
        const updated = await RMARepository_1.rmaRepository.updateRMARequest(rmaId, {
            status: shared_1.RMAStatus.REPLACED,
            replacementShippedAt: new Date(),
            resolvedAt: new Date(),
            resolvedBy: userId,
            updatedBy: userId,
        });
        // Log replacement shipment
        await RMARepository_1.rmaRepository.logActivity({
            rmaId,
            activityType: 'REPLACEMENT_SENT',
            description: `Replacement shipped via ${dto.shippingMethod}`,
            userId,
            userName: userId,
            metadata: { shippingAddress: dto.shippingAddress, trackingNumber: dto.trackingNumber },
        });
        return updated;
    }
    async closeRMA(rmaId, userId) {
        const rma = await this.getRMAById(rmaId);
        if (rma.status !== shared_1.RMAStatus.REFUNDED &&
            rma.status !== shared_1.RMAStatus.REPLACED &&
            rma.status !== shared_1.RMAStatus.REPAIRED &&
            rma.status !== shared_1.RMAStatus.REJECTED) {
            throw new Error('RMA must be resolved before closing');
        }
        const updated = await RMARepository_1.rmaRepository.updateRMARequest(rmaId, {
            status: shared_1.RMAStatus.CLOSED,
            closedAt: new Date(),
            closedBy: userId,
            updatedBy: userId,
        });
        // Log closure
        await RMARepository_1.rmaRepository.logActivity({
            rmaId,
            activityType: 'CLOSED',
            description: 'RMA request closed',
            userId,
            userName: userId,
        });
        return updated;
    }
    // ========================================================================
    // COMMUNICATIONS
    // ========================================================================
    async addCommunication(rmaId, type, direction, content, userId, subject) {
        await this.getRMAById(rmaId); // Verify RMA exists
        await RMARepository_1.rmaRepository.addCommunication({
            rmaId,
            type,
            direction,
            subject,
            content,
            sentBy: userId,
        });
    }
    async getCommunications(rmaId) {
        await this.getRMAById(rmaId); // Verify RMA exists
        return await RMARepository_1.rmaRepository.findCommunicationsByRMA(rmaId);
    }
    // ========================================================================
    // ACTIVITY LOG
    // ========================================================================
    async getActivityLog(rmaId, limit = 50) {
        await this.getRMAById(rmaId); // Verify RMA exists
        return await RMARepository_1.rmaRepository.findActivitiesByRMA(rmaId, limit);
    }
    // ========================================================================
    // DASHBOARD
    // ========================================================================
    async getDashboard() {
        return await RMARepository_1.rmaRepository.getDashboardStats();
    }
    // ========================================================================
    // HELPER METHODS
    // ========================================================================
    isValidStatusTransition(from, to) {
        const transitions = {
            [shared_1.RMAStatus.PENDING]: [shared_1.RMAStatus.APPROVED, shared_1.RMAStatus.REJECTED, shared_1.RMAStatus.CLOSED],
            [shared_1.RMAStatus.APPROVED]: [shared_1.RMAStatus.RECEIVED, shared_1.RMAStatus.REJECTED, shared_1.RMAStatus.CLOSED],
            [shared_1.RMAStatus.REJECTED]: [shared_1.RMAStatus.CLOSED],
            [shared_1.RMAStatus.RECEIVED]: [shared_1.RMAStatus.INSPECTING, shared_1.RMAStatus.CLOSED],
            [shared_1.RMAStatus.INSPECTING]: [
                shared_1.RMAStatus.AWAITING_DECISION,
                shared_1.RMAStatus.REFUND_APPROVED,
                shared_1.RMAStatus.REPLACEMENT_APPROVED,
                shared_1.RMAStatus.REPAIR_APPROVED,
            ],
            [shared_1.RMAStatus.AWAITING_DECISION]: [
                shared_1.RMAStatus.REFUND_APPROVED,
                shared_1.RMAStatus.REPLACEMENT_APPROVED,
                shared_1.RMAStatus.REPAIR_APPROVED,
                shared_1.RMAStatus.CLOSED,
            ],
            [shared_1.RMAStatus.REFUND_APPROVED]: [shared_1.RMAStatus.REFUND_PROCESSING, shared_1.RMAStatus.CLOSED],
            [shared_1.RMAStatus.REFUND_PROCESSING]: [shared_1.RMAStatus.REFUNDED],
            [shared_1.RMAStatus.REFUNDED]: [shared_1.RMAStatus.CLOSED],
            [shared_1.RMAStatus.REPLACEMENT_APPROVED]: [shared_1.RMAStatus.REPLACEMENT_PROCESSING, shared_1.RMAStatus.CLOSED],
            [shared_1.RMAStatus.REPLACEMENT_PROCESSING]: [shared_1.RMAStatus.REPLACED],
            [shared_1.RMAStatus.REPLACED]: [shared_1.RMAStatus.CLOSED],
            [shared_1.RMAStatus.REPAIR_APPROVED]: [shared_1.RMAStatus.REPAIRING, shared_1.RMAStatus.CLOSED],
            [shared_1.RMAStatus.REPAIRING]: [shared_1.RMAStatus.REPAIRED],
            [shared_1.RMAStatus.REPAIRED]: [shared_1.RMAStatus.CLOSED],
            [shared_1.RMAStatus.CLOSED]: [],
        };
        return transitions[from]?.includes(to) ?? false;
    }
    async updateStatusTimestamps(rmaId, status, userId) {
        const updates = { updatedBy: userId };
        switch (status) {
            case shared_1.RMAStatus.APPROVED:
                updates.approvedAt = new Date();
                updates.approvedBy = userId;
                break;
            case shared_1.RMAStatus.RECEIVED:
                updates.receivedAt = new Date();
                updates.receivedBy = userId;
                break;
            case shared_1.RMAStatus.INSPECTING:
                updates.inspectedAt = new Date();
                updates.inspectedBy = userId;
                break;
        }
        if (Object.keys(updates).length > 1) {
            await RMARepository_1.rmaRepository.updateRMARequest(rmaId, updates);
        }
    }
}
exports.RMAService = RMAService;
// Singleton instance
exports.rmaService = new RMAService();
//# sourceMappingURL=RMAService.js.map