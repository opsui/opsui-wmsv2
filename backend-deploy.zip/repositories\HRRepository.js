"use strict";
/**
 * HR Repository
 *
 * Data access layer for HR & Payroll operations
 * Handles employee records, timesheets, payroll runs, and leave management
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.hrRepository = exports.LeaveTypeRepository = exports.TaxTableRepository = exports.EmployeeDeductionRepository = exports.DeductionTypeRepository = exports.LeaveBalanceRepository = exports.LeaveRequestRepository = exports.PayItemRepository = exports.PayrollRunRepository = exports.PayrollPeriodRepository = exports.TimesheetEntryRepository = exports.TimesheetRepository = exports.BankAccountRepository = exports.EmploymentRepository = exports.EmployeeTaxDetailsRepository = exports.EmployeeRepository = void 0;
const client_1 = require("../db/client");
const BaseRepository_1 = require("./BaseRepository");
// ============================================================================
// EMPLOYEE REPOSITORY
// ============================================================================
class EmployeeRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super('hr_employees', 'employee_id');
    }
    // Find by email
    async findByEmail(email) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE email = $1 AND deleted_at IS NULL`, [email]);
        return result.rows[0] || null;
    }
    // Find with all details (tax, employments, bank accounts)
    async findByIdWithDetails(employeeId) {
        const employee = await this.findById(employeeId);
        if (!employee)
            return null;
        const [taxDetails, employments, bankAccounts] = await Promise.all([
            (0, client_1.query)('SELECT * FROM hr_employee_tax_details WHERE employee_id = $1', [
                employeeId,
            ]),
            (0, client_1.query)('SELECT * FROM hr_employments WHERE employee_id = $1', [employeeId]),
            (0, client_1.query)('SELECT * FROM hr_bank_accounts WHERE employee_id = $1', [employeeId]),
        ]);
        return {
            ...employee,
            taxDetails: taxDetails.rows[0] || undefined,
            employments: employments.rows,
            bankAccounts: bankAccounts.rows,
            primaryEmployment: employments.rows.find(e => e.isPrimary) || employments.rows[0],
            primaryBankAccount: bankAccounts.rows.find(b => b.isPrimary) || bankAccounts.rows[0],
        };
    }
    // Find all active employees
    async findActive() {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE status = 'ACTIVE' AND deleted_at IS NULL ORDER BY last_name, first_name`);
        return result.rows;
    }
    // Soft delete
    async softDelete(employeeId) {
        const result = await (0, client_1.query)(`UPDATE ${this.tableName} SET status = 'TERMINATED', deleted_at = NOW() WHERE ${this.primaryKey} = $1`, [employeeId]);
        return (result.rowCount || 0) > 0;
    }
    // Restore
    async restore(employeeId) {
        const result = await (0, client_1.query)(`UPDATE ${this.tableName} SET status = 'ACTIVE', deleted_at = NULL WHERE ${this.primaryKey} = $1`, [employeeId]);
        return (result.rowCount || 0) > 0;
    }
    // Search employees
    async search(searchTerm, limit = 20) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName}
       WHERE deleted_at IS NULL
       AND (
         first_name ILIKE $1 OR
         last_name ILIKE $1 OR
         email ILIKE $1 OR
         employee_number ILIKE $1
       )
       ORDER BY last_name, first_name
       LIMIT $2`, [`%${searchTerm}%`, limit]);
        return result.rows;
    }
}
exports.EmployeeRepository = EmployeeRepository;
// ============================================================================
// TAX DETAILS REPOSITORY
// ============================================================================
class EmployeeTaxDetailsRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super('hr_employee_tax_details', 'tax_detail_id');
    }
    async findByEmployeeId(employeeId) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE employee_id = $1`, [employeeId]);
        return result.rows[0] || null;
    }
    async upsert(employeeId, data) {
        const existing = await this.findByEmployeeId(employeeId);
        if (existing) {
            return (await this.update(existing.taxDetailId, data));
        }
        else {
            return await this.insert({ ...data, employeeId });
        }
    }
}
exports.EmployeeTaxDetailsRepository = EmployeeTaxDetailsRepository;
// ============================================================================
// EMPLOYMENT REPOSITORY
// ============================================================================
class EmploymentRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super('hr_employments', 'employment_id');
    }
    async findByEmployeeId(employeeId) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE employee_id = $1 ORDER BY start_date DESC`, [employeeId]);
        return result.rows;
    }
    async findPrimaryByEmployeeId(employeeId) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE employee_id = $1 AND is_primary = true AND status = 'ACTIVE'`, [employeeId]);
        return result.rows[0] || null;
    }
}
exports.EmploymentRepository = EmploymentRepository;
// ============================================================================
// BANK ACCOUNT REPOSITORY
// ============================================================================
class BankAccountRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super('hr_bank_accounts', 'bank_account_id');
    }
    async findByEmployeeId(employeeId) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE employee_id = $1 ORDER BY is_primary DESC`, [employeeId]);
        return result.rows;
    }
    async findPrimaryByEmployeeId(employeeId) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE employee_id = $1 AND is_primary = true`, [employeeId]);
        return result.rows[0] || null;
    }
}
exports.BankAccountRepository = BankAccountRepository;
// ============================================================================
// TIMESHEET REPOSITORY
// ============================================================================
class TimesheetRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super('hr_timesheets', 'timesheet_id');
    }
    async findByEmployeeId(employeeId, limit = 10) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName}
       WHERE employee_id = $1
       ORDER BY period_start_date DESC
       LIMIT $2`, [employeeId, limit]);
        return result.rows;
    }
    async findByPeriod(startDate, endDate) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName}
       WHERE period_start_date = $1 AND period_end_date = $2
       ORDER BY employee_id`, [startDate, endDate]);
        return result.rows;
    }
    async findByEmployeeAndPeriod(employeeId, startDate, endDate) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName}
       WHERE employee_id = $1 AND period_start_date = $2 AND period_end_date = $3`, [employeeId, startDate, endDate]);
        return result.rows[0] || null;
    }
    async findWithEntries(timesheetId) {
        const timesheet = await this.findById(timesheetId);
        if (!timesheet)
            return null;
        const entries = await (0, client_1.query)(`SELECT * FROM hr_timesheet_entries WHERE timesheet_id = $1 ORDER BY work_date`, [timesheetId]);
        return {
            ...timesheet,
            entries: entries.rows,
        };
    }
    async findByStatus(status) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE status = $1 ORDER BY period_start_date DESC`, [status]);
        return result.rows;
    }
    async updateStatus(timesheetId, status, userId) {
        const updates = { status };
        if (status === 'SUBMITTED') {
            updates.submittedAt = new Date();
            updates.submittedBy = userId;
        }
        else if (status === 'APPROVED') {
            updates.approvedAt = new Date();
            updates.approvedBy = userId;
        }
        return await this.update(timesheetId, updates);
    }
}
exports.TimesheetRepository = TimesheetRepository;
// ============================================================================
// TIMESHEET ENTRY REPOSITORY
// ============================================================================
class TimesheetEntryRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super('hr_timesheet_entries', 'entry_id');
    }
    async findByTimesheetId(timesheetId) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE timesheet_id = $1 ORDER BY work_date`, [timesheetId]);
        return result.rows;
    }
    async deleteByTimesheetId(timesheetId, client) {
        const result = client
            ? await client.query(`DELETE FROM ${this.tableName} WHERE timesheet_id = $1`, [timesheetId])
            : await (0, client_1.query)(`DELETE FROM ${this.tableName} WHERE timesheet_id = $1`, [timesheetId]);
        return result.rowCount || 0;
    }
}
exports.TimesheetEntryRepository = TimesheetEntryRepository;
// ============================================================================
// PAYROLL PERIOD REPOSITORY
// ============================================================================
class PayrollPeriodRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super('hr_payroll_periods', 'period_id');
    }
    async findActive() {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE is_active = true ORDER BY period_start_date DESC`);
        return result.rows;
    }
    async findCurrentPeriod() {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName}
       WHERE is_active = true
       AND period_start_date <= CURRENT_DATE
       AND period_end_date >= CURRENT_DATE
       LIMIT 1`);
        return result.rows[0] || null;
    }
    async findNextPeriod() {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName}
       WHERE is_active = true
       AND period_start_date > CURRENT_DATE
       AND payroll_run_id IS NULL
       ORDER BY period_start_date
       LIMIT 1`);
        return result.rows[0] || null;
    }
}
exports.PayrollPeriodRepository = PayrollPeriodRepository;
// ============================================================================
// PAYROLL RUN REPOSITORY
// ============================================================================
class PayrollRunRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super('hr_payroll_runs', 'payroll_run_id');
    }
    async findByPeriodId(periodId) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE period_id = $1 ORDER BY run_number DESC`, [periodId]);
        return result.rows;
    }
    async findLatest() {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} ORDER BY created_at DESC LIMIT 1`);
        return result.rows[0] || null;
    }
    async findByStatus(status) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE status = $1 ORDER BY created_at DESC`, [status]);
        return result.rows;
    }
    async getNextRunNumber(periodId) {
        const result = await (0, client_1.query)(`SELECT COUNT(*) as count FROM ${this.tableName} WHERE period_id = $1`, [periodId]);
        return parseInt(result.rows[0].count, 10) + 1;
    }
}
exports.PayrollRunRepository = PayrollRunRepository;
// ============================================================================
// PAY ITEM REPOSITORY
// ============================================================================
class PayItemRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super('hr_pay_items', 'pay_item_id');
    }
    async findByPayrollRunId(payrollRunId) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE payroll_run_id = $1 ORDER BY employee_id`, [payrollRunId]);
        return result.rows;
    }
    async findByEmployeeId(employeeId, limit = 10) {
        const result = await (0, client_1.query)(`SELECT pi.* FROM ${this.tableName} pi
       JOIN hr_payroll_runs pr ON pr.payroll_run_id = pi.payroll_run_id
       WHERE pi.employee_id = $1
       ORDER BY pr.created_at DESC
       LIMIT $2`, [employeeId, limit]);
        return result.rows;
    }
    async deleteByPayrollRunId(payrollRunId, client) {
        const result = client
            ? await client.query(`DELETE FROM ${this.tableName} WHERE payroll_run_id = $1`, [
                payrollRunId,
            ])
            : await (0, client_1.query)(`DELETE FROM ${this.tableName} WHERE payroll_run_id = $1`, [payrollRunId]);
        return result.rowCount || 0;
    }
}
exports.PayItemRepository = PayItemRepository;
// ============================================================================
// LEAVE REQUEST REPOSITORY
// ============================================================================
class LeaveRequestRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super('hr_leave_requests', 'request_id');
    }
    async findByEmployeeId(employeeId) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName}
       WHERE employee_id = $1
       ORDER BY created_at DESC`, [employeeId]);
        return result.rows;
    }
    async findByStatus(status) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName}
       WHERE status = $1
       ORDER BY start_date ASC`, [status]);
        return result.rows;
    }
    async findByDateRange(startDate, endDate) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName}
       WHERE status IN ('APPROVED', 'PENDING')
       AND (
         (start_date <= $1 AND end_date >= $1) OR
         (start_date <= $2 AND end_date >= $2) OR
         (start_date >= $1 AND end_date <= $2)
       )
       ORDER BY start_date`, [startDate, endDate]);
        return result.rows;
    }
}
exports.LeaveRequestRepository = LeaveRequestRepository;
// ============================================================================
// LEAVE BALANCE REPOSITORY
// ============================================================================
class LeaveBalanceRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super('hr_leave_balances', 'balance_id');
    }
    async findByEmployeeId(employeeId) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName}
       WHERE employee_id = $1
       ORDER BY effective_date DESC`, [employeeId]);
        return result.rows;
    }
    async findByEmployeeAndLeaveType(employeeId, leaveTypeId) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName}
       WHERE employee_id = $1 AND leave_type_id = $2
       ORDER BY effective_date DESC`, [employeeId, leaveTypeId]);
        return result.rows;
    }
    async findCurrentBalance(employeeId, leaveTypeId) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName}
       WHERE employee_id = $1 AND leave_type_id = $2
       ORDER BY effective_date DESC
       LIMIT 1`, [employeeId, leaveTypeId]);
        return result.rows[0] || null;
    }
}
exports.LeaveBalanceRepository = LeaveBalanceRepository;
// ============================================================================
// DEDUCTION TYPE REPOSITORY
// ============================================================================
class DeductionTypeRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super('hr_deduction_types', 'deduction_type_id');
    }
    async findActive() {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE is_active = true ORDER BY code`);
        return result.rows;
    }
    async findByCode(code) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE code = $1`, [
            code,
        ]);
        return result.rows[0] || null;
    }
    async findByCategory(category) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE category = $1 AND is_active = true ORDER BY code`, [category]);
        return result.rows;
    }
}
exports.DeductionTypeRepository = DeductionTypeRepository;
// ============================================================================
// EMPLOYEE DEDUCTION REPOSITORY
// ============================================================================
class EmployeeDeductionRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super('hr_employee_deductions', 'employee_deduction_id');
    }
    async findByEmployeeId(employeeId) {
        const result = await (0, client_1.query)(`SELECT ed.*, dt.name, dt.code, dt.category
       FROM ${this.tableName} ed
       JOIN hr_deduction_types dt ON dt.deduction_type_id = ed.deduction_type_id
       WHERE ed.employee_id = $1 AND ed.is_active = true
       ORDER BY dt.category, dt.code`, [employeeId]);
        return result.rows;
    }
}
exports.EmployeeDeductionRepository = EmployeeDeductionRepository;
// ============================================================================
// TAX TABLE REPOSITORY
// ============================================================================
class TaxTableRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super('hr_tax_tables', 'tax_table_id');
    }
    async findByTaxCode(taxCode) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName}
       WHERE tax_code = $1 AND is_active = true
       ORDER BY threshold_from`, [taxCode]);
        return result.rows;
    }
    async findActiveRates() {
        const result = await (0, client_1.query)(`SELECT DISTINCT ON (tax_code) *
       FROM ${this.tableName}
       WHERE is_active = true
       ORDER BY tax_code, effective_date DESC`);
        return result.rows;
    }
}
exports.TaxTableRepository = TaxTableRepository;
// ============================================================================
// LEAVE TYPE REPOSITORY
// ============================================================================
class LeaveTypeRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super('hr_leave_types', 'leave_type_id');
    }
    async findActive() {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE is_active = true ORDER BY name`);
        return result.rows;
    }
}
exports.LeaveTypeRepository = LeaveTypeRepository;
// ============================================================================
// CONSOLIDATED HR REPOSITORY
// ============================================================================
class HRRepository {
    employees = new EmployeeRepository();
    taxDetails = new EmployeeTaxDetailsRepository();
    employments = new EmploymentRepository();
    bankAccounts = new BankAccountRepository();
    timesheets = new TimesheetRepository();
    timesheetEntries = new TimesheetEntryRepository();
    payrollPeriods = new PayrollPeriodRepository();
    payrollRuns = new PayrollRunRepository();
    payItems = new PayItemRepository();
    leaveRequests = new LeaveRequestRepository();
    leaveBalances = new LeaveBalanceRepository();
    deductionTypes = new DeductionTypeRepository();
    employeeDeductions = new EmployeeDeductionRepository();
    taxTables = new TaxTableRepository();
    leaveTypes = new LeaveTypeRepository();
    // Transaction helper
    async withTransaction(callback) {
        return (0, client_1.transaction)(callback);
    }
}
exports.hrRepository = new HRRepository();
//# sourceMappingURL=HRRepository.js.map