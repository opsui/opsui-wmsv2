/**
 * Bin Location Service
 *
 * Manages warehouse bin location CRUD operations
 */
import { BinLocation, CreateBinLocationDTO, UpdateBinLocationDTO, BinType } from '@opsui/shared';
export declare class BinLocationService {
    /**
     * Create a new bin location
     */
    createBinLocation(dto: CreateBinLocationDTO): Promise<BinLocation>;
    /**
     * Get all bin locations
     */
    getAllBinLocations(filters?: {
        zone?: string;
        type?: BinType;
        active?: boolean;
        limit?: number;
        offset?: number;
    }): Promise<{
        locations: BinLocation[];
        total: number;
    }>;
    /**
     * Get a specific bin location by ID
     */
    getBinLocation(binId: string): Promise<BinLocation>;
    /**
     * Update a bin location
     */
    updateBinLocation(binId: string, updates: UpdateBinLocationDTO): Promise<BinLocation>;
    /**
     * Delete a bin location
     */
    deleteBinLocation(binId: string): Promise<void>;
    /**
     * Batch create bin locations
     */
    batchCreateBinLocations(dtos: CreateBinLocationDTO[]): Promise<{
        created: BinLocation[];
        failed: Array<{
            dto: CreateBinLocationDTO;
            error: string;
        }>;
    }>;
    /**
     * Get available zones
     */
    getZones(): Promise<string[]>;
    /**
     * Get bin locations by zone
     */
    getBinLocationsByZone(zone: string): Promise<BinLocation[]>;
    private mapRowToBinLocation;
}
export declare const binLocationService: BinLocationService;
//# sourceMappingURL=BinLocationService.d.ts.map