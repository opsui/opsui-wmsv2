/**
 * Multi-Entity API Routes
 *
 * REST API for multi-company, multi-subsidiary ERP operations
 * Handles entities, inter-company transactions, consolidation rules, and entity user assignments
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=multi-entity.d.ts.map