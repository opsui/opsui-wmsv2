/**
 * Migration: Add verified_quantity column to order_items table
 *
 * This column tracks how many items have been verified during the packing stage
 */
export {};
//# sourceMappingURL=add-verified-quantity.d.ts.map