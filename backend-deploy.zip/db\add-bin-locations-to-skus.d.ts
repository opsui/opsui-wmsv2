/**
 * Migration: Add bin_locations column to skus table
 *
 * This migration adds a bin_locations array column to the skus table
 * to store the list of bin locations where each SKU is stored.
 */
declare function addBinLocationsToSkus(): Promise<void>;
export { addBinLocationsToSkus };
//# sourceMappingURL=add-bin-locations-to-skus.d.ts.map