/**
 * WebSocket Server Setup
 *
 * Provides real-time bidirectional communication between clients and server
 * Uses Socket.IO for WebSocket functionality with JWT authentication
 */
import { Server as HTTPServer } from 'http';
import { Server as SocketIOServer } from 'socket.io';
import { WebSocketBroadcaster, broadcastEvent } from './broadcaster';
interface ServerToClientEvents {
    'order:claimed': (data: {
        orderId: string;
        pickerId: string;
        pickerName: string;
    }) => void;
    'order:completed': (data: {
        orderId: string;
        pickerId: string;
    }) => void;
    'order:cancelled': (data: {
        orderId: string;
        reason: string;
    }) => void;
    'pick:updated': (data: {
        orderId: string;
        orderItemId: string;
        pickedQuantity: number;
    }) => void;
    'pick:completed': (data: {
        orderId: string;
        orderItemId: string;
    }) => void;
    'zone:updated': (data: {
        zoneId: string;
        taskCount: number;
        pickerCount: number;
    }) => void;
    'zone:assignment': (data: {
        zoneId: string;
        pickerId: string;
        assigned: boolean;
    }) => void;
    'inventory:updated': (data: {
        sku: string;
        binLocation: string;
        quantity: number;
    }) => void;
    'inventory:low': (data: {
        sku: string;
        quantity: number;
        minThreshold: number;
    }) => void;
    'notification:new': (data: {
        notificationId: string;
        title: string;
        message: string;
    }) => void;
    'user:activity': (data: {
        userId: string;
        status: string;
        currentView?: string;
    }) => void;
    connected: (data: {
        message: string;
    }) => void;
}
interface ClientToServerEvents {
    'subscribe:orders': () => void;
    'subscribe:zone': (zoneId: string) => void;
    'unsubscribe:zone': (zoneId: string) => void;
    'subscribe:inventory': () => void;
    'update:activity': (data: {
        currentView?: string;
        status?: string;
    }) => void;
    ping: () => void;
}
declare class WebSocketServer {
    private io;
    private broadcaster;
    private rateLimiters;
    private readonly rateLimitWindowMs;
    private readonly rateLimitMaxRequests;
    /**
     * Initialize WebSocket server with HTTP server
     */
    initialize(httpServer: HTTPServer): void;
    /**
     * Check rate limit for a socket connection
     */
    private checkRateLimit;
    /**
     * Periodic cleanup of stale rate limiters
     */
    private startRateLimitCleanup;
    /**
     * Authenticate WebSocket connection using JWT
     * Handles both compact (new) and legacy (old) token formats
     */
    private authenticateSocket;
    /**
     * Handle new WebSocket connection
     */
    private handleConnection;
    /**
     * Set up event handlers for socket events from client
     */
    private setupSocketHandlers;
    /**
     * Get the Socket.IO server instance
     */
    getIO(): SocketIOServer<ServerToClientEvents, ClientToServerEvents> | null;
    /**
     * Get the broadcaster instance
     */
    getBroadcaster(): WebSocketBroadcaster | null;
    /**
     * Broadcast an event (convenience method)
     */
    broadcast(event: string, data: any, room?: string): void;
    /**
     * Get connected clients count
     */
    getConnectedCount(): number;
    /**
     * Disconnect all clients
     */
    disconnectAll(): void;
    /**
     * Close WebSocket server
     */
    close(): void;
}
declare const wsServer: WebSocketServer;
export default wsServer;
export { broadcastEvent };
export type { ServerToClientEvents, ClientToServerEvents };
//# sourceMappingURL=index.d.ts.map