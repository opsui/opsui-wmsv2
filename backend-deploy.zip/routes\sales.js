"use strict";
/**
 * Sales & CRM Routes
 *
 * API endpoints for customers, leads, opportunities, and quotes
 */
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const SalesService_1 = require("../services/SalesService");
const middleware_1 = require("../middleware");
const shared_1 = require("@opsui/shared");
const router = (0, express_1.Router)();
// All sales routes require authentication
router.use(middleware_1.authenticate);
// ============================================================================
// DASHBOARD
// ============================================================================
/**
 * GET /api/sales/dashboard
 * Get sales dashboard statistics
 * Access: All authenticated users
 */
router.get('/dashboard', (0, middleware_1.asyncHandler)(async (_req, res) => {
    const dashboard = await SalesService_1.salesService.getDashboard();
    res.json(dashboard);
}));
// ============================================================================
// CUSTOMERS
// ============================================================================
/**
 * POST /api/sales/customers
 * Create a new customer
 * Access: ADMIN, SUPERVISOR, SALES
 */
router.post('/customers', (0, middleware_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR, shared_1.UserRole.SALES), (0, middleware_1.asyncHandler)(async (req, res) => {
    const customer = await SalesService_1.salesService.createCustomer(req.body, req.user.userId);
    res.status(201).json(customer);
}));
/**
 * GET /api/sales/customers
 * Get all customers with optional filtering
 * Access: All authenticated users
 */
router.get('/customers', (0, middleware_1.asyncHandler)(async (req, res) => {
    const { status, assignedTo, limit, offset } = req.query;
    const result = await SalesService_1.salesService.getAllCustomers({
        status: status,
        assignedTo: assignedTo,
        limit: limit ? parseInt(limit) : undefined,
        offset: offset ? parseInt(offset) : undefined,
    });
    res.json(result);
}));
/**
 * GET /api/sales/customers/:customerId
 * Get a specific customer by ID
 * Access: All authenticated users
 */
router.get('/customers/:customerId', (0, middleware_1.asyncHandler)(async (req, res) => {
    const { customerId } = req.params;
    const customer = await SalesService_1.salesService.getCustomerById(customerId);
    res.json(customer);
}));
/**
 * PUT /api/sales/customers/:customerId
 * Update a customer
 * Access: ADMIN, SUPERVISOR, SALES
 */
router.put('/customers/:customerId', (0, middleware_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR, shared_1.UserRole.SALES), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { customerId } = req.params;
    const customer = await SalesService_1.salesService.updateCustomer(customerId, req.body, req.user.userId);
    res.json(customer);
}));
// ============================================================================
// LEADS
// ============================================================================
/**
 * POST /api/sales/leads
 * Create a new lead
 * Access: ADMIN, SUPERVISOR, SALES
 */
router.post('/leads', (0, middleware_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR, shared_1.UserRole.SALES), (0, middleware_1.asyncHandler)(async (req, res) => {
    const lead = await SalesService_1.salesService.createLead(req.body, req.user.userId);
    res.status(201).json(lead);
}));
/**
 * GET /api/sales/leads
 * Get all leads with optional filtering
 * Access: All authenticated users
 */
router.get('/leads', (0, middleware_1.asyncHandler)(async (req, res) => {
    const { status, assignedTo, limit, offset } = req.query;
    const result = await SalesService_1.salesService.getAllLeads({
        status: status,
        assignedTo: assignedTo,
        limit: limit ? parseInt(limit) : undefined,
        offset: offset ? parseInt(offset) : undefined,
    });
    res.json(result);
}));
/**
 * GET /api/sales/leads/:leadId
 * Get a specific lead by ID
 * Access: All authenticated users
 */
router.get('/leads/:leadId', (0, middleware_1.asyncHandler)(async (req, res) => {
    const { leadId } = req.params;
    const lead = await SalesService_1.salesService.getLeadById(leadId);
    res.json(lead);
}));
/**
 * PUT /api/sales/leads/:leadId
 * Update a lead
 * Access: ADMIN, SUPERVISOR, SALES
 */
router.put('/leads/:leadId', (0, middleware_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR, shared_1.UserRole.SALES), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { leadId } = req.params;
    const lead = await SalesService_1.salesService.updateLead(leadId, req.body, req.user.userId);
    res.json(lead);
}));
/**
 * POST /api/sales/leads/:leadId/convert
 * Convert a lead to a customer
 * Access: ADMIN, SUPERVISOR, SALES
 */
router.post('/leads/:leadId/convert', (0, middleware_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR, shared_1.UserRole.SALES), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { leadId } = req.params;
    const customer = await SalesService_1.salesService.convertLeadToCustomer(leadId, req.user.userId);
    res.status(201).json(customer);
}));
// ============================================================================
// OPPORTUNITIES
// ============================================================================
/**
 * POST /api/sales/opportunities
 * Create a new opportunity
 * Access: ADMIN, SUPERVISOR, SALES
 */
router.post('/opportunities', (0, middleware_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR, shared_1.UserRole.SALES), (0, middleware_1.asyncHandler)(async (req, res) => {
    const opportunity = await SalesService_1.salesService.createOpportunity(req.body, req.user.userId);
    res.status(201).json(opportunity);
}));
/**
 * GET /api/sales/opportunities
 * Get all opportunities with optional filtering
 * Access: All authenticated users
 */
router.get('/opportunities', (0, middleware_1.asyncHandler)(async (req, res) => {
    const { stage, customerId, assignedTo, limit, offset } = req.query;
    const result = await SalesService_1.salesService.getAllOpportunities({
        stage: stage,
        customerId: customerId,
        assignedTo: assignedTo,
        limit: limit ? parseInt(limit) : undefined,
        offset: offset ? parseInt(offset) : undefined,
    });
    res.json(result);
}));
/**
 * GET /api/sales/opportunities/:opportunityId
 * Get a specific opportunity by ID
 * Access: All authenticated users
 */
router.get('/opportunities/:opportunityId', (0, middleware_1.asyncHandler)(async (req, res) => {
    const { opportunityId } = req.params;
    const opportunity = await SalesService_1.salesService.getOpportunityById(opportunityId);
    res.json(opportunity);
}));
/**
 * PUT /api/sales/opportunities/:opportunityId/stage
 * Update opportunity stage
 * Access: ADMIN, SUPERVISOR, SALES
 */
router.put('/opportunities/:opportunityId/stage', (0, middleware_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR, shared_1.UserRole.SALES), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { opportunityId } = req.params;
    const { stage } = req.body;
    const opportunity = await SalesService_1.salesService.updateOpportunityStage(opportunityId, stage, req.user.userId);
    res.json(opportunity);
}));
// ============================================================================
// QUOTES
// ============================================================================
/**
 * POST /api/sales/quotes
 * Create a new quote
 * Access: ADMIN, SUPERVISOR, SALES
 */
router.post('/quotes', (0, middleware_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR, shared_1.UserRole.SALES), (0, middleware_1.asyncHandler)(async (req, res) => {
    const quote = await SalesService_1.salesService.createQuote(req.body, req.user.userId);
    res.status(201).json(quote);
}));
/**
 * GET /api/sales/quotes
 * Get all quotes with optional filtering
 * Access: All authenticated users
 */
router.get('/quotes', (0, middleware_1.asyncHandler)(async (req, res) => {
    const { customerId, status, limit, offset } = req.query;
    const result = await SalesService_1.salesService.getAllQuotes({
        customerId: customerId,
        status: status,
        limit: limit ? parseInt(limit) : undefined,
        offset: offset ? parseInt(offset) : undefined,
    });
    res.json(result);
}));
/**
 * GET /api/sales/quotes/:quoteId
 * Get a specific quote by ID
 * Access: All authenticated users
 */
router.get('/quotes/:quoteId', (0, middleware_1.asyncHandler)(async (req, res) => {
    const { quoteId } = req.params;
    const quote = await SalesService_1.salesService.getQuoteById(quoteId);
    res.json(quote);
}));
/**
 * POST /api/sales/quotes/:quoteId/send
 * Send a quote to customer
 * Access: ADMIN, SUPERVISOR, SALES
 */
router.post('/quotes/:quoteId/send', (0, middleware_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR, shared_1.UserRole.SALES), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { quoteId } = req.params;
    const quote = await SalesService_1.salesService.sendQuote(quoteId, req.user.userId);
    res.json(quote);
}));
/**
 * POST /api/sales/quotes/:quoteId/accept
 * Accept a quote (mark as accepted and convert to order)
 * Access: ADMIN, SUPERVISOR, SALES
 */
router.post('/quotes/:quoteId/accept', (0, middleware_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR, shared_1.UserRole.SALES), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { quoteId } = req.params;
    const result = await SalesService_1.salesService.acceptQuote(quoteId, req.user.userId);
    res.json(result);
}));
// ============================================================================
// CUSTOMER INTERACTIONS
// ============================================================================
/**
 * POST /api/sales/interactions
 * Log a customer interaction
 * Access: ADMIN, SUPERVISOR, SALES
 */
router.post('/interactions', (0, middleware_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR, shared_1.UserRole.SALES), (0, middleware_1.asyncHandler)(async (req, res) => {
    const interaction = await SalesService_1.salesService.logInteraction({
        ...req.body,
        createdAt: new Date(),
    });
    res.status(201).json(interaction);
}));
/**
 * GET /api/sales/customers/:customerId/interactions
 * Get interaction history for a customer
 * Access: All authenticated users
 */
router.get('/customers/:customerId/interactions', (0, middleware_1.asyncHandler)(async (req, res) => {
    const { customerId } = req.params;
    const { limit } = req.query;
    const interactions = await SalesService_1.salesService.getCustomerInteractions(customerId, limit ? parseInt(limit) : 50);
    res.json({ interactions, count: interactions.length });
}));
exports.default = router;
//# sourceMappingURL=sales.js.map