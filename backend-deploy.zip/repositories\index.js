"use strict";
/**
 * Repository index
 *
 * Exports all repositories for easy importing
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.notificationRepository = exports.skuRepository = exports.userRepository = exports.inventoryRepository = exports.pickTaskRepository = exports.orderRepository = void 0;
__exportStar(require("./BaseRepository"), exports);
__exportStar(require("./OrderRepository"), exports);
__exportStar(require("./PickTaskRepository"), exports);
__exportStar(require("./InventoryRepository"), exports);
__exportStar(require("./UserRepository"), exports);
__exportStar(require("./SKURepository"), exports);
__exportStar(require("./NotificationRepository"), exports);
// Re-export singleton instances
var OrderRepository_1 = require("./OrderRepository");
Object.defineProperty(exports, "orderRepository", { enumerable: true, get: function () { return OrderRepository_1.orderRepository; } });
var PickTaskRepository_1 = require("./PickTaskRepository");
Object.defineProperty(exports, "pickTaskRepository", { enumerable: true, get: function () { return PickTaskRepository_1.pickTaskRepository; } });
var InventoryRepository_1 = require("./InventoryRepository");
Object.defineProperty(exports, "inventoryRepository", { enumerable: true, get: function () { return InventoryRepository_1.inventoryRepository; } });
var UserRepository_1 = require("./UserRepository");
Object.defineProperty(exports, "userRepository", { enumerable: true, get: function () { return UserRepository_1.userRepository; } });
var SKURepository_1 = require("./SKURepository");
Object.defineProperty(exports, "skuRepository", { enumerable: true, get: function () { return SKURepository_1.skuRepository; } });
var NotificationRepository_1 = require("./NotificationRepository");
Object.defineProperty(exports, "notificationRepository", { enumerable: true, get: function () { return NotificationRepository_1.notificationRepository; } });
//# sourceMappingURL=index.js.map