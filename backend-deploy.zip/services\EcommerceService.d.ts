/**
 * E-commerce Integration Service
 *
 * Business logic for e-commerce platform integration
 * Supports Shopify, WooCommerce, Magento, and custom platforms
 */
import { EcommerceConnection, EcommerceProductMapping, EcommerceSyncLog, PlatformType, CreateEcommerceConnectionDTO, UpdateEcommerceConnectionDTO, CreateProductMappingDTO, UpdateProductMappingDTO, SyncInventoryRequestDTO, SyncProductsRequestDTO, SyncOrdersRequestDTO, TestConnectionResult } from '@opsui/shared';
export declare class EcommerceService {
    private platformServices;
    constructor();
    /**
     * Create a new e-commerce connection
     */
    createConnection(dto: CreateEcommerceConnectionDTO): Promise<EcommerceConnection>;
    /**
     * Update an existing connection
     */
    updateConnection(connectionId: string, dto: UpdateEcommerceConnectionDTO): Promise<EcommerceConnection | null>;
    /**
     * Get connection by ID
     */
    getConnection(connectionId: string): Promise<EcommerceConnection | null>;
    /**
     * Get all connections
     */
    getAllConnections(): Promise<EcommerceConnection[]>;
    /**
     * Get active connections
     */
    getActiveConnections(): Promise<EcommerceConnection[]>;
    /**
     * Delete a connection
     */
    deleteConnection(connectionId: string): Promise<boolean>;
    /**
     * Test connection to e-commerce platform
     */
    testConnection(connectionId: string): Promise<TestConnectionResult>;
    /**
     * Create product mapping
     */
    createProductMapping(dto: CreateProductMappingDTO): Promise<EcommerceProductMapping>;
    /**
     * Update product mapping
     */
    updateProductMapping(mappingId: string, dto: UpdateProductMappingDTO): Promise<EcommerceProductMapping | null>;
    /**
     * Get product mappings for a connection
     */
    getProductMappings(connectionId: string): Promise<EcommerceProductMapping[]>;
    /**
     * Delete product mapping
     */
    deleteProductMapping(mappingId: string): Promise<boolean>;
    /**
     * Sync inventory for SKUs
     */
    syncInventory(dto: SyncInventoryRequestDTO): Promise<EcommerceSyncLog>;
    /**
     * Sync products from platform
     */
    syncProducts(dto: SyncProductsRequestDTO): Promise<EcommerceSyncLog>;
    /**
     * Sync orders from platform
     */
    syncOrders(dto: SyncOrdersRequestDTO): Promise<EcommerceSyncLog>;
    /**
     * Process a platform order and create internal sales order
     */
    private processPlatformOrder;
    /**
     * Process incoming webhook
     */
    processWebhook(connectionId: string, event: string, payload: any): Promise<void>;
    /**
     * Handle specific webhook event
     */
    private handleWebhookEvent;
    /**
     * Get connection status overview
     */
    getConnectionStatus(): Promise<import("@opsui/shared").EcommerceConnectionStatus[]>;
    /**
     * Get sync errors
     */
    getSyncErrors(): Promise<import("@opsui/shared").EcommerceSyncError[]>;
    /**
     * Get pending syncs
     */
    getPendingSyncs(): Promise<import("@opsui/shared").EcommercePendingSync[]>;
    /**
     * Get sync logs for a connection
     */
    getSyncLogs(connectionId: string, limit?: number): Promise<EcommerceSyncLog[]>;
    /**
     * Save platform-specific settings
     */
    private savePlatformSettings;
    /**
     * Get platform-specific settings
     */
    getPlatformSettings(connectionId: string, platformType: PlatformType): Promise<any>;
}
export declare const ecommerceService: EcommerceService;
//# sourceMappingURL=EcommerceService.d.ts.map