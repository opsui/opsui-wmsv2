/**
 * Run the add-on modules migration
 * Creates tables for Production Management, Sales & CRM, and Maintenance & Assets
 */
export {};
//# sourceMappingURL=run-addon-modules-migration.d.ts.map