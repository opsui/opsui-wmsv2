"use strict";
/**
 * Custom Roles routes
 *
 * Provides endpoints for managing custom roles with permissions
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const CustomRoleRepository_1 = require("../repositories/CustomRoleRepository");
const UserRepository_1 = require("../repositories/UserRepository");
const middleware_1 = require("../middleware");
const shared_1 = require("@opsui/shared");
const shared_2 = require("@opsui/shared");
const nanoid_1 = require("nanoid");
const AuditService_1 = require("../services/AuditService");
const router = (0, express_1.Router)();
const customRoleRepo = new CustomRoleRepository_1.CustomRoleRepository();
const userRepo = new UserRepository_1.UserRepository();
const auditService = (0, AuditService_1.getAuditService)();
// Helper middleware to check if user is admin
const requireAdmin = (req, res, next) => {
    // Check base role - admins with any active role should still have admin access
    if (req.user?.baseRole !== shared_1.UserRole.ADMIN) {
        res.status(403).json({
            error: 'Admin access required',
            code: 'FORBIDDEN',
        });
        return;
    }
    next();
};
/**
 * GET /api/custom-roles
 * Get all custom roles with their permissions (admin only)
 */
router.get('/', middleware_1.authenticate, requireAdmin, (0, middleware_1.asyncHandler)(async (_req, res) => {
    const roles = await customRoleRepo.getAllRolesWithPermissions();
    // Also include system roles (predefined UserRole enum)
    const systemRoles = await customRoleRepo.getSystemRoles();
    // Combine all roles, deduplicating by roleId (system roles take precedence)
    const roleMap = new Map();
    for (const role of roles) {
        roleMap.set(role.roleId, role);
    }
    for (const systemRole of systemRoles) {
        roleMap.set(systemRole.roleId, systemRole);
    }
    const allRoles = Array.from(roleMap.values());
    res.json(allRoles);
}));
/**
 * GET /api/custom-roles/system
 * Get all system roles (predefined UserRole enum) with their default permissions (admin only)
 * IMPORTANT: This must come BEFORE /:roleId to avoid "system" being treated as a role ID
 */
router.get('/system', middleware_1.authenticate, requireAdmin, (0, middleware_1.asyncHandler)(async (_req, res) => {
    const systemRoles = await customRoleRepo.getSystemRoles();
    res.json(systemRoles);
}));
/**
 * GET /api/custom-roles/permissions
 * Get all available permissions (admin only)
 * IMPORTANT: This must come BEFORE /:roleId to avoid "permissions" being treated as a role ID
 */
router.get('/permissions', middleware_1.authenticate, requireAdmin, (0, middleware_1.asyncHandler)(async (_req, res) => {
    // Import permission groups
    const { PERMISSION_GROUPS } = await Promise.resolve().then(() => __importStar(require('@opsui/shared')));
    // Return permissions organized by groups
    res.json({
        permissions: Object.values(shared_2.Permission),
        groups: PERMISSION_GROUPS,
    });
}));
/**
 * GET /api/custom-roles/my-permissions
 * Get current user's permissions (all users)
 * IMPORTANT: This must come BEFORE /:roleId to avoid "my-permissions" being treated as a role ID
 */
router.get('/my-permissions', middleware_1.authenticate, (0, middleware_1.asyncHandler)(async (req, res) => {
    if (!req.user) {
        res.status(401).json({
            error: 'Not authenticated',
            code: 'NOT_AUTHENTICATED',
        });
        return;
    }
    const permissions = await customRoleRepo.getUserPermissions(req.user.userId, req.user.role);
    res.json({ permissions });
}));
/**
 * GET /api/custom-roles/:roleId
 * Get a specific custom role by ID (admin only)
 * IMPORTANT: This must come AFTER all specific routes to avoid catching them
 */
router.get('/:roleId', middleware_1.authenticate, requireAdmin, (0, middleware_1.asyncHandler)(async (req, res) => {
    const { roleId } = req.params;
    const role = await customRoleRepo.getCustomRoleById(roleId);
    if (!role) {
        res.status(404).json({
            error: 'Role not found',
            code: 'ROLE_NOT_FOUND',
        });
        return;
    }
    res.json(role);
}));
/**
 * POST /api/custom-roles
 * Create a new custom role (admin only)
 */
router.post('/', middleware_1.authenticate, requireAdmin, (0, middleware_1.asyncHandler)(async (req, res) => {
    const { name, description, permissions } = req.body;
    // Validate request
    if (!name || !description) {
        res.status(400).json({
            error: 'Name and description are required',
            code: 'MISSING_FIELDS',
        });
        return;
    }
    // Validate name length
    if (name.length < 3 || name.length > 100) {
        res.status(400).json({
            error: 'Name must be between 3 and 100 characters',
            code: 'INVALID_NAME_LENGTH',
        });
        return;
    }
    // Validate permissions
    if (!permissions || !Array.isArray(permissions) || permissions.length === 0) {
        res.status(400).json({
            error: 'At least one permission is required',
            code: 'NO_PERMISSIONS',
        });
        return;
    }
    // Validate each permission
    const validPermissions = Object.values(shared_2.Permission);
    const invalidPermissions = permissions.filter(p => !validPermissions.includes(p));
    if (invalidPermissions.length > 0) {
        res.status(400).json({
            error: 'Invalid permissions',
            code: 'INVALID_PERMISSIONS',
            details: invalidPermissions,
        });
        return;
    }
    // Generate role ID
    const roleId = `custom_${(0, nanoid_1.nanoid)(8).toLowerCase()}`;
    // Create the role
    const newRole = await customRoleRepo.createCustomRole({
        roleId,
        name,
        description,
        permissions,
        grantedBy: req.user.userId,
    });
    // Get admin user info for audit log
    const adminUser = await userRepo.findById(req.user.userId);
    // Safely get IP and user-agent
    const ipAddress = req.ip || req.socket?.remoteAddress || null;
    const userAgent = req.get('user-agent') || null;
    // Log the custom role creation in audit logs
    try {
        await auditService.logAuthorization(AuditService_1.AuditEventType.CUSTOM_ROLE_CREATED, req.user.userId, adminUser?.email || req.user.email || null, adminUser?.role || req.user.effectiveRole || null, 'custom_role', roleId, `Created custom role "${name}" (${roleId})`, undefined, { name, description, permissions }, undefined, ipAddress, userAgent);
    }
    catch (auditError) {
        // Log the audit error but don't fail the request
        console.error('[customRoles] Failed to log role creation to audit:', auditError);
    }
    res.status(201).json(newRole);
}));
/**
 * PUT /api/custom-roles/:roleId
 * Update a custom role (admin only)
 */
router.put('/:roleId', middleware_1.authenticate, requireAdmin, (0, middleware_1.asyncHandler)(async (req, res) => {
    const { roleId } = req.params;
    const { name, description, permissions } = req.body;
    // Validate name length if provided
    if (name !== undefined && (name.length < 3 || name.length > 100)) {
        res.status(400).json({
            error: 'Name must be between 3 and 100 characters',
            code: 'INVALID_NAME_LENGTH',
        });
        return;
    }
    // Validate permissions if provided
    if (permissions !== undefined) {
        if (!Array.isArray(permissions) || permissions.length === 0) {
            res.status(400).json({
                error: 'At least one permission is required',
                code: 'NO_PERMISSIONS',
            });
            return;
        }
        const validPermissions = Object.values(shared_2.Permission);
        const invalidPermissions = permissions.filter(p => !validPermissions.includes(p));
        if (invalidPermissions.length > 0) {
            res.status(400).json({
                error: 'Invalid permissions',
                code: 'INVALID_PERMISSIONS',
                details: invalidPermissions,
            });
            return;
        }
    }
    // Get the existing role for audit oldValues
    const existingRole = await customRoleRepo.getCustomRoleById(roleId);
    // Update the role
    const updatedRole = await customRoleRepo.updateCustomRole(roleId, {
        name,
        description,
        permissions,
        grantedBy: req.user.userId,
    });
    // Get admin user info for audit log
    const adminUser = await userRepo.findById(req.user.userId);
    // Safely get IP and user-agent
    const ipAddress = req.ip || req.socket?.remoteAddress || null;
    const userAgent = req.get('user-agent') || null;
    // Log the custom role update in audit logs
    try {
        await auditService.logAuthorization(AuditService_1.AuditEventType.CUSTOM_ROLE_UPDATED, req.user.userId, adminUser?.email || req.user.email || null, adminUser?.role || req.user.effectiveRole || null, 'custom_role', roleId, `Updated custom role "${updatedRole.name}" (${roleId})`, existingRole
            ? {
                name: existingRole.name,
                description: existingRole.description,
                permissions: existingRole.permissions,
            }
            : undefined, { name, description, permissions }, undefined, ipAddress, userAgent);
    }
    catch (auditError) {
        // Log the audit error but don't fail the request
        console.error('[customRoles] Failed to log role update to audit:', auditError);
    }
    res.json(updatedRole);
}));
/**
 * DELETE /api/custom-roles/:roleId
 * Delete a custom role (admin only)
 */
router.delete('/:roleId', middleware_1.authenticate, requireAdmin, (0, middleware_1.asyncHandler)(async (req, res) => {
    const { roleId } = req.params;
    // Get the existing role for audit log before deleting
    const existingRole = await customRoleRepo.getCustomRoleById(roleId);
    await customRoleRepo.deleteCustomRole(roleId);
    // Get admin user info for audit log
    const adminUser = await userRepo.findById(req.user.userId);
    // Safely get IP and user-agent
    const ipAddress = req.ip || req.socket?.remoteAddress || null;
    const userAgent = req.get('user-agent') || null;
    // Log the custom role deletion in audit logs
    try {
        await auditService.logAuthorization(AuditService_1.AuditEventType.CUSTOM_ROLE_DELETED, req.user.userId, adminUser?.email || req.user.email || null, adminUser?.role || req.user.effectiveRole || null, 'custom_role', roleId, `Deleted custom role "${existingRole?.name || roleId}" (${roleId})`, existingRole
            ? {
                name: existingRole.name,
                description: existingRole.description,
                permissions: existingRole.permissions,
            }
            : undefined, undefined, undefined, ipAddress, userAgent);
    }
    catch (auditError) {
        // Log the audit error but don't fail the request
        console.error('[customRoles] Failed to log role deletion to audit:', auditError);
    }
    res.json({ success: true, message: 'Role deleted successfully' });
}));
exports.default = router;
//# sourceMappingURL=customRoles.js.map