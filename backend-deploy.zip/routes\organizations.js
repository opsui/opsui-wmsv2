"use strict";
/**
 * Organization Routes
 *
 * API endpoints for multi-tenant organization management.
 * Handles organization CRUD, memberships, invitations, and settings.
 */
Object.defineProperty(exports, "__esModule", { value: true });
const shared_1 = require("@opsui/shared");
const express_1 = require("express");
const middleware_1 = require("../middleware");
const OrganizationService_1 = require("../services/OrganizationService");
// ============================================================================
// ROUTER SETUP
// ============================================================================
const router = (0, express_1.Router)();
// All organization routes require authentication
router.use(middleware_1.authenticate);
// ============================================================================
// ORGANIZATION CRUD
// ============================================================================
/**
 * POST /api/organizations
 * Create a new organization
 * Any authenticated user can create an organization (becomes owner)
 */
router.post('/', (0, middleware_1.asyncHandler)(async (req, res) => {
    if (!req.user) {
        res.status(401).json({ error: 'Not authenticated' });
        return;
    }
    const data = {
        organizationName: req.body.organizationName,
        slug: req.body.slug,
        legalName: req.body.legalName,
        taxId: req.body.taxId,
        registrationNumber: req.body.registrationNumber,
        tier: req.body.tier,
        addressLine1: req.body.addressLine1,
        addressLine2: req.body.addressLine2,
        city: req.body.city,
        stateProvince: req.body.stateProvince,
        postalCode: req.body.postalCode,
        countryCode: req.body.countryCode,
        phone: req.body.phone,
        email: req.body.email,
        website: req.body.website,
        baseCurrency: req.body.baseCurrency,
        timezone: req.body.timezone,
        dateFormat: req.body.dateFormat,
        fiscalYearStartMonth: req.body.fiscalYearStartMonth,
        ownerId: req.user.userId,
    };
    const organization = await OrganizationService_1.organizationService.createOrganization(data);
    res.status(201).json({
        success: true,
        data: organization,
    });
}));
/**
 * GET /api/organizations
 * List organizations (admin only - for system management)
 */
router.get('/', (0, middleware_1.authorize)(shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (req, res) => {
    const filters = {
        status: req.query.status,
        tier: req.query.tier,
        search: req.query.search,
        isActive: req.query.isActive === 'true' ? true : req.query.isActive === 'false' ? false : undefined,
    };
    const page = parseInt(req.query.page) || 1;
    const pageSize = parseInt(req.query.pageSize) || 20;
    const result = await OrganizationService_1.organizationService.listOrganizations(filters, page, pageSize);
    res.json({
        success: true,
        data: result,
    });
}));
/**
 * GET /api/organizations/my
 * Get current user's organizations
 */
router.get('/my', (0, middleware_1.asyncHandler)(async (req, res) => {
    if (!req.user) {
        res.status(401).json({ error: 'Not authenticated' });
        return;
    }
    const result = await OrganizationService_1.organizationService.getUserOrganizations(req.user.userId);
    res.json({
        success: true,
        data: result,
    });
}));
/**
 * GET /api/organizations/:organizationId
 * Get organization by ID
 */
router.get('/:organizationId', (0, middleware_1.asyncHandler)(async (req, res) => {
    if (!req.user) {
        res.status(401).json({ error: 'Not authenticated' });
        return;
    }
    const { organizationId } = req.params;
    // Check access
    await OrganizationService_1.organizationService.checkAccess(organizationId, req.user.userId);
    const organization = await OrganizationService_1.organizationService.getOrganization(organizationId);
    res.json({
        success: true,
        data: organization,
    });
}));
/**
 * GET /api/organizations/slug/:slug
 * Get organization by slug
 */
router.get('/slug/:slug', (0, middleware_1.asyncHandler)(async (req, res) => {
    if (!req.user) {
        res.status(401).json({ error: 'Not authenticated' });
        return;
    }
    const { slug } = req.params;
    const organization = await OrganizationService_1.organizationService.getOrganizationBySlug(slug);
    // Check access
    await OrganizationService_1.organizationService.checkAccess(organization.organizationId, req.user.userId);
    res.json({
        success: true,
        data: organization,
    });
}));
/**
 * PUT /api/organizations/:organizationId
 * Update organization
 */
router.put('/:organizationId', (0, middleware_1.asyncHandler)(async (req, res) => {
    if (!req.user) {
        res.status(401).json({ error: 'Not authenticated' });
        return;
    }
    const { organizationId } = req.params;
    const data = {
        organizationName: req.body.organizationName,
        legalName: req.body.legalName,
        taxId: req.body.taxId,
        registrationNumber: req.body.registrationNumber,
        addressLine1: req.body.addressLine1,
        addressLine2: req.body.addressLine2,
        city: req.body.city,
        stateProvince: req.body.stateProvince,
        postalCode: req.body.postalCode,
        countryCode: req.body.countryCode,
        phone: req.body.phone,
        email: req.body.email,
        website: req.body.website,
        logoUrl: req.body.logoUrl,
        primaryColor: req.body.primaryColor,
        customDomain: req.body.customDomain,
        baseCurrency: req.body.baseCurrency,
        timezone: req.body.timezone,
        dateFormat: req.body.dateFormat,
        fiscalYearStartMonth: req.body.fiscalYearStartMonth,
        settings: req.body.settings,
    };
    const organization = await OrganizationService_1.organizationService.updateOrganization(organizationId, data, req.user.userId);
    res.json({
        success: true,
        data: organization,
    });
}));
/**
 * PUT /api/organizations/:organizationId/status
 * Update organization status
 */
router.put('/:organizationId/status', (0, middleware_1.asyncHandler)(async (req, res) => {
    if (!req.user) {
        res.status(401).json({ error: 'Not authenticated' });
        return;
    }
    const { organizationId } = req.params;
    const { status } = req.body;
    if (!status) {
        res.status(400).json({ error: 'Status is required' });
        return;
    }
    const organization = await OrganizationService_1.organizationService.updateStatus(organizationId, status, req.user.userId);
    res.json({
        success: true,
        data: organization,
    });
}));
/**
 * PUT /api/organizations/:organizationId/tier
 * Update organization tier
 */
router.put('/:organizationId/tier', (0, middleware_1.asyncHandler)(async (req, res) => {
    if (!req.user) {
        res.status(401).json({ error: 'Not authenticated' });
        return;
    }
    const { organizationId } = req.params;
    const { tier } = req.body;
    if (!tier) {
        res.status(400).json({ error: 'Tier is required' });
        return;
    }
    const organization = await OrganizationService_1.organizationService.updateTier(organizationId, tier, req.user.userId);
    res.json({
        success: true,
        data: organization,
    });
}));
/**
 * PUT /api/organizations/:organizationId/set-primary
 * Set as user's primary organization
 */
router.put('/:organizationId/set-primary', (0, middleware_1.asyncHandler)(async (req, res) => {
    if (!req.user) {
        res.status(401).json({ error: 'Not authenticated' });
        return;
    }
    const { organizationId } = req.params;
    await OrganizationService_1.organizationService.setPrimaryOrganization(req.user.userId, organizationId);
    res.json({
        success: true,
        message: 'Primary organization updated',
    });
}));
// ============================================================================
// MEMBERSHIP MANAGEMENT
// ============================================================================
/**
 * GET /api/organizations/:organizationId/members
 * Get organization members
 */
router.get('/:organizationId/members', (0, middleware_1.asyncHandler)(async (req, res) => {
    if (!req.user) {
        res.status(401).json({ error: 'Not authenticated' });
        return;
    }
    const { organizationId } = req.params;
    const filters = {
        role: req.query.role,
        isActive: req.query.isActive === 'true' ? true : req.query.isActive === 'false' ? false : undefined,
        search: req.query.search,
    };
    const page = parseInt(req.query.page) || 1;
    const pageSize = parseInt(req.query.pageSize) || 50;
    const result = await OrganizationService_1.organizationService.getMembers(organizationId, req.user.userId, filters, page, pageSize);
    res.json({
        success: true,
        data: result,
    });
}));
/**
 * POST /api/organizations/:organizationId/members
 * Add member to organization
 */
router.post('/:organizationId/members', (0, middleware_1.asyncHandler)(async (req, res) => {
    if (!req.user) {
        res.status(401).json({ error: 'Not authenticated' });
        return;
    }
    const { organizationId } = req.params;
    const data = {
        organizationId,
        userId: req.body.userId,
        role: req.body.role,
        isPrimary: req.body.isPrimary,
        canManageUsers: req.body.canManageUsers,
        canManageBilling: req.body.canManageBilling,
        canManageSettings: req.body.canManageSettings,
        canInviteUsers: req.body.canInviteUsers,
    };
    const membership = await OrganizationService_1.organizationService.addMember(organizationId, data, req.user.userId);
    res.status(201).json({
        success: true,
        data: membership,
    });
}));
/**
 * PUT /api/organizations/:organizationId/members/:userId
 * Update member role/permissions
 */
router.put('/:organizationId/members/:userId', (0, middleware_1.asyncHandler)(async (req, res) => {
    if (!req.user) {
        res.status(401).json({ error: 'Not authenticated' });
        return;
    }
    const { organizationId, userId } = req.params;
    const data = {
        role: req.body.role,
        isPrimary: req.body.isPrimary,
        canManageUsers: req.body.canManageUsers,
        canManageBilling: req.body.canManageBilling,
        canManageSettings: req.body.canManageSettings,
        canInviteUsers: req.body.canInviteUsers,
        isActive: req.body.isActive,
    };
    const membership = await OrganizationService_1.organizationService.updateMember(organizationId, userId, data, req.user.userId);
    res.json({
        success: true,
        data: membership,
    });
}));
/**
 * DELETE /api/organizations/:organizationId/members/:userId
 * Remove member from organization
 */
router.delete('/:organizationId/members/:userId', (0, middleware_1.asyncHandler)(async (req, res) => {
    if (!req.user) {
        res.status(401).json({ error: 'Not authenticated' });
        return;
    }
    const { organizationId, userId } = req.params;
    await OrganizationService_1.organizationService.removeMember(organizationId, userId, req.user.userId);
    res.json({
        success: true,
        message: 'Member removed from organization',
    });
}));
// ============================================================================
// INVITATIONS
// ============================================================================
/**
 * GET /api/organizations/invitations/pending
 * Get pending invitations for current user's email
 */
router.get('/invitations/pending', (0, middleware_1.asyncHandler)(async (req, res) => {
    if (!req.user) {
        res.status(401).json({ error: 'Not authenticated' });
        return;
    }
    // Get user's email from database
    const invitations = await OrganizationService_1.organizationService.getPendingInvitations(req.user.email);
    res.json({
        success: true,
        data: invitations,
    });
}));
/**
 * GET /api/organizations/invitations/:token
 * Get invitation by token
 */
router.get('/invitations/:token', (0, middleware_1.asyncHandler)(async (req, res) => {
    const { token } = req.params;
    const invitation = await OrganizationService_1.organizationService.getInvitationByToken(token);
    res.json({
        success: true,
        data: invitation,
    });
}));
/**
 * POST /api/organizations/invitations/:token/accept
 * Accept invitation
 */
router.post('/invitations/:token/accept', (0, middleware_1.asyncHandler)(async (req, res) => {
    if (!req.user) {
        res.status(401).json({ error: 'Not authenticated' });
        return;
    }
    const { token } = req.params;
    const data = {
        token,
        userId: req.user.userId,
        name: req.body.name,
        password: req.body.password,
    };
    const membership = await OrganizationService_1.organizationService.acceptInvitation(data);
    res.json({
        success: true,
        data: membership,
        message: 'Invitation accepted',
    });
}));
/**
 * POST /api/organizations/invitations/:token/decline
 * Decline invitation
 */
router.post('/invitations/:token/decline', (0, middleware_1.asyncHandler)(async (req, res) => {
    const { token } = req.params;
    await OrganizationService_1.organizationService.declineInvitation(token);
    res.json({
        success: true,
        message: 'Invitation declined',
    });
}));
/**
 * GET /api/organizations/:organizationId/invitations
 * Get organization's pending invitations
 */
router.get('/:organizationId/invitations', (0, middleware_1.asyncHandler)(async (req, res) => {
    if (!req.user) {
        res.status(401).json({ error: 'Not authenticated' });
        return;
    }
    const { organizationId } = req.params;
    const invitations = await OrganizationService_1.organizationService.getInvitations(organizationId, req.user.userId);
    res.json({
        success: true,
        data: invitations,
    });
}));
/**
 * POST /api/organizations/:organizationId/invitations
 * Invite user to organization
 */
router.post('/:organizationId/invitations', (0, middleware_1.asyncHandler)(async (req, res) => {
    if (!req.user) {
        res.status(401).json({ error: 'Not authenticated' });
        return;
    }
    const { organizationId } = req.params;
    const data = {
        organizationId,
        email: req.body.email,
        role: req.body.role,
        message: req.body.message,
    };
    const invitation = await OrganizationService_1.organizationService.inviteUser(organizationId, data, req.user.userId);
    res.status(201).json({
        success: true,
        data: invitation,
        message: 'Invitation sent',
    });
}));
/**
 * DELETE /api/organizations/:organizationId/invitations/:invitationId
 * Cancel invitation
 */
router.delete('/:organizationId/invitations/:invitationId', (0, middleware_1.asyncHandler)(async (req, res) => {
    if (!req.user) {
        res.status(401).json({ error: 'Not authenticated' });
        return;
    }
    const { organizationId, invitationId } = req.params;
    await OrganizationService_1.organizationService.cancelInvitation(invitationId, organizationId, req.user.userId);
    res.json({
        success: true,
        message: 'Invitation cancelled',
    });
}));
// ============================================================================
// SETTINGS
// ============================================================================
/**
 * GET /api/organizations/:organizationId/settings
 * Get organization settings
 */
router.get('/:organizationId/settings', (0, middleware_1.asyncHandler)(async (req, res) => {
    if (!req.user) {
        res.status(401).json({ error: 'Not authenticated' });
        return;
    }
    const { organizationId } = req.params;
    const settings = await OrganizationService_1.organizationService.getSettings(organizationId, req.user.userId);
    res.json({
        success: true,
        data: settings,
    });
}));
/**
 * GET /api/organizations/:organizationId/settings/:key
 * Get specific setting
 */
router.get('/:organizationId/settings/:key', (0, middleware_1.asyncHandler)(async (req, res) => {
    if (!req.user) {
        res.status(401).json({ error: 'Not authenticated' });
        return;
    }
    const { organizationId, key } = req.params;
    const setting = await OrganizationService_1.organizationService.getSetting(organizationId, key, req.user.userId);
    res.json({
        success: true,
        data: setting,
    });
}));
/**
 * PUT /api/organizations/:organizationId/settings/:key
 * Set organization setting
 */
router.put('/:organizationId/settings/:key', (0, middleware_1.asyncHandler)(async (req, res) => {
    if (!req.user) {
        res.status(401).json({ error: 'Not authenticated' });
        return;
    }
    const { organizationId, key } = req.params;
    const { value, type } = req.body;
    const setting = await OrganizationService_1.organizationService.setSetting(organizationId, key, value, type || 'STRING', req.user.userId);
    res.json({
        success: true,
        data: setting,
    });
}));
/**
 * DELETE /api/organizations/:organizationId/settings/:key
 * Delete organization setting
 */
router.delete('/:organizationId/settings/:key', (0, middleware_1.asyncHandler)(async (req, res) => {
    if (!req.user) {
        res.status(401).json({ error: 'Not authenticated' });
        return;
    }
    const { organizationId, key } = req.params;
    await OrganizationService_1.organizationService.deleteSetting(organizationId, key, req.user.userId);
    res.json({
        success: true,
        message: 'Setting deleted',
    });
}));
// ============================================================================
// ACCESS CHECK
// ============================================================================
/**
 * GET /api/organizations/:organizationId/check-access
 * Check if current user has access to organization
 */
router.get('/:organizationId/check-access', (0, middleware_1.asyncHandler)(async (req, res) => {
    if (!req.user) {
        res.status(401).json({ error: 'Not authenticated' });
        return;
    }
    const { organizationId } = req.params;
    try {
        const membership = await OrganizationService_1.organizationService.checkAccess(organizationId, req.user.userId);
        res.json({
            success: true,
            data: {
                hasAccess: true,
                role: membership.role,
                isPrimary: membership.isPrimary,
                permissions: {
                    canManageUsers: membership.canManageUsers,
                    canManageBilling: membership.canManageBilling,
                    canManageSettings: membership.canManageSettings,
                    canInviteUsers: membership.canInviteUsers,
                },
            },
        });
    }
    catch (error) {
        res.json({
            success: true,
            data: {
                hasAccess: false,
            },
        });
    }
}));
// ============================================================================
// EXPORT
// ============================================================================
exports.default = router;
//# sourceMappingURL=organizations.js.map