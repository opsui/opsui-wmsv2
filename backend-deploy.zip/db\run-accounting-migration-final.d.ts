/**
 * Run the accounting tables migration (final)
 */
export {};
//# sourceMappingURL=run-accounting-migration-final.d.ts.map