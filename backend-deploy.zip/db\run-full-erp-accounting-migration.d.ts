/**
 * Run full ERP accounting migrations (all phases)
 * Phase 1: Chart of Accounts, Journal Entries, Balance Sheet, Cash Flow
 * Phase 2: Enhanced AR/AP, Cash Management, Revenue Recognition
 * Phase 3: Multi-Currency, Budgeting, Fixed Assets, Compliance
 */
export {};
//# sourceMappingURL=run-full-erp-accounting-migration.d.ts.map