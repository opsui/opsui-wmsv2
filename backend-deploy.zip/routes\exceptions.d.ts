/**
 * Order Exception routes
 *
 * Endpoints for logging and resolving order exceptions during fulfillment
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=exceptions.d.ts.map