"use strict";
/**
 * Multi-Entity API Routes
 *
 * REST API for multi-company, multi-subsidiary ERP operations
 * Handles entities, inter-company transactions, consolidation rules, and entity user assignments
 */
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const MultiEntityService_1 = require("../services/MultiEntityService");
const middleware_1 = require("../middleware");
const shared_1 = require("@opsui/shared");
const router = (0, express_1.Router)();
// All multi-entity routes require authentication
router.use(middleware_1.authenticate);
// Multi-entity management requires Admin access
const adminAuth = (0, middleware_1.authorize)(shared_1.UserRole.ADMIN);
// Entity users can be managed by Admin or HR Manager
const userManagementAuth = (0, middleware_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.HR_MANAGER);
// Entity viewers can read entity data
const viewerAuth = (0, middleware_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.HR_MANAGER, shared_1.UserRole.ACCOUNTING, shared_1.UserRole.SALES, shared_1.UserRole.SUPERVISOR);
// ============================================================================
// ENTITIES
// ============================================================================
/**
 * GET /api/multi-entity/entities
 * Get all entities with optional filters
 * Query params: entity_type, entity_status, parent_entity_id, base_currency, country_code, is_active, search
 */
router.get('/entities', viewerAuth, (0, middleware_1.asyncHandler)(async (req, res) => {
    const filters = {
        entity_type: req.query.entity_type,
        entity_status: req.query.entity_status,
        parent_entity_id: req.query.parent_entity_id,
        base_currency: req.query.base_currency,
        country_code: req.query.country_code,
        is_active: req.query.is_active === 'true' ? true : req.query.is_active === 'false' ? false : undefined,
        search: req.query.search,
    };
    const entities = await MultiEntityService_1.multiEntityService.getEntities(filters);
    res.json(entities);
}));
/**
 * GET /api/multi-entity/entities/hierarchy
 * Get entity hierarchy tree
 * Query params: root_entity_id (optional)
 */
router.get('/entities/hierarchy', viewerAuth, (0, middleware_1.asyncHandler)(async (req, res) => {
    const rootEntityId = req.query.root_entity_id;
    const hierarchy = await MultiEntityService_1.multiEntityService.getEntityHierarchy(rootEntityId);
    res.json(hierarchy);
}));
/**
 * GET /api/multi-entity/entities/:id
 * Get entity by ID
 */
router.get('/entities/:id', viewerAuth, (0, middleware_1.asyncHandler)(async (req, res) => {
    const includeHierarchy = req.query.include_hierarchy === 'true';
    const entity = includeHierarchy
        ? await MultiEntityService_1.multiEntityService.getEntityWithHierarchy(req.params.id)
        : await MultiEntityService_1.multiEntityService.getEntityById(req.params.id);
    res.json(entity);
}));
/**
 * GET /api/multi-entity/entities/:id/subsidiaries
 * Get all subsidiaries of an entity
 * Query params: include_children (default: true)
 */
router.get('/entities/:id/subsidiaries', viewerAuth, (0, middleware_1.asyncHandler)(async (req, res) => {
    const includeChildren = req.query.include_children !== 'false';
    const subsidiaries = await MultiEntityService_1.multiEntityService.getEntitySubsidiaries(req.params.id, includeChildren);
    res.json(subsidiaries);
}));
/**
 * POST /api/multi-entity/entities
 * Create a new entity
 */
router.post('/entities', adminAuth, (0, middleware_1.asyncHandler)(async (req, res) => {
    const entity = await MultiEntityService_1.multiEntityService.createEntity(req.body, req.user?.userId || '');
    res.status(201).json(entity);
}));
/**
 * PUT /api/multi-entity/entities/:id
 * Update an entity
 */
router.put('/entities/:id', adminAuth, (0, middleware_1.asyncHandler)(async (req, res) => {
    const entity = await MultiEntityService_1.multiEntityService.updateEntity(req.params.id, req.body, req.user?.userId || '');
    res.json(entity);
}));
/**
 * DELETE /api/multi-entity/entities/:id
 * Delete (soft delete) an entity
 */
router.delete('/entities/:id', adminAuth, (0, middleware_1.asyncHandler)(async (req, res) => {
    const deleted = await MultiEntityService_1.multiEntityService.deleteEntity(req.params.id, req.user?.userId || '');
    res.json({ success: deleted });
}));
// ============================================================================
// ENTITY SETTINGS
// ============================================================================
/**
 * GET /api/multi-entity/entities/:id/settings
 * Get all settings for an entity
 */
router.get('/entities/:id/settings', viewerAuth, (0, middleware_1.asyncHandler)(async (req, res) => {
    const settings = await MultiEntityService_1.multiEntityService.getEntitySettings(req.params.id);
    res.json(settings);
}));
/**
 * GET /api/multi-entity/entities/:id/settings/:key
 * Get a specific setting value
 */
router.get('/entities/:id/settings/:key', viewerAuth, (0, middleware_1.asyncHandler)(async (req, res) => {
    const value = await MultiEntityService_1.multiEntityService.getEntitySetting(req.params.id, req.params.key, req.query.default);
    res.json({ key: req.params.key, value });
}));
/**
 * PUT /api/multi-entity/entities/:id/settings/:key
 * Set entity setting value
 * Body: { value: string, type: 'STRING' | 'NUMBER' | 'BOOLEAN' | 'JSON' }
 */
router.put('/entities/:id/settings/:key', adminAuth, (0, middleware_1.asyncHandler)(async (req, res) => {
    const { value, type } = req.body;
    const setting = await MultiEntityService_1.multiEntityService.setEntitySetting(req.params.id, req.params.key, value, type || 'STRING', req.user?.userId || '');
    res.json({ key: req.params.key, value });
}));
// ============================================================================
// INTER-COMPANY TRANSACTIONS
// ============================================================================
/**
 * GET /api/multi-entity/transactions
 * Get inter-company transactions with optional filters
 * Query params: from_entity_id, to_entity_id, entity_id, transaction_type, transaction_status, date_from, date_to, search
 */
router.get('/transactions', viewerAuth, (0, middleware_1.asyncHandler)(async (req, res) => {
    const filters = {
        from_entity_id: req.query.from_entity_id,
        to_entity_id: req.query.to_entity_id,
        entity_id: req.query.entity_id,
        transaction_type: req.query.transaction_type,
        transaction_status: req.query.transaction_status,
        date_from: req.query.date_from ? new Date(req.query.date_from) : undefined,
        date_to: req.query.date_to ? new Date(req.query.date_to) : undefined,
        search: req.query.search,
    };
    const transactions = await MultiEntityService_1.multiEntityService.getIntercompanyTransactions(filters);
    res.json(transactions);
}));
/**
 * GET /api/multi-entity/transactions/summary
 * Get inter-company transaction summary
 * Query params: same as /transactions
 */
router.get('/transactions/summary', viewerAuth, (0, middleware_1.asyncHandler)(async (req, res) => {
    const filters = {
        from_entity_id: req.query.from_entity_id,
        to_entity_id: req.query.to_entity_id,
        entity_id: req.query.entity_id,
        transaction_type: req.query.transaction_type,
        transaction_status: req.query.transaction_status,
        date_from: req.query.date_from ? new Date(req.query.date_from) : undefined,
        date_to: req.query.date_to ? new Date(req.query.date_to) : undefined,
    };
    const summary = await MultiEntityService_1.multiEntityService.getIntercompanyTransactionSummary(filters);
    res.json(summary);
}));
/**
 * GET /api/multi-entity/transactions/:id
 * Get inter-company transaction by ID
 */
router.get('/transactions/:id', viewerAuth, (0, middleware_1.asyncHandler)(async (req, res) => {
    const transaction = await MultiEntityService_1.multiEntityService.getIntercompanyTransactionById(req.params.id);
    res.json(transaction);
}));
/**
 * POST /api/multi-entity/transactions
 * Create a new inter-company transaction
 */
router.post('/transactions', adminAuth, (0, middleware_1.asyncHandler)(async (req, res) => {
    const transaction = await MultiEntityService_1.multiEntityService.createIntercompanyTransaction(req.body, req.user?.userId || '');
    res.status(201).json(transaction);
}));
/**
 * PUT /api/multi-entity/transactions/:id
 * Update an inter-company transaction
 */
router.put('/transactions/:id', adminAuth, (0, middleware_1.asyncHandler)(async (req, res) => {
    const transaction = await MultiEntityService_1.multiEntityService.updateIntercompanyTransaction(req.params.id, req.body, req.user?.userId || '');
    res.json(transaction);
}));
/**
 * POST /api/multi-entity/transactions/:id/approve
 * Approve an inter-company transaction
 */
router.post('/transactions/:id/approve', adminAuth, (0, middleware_1.asyncHandler)(async (req, res) => {
    const transaction = await MultiEntityService_1.multiEntityService.approveIntercompanyTransaction(req.params.id, req.user?.userId || '');
    res.json(transaction);
}));
// ============================================================================
// ENTITY RELATIONSHIPS
// ============================================================================
/**
 * GET /api/multi-entity/entities/:id/relationships
 * Get relationships for an entity
 */
router.get('/entities/:id/relationships', viewerAuth, (0, middleware_1.asyncHandler)(async (req, res) => {
    const relationships = await MultiEntityService_1.multiEntityService.getEntityRelationships(req.params.id);
    res.json(relationships);
}));
/**
 * POST /api/multi-entity/relationships
 * Create a new entity relationship
 */
router.post('/relationships', adminAuth, (0, middleware_1.asyncHandler)(async (req, res) => {
    const relationship = await MultiEntityService_1.multiEntityService.createEntityRelationship(req.body, req.user?.userId || '');
    res.status(201).json(relationship);
}));
/**
 * DELETE /api/multi-entity/relationships/:id
 * Delete an entity relationship
 */
router.delete('/relationships/:id', adminAuth, (0, middleware_1.asyncHandler)(async (req, res) => {
    const deleted = await MultiEntityService_1.multiEntityService.deleteEntityRelationship(req.params.id);
    res.json({ success: deleted });
}));
// ============================================================================
// ENTITY USERS
// ============================================================================
/**
 * GET /api/multi-entity/entities/:id/users
 * Get users assigned to an entity
 */
router.get('/entities/:id/users', viewerAuth, (0, middleware_1.asyncHandler)(async (req, res) => {
    const users = await MultiEntityService_1.multiEntityService.getEntityUsers(req.params.id);
    res.json(users);
}));
/**
 * GET /api/multi-entity/users/:id/entities
 * Get entities for a user
 */
router.get('/users/:id/entities', userManagementAuth, (0, middleware_1.asyncHandler)(async (req, res) => {
    const entities = await MultiEntityService_1.multiEntityService.getUserEntities(req.params.id);
    res.json(entities);
}));
/**
 * GET /api/multi-entity/users/:id/default-entity
 * Get user's default entity
 */
router.get('/users/:id/default-entity', viewerAuth, (0, middleware_1.asyncHandler)(async (req, res) => {
    const entity = await MultiEntityService_1.multiEntityService.getUserDefaultEntity(req.params.id);
    res.json(entity);
}));
/**
 * POST /api/multi-entity/users/assign
 * Assign user to entity
 */
router.post('/users/assign', userManagementAuth, (0, middleware_1.asyncHandler)(async (req, res) => {
    const entityUser = await MultiEntityService_1.multiEntityService.assignUserToEntity(req.body, req.user?.userId || '');
    res.status(201).json(entityUser);
}));
/**
 * PUT /api/multi-entity/entity-users/:id
 * Update entity user assignment
 */
router.put('/entity-users/:id', userManagementAuth, (0, middleware_1.asyncHandler)(async (req, res) => {
    const entityUser = await MultiEntityService_1.multiEntityService.updateEntityUserAssignment(req.params.id, req.body);
    res.json(entityUser);
}));
/**
 * DELETE /api/multi-entity/entity-users/:id
 * Remove user from entity
 */
router.delete('/entity-users/:id', userManagementAuth, (0, middleware_1.asyncHandler)(async (req, res) => {
    const deleted = await MultiEntityService_1.multiEntityService.removeUserFromEntity(req.params.id);
    res.json({ success: deleted });
}));
/**
 * POST /api/multi-entity/users/:id/default-entity
 * Set default entity for user
 * Body: { entity_id: string }
 */
router.post('/users/:id/default-entity', userManagementAuth, (0, middleware_1.asyncHandler)(async (req, res) => {
    const { entity_id } = req.body;
    const result = await MultiEntityService_1.multiEntityService.setUserDefaultEntity(req.params.id, entity_id);
    res.json({ success: result });
}));
/**
 * GET /api/multi-entity/users/:id/entities/:entityId/permissions/:permission
 * Check if user has permission on entity
 */
router.get('/users/:userId/entities/:entityId/permissions/:permission', viewerAuth, (0, middleware_1.asyncHandler)(async (req, res) => {
    const hasPermission = await MultiEntityService_1.multiEntityService.checkEntityPermission(req.params.userId, req.params.entityId, req.params.permission);
    res.json({ has_permission: hasPermission });
}));
// ============================================================================
// CONSOLIDATION RULES
// ============================================================================
/**
 * GET /api/multi-entity/consolidation-rules
 * Get consolidation rules
 * Query params: parent_entity_id (optional)
 */
router.get('/consolidation-rules', viewerAuth, (0, middleware_1.asyncHandler)(async (req, res) => {
    const parentId = req.query.parent_entity_id;
    const rules = await MultiEntityService_1.multiEntityService.getConsolidationRules(parentId);
    res.json(rules);
}));
/**
 * GET /api/multi-entity/consolidation-rules/:id
 * Get consolidation rule by ID
 */
router.get('/consolidation-rules/:id', viewerAuth, (0, middleware_1.asyncHandler)(async (req, res) => {
    const rule = await MultiEntityService_1.multiEntityService.getConsolidationRuleById(req.params.id);
    res.json(rule);
}));
/**
 * POST /api/multi-entity/consolidation-rules
 * Create a new consolidation rule
 */
router.post('/consolidation-rules', adminAuth, (0, middleware_1.asyncHandler)(async (req, res) => {
    const rule = await MultiEntityService_1.multiEntityService.createConsolidationRule(req.body, req.user?.userId || '');
    res.status(201).json(rule);
}));
/**
 * PUT /api/multi-entity/consolidation-rules/:id
 * Update a consolidation rule
 */
router.put('/consolidation-rules/:id', adminAuth, (0, middleware_1.asyncHandler)(async (req, res) => {
    const rule = await MultiEntityService_1.multiEntityService.updateConsolidationRule(req.params.id, req.body);
    res.json(rule);
}));
/**
 * DELETE /api/multi-entity/consolidation-rules/:id
 * Delete a consolidation rule
 */
router.delete('/consolidation-rules/:id', adminAuth, (0, middleware_1.asyncHandler)(async (req, res) => {
    const deleted = await MultiEntityService_1.multiEntityService.deleteConsolidationRule(req.params.id);
    res.json({ success: deleted });
}));
// ============================================================================
// ENTITY EXCHANGE RATES
// ============================================================================
/**
 * GET /api/multi-entity/entities/:id/exchange-rates
 * Get exchange rates for an entity
 */
router.get('/entities/:id/exchange-rates', viewerAuth, (0, middleware_1.asyncHandler)(async (req, res) => {
    const rates = await MultiEntityService_1.multiEntityService.getEntityExchangeRates(req.params.id);
    res.json(rates);
}));
/**
 * GET /api/multi-entity/entities/:id/exchange-rates/:fromCurrency/:toCurrency
 * Get latest exchange rate for currency pair
 */
router.get('/entities/:id/exchange-rates/:fromCurrency/:toCurrency', viewerAuth, (0, middleware_1.asyncHandler)(async (req, res) => {
    const rate = await MultiEntityService_1.multiEntityService.getLatestExchangeRate(req.params.id, req.params.fromCurrency.toUpperCase(), req.params.toCurrency.toUpperCase());
    res.json(rate);
}));
/**
 * PUT /api/multi-entity/exchange-rates
 * Set exchange rate
 */
router.put('/exchange-rates', adminAuth, (0, middleware_1.asyncHandler)(async (req, res) => {
    const rate = await MultiEntityService_1.multiEntityService.setExchangeRate(req.body, req.user?.userId || '');
    res.json(rate);
}));
// ============================================================================
// CONSOLIDATION
// ============================================================================
/**
 * POST /api/multi-entity/consolidation
 * Generate consolidated financial statements
 * Body: { period: string, parent_entity_id: string }
 */
router.post('/consolidation', viewerAuth, (0, middleware_1.asyncHandler)(async (req, res) => {
    const { period, parent_entity_id } = req.body;
    const financials = await MultiEntityService_1.multiEntityService.generateConsolidatedFinancials(period, parent_entity_id);
    res.json(financials);
}));
// ============================================================================
// AUDIT LOG
// ============================================================================
/**
 * GET /api/multi-entity/entities/:id/audit-log
 * Get audit log for an entity
 * Query params: limit (default: 100)
 */
router.get('/entities/:id/audit-log', adminAuth, (0, middleware_1.asyncHandler)(async (req, res) => {
    const limit = req.query.limit ? parseInt(req.query.limit) : 100;
    const auditLog = await MultiEntityService_1.multiEntityService.getEntityAuditLog(req.params.id, limit);
    res.json(auditLog);
}));
// ============================================================================
// EXPORT ROUTER
// ============================================================================
exports.default = router;
//# sourceMappingURL=multi-entity.js.map