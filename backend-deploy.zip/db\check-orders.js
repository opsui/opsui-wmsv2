"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const client_1 = require("./client");
async function checkOrders() {
    const pool = (0, client_1.getPool)();
    const result = await pool.query(`SELECT order_id, status, picker_id, updated_at
     FROM orders
     WHERE status IN ('PICKED', 'PACKING', 'PACKED', 'SHIPPED')
     LIMIT 10`);
    console.log('Sample orders:', JSON.stringify(result.rows, null, 2));
    await pool.end();
}
checkOrders().catch(console.error);
//# sourceMappingURL=check-orders.js.map