/**
 * Check what tables exist in the database
 */
export {};
//# sourceMappingURL=check-tables.d.ts.map