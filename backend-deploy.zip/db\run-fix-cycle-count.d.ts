/**
 * Quick migration: Fix cycle_count column lengths for user ID references
 * Updates count_type, count_by, created_by, counted_by, and reviewed_by to VARCHAR(50)
 */
export {};
//# sourceMappingURL=run-fix-cycle-count.d.ts.map