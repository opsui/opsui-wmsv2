/**
 * Stock Control Service
 *
 * Business logic for stock control operations including stock counts,
 * transfers, adjustments, and reporting
 */
import { InventoryTransaction, TransactionType, BinLocation } from '@opsui/shared';
export interface StockCount {
    countId: string;
    binLocation: string;
    type: 'FULL' | 'CYCLIC' | 'SPOT';
    status: 'PENDING' | 'IN_PROGRESS' | 'COMPLETED' | 'VERIFIED';
    createdBy: string;
    createdAt: Date;
    completedAt?: Date;
    verifiedBy?: string;
    items?: StockCountItem[];
}
export interface StockCountItem {
    countItemId: string;
    sku: string;
    expectedQuantity: number;
    countedQuantity: number;
    variance: number;
    notes?: string;
}
export interface StockTransfer {
    transferId: string;
    sku: string;
    fromBin: string;
    toBin: string;
    quantity: number;
    reason: string;
    performedBy: string;
    performedAt: Date;
}
export interface StockAdjustment {
    adjustmentId: string;
    sku: string;
    binLocation: string;
    previousQuantity: number;
    newQuantity: number;
    variance: number;
    reason: string;
    performedBy: string;
    performedAt: Date;
}
export interface Discrepancy {
    sku: string;
    binLocation: string;
    systemQuantity: number;
    actualQuantity: number;
    variance: number;
    reason: string;
}
export declare class StockControlService {
    getDashboard(): Promise<{
        totalSKUs: number;
        totalBins: number;
        lowStockItems: number;
        outOfStockItems: number;
        pendingStockCounts: number;
        recentTransactions: InventoryTransaction[];
        totalInventoryValue?: number;
    }>;
    getInventoryList(filters: {
        name?: string;
        sku?: string;
        category?: string;
        binLocation?: string;
        lowStock?: boolean;
        outOfStock?: boolean;
        page: number;
        limit: number;
    }): Promise<{
        items: Array<{
            sku: string;
            name: string;
            category: string;
            binLocation: string;
            quantity: number;
            reserved: number;
            available: number;
        }>;
        total: number;
        page: number;
        pageSize: number;
    }>;
    getSKUInventoryDetail(sku: string): Promise<{
        sku: string;
        name: string;
        description: string;
        category: string;
        barcode?: string;
        totalQuantity: number;
        totalReserved: number;
        totalAvailable: number;
        locations: Array<{
            binLocation: string;
            quantity: number;
            reserved: number;
            available: number;
            lastUpdated: Date;
        }>;
        recentTransactions: InventoryTransaction[];
    }>;
    createStockCount(binLocation: string, type: 'FULL' | 'CYCLIC' | 'SPOT', userId: string): Promise<StockCount>;
    submitStockCount(countId: string, items: Array<{
        sku: string;
        countedQuantity: number;
        notes?: string;
    }>, userId: string): Promise<{
        countId: string;
        status: string;
        discrepancies: Array<{
            sku: string;
            binLocation: string;
            expectedQuantity: number;
            countedQuantity: number;
            variance: number;
        }>;
    }>;
    getStockCounts(filters: {
        status?: string;
        limit: number;
        offset: number;
    }): Promise<{
        counts: StockCount[];
        total: number;
    }>;
    transferStock(sku: string, fromBin: string, toBin: string, quantity: number, reason: string, userId: string): Promise<StockTransfer>;
    adjustInventory(sku: string, binLocation: string, quantity: number, reason: string, userId: string): Promise<StockAdjustment>;
    getTransactionHistory(filters: {
        sku?: string;
        binLocation?: string;
        type?: TransactionType;
        userId?: string;
        startDate?: string;
        endDate?: string;
        limit: number;
        offset: number;
    }): Promise<{
        transactions: InventoryTransaction[];
        total: number;
    }>;
    getLowStockReport(threshold: number): Promise<{
        threshold: number;
        items: Array<{
            sku: string;
            name: string;
            category: string;
            binLocation: string;
            available: number;
            quantity: number;
        }>;
        generatedAt: Date;
    }>;
    getMovementReport(filters: {
        startDate?: string;
        endDate?: string;
        sku?: string;
    }): Promise<{
        movements: Array<{
            sku: string;
            name: string;
            receipts: number;
            deductions: number;
            adjustments: number;
            netChange: number;
        }>;
        period: {
            startDate?: string;
            endDate?: string;
        };
        generatedAt: Date;
    }>;
    reconcileDiscrepancies(discrepancies: Discrepancy[], userId: string): Promise<{
        reconciled: number;
        details: StockAdjustment[];
    }>;
    getBinLocations(filters: {
        zone?: string;
        active?: boolean;
    }): Promise<BinLocation[]>;
    /**
     * Get inventory aging report - items grouped by how long they've been in warehouse
     */
    getInventoryAgingReport(filters?: {
        sku?: string;
        binLocation?: string;
        minDays?: number;
    }): Promise<{
        items: Array<{
            sku: string;
            name: string;
            binLocation: string;
            quantity: number;
            daysInWarehouse: number;
            lastReceivedDate: Date;
            lotNumber?: string;
            expirationDate?: Date;
        }>;
        agingBuckets: Array<{
            range: string;
            itemCount: number;
            totalQuantity: number;
        }>;
    }>;
    /**
     * Get lot tracking information for an SKU
     */
    getLotTracking(sku: string): Promise<{
        lots: Array<{
            lotNumber: string;
            expirationDate?: Date;
            quantity: number;
            available: number;
            binLocations: string[];
            daysUntilExpiration?: number;
            status: 'OK' | 'EXPIRING_SOON' | 'EXPIRED';
        }>;
    }>;
    /**
     * Get expiring inventory report (FEFO - First Expired First Out)
     */
    getExpiringInventory(days?: number): Promise<{
        items: Array<{
            sku: string;
            name: string;
            lotNumber: string;
            expirationDate: Date;
            daysUntilExpiration: number;
            quantity: number;
            available: number;
            binLocation: string;
            urgency: 'CRITICAL' | 'WARNING' | 'INFO';
        }>;
    }>;
    /**
     * Get bin utilization report from location_capacities table
     */
    getBinUtilizationReport(filters?: {
        zone?: string;
        status?: 'OK' | 'WARNING' | 'OVER_CAPACITY';
    }): Promise<{
        bins: Array<{
            binLocation: string;
            zone: string;
            capacityType: 'WEIGHT' | 'VOLUME' | 'QUANTITY';
            maximumCapacity: number;
            currentUtilization: number;
            availableCapacity: number;
            utilizationPercent: number;
            status: 'OK' | 'WARNING' | 'OVER_CAPACITY';
            itemsCount: number;
        }>;
        zoneSummary: Array<{
            zone: string;
            totalBins: number;
            occupiedBins: number;
            averageUtilization: number;
            overCapacityBins: number;
        }>;
    }>;
    /**
     * Get inventory turnover metrics
     */
    getInventoryTurnover(period?: 'month' | 'quarter' | 'year'): Promise<{
        period: string;
        startDate: Date;
        endDate: Date;
        items: Array<{
            sku: string;
            name: string;
            receiptsQuantity: number;
            deductionsQuantity: number;
            averageInventory: number;
            turnoverCount: number;
            turnoverRate: 'HIGH' | 'NORMAL' | 'LOW' | 'STAGNANT';
        }>;
    }>;
}
export declare const stockControlService: StockControlService;
//# sourceMappingURL=StockControlService.d.ts.map