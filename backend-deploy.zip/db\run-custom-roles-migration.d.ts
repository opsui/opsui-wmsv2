/**
 * Run the custom roles migration
 *
 * Creates tables for custom roles and permissions system
 */
export {};
//# sourceMappingURL=run-custom-roles-migration.d.ts.map