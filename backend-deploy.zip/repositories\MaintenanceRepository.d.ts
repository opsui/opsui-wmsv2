/**
 * Maintenance & Assets Repository
 *
 * Data access layer for equipment maintenance and asset tracking
 */
import { Asset, MaintenanceSchedule, MaintenanceWorkOrder, ServiceLog, MeterReading, AssetStatus, MaintenanceStatus } from '@opsui/shared';
export declare class MaintenanceRepository {
    createAsset(asset: Omit<Asset, 'assetId' | 'assetNumber' | 'createdAt' | 'updatedAt'>): Promise<Asset>;
    findAssetById(assetId: string): Promise<Asset | null>;
    findAllAssets(filters?: {
        status?: AssetStatus;
        type?: string;
        limit?: number;
        offset?: number;
    }): Promise<{
        assets: Asset[];
        total: number;
    }>;
    updateAsset(assetId: string, updates: Partial<Asset>): Promise<Asset | null>;
    createSchedule(schedule: Omit<MaintenanceSchedule, 'scheduleId' | 'createdAt' | 'updatedAt' | 'lastPerformedDate'>): Promise<MaintenanceSchedule>;
    findSchedulesByAsset(assetId: string): Promise<MaintenanceSchedule[]>;
    findDueSchedules(daysAhead?: number): Promise<MaintenanceSchedule[]>;
    createWorkOrder(workOrder: Omit<MaintenanceWorkOrder, 'workOrderId' | 'workOrderNumber' | 'createdAt' | 'updatedAt' | 'actualStartDate' | 'actualEndDate' | 'completedAt' | 'completedBy'>): Promise<MaintenanceWorkOrder>;
    findWorkOrderById(workOrderId: string): Promise<MaintenanceWorkOrder | null>;
    findAllWorkOrders(filters?: {
        status?: MaintenanceStatus;
        assignedTo?: string;
        limit?: number;
        offset?: number;
    }): Promise<{
        workOrders: MaintenanceWorkOrder[];
        total: number;
    }>;
    completeWorkOrder(workOrderId: string, completionData: {
        workPerformed: string;
        partsUsed?: any[];
        actualDurationHours?: number;
        laborCost?: number;
        partsCost?: number;
        notes?: string;
        completedBy: string;
    }): Promise<MaintenanceWorkOrder | null>;
    updateWorkOrder(workOrderId: string, updates: Partial<MaintenanceWorkOrder>): Promise<MaintenanceWorkOrder | null>;
    createServiceLog(log: Omit<ServiceLog, 'logId' | 'createdAt'>): Promise<ServiceLog>;
    findServiceLogsByAsset(assetId: string, limit?: number): Promise<ServiceLog[]>;
    addMeterReading(reading: Omit<MeterReading, 'readingId'>): Promise<MeterReading>;
    findMeterReadingsByAsset(assetId: string, limit?: number): Promise<MeterReading[]>;
    private mapRowToAsset;
    private mapRowToSchedule;
    private mapRowToWorkOrder;
}
export declare const maintenanceRepository: MaintenanceRepository;
//# sourceMappingURL=MaintenanceRepository.d.ts.map