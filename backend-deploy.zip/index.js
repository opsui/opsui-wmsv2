"use strict";
/**
 * WMS Backend - Server Entry Point
 *
 * Warehouse Management System API Server
 * Production-ready with proper error handling, logging, and database transactions
 * Port-locked to prevent duplicate instances
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.isShuttingDown = void 0;
require("dotenv/config");
// OpenTelemetry must be initialized FIRST, before any other imports
if (process.env.ENABLE_OPENTELEMETRY !== 'false') {
    // Initialize OpenTelemetry SDK for distributed tracing, metrics, and logging
    // This must happen before any other imports to ensure proper instrumentation
    Promise.resolve().then(() => __importStar(require('./observability/telemetry'))).then(({ initializeTelemetry }) => {
        initializeTelemetry();
    })
        .catch(err => {
        console.error('Failed to initialize OpenTelemetry:', err);
    });
}
const app_1 = require("./app");
const config_1 = __importDefault(require("./config"));
const logger_1 = require("./config/logger");
const client_1 = require("./db/client");
const portLock_1 = require("./utils/portLock");
const gracefulShutdown_1 = require("./utils/gracefulShutdown");
const websocket_1 = __importDefault(require("./websocket"));
const RecurringScheduleService_1 = require("./services/RecurringScheduleService");
const TokenBlacklistService_1 = require("./services/TokenBlacklistService");
// Export shutdown check for health endpoints
exports.isShuttingDown = gracefulShutdown_1.isShuttingDown;
// ============================================================================
// PORT LOCKING - Prevent Duplicate Instances
// ============================================================================
const BACKEND_PORT = portLock_1.SERVICE_PORTS.BACKEND_API; // Always 3001
async function acquireServerPort() {
    logger_1.logger.info('Acquiring port lock...', { port: BACKEND_PORT });
    const result = await (0, portLock_1.acquirePortLock)(BACKEND_PORT, 'wms-backend-api', config_1.default.host);
    if (!result.acquired) {
        logger_1.logger.error('Failed to acquire port lock - another instance may be running', {
            port: BACKEND_PORT,
            reason: result.reason,
        });
        console.error('\n' + '='.repeat(70));
        console.error('❌ PORT LOCK FAILED');
        console.error('='.repeat(70));
        console.error(`Port ${BACKEND_PORT} is already in use.`);
        console.error('\nPossible causes:');
        console.error('  1. Another backend instance is already running');
        console.error('  2. A different process is using this port');
        console.error('  3. A previous instance crashed without cleaning up');
        console.error('\nSolutions:');
        console.error('  1. Check running processes: netstat -ano | findstr :3001');
        console.error('  2. Kill the existing process');
        console.error('  3. Or wait a moment and try again');
        console.error('  4. Check port locks: type .port-locks\\port-3001.lock');
        console.error('='.repeat(70) + '\n');
        return false;
    }
    logger_1.logger.info('Port lock acquired successfully', { port: BACKEND_PORT });
    return true;
}
// ============================================================================
// START SERVER
// ============================================================================
async function main() {
    try {
        // 1. Acquire port lock FIRST (before anything else)
        const portAcquired = await acquireServerPort();
        if (!portAcquired) {
            process.exit(1);
        }
        // 2. Setup cleanup for port lock on exit
        (0, portLock_1.setupPortLockCleanup)(BACKEND_PORT);
        // 3. Create Express app
        const app = (0, app_1.createApp)();
        // 4. Initialize services
        await (0, app_1.startServer)();
        // 5. Start HTTP server with keep-alive settings
        const server = app.listen(config_1.default.port, config_1.default.host, () => {
            logger_1.logger.info(`Server listening on ${config_1.default.host}:${config_1.default.port}`);
            logger_1.logger.info(`Environment: ${config_1.default.nodeEnv}`);
            logger_1.logger.info(`Port Lock: ACTIVE (PID ${process.pid})`);
            logger_1.logger.info(`API Documentation: http://${config_1.default.host}:${config_1.default.port}/`);
            logger_1.logger.info(`Health Check: http://${config_1.default.host}:${config_1.default.port}/health`);
        });
        // Keep-alive settings to prevent connection drops
        server.keepAliveTimeout = 65000; // 65 seconds (higher than AWS ALB defaults)
        server.headersTimeout = 66000; // Slightly higher than keep-alive timeout
        // 6. Initialize WebSocket server with HTTP server
        websocket_1.default.initialize(server);
        logger_1.logger.info('WebSocket server initialized');
        // 6.5. Initialize token blacklist service
        TokenBlacklistService_1.tokenBlacklistService.initialize();
        logger_1.logger.info('Token blacklist service initialized');
        // 7. Setup cron job for recurring count schedules
        // Run every hour to check for due schedules and generate cycle counts
        const RECURRING_SCHEDULE_INTERVAL = 60 * 60 * 1000; // 1 hour
        const scheduleInterval = setInterval(async () => {
            try {
                await RecurringScheduleService_1.recurringScheduleService.processDueSchedules();
            }
            catch (error) {
                logger_1.logger.error('Error processing recurring schedules', {
                    error: error instanceof Error ? error.message : String(error),
                    stack: error instanceof Error ? error.stack : undefined,
                });
            }
        }, RECURRING_SCHEDULE_INTERVAL);
        logger_1.logger.info('Recurring schedule processor initialized (runs every hour)');
        // --------------------------------------------------------------------------
        // COMPREHENSIVE GRACEFUL SHUTDOWN
        // --------------------------------------------------------------------------
        // Define cleanup tasks
        const cleanupTasks = [
            // 0. Clear recurring schedule interval
            async () => {
                clearInterval(scheduleInterval);
                logger_1.logger.info('✅ Recurring schedule interval cleared');
            },
            // 1. Wait for active HTTP connections to drain
            async () => {
                logger_1.logger.info('Waiting for active connections to drain...');
                const drained = await (0, app_1.waitForDrain)(30000);
                if (drained) {
                    logger_1.logger.info('✅ All connections drained gracefully');
                }
                else {
                    logger_1.logger.warn('⚠️ Connection drain timeout - proceeding with shutdown');
                }
            },
            // 2. Close WebSocket connections
            async () => {
                const wsCount = websocket_1.default.getConnectedCount();
                if (wsCount > 0) {
                    logger_1.logger.info(`Closing ${wsCount} WebSocket connections...`);
                }
                websocket_1.default.close();
                logger_1.logger.info('✅ WebSocket server closed');
            },
            // 2.5. Shutdown token blacklist service
            async () => {
                TokenBlacklistService_1.tokenBlacklistService.shutdown();
                logger_1.logger.info('✅ Token blacklist service shutdown');
            },
            // 3. Close database connections
            async () => {
                await (0, client_1.closePool)();
                logger_1.logger.info('✅ Database connections closed');
            },
            // 4. Flush any pending operations
            async () => {
                await new Promise(resolve => setTimeout(resolve, 100));
                logger_1.logger.info('✅ Pending operations flushed');
            },
        ];
        // Setup graceful shutdown handlers
        (0, gracefulShutdown_1.setupGracefulShutdown)({
            server,
            port: BACKEND_PORT,
            logger: logger_1.logger,
            cleanupTasks,
            forceTimeout: 30000, // 30 second force timeout
        });
    }
    catch (error) {
        logger_1.logger.error('Failed to start server', {
            error: error instanceof Error ? error.message : String(error),
            stack: error instanceof Error ? error.stack : undefined,
        });
        await (0, client_1.closePool)();
        process.exit(1);
    }
}
// --------------------------------------------------------------------------
// UNHANDLED ERRORS - PREVENT CRASHES
// --------------------------------------------------------------------------
// Handle unhandled promise rejections without crashing
process.on('unhandledRejection', (reason, promise) => {
    logger_1.logger.error('Unhandled Rejection (caught, preventing crash)', {
        reason: reason instanceof Error ? reason.message : String(reason),
        stack: reason instanceof Error ? reason.stack : undefined,
        promise: String(promise),
    });
    // Don't exit - just log and continue
});
// Handle uncaught exceptions but try to recover
process.on('uncaughtException', error => {
    if ((0, gracefulShutdown_1.isShuttingDown)()) {
        return;
    }
    logger_1.logger.error('Uncaught Exception (caught, preventing crash)', {
        error: error.message,
        stack: error.stack,
    });
    // Don't exit immediately - give the server a chance to continue
    // Only exit on fatal errors
    if (error.message.includes('EADDRINUSE')) {
        logger_1.logger.error('Port already in use - exiting');
        setTimeout(() => {
            process.exit(1);
        }, 1000);
    }
    // For other errors, log but don't crash
});
// Start the server
main();
//# sourceMappingURL=index.js.map