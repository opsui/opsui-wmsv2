/**
 * Interleaved Count routes
 *
 * Endpoints for micro-counts performed during picking and other operations
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=interleavedCount.d.ts.map