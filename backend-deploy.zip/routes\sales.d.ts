/**
 * Sales & CRM Routes
 *
 * API endpoints for customers, leads, opportunities, and quotes
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=sales.d.ts.map