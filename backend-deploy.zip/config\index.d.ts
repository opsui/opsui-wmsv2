/**
 * Configuration module
 *
 * Centralizes all configuration values from environment variables
 */
declare const _default: {
    port: number;
    host: string;
    nodeEnv: string;
    database: {
        host: string;
        port: number;
        name: string;
        user: string;
        password: string;
        ssl: boolean;
        poolMin: number;
        poolMax: number;
    };
    redis: {
        host: string;
        port: number;
        password: string;
        db: number;
        ttl: number;
        enabled: boolean;
    };
    jwt: {
        readonly secret: string;
        readonly expiresIn: string;
        readonly refreshExpiresIn: string;
    };
    bcrypt: {
        rounds: number;
    };
    rateLimit: {
        windowMs: number;
        maxRequests: number;
    };
    cors: {
        origin: string[];
    };
    app: {
        defaultPickerCapacity: number;
        maxOrdersPerPicker: number;
        pickTimeoutMinutes: number;
    };
    websocket: {
        enabled: boolean;
        port: number;
    };
    health: {
        checkInterval: number;
    };
    features: {
        websocket: boolean;
        redisCache: boolean;
        auditLog: boolean;
        openTelemetry: boolean;
        prometheus: boolean;
    };
    testMode: boolean;
    otel: {
        serviceName: string;
        collectorUrl: string;
        enabled: boolean;
    };
    prometheus: {
        enabled: boolean;
        port: number;
        path: string;
    };
    nzc: {
        baseUrl: string;
        apiKey: string;
        siteId: string;
        supportEmail: string;
    };
    email: {
        sendgrid: {
            apiKey: string;
            from: string | undefined;
            replyTo: string | undefined;
        };
        postmark: {
            apiKey: string;
            from: string | undefined;
            replyTo: string | undefined;
        };
        ses: {
            region: string;
            accessKeyId: string;
            secretAccessKey: string;
            from: string | undefined;
        };
    };
    sms: {
        accountSid: string;
        authToken: string;
        from: string | undefined;
        rateLimitPerSecond: number;
    };
    push: {
        vapidPublicKey: string;
        vapidPrivateKey: string;
        vapidSubject: string;
    };
    isProduction(): boolean;
    isDevelopment(): boolean;
    isTest(): boolean;
};
export default _default;
//# sourceMappingURL=index.d.ts.map