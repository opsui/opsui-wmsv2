"use strict";
/**
 * Zone Picking Routes
 *
 * API endpoints for zone-based picking operations
 */
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const auth_1 = require("../middleware/auth");
const auth_2 = require("../middleware/auth");
const ZonePickingService_1 = require("../services/ZonePickingService");
const logger_1 = require("../config/logger");
const shared_1 = require("@opsui/shared");
const router = (0, express_1.Router)();
/**
 * GET /api/v1/zones
 * Get all zones in the warehouse
 */
router.get('/', auth_1.authenticate, async (_req, res) => {
    try {
        const zones = await ZonePickingService_1.zonePickingService.getZones();
        res.json({
            success: true,
            data: zones,
        });
    }
    catch (error) {
        logger_1.logger.error('Get zones error', { error });
        res.status(500).json({
            error: 'Failed to get zones',
            message: error.message,
        });
    }
});
/**
 * GET /api/v1/zones/:zoneId/stats
 * Get statistics for a specific zone
 */
router.get('/:zoneId/stats', auth_1.authenticate, async (req, res) => {
    try {
        const { zoneId } = req.params;
        const stats = await ZonePickingService_1.zonePickingService.getZoneStats(zoneId);
        if (!stats) {
            res.status(404).json({
                error: 'Zone not found',
                message: `Zone ${zoneId} not found`,
            });
            return;
        }
        res.json({
            success: true,
            data: stats,
        });
    }
    catch (error) {
        logger_1.logger.error('Get zone stats error', { error });
        res.status(500).json({
            error: 'Failed to get zone stats',
            message: error.message,
        });
    }
});
/**
 * GET /api/v1/zones/stats/all
 * Get statistics for all zones
 */
router.get('/stats/all', auth_1.authenticate, async (_req, res) => {
    try {
        const stats = await ZonePickingService_1.zonePickingService.getAllZoneStats();
        res.json({
            success: true,
            data: stats,
        });
    }
    catch (error) {
        logger_1.logger.error('Get all zone stats error', { error });
        res.status(500).json({
            error: 'Failed to get zone stats',
            message: error.message,
        });
    }
});
/**
 * POST /api/v1/zones/assign
 * Assign a picker to a zone
 */
router.post('/assign', auth_1.authenticate, (0, auth_2.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR), async (req, res) => {
    try {
        const { pickerId, zoneId } = req.body;
        if (!pickerId || !zoneId) {
            res.status(400).json({
                error: 'Missing required fields',
                message: 'pickerId and zoneId are required',
            });
            return;
        }
        const context = {
            userId: req.user?.userId,
            userEmail: req.user?.email,
            userRole: req.user?.role,
            ipAddress: req.ip,
            userAgent: req.get('user-agent'),
            requestId: req.id,
        };
        const assignment = await ZonePickingService_1.zonePickingService.assignPickerToZone(pickerId, zoneId, context);
        res.status(201).json({
            success: true,
            message: 'Picker assigned to zone',
            data: assignment,
        });
    }
    catch (error) {
        logger_1.logger.error('Zone assignment error', { error });
        res.status(500).json({
            error: 'Zone assignment failed',
            message: error.message,
        });
    }
});
/**
 * POST /api/v1/zones/release
 * Release picker from current zone
 */
router.post('/release', auth_1.authenticate, auth_1.requirePicker, async (req, res) => {
    try {
        const { pickerId } = req.body;
        if (!pickerId) {
            // Use current user if not specified
            req.body.pickerId = req.user?.userId;
        }
        const context = {
            userId: req.user?.userId,
            userEmail: req.user?.email,
            userRole: req.user?.role,
            ipAddress: req.ip,
            userAgent: req.get('user-agent'),
            requestId: req.id,
        };
        await ZonePickingService_1.zonePickingService.releasePickerFromZone(req.body.pickerId, context);
        res.json({
            success: true,
            message: 'Picker released from zone',
        });
    }
    catch (error) {
        logger_1.logger.error('Zone release error', { error });
        res.status(500).json({
            error: 'Zone release failed',
            message: error.message,
        });
    }
});
/**
 * POST /api/v1/zones/rebalance
 * Rebalance pickers across zones based on workload
 */
router.post('/rebalance', auth_1.authenticate, (0, auth_2.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR), async (req, res) => {
    try {
        const context = {
            userId: req.user?.userId,
            userEmail: req.user?.email,
            userRole: req.user?.role,
            ipAddress: req.ip,
            userAgent: req.get('user-agent'),
            requestId: req.id,
        };
        await ZonePickingService_1.zonePickingService.rebalancePickers(context);
        res.json({
            success: true,
            message: 'Pickers rebalanced across zones',
        });
    }
    catch (error) {
        logger_1.logger.error('Zone rebalance error', { error });
        res.status(500).json({
            error: 'Zone rebalancing failed',
            message: error.message,
        });
    }
});
/**
 * GET /api/v1/zones/:zoneId/tasks
 * Get pick tasks for a specific zone
 */
router.get('/:zoneId/tasks', auth_1.authenticate, auth_1.requirePicker, async (req, res) => {
    try {
        const { zoneId } = req.params;
        const { status } = req.query;
        const statuses = status ? status.split(',') : undefined;
        const tasks = await ZonePickingService_1.zonePickingService.getZonePickTasks(zoneId, statuses);
        res.json({
            success: true,
            data: tasks,
        });
    }
    catch (error) {
        logger_1.logger.error('Get zone tasks error', { error });
        res.status(500).json({
            error: 'Failed to get zone tasks',
            message: error.message,
        });
    }
});
exports.default = router;
//# sourceMappingURL=zones.js.map