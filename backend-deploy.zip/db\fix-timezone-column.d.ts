/**
 * Fix timezone issue in current_view_updated_at column
 *
 * The column was created as TIMESTAMP WITHOUT TIME ZONE, which causes
 * issues with timezone conversion. This script converts it to
 * TIMESTAMP WITH TIME ZONE.
 */
export {};
//# sourceMappingURL=fix-timezone-column.d.ts.map