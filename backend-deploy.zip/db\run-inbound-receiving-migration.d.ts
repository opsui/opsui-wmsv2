/**
 * Run the inbound receiving migration
 */
export {};
//# sourceMappingURL=run-inbound-receiving-migration.d.ts.map