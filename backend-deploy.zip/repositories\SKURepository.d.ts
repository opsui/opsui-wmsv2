/**
 * SKU repository
 *
 * Handles all database operations for SKU catalog
 */
import { BaseRepository } from './BaseRepository';
import { SKU } from '@opsui/shared';
export declare class SKURepository extends BaseRepository<SKU> {
    constructor();
    findByCategory(category: string, activeOnly?: boolean): Promise<SKU[]>;
    getAllSKUs(activeOnly?: boolean, limit?: number): Promise<SKU[]>;
    search(searchTerm: string, activeOnly?: boolean): Promise<SKU[]>;
    getCategories(): Promise<string[]>;
    createSKU(data: {
        sku: string;
        name: string;
        description: string;
        image?: string;
        category: string;
        binLocations: string[];
    }): Promise<SKU>;
    updateSKU(sku: string, data: {
        name?: string;
        description?: string;
        image?: string;
        category?: string;
        binLocations?: string[];
        active?: boolean;
    }): Promise<SKU>;
    deactivateSKU(sku: string): Promise<SKU>;
    activateSKU(sku: string): Promise<SKU>;
    getSKUWithInventory(sku: string): Promise<SKU & {
        inventory: Array<{
            binLocation: string;
            quantity: number;
            available: number;
        }>;
    }>;
}
export declare const skuRepository: SKURepository;
//# sourceMappingURL=SKURepository.d.ts.map