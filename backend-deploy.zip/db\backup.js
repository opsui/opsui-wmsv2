"use strict";
/**
 * Database Backup Utility
 *
 * Creates JSON backups of database data
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.createBackup = createBackup;
exports.restoreBackup = restoreBackup;
exports.listBackups = listBackups;
exports.backupCli = main;
const client_1 = require("./client");
const logger_1 = require("../config/logger");
const fs_1 = require("fs");
const path_1 = require("path");
const url_1 = require("url");
/**
 * Create a backup of all database data
 */
async function createBackup(backupName) {
    try {
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        const backupId = backupName || `backup-${timestamp}`;
        logger_1.logger.info('Creating database backup...', { backupId });
        const tables = [
            'users',
            'skus',
            'bin_locations',
            'inventory_units',
            'orders',
            'order_items',
            'pick_tasks',
            'inventory_transactions',
            'order_state_changes',
        ];
        const backupData = {
            timestamp: new Date().toISOString(),
            version: '1.0.0',
            tables: {},
        };
        // Dump each table
        for (const table of tables) {
            try {
                const result = await (0, client_1.query)(`SELECT * FROM ${table}`);
                backupData.tables[table] = result.rows;
                logger_1.logger.info(`Backed up ${table}: ${result.rowCount} rows`);
            }
            catch (error) {
                logger_1.logger.warn(`Failed to backup ${table}`, {
                    error: error instanceof Error ? error.message : String(error),
                });
                // Continue with other tables
            }
        }
        // Ensure backup directory exists
        const backupDir = (0, path_1.join)(process.cwd(), 'backups');
        if (!(0, fs_1.existsSync)(backupDir)) {
            (0, fs_1.mkdirSync)(backupDir, { recursive: true });
        }
        // Write backup file
        const backupPath = (0, path_1.join)(backupDir, `${backupId}.json`);
        (0, fs_1.writeFileSync)(backupPath, JSON.stringify(backupData, null, 2), 'utf-8');
        const fileSize = Buffer.byteLength(JSON.stringify(backupData), 'utf-8');
        logger_1.logger.info('Backup created successfully', {
            backupId,
            path: backupPath,
            size: `${(fileSize / 1024).toFixed(2)} KB`,
        });
        return backupPath;
    }
    catch (error) {
        logger_1.logger.error('Backup failed', {
            error: error instanceof Error ? error.message : String(error),
        });
        throw error;
    }
}
/**
 * Restore database from a backup file
 */
async function restoreBackup(backupPath) {
    try {
        logger_1.logger.info('Restoring database from backup...', { backupPath });
        // Read backup file
        const backupContent = (0, fs_1.readFileSync)(backupPath, 'utf-8');
        const backupData = JSON.parse(backupContent);
        logger_1.logger.info('Backup info', {
            timestamp: backupData.timestamp,
            version: backupData.version,
            tables: Object.keys(backupData.tables),
        });
        // Begin transaction
        await (0, client_1.query)('BEGIN');
        // Clear existing data
        await (0, client_1.query)(`
      TRUNCATE TABLE
        order_state_changes CASCADE,
        inventory_transactions CASCADE,
        pick_tasks CASCADE,
        order_items CASCADE,
        orders CASCADE,
        inventory_units CASCADE,
        bin_locations CASCADE,
        skus CASCADE,
        users CASCADE
    `);
        // Restore each table
        for (const [table, rows] of Object.entries(backupData.tables)) {
            if (rows.length === 0)
                continue;
            const columns = Object.keys(rows[0]);
            const placeholders = columns.map((_, i) => `$${i + 1}`).join(', ');
            const columnsStr = columns.join(', ');
            for (const row of rows) {
                const values = columns.map(col => row[col]);
                await (0, client_1.query)(`INSERT INTO ${table} (${columnsStr}) VALUES (${placeholders})`, values);
            }
            logger_1.logger.info(`Restored ${table}: ${rows.length} rows`);
        }
        // Commit transaction
        await (0, client_1.query)('COMMIT');
        logger_1.logger.info('Database restored successfully');
    }
    catch (error) {
        await (0, client_1.query)('ROLLBACK');
        logger_1.logger.error('Restore failed', {
            error: error instanceof Error ? error.message : String(error),
        });
        throw error;
    }
}
/**
 * List all available backups
 */
async function listBackups() {
    const backupDir = (0, path_1.join)(process.cwd(), 'backups');
    if (!(0, fs_1.existsSync)(backupDir)) {
        return [];
    }
    const files = (0, fs_1.readdirSync)(backupDir)
        .filter((f) => f.endsWith('.json'))
        .sort()
        .reverse();
    return files.map((f) => (0, path_1.join)(backupDir, f));
}
// CLI Entry Point
async function main() {
    const command = process.argv[2] || 'create';
    const arg = process.argv[3];
    try {
        switch (command) {
            case 'create':
                const backupPath = await createBackup(arg);
                console.log(`✅ Backup created: ${backupPath}`);
                break;
            case 'restore':
                if (!arg) {
                    console.error('Usage: tsx src/db/backup.ts restore <backup-file>');
                    process.exit(1);
                }
                await restoreBackup(arg);
                console.log('✅ Database restored');
                break;
            case 'list':
                const backups = await listBackups();
                if (backups.length === 0) {
                    console.log('No backups found');
                }
                else {
                    console.log('\n📋 Available backups:\n');
                    backups.forEach((backup, i) => {
                        const stats = (0, fs_1.statSync)(backup);
                        const size = (stats.size / 1024).toFixed(2);
                        const fileName = backup.split('\\').pop()?.split('/').pop() || backup;
                        console.log(`  ${i + 1}. ${fileName} (${size} KB)`);
                    });
                }
                break;
            default:
                console.error('Unknown command:', command);
                console.error('Usage: tsx src/db/backup.ts <create|restore|list> [arg]');
                process.exit(1);
        }
        await (0, client_1.closePool)();
        process.exit(0);
    }
    catch (error) {
        console.error('❌ Error:', error instanceof Error ? error.message : String(error));
        await (0, client_1.closePool)();
        process.exit(1);
    }
}
// Check if this file is being run directly
const modulePath = (0, url_1.fileURLToPath)(import.meta.url);
if (process.argv[1] === modulePath) {
    main();
}
//# sourceMappingURL=backup.js.map