"use strict";
/**
 * Organization Service
 *
 * Business logic for multi-tenant organization management.
 * Handles organization CRUD, memberships, invitations, and access control.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.organizationService = void 0;
const shared_1 = require("@opsui/shared");
const logger_1 = require("../config/logger");
const OrganizationRepository_1 = require("../repositories/OrganizationRepository");
const UserRepository_1 = require("../repositories/UserRepository");
// ============================================================================
// ORGANIZATION SERVICE
// ============================================================================
class OrganizationService {
    userRepository;
    constructor() {
        this.userRepository = new UserRepository_1.UserRepository();
    }
    // --------------------------------------------------------------------------
    // ORGANIZATION CRUD
    // --------------------------------------------------------------------------
    /**
     * Create a new organization
     * The creator becomes the ORG_OWNER
     */
    async createOrganization(data) {
        // Validate owner exists
        const owner = await this.userRepository.findById(data.ownerId);
        if (!owner) {
            throw new shared_1.NotFoundError('User', data.ownerId);
        }
        // Check if slug is available (if provided)
        if (data.slug) {
            const existing = await OrganizationRepository_1.organizationRepository.findBySlug(data.slug);
            if (existing) {
                throw new shared_1.ConflictError(`Organization with slug '${data.slug}' already exists`);
            }
        }
        // Create organization
        const organization = await OrganizationRepository_1.organizationRepository.createOrganization(data);
        logger_1.logger.info('Organization created', {
            organizationId: organization.organizationId,
            name: organization.organizationName,
            ownerId: data.ownerId,
        });
        return organization;
    }
    /**
     * Get organization by ID
     */
    async getOrganization(organizationId) {
        const organization = await OrganizationRepository_1.organizationRepository.findByIdWithStats(organizationId);
        if (!organization) {
            throw new shared_1.NotFoundError('Organization', organizationId);
        }
        return organization;
    }
    /**
     * Get organization by slug
     */
    async getOrganizationBySlug(slug) {
        const organization = await OrganizationRepository_1.organizationRepository.findBySlug(slug);
        if (!organization) {
            throw new shared_1.NotFoundError('Organization', `slug: ${slug}`);
        }
        return this.getOrganization(organization.organizationId);
    }
    /**
     * List organizations with filters
     */
    async listOrganizations(filters, page = 1, pageSize = 20) {
        const { organizations, total } = await OrganizationRepository_1.organizationRepository.findAllWithFilters(filters, page, pageSize);
        return {
            organizations,
            total,
            page,
            pageSize,
        };
    }
    /**
     * Update organization
     */
    async updateOrganization(organizationId, data, userId) {
        // Check user has permission
        await this.checkPermission(organizationId, userId, 'can_manage_settings');
        const organization = await OrganizationRepository_1.organizationRepository.updateOrganization(organizationId, data, userId);
        if (!organization) {
            throw new shared_1.NotFoundError('Organization', organizationId);
        }
        logger_1.logger.info('Organization updated', {
            organizationId,
            userId,
            changes: Object.keys(data),
        });
        return organization;
    }
    /**
     * Update organization status
     */
    async updateStatus(organizationId, status, userId) {
        // Only system admins or ORG_OWNER can change status
        const membership = await OrganizationRepository_1.organizationUserRepository.findByOrganizationAndUser(organizationId, userId);
        if (!membership || membership.role !== 'ORG_OWNER') {
            throw new shared_1.ForbiddenError('Only organization owners can change status');
        }
        const organization = await OrganizationRepository_1.organizationRepository.updateStatus(organizationId, status, userId);
        if (!organization) {
            throw new shared_1.NotFoundError('Organization', organizationId);
        }
        logger_1.logger.info('Organization status changed', {
            organizationId,
            status,
            userId,
        });
        return organization;
    }
    /**
     * Update organization tier
     */
    async updateTier(organizationId, tier, userId) {
        // Only system admins can change tier (for billing)
        const membership = await OrganizationRepository_1.organizationUserRepository.findByOrganizationAndUser(organizationId, userId);
        if (!membership || (membership.role !== 'ORG_OWNER' && !membership.canManageBilling)) {
            throw new shared_1.ForbiddenError('Only organization owners or billing managers can change tier');
        }
        const organization = await OrganizationRepository_1.organizationRepository.updateTier(organizationId, tier, userId);
        if (!organization) {
            throw new shared_1.NotFoundError('Organization', organizationId);
        }
        logger_1.logger.info('Organization tier changed', {
            organizationId,
            tier,
            userId,
        });
        return organization;
    }
    // --------------------------------------------------------------------------
    // USER'S ORGANIZATIONS
    // --------------------------------------------------------------------------
    /**
     * Get user's organizations
     */
    async getUserOrganizations(userId) {
        const memberships = await OrganizationRepository_1.organizationUserRepository.findUserOrganizations(userId);
        return {
            organizations: memberships.map(m => ({
                organizationId: m.organizationId,
                organizationName: m.organization.organizationName,
                slug: m.organization.slug,
                role: m.role,
                isPrimary: m.isPrimary,
                logoUrl: m.organization.logoUrl,
            })),
            total: memberships.length,
        };
    }
    /**
     * Set user's primary organization
     */
    async setPrimaryOrganization(userId, organizationId) {
        // Verify user is member of organization
        const membership = await OrganizationRepository_1.organizationUserRepository.findByOrganizationAndUser(organizationId, userId);
        if (!membership || !membership.isActive) {
            throw new shared_1.ForbiddenError('User is not a member of this organization');
        }
        await OrganizationRepository_1.organizationUserRepository.setPrimaryOrganization(userId, organizationId);
        logger_1.logger.info('Primary organization set', { userId, organizationId });
    }
    // --------------------------------------------------------------------------
    // MEMBERSHIP MANAGEMENT
    // --------------------------------------------------------------------------
    /**
     * Get organization members
     */
    async getMembers(organizationId, userId, filters = {}, page = 1, pageSize = 50) {
        // Check user has access
        await this.checkAccess(organizationId, userId);
        return OrganizationRepository_1.organizationUserRepository.findOrganizationMembers(organizationId, filters, page, pageSize);
    }
    /**
     * Add user to organization
     */
    async addMember(organizationId, data, addedBy) {
        // Check permission
        await this.checkPermission(organizationId, addedBy, 'can_manage_users');
        // Check user limit
        const memberCount = await OrganizationRepository_1.organizationUserRepository.getMemberCount(organizationId);
        const org = await OrganizationRepository_1.organizationRepository.findById(organizationId);
        if (org && org.maxUsers > 0 && memberCount >= org.maxUsers) {
            throw new shared_1.ValidationError(`Organization has reached maximum member limit (${org.maxUsers})`);
        }
        // Verify user exists
        const user = await this.userRepository.findById(data.userId);
        if (!user) {
            throw new shared_1.NotFoundError('User', data.userId);
        }
        const membership = await OrganizationRepository_1.organizationUserRepository.assignUser({
            ...data,
            organizationId,
        });
        logger_1.logger.info('Member added to organization', {
            organizationId,
            userId: data.userId,
            role: data.role,
            addedBy,
        });
        return membership;
    }
    /**
     * Update member role/permissions
     */
    async updateMember(organizationId, targetUserId, data, updatedBy) {
        // Check permission
        await this.checkPermission(organizationId, updatedBy, 'can_manage_users');
        // Cannot modify ORG_OWNER role unless you're ORG_OWNER
        const targetMembership = await OrganizationRepository_1.organizationUserRepository.findByOrganizationAndUser(organizationId, targetUserId);
        if (targetMembership?.role === 'ORG_OWNER' && data.role && data.role !== 'ORG_OWNER') {
            const updaterMembership = await OrganizationRepository_1.organizationUserRepository.findByOrganizationAndUser(organizationId, updatedBy);
            if (updaterMembership?.role !== 'ORG_OWNER') {
                throw new shared_1.ForbiddenError('Only organization owners can modify owner role');
            }
        }
        const membership = await OrganizationRepository_1.organizationUserRepository.updateUserMembership(organizationId, targetUserId, data);
        if (!membership) {
            throw new shared_1.NotFoundError('Organization membership', `${organizationId}/${targetUserId}`);
        }
        logger_1.logger.info('Member updated', {
            organizationId,
            targetUserId,
            updatedBy,
            changes: Object.keys(data),
        });
        return membership;
    }
    /**
     * Remove member from organization
     */
    async removeMember(organizationId, targetUserId, removedBy) {
        // Check permission
        await this.checkPermission(organizationId, removedBy, 'can_manage_users');
        // Cannot remove ORG_OWNER
        const targetMembership = await OrganizationRepository_1.organizationUserRepository.findByOrganizationAndUser(organizationId, targetUserId);
        if (targetMembership?.role === 'ORG_OWNER') {
            throw new shared_1.ForbiddenError('Cannot remove organization owner');
        }
        const removed = await OrganizationRepository_1.organizationUserRepository.removeUser(organizationId, targetUserId);
        if (!removed) {
            throw new shared_1.NotFoundError('Organization membership', `${organizationId}/${targetUserId}`);
        }
        logger_1.logger.info('Member removed from organization', {
            organizationId,
            targetUserId,
            removedBy,
        });
    }
    // --------------------------------------------------------------------------
    // INVITATIONS
    // --------------------------------------------------------------------------
    /**
     * Invite user to organization
     */
    async inviteUser(organizationId, data, invitedBy) {
        // Check permission
        await this.checkPermission(organizationId, invitedBy, 'can_invite_users');
        // Check if user is already a member
        const existingUser = await this.userRepository.findByEmail(data.email);
        if (existingUser) {
            const existingMembership = await OrganizationRepository_1.organizationUserRepository.findByOrganizationAndUser(organizationId, existingUser.userId);
            if (existingMembership?.isActive) {
                throw new shared_1.ConflictError('User is already a member of this organization');
            }
        }
        // Check for existing pending invitation
        const pendingInvites = await OrganizationRepository_1.organizationInvitationRepository.findPendingByEmail(data.email);
        const existingInvite = pendingInvites.find(i => i.organizationId === organizationId);
        if (existingInvite) {
            throw new shared_1.ConflictError('User already has a pending invitation to this organization');
        }
        const invitation = await OrganizationRepository_1.organizationInvitationRepository.createInvitation({ ...data, organizationId }, invitedBy);
        logger_1.logger.info('User invited to organization', {
            organizationId,
            email: data.email,
            role: data.role,
            invitedBy,
        });
        // TODO: Send invitation email
        return invitation;
    }
    /**
     * Get pending invitations for organization
     */
    async getInvitations(organizationId, userId) {
        // Check access
        await this.checkAccess(organizationId, userId);
        return OrganizationRepository_1.organizationInvitationRepository.findOrganizationInvitations(organizationId);
    }
    /**
     * Get pending invitations for email
     */
    async getPendingInvitations(email) {
        return OrganizationRepository_1.organizationInvitationRepository.findPendingByEmail(email);
    }
    /**
     * Get invitation by token
     */
    async getInvitationByToken(token) {
        const invitation = await OrganizationRepository_1.organizationInvitationRepository.findByToken(token);
        if (!invitation) {
            throw new shared_1.NotFoundError('Invitation', 'invalid or expired token');
        }
        return invitation;
    }
    /**
     * Accept invitation
     */
    async acceptInvitation(data) {
        const result = await OrganizationRepository_1.organizationInvitationRepository.acceptInvitation(data.token, data.userId);
        if (!result) {
            throw new shared_1.NotFoundError('Invitation', 'invalid or expired token');
        }
        logger_1.logger.info('Invitation accepted', {
            organizationId: result.membership.organizationId,
            userId: data.userId,
            invitationId: result.invitation.invitationId,
        });
        return result.membership;
    }
    /**
     * Decline invitation
     */
    async declineInvitation(token) {
        const invitation = await OrganizationRepository_1.organizationInvitationRepository.declineInvitation(token);
        if (!invitation) {
            throw new shared_1.NotFoundError('Invitation', 'invalid token');
        }
        logger_1.logger.info('Invitation declined', {
            organizationId: invitation.organizationId,
            email: invitation.email,
        });
    }
    /**
     * Cancel invitation
     */
    async cancelInvitation(invitationId, organizationId, cancelledBy) {
        // Check permission
        await this.checkPermission(organizationId, cancelledBy, 'can_invite_users');
        const cancelled = await OrganizationRepository_1.organizationInvitationRepository.cancelInvitation(invitationId);
        if (!cancelled) {
            throw new shared_1.NotFoundError('Invitation', invitationId);
        }
        logger_1.logger.info('Invitation cancelled', {
            invitationId,
            organizationId,
            cancelledBy,
        });
    }
    // --------------------------------------------------------------------------
    // SETTINGS
    // --------------------------------------------------------------------------
    /**
     * Get organization settings
     */
    async getSettings(organizationId, userId) {
        // Check access
        await this.checkAccess(organizationId, userId);
        return OrganizationRepository_1.organizationSettingRepository.getAllSettings(organizationId);
    }
    /**
     * Get specific setting
     */
    async getSetting(organizationId, key, userId) {
        // Check access
        await this.checkAccess(organizationId, userId);
        return OrganizationRepository_1.organizationSettingRepository.getSetting(organizationId, key);
    }
    /**
     * Set organization setting
     */
    async setSetting(organizationId, key, value, type, userId) {
        // Check permission
        await this.checkPermission(organizationId, userId, 'can_manage_settings');
        return OrganizationRepository_1.organizationSettingRepository.upsertSetting(organizationId, key, value, type, userId);
    }
    /**
     * Delete organization setting
     */
    async deleteSetting(organizationId, key, userId) {
        // Check permission
        await this.checkPermission(organizationId, userId, 'can_manage_settings');
        const deleted = await OrganizationRepository_1.organizationSettingRepository.deleteSetting(organizationId, key);
        if (!deleted) {
            throw new shared_1.NotFoundError('Setting', key);
        }
    }
    // --------------------------------------------------------------------------
    // ACCESS CONTROL HELPERS
    // --------------------------------------------------------------------------
    /**
     * Check if user has access to organization
     */
    async checkAccess(organizationId, userId) {
        const membership = await OrganizationRepository_1.organizationUserRepository.findByOrganizationAndUser(organizationId, userId);
        if (!membership || !membership.isActive) {
            throw new shared_1.ForbiddenError('User does not have access to this organization');
        }
        const organization = await OrganizationRepository_1.organizationRepository.findById(organizationId);
        if (!organization || !organization.isActive) {
            throw new shared_1.ForbiddenError('Organization is not active');
        }
        return membership;
    }
    /**
     * Check if user has specific permission
     */
    async checkPermission(organizationId, userId, permission) {
        const membership = await this.checkAccess(organizationId, userId);
        // ORG_OWNER and ORG_ADMIN have all permissions
        if (membership.role === 'ORG_OWNER' || membership.role === 'ORG_ADMIN') {
            return membership;
        }
        // Check specific permission
        const permissionMap = {
            can_manage_users: 'canManageUsers',
            can_manage_billing: 'canManageBilling',
            can_manage_settings: 'canManageSettings',
            can_invite_users: 'canInviteUsers',
        };
        if (!membership[permissionMap[permission]]) {
            throw new shared_1.ForbiddenError(`User does not have permission: ${permission}`);
        }
        return membership;
    }
    /**
     * Check if user is organization owner
     */
    async isOwner(organizationId, userId) {
        const membership = await OrganizationRepository_1.organizationUserRepository.findByOrganizationAndUser(organizationId, userId);
        return membership?.role === 'ORG_OWNER';
    }
    /**
     * Check if user is organization admin
     */
    async isAdmin(organizationId, userId) {
        const membership = await OrganizationRepository_1.organizationUserRepository.findByOrganizationAndUser(organizationId, userId);
        return membership?.role === 'ORG_OWNER' || membership?.role === 'ORG_ADMIN';
    }
    // --------------------------------------------------------------------------
    // CLEANUP & MAINTENANCE
    // --------------------------------------------------------------------------
    /**
     * Cleanup expired invitations
     */
    async cleanupExpiredInvitations() {
        const count = await OrganizationRepository_1.organizationInvitationRepository.cleanupExpired();
        if (count > 0) {
            logger_1.logger.info('Expired invitations cleaned up', { count });
        }
        return count;
    }
}
// ============================================================================
// EXPORT
// ============================================================================
exports.organizationService = new OrganizationService();
//# sourceMappingURL=OrganizationService.js.map