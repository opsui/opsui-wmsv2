/**
 * @file OrderService.ts
 * @purpose Manages order lifecycle including claiming, picking, and state transitions
 * @complexity high (multiple state validations, transaction coordination)
 * @tested yes (90% coverage)
 * @last-change 2025-01-19 (added file annotation header)
 * @dependencies OrderRepository, PickTaskRepository, InventoryRepository, db.transaction
 * @domain orders
 *
 * @description
 * Handles all order state transitions following the strict state machine:
 * PENDING → PICKING → PICKED → PACKING → PACKED → SHIPPED.
 * Coordinates with inventory service for reservations and deductions.
 * Enforces picker capacity limits and pick timeout constraints.
 *
 * @invariants
 * - Order status must follow valid state transitions only
 * - All multi-step operations are atomic (wrapped in transactions)
 * - Picker cannot exceed MAX_ORDERS_PER_PICKER (10) active orders
 * - Inventory reservations are made atomically with order creation
 *
 * @performance
 * - Uses database indexes for order queries
 * - Transaction overhead ~50ms for state changes
 * - N+1 query risk: avoid looping through orders without eager loading
 *
 * @security
 * - All methods require authentication context
 * - Pickers can only access orders they have claimed
 * - State transitions validated before execution
 *
 * @see {@link OrderRepository} for data access methods
 * @see {@link InventoryService} for reservation logic
 * @see {@link packages/shared/src/types/workflow.ts} for state machine definition
 */
import { Order, OrderStatus, OrderPriority, CreateOrderDTO, ClaimOrderDTO, PickItemDTO, CompleteOrderDTO, CancelOrderDTO, PickActionResponse } from '@opsui/shared';
export declare class OrderService {
    createOrder(dto: CreateOrderDTO): Promise<Order>;
    pickItem(orderId: string, dto: PickItemDTO, pickerId: string): Promise<PickActionResponse>;
    updatePickTaskStatus(pickTaskId: string, status: any): Promise<any>;
    getPickerActiveOrders(pickerId: string): Promise<Order[]>;
    getNextPickTask(orderId: string): Promise<{
        pickTaskId: string;
        sku: string;
        name: string;
        targetBin: string;
        quantity: number;
        pickedQuantity: number;
    } | null>;
    skipPickTask(pickTaskId: string, reason: string, pickerId: string): Promise<Order>;
    manualOverride(pickTaskId: string, newQuantity: number, reason: string, notes: string | undefined, userId: string): Promise<{
        success: boolean;
        order: Order;
        exception: any;
    }>;
    undoPick(pickTaskId: string, quantity: number | undefined, reason: string): Promise<Order>;
    getOrderPickingProgress(orderId: string): Promise<{
        total: number;
        completed: number;
        skipped: number;
        inProgress: number;
        pending: number;
        percentage: number;
    }>;
    getOrderQueue(filters?: {
        status?: OrderStatus;
        priority?: OrderPriority;
        pickerId?: string;
        page?: number;
        limit?: number;
    }): Promise<{
        orders: Order[];
        total: number;
    }>;
    getOrdersWithItemsByStatus(filters?: {
        status?: OrderStatus;
        packerId?: string;
    }): Promise<{
        orders: Order[];
    }>;
    getOrder(orderId: string): Promise<Order>;
    private recentClaimNotifications;
    private readonly CLAIM_DEDUP_WINDOW_MS;
    claimOrder(orderId: string, dto: ClaimOrderDTO): Promise<Order>;
    continueOrder(orderId: string, userId: string): Promise<{
        orderId: string;
        status: string;
    }>;
    completeOrder(orderId: string, dto: CompleteOrderDTO): Promise<Order>;
    cancelOrder(orderId: string, dto: CancelOrderDTO): Promise<Order>;
    unclaimOrder(orderId: string, userId: string, reason: string): Promise<Order>;
    claimOrderForPacking(orderId: string, packerId: string): Promise<Order>;
    completePacking(orderId: string, packerId: string): Promise<Order>;
    getPackingQueue(): Promise<Order[]>;
    verifyPackingItem(orderId: string, orderItemId: string, quantity?: number): Promise<Order>;
    skipPackingItem(orderId: string, orderItemId: string, reason: string): Promise<Order>;
    undoPackingVerification(orderId: string, orderItemId: string, quantity: number | undefined, reason: string): Promise<Order>;
    unclaimPackingOrder(orderId: string, packerId: string, reason: string): Promise<Order>;
}
export declare const orderService: OrderService;
//# sourceMappingURL=OrderService.d.ts.map