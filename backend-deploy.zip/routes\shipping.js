"use strict";
/**
 * Shipping routes
 *
 * Endpoints for managing carriers, shipments, labels, and tracking
 */
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const ShippingService_1 = require("../services/ShippingService");
const middleware_1 = require("../middleware");
const shared_1 = require("@opsui/shared");
const router = (0, express_1.Router)();
// All shipping routes require authentication
router.use(middleware_1.authenticate);
// ============================================================================
// CARRIER ROUTES
// ============================================================================
/**
 * GET /api/shipping/carriers
 * Get all active carriers
 */
router.get('/carriers', (0, middleware_1.asyncHandler)(async (_req, res) => {
    const carriers = await ShippingService_1.shippingService.getActiveCarriers();
    res.json(carriers);
}));
/**
 * GET /api/shipping/carriers/:carrierId
 * Get a specific carrier by ID
 */
router.get('/carriers/:carrierId', (0, middleware_1.asyncHandler)(async (req, res) => {
    const { carrierId } = req.params;
    const carrier = await ShippingService_1.shippingService.getCarrier(carrierId);
    res.json(carrier);
}));
// ============================================================================
// SHIPPED ORDERS ROUTES
// ============================================================================
/**
 * GET /api/shipping/orders
 * Get all shipped orders with filters
 */
router.get('/orders', (0, middleware_1.asyncHandler)(async (req, res) => {
    const filters = {
        status: req.query.status,
        carrierId: req.query.carrierId,
        startDate: req.query.startDate,
        endDate: req.query.endDate,
        search: req.query.search,
        sortBy: req.query.sortBy,
        sortOrder: req.query.sortOrder,
        page: req.query.page ? parseInt(req.query.page) : 1,
        limit: req.query.limit ? parseInt(req.query.limit) : 20,
    };
    const result = await ShippingService_1.shippingService.getShippedOrders(filters);
    res.json(result);
}));
/**
 * GET /api/shipping/orders/export
 * Export shipped orders to CSV
 */
router.get('/orders/export', (0, middleware_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { orderIds } = req.query;
    if (!orderIds || typeof orderIds !== 'string') {
        res.status(400).json({
            error: 'orderIds parameter is required',
            code: 'MISSING_ORDER_IDS',
        });
        return;
    }
    const ids = orderIds.split(',');
    const csvData = await ShippingService_1.shippingService.exportShippedOrdersToCSV(ids);
    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', `attachment; filename="shipped-orders-${Date.now()}.csv"`);
    res.send(csvData);
}));
// ============================================================================
// SHIPMENT ROUTES
// ============================================================================
/**
 * POST /api/shipping/shipments
 * Create a new shipment
 */
router.post('/shipments', (0, middleware_1.authorize)(shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { orderId, carrierId, serviceType, shippingMethod, shipFromAddress, shipToAddress, totalWeight, totalPackages, dimensions, insuranceValue, shipDate, } = req.body;
    // Validate required fields
    if (!orderId ||
        !carrierId ||
        !serviceType ||
        !shippingMethod ||
        !shipFromAddress ||
        !shipToAddress ||
        !totalWeight ||
        !totalPackages) {
        res.status(400).json({
            error: 'Missing required fields',
            code: 'MISSING_FIELDS',
        });
        return;
    }
    const shipment = await ShippingService_1.shippingService.createShipment({
        orderId,
        carrierId,
        serviceType,
        shippingMethod,
        shipFromAddress,
        shipToAddress,
        totalWeight,
        totalPackages,
        dimensions,
        insuranceValue,
        shipDate: shipDate ? new Date(shipDate) : undefined,
        createdBy: req.user.userId,
    });
    res.status(201).json(shipment);
}));
/**
 * GET /api/shipping/shipments
 * Get all shipments with optional filters
 */
router.get('/shipments', (0, middleware_1.authorize)(shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (req, res) => {
    const filters = {
        status: req.query.status,
        carrierId: req.query.carrierId,
        limit: req.query.limit ? parseInt(req.query.limit) : 50,
        offset: req.query.offset ? parseInt(req.query.offset) : 0,
    };
    const result = await ShippingService_1.shippingService.getAllShipments(filters);
    res.json(result);
}));
/**
 * GET /api/shipping/shipments/:shipmentId
 * Get a specific shipment by ID
 */
router.get('/shipments/:shipmentId', (0, middleware_1.asyncHandler)(async (req, res) => {
    const { shipmentId } = req.params;
    const shipment = await ShippingService_1.shippingService.getShipment(shipmentId);
    res.json(shipment);
}));
/**
 * GET /api/shipping/orders/:orderId/shipment
 * Get shipment by order ID
 */
router.get('/orders/:orderId/shipment', (0, middleware_1.asyncHandler)(async (req, res) => {
    const { orderId } = req.params;
    const shipment = await ShippingService_1.shippingService.getShipmentByOrderId(orderId);
    if (!shipment) {
        res.status(404).json({
            error: 'Shipment not found for this order',
            code: 'SHIPMENT_NOT_FOUND',
        });
        return;
    }
    res.json(shipment);
}));
/**
 * PATCH /api/shipping/shipments/:shipmentId/status
 * Update shipment status
 */
router.patch('/shipments/:shipmentId/status', (0, middleware_1.authorize)(shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { shipmentId } = req.params;
    const { status } = req.body;
    if (!status) {
        res.status(400).json({
            error: 'Status is required',
            code: 'MISSING_STATUS',
        });
        return;
    }
    const shipment = await ShippingService_1.shippingService.updateShipmentStatus(shipmentId, status, req.user.userId);
    res.json(shipment);
}));
/**
 * POST /api/shipping/shipments/:shipmentId/tracking
 * Add tracking number to shipment
 */
router.post('/shipments/:shipmentId/tracking', (0, middleware_1.authorize)(shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { shipmentId } = req.params;
    const { trackingNumber, trackingUrl } = req.body;
    if (!trackingNumber) {
        res.status(400).json({
            error: 'trackingNumber is required',
            code: 'MISSING_TRACKING_NUMBER',
        });
        return;
    }
    const shipment = await ShippingService_1.shippingService.addTrackingNumber(shipmentId, trackingNumber, trackingUrl);
    res.json(shipment);
}));
// ============================================================================
// SHIPPING LABEL ROUTES
// ============================================================================
/**
 * POST /api/shipping/labels
 * Create a shipping label
 */
router.post('/labels', (0, middleware_1.authorize)(shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { shipmentId, packageNumber, packageWeight, packageDimensions } = req.body;
    // Validate required fields
    if (!shipmentId || !packageNumber || !packageWeight) {
        res.status(400).json({
            error: 'Missing required fields',
            code: 'MISSING_FIELDS',
        });
        return;
    }
    const label = await ShippingService_1.shippingService.createShippingLabel({
        shipmentId,
        packageNumber: parseInt(packageNumber),
        packageWeight: parseFloat(packageWeight),
        packageDimensions,
        createdBy: req.user.userId,
    });
    res.status(201).json(label);
}));
/**
 * POST /api/shipping/labels/:labelId/print
 * Mark label as printed
 */
router.post('/labels/:labelId/print', (0, middleware_1.asyncHandler)(async (req, res) => {
    const { labelId } = req.params;
    const label = await ShippingService_1.shippingService.markLabelPrinted(labelId);
    res.json(label);
}));
// ============================================================================
// TRACKING EVENT ROUTES
// ============================================================================
/**
 * GET /api/shipping/shipments/:shipmentId/tracking/events
 * Get tracking events for shipment
 */
router.get('/shipments/:shipmentId/tracking/events', (0, middleware_1.asyncHandler)(async (req, res) => {
    const { shipmentId } = req.params;
    const events = await ShippingService_1.shippingService.getTrackingEvents(shipmentId);
    res.json(events);
}));
/**
 * POST /api/shipping/tracking/events
 * Add tracking event (for webhooks or manual entry)
 */
router.post('/tracking/events', (0, middleware_1.authorize)(shared_1.UserRole.SUPERVISOR, shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { shipmentId, eventCode, eventDescription, eventLocation, eventDate, eventSource, rawEventData, } = req.body;
    // Validate required fields
    if (!shipmentId || !eventCode || !eventDescription || !eventDate) {
        res.status(400).json({
            error: 'Missing required fields',
            code: 'MISSING_FIELDS',
        });
        return;
    }
    const event = await ShippingService_1.shippingService.addTrackingEvent({
        shipmentId,
        eventCode,
        eventDescription,
        eventLocation,
        eventDate: new Date(eventDate),
        eventSource: eventSource || 'MANUAL',
        rawEventData,
    });
    res.status(201).json(event);
}));
exports.default = router;
//# sourceMappingURL=shipping.js.map