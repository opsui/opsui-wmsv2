/**
 * Fix state change ID generation to be more unique
 *
 * This script updates the generate_state_change_id() function to use
 * millisecond precision + random component to avoid duplicate key errors
 * when multiple orders are updated in quick succession.
 */
export {};
//# sourceMappingURL=fix-state-change-id.d.ts.map