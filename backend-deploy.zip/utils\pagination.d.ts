/**
 * Pagination Utilities
 *
 * Provides helpers for paginated responses with metadata
 */
import { Response } from 'express';
export interface PaginationParams {
    page: number;
    limit: number;
    sortBy?: string;
    sortOrder?: 'asc' | 'desc';
}
export interface PaginationMeta {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
    hasNextPage: boolean;
    hasPreviousPage: boolean;
    nextPage?: number;
    previousPage?: number;
}
export interface PaginatedResponse<T> {
    data: T[];
    pagination: PaginationMeta;
}
/**
 * Calculate pagination metadata from total count and current params
 */
export declare function calculatePaginationMeta(total: number, page: number, limit: number): PaginationMeta;
/**
 * Parse and validate pagination query parameters
 */
export declare function parsePaginationParams(query: any, defaultPage?: number, defaultLimit?: number, maxLimit?: number): PaginationParams;
/**
 * Calculate SQL offset and limit from pagination params
 */
export declare function calculateSqlOffset(pagination: PaginationParams): {
    offset: number;
    limit: number;
};
/**
 * Send paginated response with metadata
 */
export declare function sendPaginatedResponse<T>(res: Response, data: T[], total: number, pagination: PaginationParams): void;
/**
 * Add ORDER BY clause to SQL query based on pagination params
 */
export declare function addOrderByClause(sql: string, sortBy: string, sortOrder?: 'asc' | 'desc'): string;
/**
 * Add pagination (LIMIT/OFFSET) to SQL query
 */
export declare function addPaginationClause(sql: string, offset: number, _limit: number): string;
//# sourceMappingURL=pagination.d.ts.map