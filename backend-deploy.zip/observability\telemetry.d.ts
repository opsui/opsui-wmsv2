/**
 * OpenTelemetry Configuration and Instrumentation
 *
 * Provides distributed tracing and metrics instrumentation
 * for the Warehouse Management System.
 *
 * @see https://opentelemetry.io/docs/instrumentation/js/
 */
import { NodeSDK } from '@opentelemetry/sdk-node';
import * as diag from '@opentelemetry/api';
/**
 * Initialize OpenTelemetry SDK
 * Call this before importing any other application code
 */
export declare function initializeTelemetry(): NodeSDK;
/**
 * Wrap an async function with a span
 */
export declare function withSpan<T>(name: string, fn: (span: diag.Span) => Promise<T>, attributes?: Record<string, unknown>): Promise<T>;
/**
 * Add attributes to current span
 */
export declare function addSpanAttributes(attributes: Record<string, unknown>): void;
/**
 * Add event to current span
 */
export declare function addSpanEvent(name: string, attributes?: Record<string, unknown>): void;
/**
 * Record exception on current span
 */
export declare function recordException(error: Error): void;
/**
 * Create a counter metric
 */
export declare function createCounter(name: string, options?: {
    description?: string;
    unit?: string;
}): diag.Counter<diag.Attributes>;
/**
 * Create a histogram metric
 */
export declare function createHistogram(name: string, options?: {
    description?: string;
    unit?: string;
}): diag.Histogram<diag.Attributes>;
/**
 * Create a gauge metric
 */
export declare function createGauge(name: string, options?: {
    description?: string;
    unit?: string;
}): diag.ObservableGauge<diag.Attributes>;
export declare const httpRequestDuration: diag.Histogram<diag.Attributes>;
export declare const httpRequestSize: diag.Histogram<diag.Attributes>;
export declare const httpResponseSize: diag.Histogram<diag.Attributes>;
export declare const dbQueryDuration: diag.Histogram<diag.Attributes>;
export declare const ordersProcessed: diag.Counter<diag.Attributes>;
export declare const picksCompleted: diag.Counter<diag.Attributes>;
export declare const inventoryTransactions: diag.Counter<diag.Attributes>;
export declare const errorsTotal: diag.Counter<diag.Attributes>;
declare const _default: {
    initializeTelemetry: typeof initializeTelemetry;
    withSpan: typeof withSpan;
    addSpanAttributes: typeof addSpanAttributes;
    addSpanEvent: typeof addSpanEvent;
    recordException: typeof recordException;
    createCounter: typeof createCounter;
    createHistogram: typeof createHistogram;
    createGauge: typeof createGauge;
    httpRequestDuration: diag.Histogram<diag.Attributes>;
    httpRequestSize: diag.Histogram<diag.Attributes>;
    httpResponseSize: diag.Histogram<diag.Attributes>;
    dbQueryDuration: diag.Histogram<diag.Attributes>;
    ordersProcessed: diag.Counter<diag.Attributes>;
    picksCompleted: diag.Counter<diag.Attributes>;
    inventoryTransactions: diag.Counter<diag.Attributes>;
    errorsTotal: diag.Counter<diag.Attributes>;
    tracer: diag.Tracer;
    meter: diag.Meter;
};
export default _default;
//# sourceMappingURL=telemetry.d.ts.map