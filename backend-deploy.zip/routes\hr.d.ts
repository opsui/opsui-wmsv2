/**
 * HR & Payroll API Routes
 *
 * REST API for employee management, timesheets, payroll processing,
 * and leave management with NZ tax compliance
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=hr.d.ts.map