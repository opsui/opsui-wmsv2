/**
 * Debug aggregate query
 */
export {};
//# sourceMappingURL=debug-aggregate.d.ts.map