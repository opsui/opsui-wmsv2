"use strict";
/**
 * Migration: Add verified_quantity column to order_items table
 *
 * This column tracks how many items have been verified during the packing stage
 */
Object.defineProperty(exports, "__esModule", { value: true });
const client_1 = require("./client");
async function addVerifiedQuantityColumn() {
    console.log('Adding verified_quantity column to order_items table...');
    try {
        // Check if column already exists
        const checkResult = await (0, client_1.query)(`
      SELECT column_name
      FROM information_schema.columns
      WHERE table_name = 'order_items'
      AND column_name = 'verified_quantity';
    `);
        if (checkResult.rows.length > 0) {
            console.log('Column verified_quantity already exists, skipping migration');
            return;
        }
        // Add the column
        await (0, client_1.query)(`
      ALTER TABLE order_items
      ADD COLUMN verified_quantity INTEGER DEFAULT 0;
    `);
        console.log('Successfully added verified_quantity column to order_items table');
        // Verify the column was added
        const verifyResult = await (0, client_1.query)(`
      SELECT column_name, data_type, column_default
      FROM information_schema.columns
      WHERE table_name = 'order_items'
      AND column_name = 'verified_quantity';
    `);
        console.log('Column details:', verifyResult.rows[0]);
    }
    catch (error) {
        console.error('Error adding verified_quantity column:', error);
        throw error;
    }
}
// Run the migration
addVerifiedQuantityColumn()
    .then(() => {
    console.log('Migration completed successfully');
    (0, client_1.closePool)();
})
    .catch(error => {
    console.error('Migration failed:', error);
    (0, client_1.closePool)();
    process.exit(1);
});
//# sourceMappingURL=add-verified-quantity.js.map