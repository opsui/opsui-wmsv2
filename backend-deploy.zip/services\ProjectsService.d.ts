/**
 * Projects Service
 *
 * Business logic for project management operations
 * Handles projects, tasks, milestones, time entries, expenses, billing, and resources
 */
import type { Project, ProjectWithDetails, ProjectSummary, ProjectTask, ProjectTaskWithDetails, ProjectMilestone, ProjectTimeEntry, ProjectTimeEntryWithDetails, ProjectExpense, ProjectBillingSchedule, ProjectResource, ProjectResourceWithDetails, CreateProjectDTO, UpdateProjectDTO, CreateTaskDTO, UpdateTaskDTO, CreateMilestoneDTO, CreateTimeEntryDTO, ApproveTimeEntriesDTO, CreateExpenseDTO, CreateBillingScheduleDTO, GenerateProjectInvoiceDTO, GenerateProjectInvoiceResult, AssignResourceDTO, ProjectQueryFilters, TimeEntryQueryFilters, ExpenseQueryFilters, GanttChartData, ProjectDashboardMetrics, ProjectProfitabilityReport, ResourceUtilizationReport } from '@opsui/shared';
declare class ProjectsService {
    /**
     * Get all projects with optional filters
     */
    getProjects(filters?: ProjectQueryFilters): Promise<Project[]>;
    /**
     * Get project by ID
     */
    getProjectById(projectId: string): Promise<ProjectWithDetails>;
    /**
     * Get project summary with financials
     */
    getProjectSummary(projectId: string): Promise<ProjectSummary>;
    /**
     * Create new project
     */
    createProject(dto: CreateProjectDTO, createdBy: string): Promise<Project>;
    /**
     * Update project
     */
    updateProject(projectId: string, dto: UpdateProjectDTO, updatedBy: string): Promise<Project>;
    /**
     * Delete project (soft delete)
     */
    deleteProject(projectId: string, deletedBy: string): Promise<boolean>;
    /**
     * Get tasks for a project
     */
    getTasks(projectId: string): Promise<ProjectTaskWithDetails[]>;
    /**
     * Get task by ID
     */
    getTaskById(taskId: string): Promise<ProjectTaskWithDetails>;
    /**
     * Get Gantt chart data for a project
     */
    getGanttChartData(projectId: string): Promise<GanttChartData[]>;
    /**
     * Create task
     */
    createTask(dto: CreateTaskDTO, createdBy: string): Promise<ProjectTask>;
    /**
     * Update task
     */
    updateTask(taskId: string, dto: UpdateTaskDTO, updatedBy: string): Promise<ProjectTask>;
    /**
     * Delete task
     */
    deleteTask(taskId: string): Promise<boolean>;
    /**
     * Get milestones for a project
     */
    getMilestones(projectId: string): Promise<ProjectMilestone[]>;
    /**
     * Create milestone
     */
    createMilestone(dto: CreateMilestoneDTO, createdBy: string): Promise<ProjectMilestone>;
    /**
     * Update milestone
     */
    updateMilestone(milestoneId: string, dto: Partial<CreateMilestoneDTO>): Promise<ProjectMilestone>;
    /**
     * Mark milestone as complete
     */
    completeMilestone(milestoneId: string): Promise<ProjectMilestone>;
    /**
     * Get time entries with filters
     */
    getTimeEntries(filters?: TimeEntryQueryFilters): Promise<ProjectTimeEntryWithDetails[]>;
    /**
     * Create time entry
     */
    createTimeEntry(dto: CreateTimeEntryDTO, createdBy: string): Promise<ProjectTimeEntry>;
    /**
     * Approve time entries
     */
    approveTimeEntries(dto: ApproveTimeEntriesDTO, approvedBy: string): Promise<void>;
    /**
     * Batch approve time entries
     */
    batchApproveTimeEntries(timeEntryIds: string[], approve: boolean, approvedBy: string): Promise<void>;
    /**
     * Get expenses with filters
     */
    getExpenses(filters?: ExpenseQueryFilters): Promise<ProjectExpense[]>;
    /**
     * Create expense
     */
    createExpense(dto: CreateExpenseDTO, createdBy: string): Promise<ProjectExpense>;
    /**
     * Approve expense
     */
    approveExpense(expenseId: string, approve: boolean, approvedBy: string, rejectionReason?: string): Promise<void>;
    /**
     * Batch approve expenses
     */
    batchApproveExpenses(expenseIds: string[], approve: boolean, approvedBy: string, rejectionReason?: string): Promise<void>;
    /**
     * Get billing schedule for a project
     */
    getBillingSchedule(projectId: string): Promise<ProjectBillingSchedule[]>;
    /**
     * Create billing schedule item
     */
    createBillingSchedule(dto: CreateBillingScheduleDTO, createdBy: string): Promise<ProjectBillingSchedule>;
    /**
     * Generate project invoice
     * Creates accounting invoice with unbilled time entries and expenses
     */
    generateProjectInvoice(dto: GenerateProjectInvoiceDTO, createdBy: string): Promise<GenerateProjectInvoiceResult>;
    /**
     * Get project resources
     */
    getProjectResources(projectId: string): Promise<ProjectResourceWithDetails[]>;
    /**
     * Assign resource to project
     */
    assignResource(dto: AssignResourceDTO, createdBy: string): Promise<ProjectResource>;
    /**
     * Remove resource from project
     */
    removeResource(resourceId: string): Promise<boolean>;
    /**
     * Get project dashboard metrics
     */
    getProjectDashboardMetrics(filters?: ProjectQueryFilters): Promise<ProjectDashboardMetrics>;
    /**
     * Get project profitability report
     */
    getProjectProfitabilityReport(projectId: string): Promise<ProjectProfitabilityReport>;
    /**
     * Get resource utilization report
     */
    getResourceUtilization(userId?: string): Promise<ResourceUtilizationReport[]>;
}
export declare const projectsService: ProjectsService;
export {};
//# sourceMappingURL=ProjectsService.d.ts.map