"use strict";
/**
 * Inventory routes
 */
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const InventoryService_1 = require("../services/InventoryService");
const middleware_1 = require("../middleware");
const shared_1 = require("@opsui/shared");
const router = (0, express_1.Router)();
// All inventory routes require authentication
router.use(middleware_1.authenticate);
/**
 * GET /api/inventory/sku/:sku
 * Get inventory for a specific SKU
 */
router.get('/sku/:sku', (0, middleware_1.asyncHandler)(async (req, res) => {
    (0, shared_1.validateSKU)(req.params.sku);
    const inventory = await InventoryService_1.inventoryService.getInventoryBySKU(req.params.sku);
    res.json(inventory);
}));
/**
 * GET /api/inventory/bin/:binLocation
 * Get inventory at a specific bin location
 */
router.get('/bin/:binLocation', (0, middleware_1.asyncHandler)(async (req, res) => {
    (0, shared_1.validateBinLocation)(req.params.binLocation);
    const inventory = await InventoryService_1.inventoryService.getInventoryByBinLocation(req.params.binLocation);
    res.json(inventory);
}));
/**
 * GET /api/inventory/sku/:sku/available
 * Get available inventory locations for a SKU
 */
router.get('/sku/:sku/available', (0, middleware_1.asyncHandler)(async (req, res) => {
    (0, shared_1.validateSKU)(req.params.sku);
    const available = await InventoryService_1.inventoryService.getAvailableInventory(req.params.sku);
    res.json(available);
}));
/**
 * GET /api/inventory/sku/:sku/total
 * Get total available quantity for a SKU
 */
router.get('/sku/:sku/total', (0, middleware_1.asyncHandler)(async (req, res) => {
    (0, shared_1.validateSKU)(req.params.sku);
    const total = await InventoryService_1.inventoryService.getTotalAvailable(req.params.sku);
    res.json({ sku: req.params.sku, totalAvailable: total });
}));
/**
 * POST /api/inventory/adjust
 * Manually adjust inventory (admin/supervisor only)
 */
router.post('/adjust', (0, middleware_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR), (0, middleware_1.asyncHandler)(async (req, res) => {
    if (!req.user) {
        res.status(401).json({ error: 'Not authenticated' });
        return;
    }
    const { sku, binLocation, quantity, reason } = req.body;
    (0, shared_1.validateSKU)(sku);
    (0, shared_1.validateBinLocation)(binLocation);
    if (typeof quantity !== 'number') {
        res.status(400).json({
            error: 'Quantity must be a number',
            code: 'INVALID_QUANTITY',
        });
        return;
    }
    if (!reason || typeof reason !== 'string') {
        res.status(400).json({
            error: 'Reason is required',
            code: 'MISSING_REASON',
        });
        return;
    }
    const inventory = await InventoryService_1.inventoryService.adjustInventory(sku, binLocation, quantity, req.user.userId, reason);
    res.json(inventory);
}));
/**
 * GET /api/inventory/transactions
 * Get transaction history
 */
router.get('/transactions', (0, middleware_1.asyncHandler)(async (req, res) => {
    const filters = {
        sku: req.query.sku,
        orderId: req.query.orderId,
        type: req.query.type,
        limit: req.query.limit ? parseInt(req.query.limit) : undefined,
        offset: req.query.offset ? parseInt(req.query.offset) : undefined,
    };
    const result = await InventoryService_1.inventoryService.getTransactionHistory(filters);
    res.json(result);
}));
/**
 * GET /api/inventory/alerts/low-stock
 * Get low stock alerts
 */
router.get('/alerts/low-stock', (0, middleware_1.asyncHandler)(async (req, res) => {
    const threshold = req.query.threshold ? parseInt(req.query.threshold) : 10;
    const alerts = await InventoryService_1.inventoryService.getLowStockAlerts(threshold);
    res.json(alerts);
}));
/**
 * GET /api/inventory/reconcile/:sku
 * Reconcile inventory for a SKU
 */
router.get('/reconcile/:sku', (0, middleware_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR), (0, middleware_1.asyncHandler)(async (req, res) => {
    (0, shared_1.validateSKU)(req.params.sku);
    const reconciliation = await InventoryService_1.inventoryService.reconcileInventory(req.params.sku);
    res.json(reconciliation);
}));
/**
 * GET /api/inventory/metrics
 * Get inventory metrics
 */
router.get('/metrics', (0, middleware_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR), (0, middleware_1.asyncHandler)(async (_req, res) => {
    const metrics = await InventoryService_1.inventoryService.getInventoryMetrics();
    res.json(metrics);
}));
exports.default = router;
//# sourceMappingURL=inventory.js.map