/**
 * Quality Control routes
 *
 * Endpoints for managing quality inspections, checklists, and returns
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=qualityControl.d.ts.map