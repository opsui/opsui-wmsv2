/**
 * Run cycle count tables migration
 *
 * Creates the cycle_count_plans, cycle_count_entries, and cycle_count_tolerances tables
 */
declare function runCycleCountMigration(): Promise<void>;
export { runCycleCountMigration };
//# sourceMappingURL=run-cycle-count-migration.d.ts.map