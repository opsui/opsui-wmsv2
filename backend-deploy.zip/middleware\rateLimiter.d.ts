/**
 * Rate limiting middleware
 *
 * Prevents abuse by limiting request rate per IP address
 */
export declare const rateLimiter: import("express-rate-limit").RateLimitRequestHandler;
export declare const authRateLimiterSimple: import("express-rate-limit").RateLimitRequestHandler;
export declare const pickingRateLimiter: import("express-rate-limit").RateLimitRequestHandler;
//# sourceMappingURL=rateLimiter.d.ts.map