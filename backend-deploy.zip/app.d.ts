/**
 * Express application configuration
 *
 * Sets up middleware, routes, and error handling
 */
import { Application } from 'express';
export declare function getActiveConnections(): number;
export declare function getAllConnections(): Set<string>;
export declare function waitForDrain(timeoutMs?: number): Promise<boolean>;
export declare function createApp(): Application;
export declare function startServer(): Promise<void>;
//# sourceMappingURL=app.d.ts.map