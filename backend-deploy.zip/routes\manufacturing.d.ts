/**
 * Manufacturing API Routes
 *
 * REST API for manufacturing operations
 * Handles work centers, routings, MPS, MRP, production orders,
 * shop floor control, quality, and capacity planning
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=manufacturing.d.ts.map