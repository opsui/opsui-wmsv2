/**
 * Root Cause Analysis Service
 *
 * Manages root cause categorization for cycle count variances.
 * Provides Pareto analysis and trending analysis for continuous improvement.
 */
export interface RootCauseCategory {
    categoryId: string;
    categoryName: string;
    categoryCode: string;
    description?: string;
    displayOrder: number;
    isActive: boolean;
    createdAt: Date;
}
export interface VarianceRootCause {
    rootCauseId: string;
    entryId: string;
    categoryId: string;
    categoryName: string;
    categoryCode: string;
    additionalNotes?: string;
    createdBy: string;
    createdAt: Date;
}
export interface RecordRootCauseDTO {
    entryId: string;
    categoryId: string;
    additionalNotes?: string;
    createdBy: string;
}
export interface RootCauseParetoData {
    category: string;
    categoryCode: string;
    count: number;
    totalVariance: number;
    cumulativePercent: number;
}
export interface CategoryBreakdown {
    category: string;
    categoryCode: string;
    varianceCount: number;
    averageVariancePercent: number;
    totalVariance: number;
    trend: 'INCREASING' | 'DECREASING' | 'STABLE';
    recentCount: number;
    previousCount: number;
}
export interface TrendingRootCause {
    category: string;
    categoryCode: string;
    currentPeriodCount: number;
    previousPeriodCount: number;
    percentChange: number;
    trend: 'INCREASING' | 'DECREASING' | 'STABLE';
}
export interface RootCauseBySKU {
    sku: string;
    skuName: string;
    rootCauses: Array<{
        category: string;
        count: number;
    }>;
    mostFrequentCategory: string;
    totalVarianceCount: number;
}
export interface RootCauseByZone {
    zone: string;
    rootCauses: Array<{
        category: string;
        count: number;
    }>;
    mostFrequentCategory: string;
    totalVarianceCount: number;
}
export declare class RootCauseAnalysisService {
    /**
     * Get all root cause categories
     */
    getAllCategories(): Promise<RootCauseCategory[]>;
    /**
     * Get a specific category
     */
    getCategory(categoryId: string): Promise<RootCauseCategory>;
    /**
     * Record root cause for a variance entry
     */
    recordRootCause(dto: RecordRootCauseDTO): Promise<VarianceRootCause>;
    /**
     * Get Pareto analysis of root causes (80/20 rule)
     */
    getRootCausePareto(days?: number): Promise<RootCauseParetoData[]>;
    /**
     * Get breakdown by category with trend analysis
     */
    getCategoryBreakdown(_days?: number): Promise<CategoryBreakdown[]>;
    /**
     * Get trending root causes (increasing problems)
     */
    getTrendingRootCauses(days?: number): Promise<TrendingRootCause[]>;
    /**
     * Get root cause analysis by SKU
     */
    getRootCauseBySKU(sku: string, days?: number): Promise<RootCauseBySKU[]>;
    /**
     * Get root cause analysis by zone
     */
    getRootCauseByZone(zone: string, days?: number): Promise<RootCauseByZone[]>;
    /**
     * Get root cause for a specific entry
     */
    getRootCauseForEntry(entryId: string): Promise<VarianceRootCause | null>;
    private mapRowToCategory;
}
export declare const rootCauseAnalysisService: RootCauseAnalysisService;
//# sourceMappingURL=RootCauseAnalysisService.d.ts.map