"use strict";
/**
 * Migration: Add skip_reason column to order_items table
 *
 * This column stores the reason when an item is skipped during packing
 */
Object.defineProperty(exports, "__esModule", { value: true });
const client_1 = require("./client");
async function addSkipReasonColumn() {
    console.log('Adding skip_reason column to order_items table...');
    try {
        // Check if column already exists
        const checkResult = await (0, client_1.query)(`
      SELECT column_name
      FROM information_schema.columns
      WHERE table_name = 'order_items'
      AND column_name = 'skip_reason';
    `);
        if (checkResult.rows.length > 0) {
            console.log('Column skip_reason already exists, skipping migration');
            return;
        }
        // Add the column
        await (0, client_1.query)(`
      ALTER TABLE order_items
      ADD COLUMN skip_reason TEXT;
    `);
        console.log('Successfully added skip_reason column to order_items table');
        // Verify the column was added
        const verifyResult = await (0, client_1.query)(`
      SELECT column_name, data_type, is_nullable
      FROM information_schema.columns
      WHERE table_name = 'order_items'
      AND column_name = 'skip_reason';
    `);
        console.log('Column details:', verifyResult.rows[0]);
    }
    catch (error) {
        console.error('Error adding skip_reason column:', error);
        throw error;
    }
}
// Run the migration
addSkipReasonColumn()
    .then(() => {
    console.log('Migration completed successfully');
    (0, client_1.closePool)();
})
    .catch(error => {
    console.error('Migration failed:', error);
    (0, client_1.closePool)();
    process.exit(1);
});
//# sourceMappingURL=add-skip-reason.js.map