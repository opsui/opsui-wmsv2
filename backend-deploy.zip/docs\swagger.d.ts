/**
 * OpenAPI/Swagger Documentation Generator
 *
 * This file automatically generates API documentation from Joi schemas
 * and route definitions using Express-compatible swagger-jsdoc.
 */
import swaggerJSDoc from 'swagger-jsdoc';
/**
 * OpenAPI/Swagger configuration for the WMS API
 */
export declare const swaggerOptions: swaggerJSDoc.Options;
/**
 * Generate Swagger specification
 */
export declare const swaggerSpec: object;
/**
 * Setup Swagger documentation for Express app
 */
export declare function setupSwagger(app: any): void;
/**
 * Helper to generate Swagger schema from Joi validator
 * This can be used to auto-generate schemas from Joi validators
 */
export declare function generateSwaggerFromJoi(joiSchema: any): any;
//# sourceMappingURL=swagger.d.ts.map