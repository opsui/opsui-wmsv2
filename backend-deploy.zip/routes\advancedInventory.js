"use strict";
/**
 * Advanced Inventory Routes
 *
 * API endpoints for advanced inventory management
 */
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const AdvancedInventoryService_1 = require("../services/AdvancedInventoryService");
const middleware_1 = require("../middleware");
const router = (0, express_1.Router)();
// All routes require authentication
router.use(middleware_1.authenticate);
// ============================================================================
// LANDED COST
// ============================================================================
/**
 * POST /api/advanced-inventory/landed-cost
 * Add landed cost component
 */
router.post('/landed-cost', (0, middleware_1.asyncHandler)(async (req, res) => {
    const component = await AdvancedInventoryService_1.advancedInventoryService.addLandedCostComponent(req.body);
    res.status(201).json(component);
}));
/**
 * GET /api/advanced-inventory/landed-cost/receipt/:receiptLineId
 * Calculate landed cost for a receipt line
 */
router.get('/landed-cost/receipt/:receiptLineId', (0, middleware_1.asyncHandler)(async (req, res) => {
    const { receiptLineId } = req.params;
    const landedCost = await AdvancedInventoryService_1.advancedInventoryService.calculateLandedCost(receiptLineId);
    res.json({ receiptLineId, landedCost });
}));
/**
 * GET /api/advanced-inventory/layers/:sku
 * Get inventory layers for a SKU
 */
router.get('/layers/:sku', (0, middleware_1.asyncHandler)(async (req, res) => {
    const { sku } = req.params;
    const includeExhausted = req.query.includeExhausted === 'true';
    const layers = await AdvancedInventoryService_1.advancedInventoryService.getInventoryLayers(sku, includeExhausted);
    res.json(layers);
}));
/**
 * GET /api/advanced-inventory/layers/:sku/summary
 * Get inventory layers summary
 */
router.get('/layers/:sku/summary', (0, middleware_1.asyncHandler)(async (req, res) => {
    const { sku } = req.params;
    const summary = await AdvancedInventoryService_1.advancedInventoryService.getInventoryLayersSummary(sku);
    res.json(summary);
}));
// ============================================================================
// ABC ANALYSIS
// ============================================================================
/**
 * POST /api/advanced-inventory/abc-analysis
 * Run ABC analysis
 */
router.post('/abc-analysis', (0, middleware_1.asyncHandler)(async (req, res) => {
    const analysis = await AdvancedInventoryService_1.advancedInventoryService.runABCAnalysis({
        ...req.body,
        createdBy: req.user?.userId,
    });
    res.status(201).json(analysis);
}));
/**
 * GET /api/advanced-inventory/abc-analysis/latest
 * Get latest ABC analysis
 */
router.get('/abc-analysis/latest', (0, middleware_1.asyncHandler)(async (_req, res) => {
    const analysis = await AdvancedInventoryService_1.advancedInventoryService.getLatestABCAnalysis();
    res.json(analysis);
}));
/**
 * GET /api/advanced-inventory/abc-analysis/:analysisId
 * Get ABC analysis with details
 */
router.get('/abc-analysis/:analysisId', (0, middleware_1.asyncHandler)(async (req, res) => {
    const { analysisId } = req.params;
    const result = await AdvancedInventoryService_1.advancedInventoryService.getABCAnalysis(analysisId);
    if (!result) {
        res.status(404).json({ error: 'Analysis not found' });
        return;
    }
    res.json(result);
}));
// ============================================================================
// DEMAND FORECASTING
// ============================================================================
/**
 * POST /api/advanced-inventory/forecasts
 * Create demand forecast
 */
router.post('/forecasts', (0, middleware_1.asyncHandler)(async (req, res) => {
    const forecast = await AdvancedInventoryService_1.advancedInventoryService.createDemandForecast({
        ...req.body,
        createdBy: req.user?.userId,
    });
    res.status(201).json(forecast);
}));
/**
 * GET /api/advanced-inventory/forecasts/:forecastId
 * Get demand forecast with details
 */
router.get('/forecasts/:forecastId', (0, middleware_1.asyncHandler)(async (req, res) => {
    const { forecastId } = req.params;
    const result = await AdvancedInventoryService_1.advancedInventoryService.getDemandForecast(forecastId);
    if (!result) {
        res.status(404).json({ error: 'Forecast not found' });
        return;
    }
    res.json(result);
}));
// ============================================================================
// SAFETY STOCK
// ============================================================================
/**
 * POST /api/advanced-inventory/safety-stock/calculate
 * Calculate safety stock
 */
router.post('/safety-stock/calculate', (0, middleware_1.asyncHandler)(async (req, res) => {
    const safetyStock = await AdvancedInventoryService_1.advancedInventoryService.calculateSafetyStock({
        ...req.body,
        calculatedBy: req.user?.userId,
    });
    res.status(201).json(safetyStock);
}));
/**
 * GET /api/advanced-inventory/safety-stock/alerts
 * Get safety stock alerts
 */
router.get('/safety-stock/alerts', (0, middleware_1.asyncHandler)(async (_req, res) => {
    const alerts = await AdvancedInventoryService_1.advancedInventoryService.getSafetyStockAlerts();
    res.json(alerts);
}));
// ============================================================================
// CYCLE COUNT OPTIMIZATION
// ============================================================================
/**
 * POST /api/advanced-inventory/cycle-count-optimization
 * Create cycle count optimization
 */
router.post('/cycle-count-optimization', (0, middleware_1.asyncHandler)(async (req, res) => {
    const optimization = await AdvancedInventoryService_1.advancedInventoryService.createCycleCountOptimization({
        ...req.body,
        createdBy: req.user?.userId,
    });
    res.status(201).json(optimization);
}));
/**
 * GET /api/advanced-inventory/cycle-count-schedule
 * Get cycle count schedule
 */
router.get('/cycle-count-schedule', (0, middleware_1.asyncHandler)(async (req, res) => {
    const startDate = req.query.startDate ? new Date(req.query.startDate) : new Date();
    const endDate = req.query.endDate
        ? new Date(req.query.endDate)
        : new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
    const schedule = await AdvancedInventoryService_1.advancedInventoryService.getCycleCountSchedule(startDate, endDate);
    res.json(schedule);
}));
// ============================================================================
// SLOW MOVING INVENTORY
// ============================================================================
/**
 * GET /api/advanced-inventory/slow-moving
 * Get slow moving inventory
 */
router.get('/slow-moving', (0, middleware_1.asyncHandler)(async (req, res) => {
    const thresholdDays = parseInt(req.query.threshold) || 90;
    const inventory = await AdvancedInventoryService_1.advancedInventoryService.getSlowMovingInventory(thresholdDays);
    res.json(inventory);
}));
/**
 * GET /api/advanced-inventory/investment-analysis
 * Get inventory investment analysis
 */
router.get('/investment-analysis', (0, middleware_1.asyncHandler)(async (req, res) => {
    const startDate = req.query.startDate
        ? new Date(req.query.startDate)
        : new Date(Date.now() - 90 * 24 * 60 * 60 * 1000);
    const endDate = req.query.endDate ? new Date(req.query.endDate) : new Date();
    const analysis = await AdvancedInventoryService_1.advancedInventoryService.getInventoryInvestmentAnalysis(startDate, endDate);
    res.json(analysis);
}));
exports.default = router;
//# sourceMappingURL=advancedInventory.js.map