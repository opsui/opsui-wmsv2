/**
 * Permission-based access control middleware
 *
 * Checks if users have specific permissions based on their role(s)
 */
import { Response, NextFunction } from 'express';
import { Permission } from '@opsui/shared';
import { AuthenticatedRequest } from './auth';
export declare let permissionsCleanupInterval: null;
/**
 * Check if user has a specific permission
 */
export declare function hasPermission(userPermissions: Permission[], requiredPermission: Permission): boolean;
/**
 * Check if user has ANY of the specified permissions (OR logic)
 */
export declare function hasAnyPermission(userPermissions: Permission[], requiredPermissions: Permission[]): boolean;
/**
 * Check if user has ALL of the specified permissions (AND logic)
 */
export declare function hasAllPermissions(userPermissions: Permission[], requiredPermissions: Permission[]): boolean;
/**
 * Middleware factory to require a specific permission
 *
 * @example
 * router.get('/orders', requirePermission(Permission.VIEW_ORDERS), getOrdersHandler);
 */
export declare function requirePermission(permission: Permission): (req: AuthenticatedRequest, _res: Response, next: NextFunction) => Promise<void>;
/**
 * Middleware factory to require ANY of the specified permissions (OR logic)
 *
 * @example
 * router.post('/reports', requireAnyPermission([
 *   Permission.VIEW_REPORTS,
 *   Permission.GENERATE_REPORTS
 * ]), generateReportHandler);
 */
export declare function requireAnyPermission(permissions: Permission[]): (req: AuthenticatedRequest, _res: Response, next: NextFunction) => Promise<void>;
/**
 * Middleware factory to require ALL of the specified permissions (AND logic)
 *
 * @example
 * router.post('/orders', requireAllPermissions([
 *   Permission.VIEW_ORDERS,
 *   Permission.CREATE_ORDERS
 * ]), createOrderHandler);
 */
export declare function requireAllPermissions(permissions: Permission[]): (req: AuthenticatedRequest, _res: Response, next: NextFunction) => Promise<void>;
/**
 * Clear permissions cache for a specific user
 * Call this when granting/revoking roles or changing permissions
 */
export declare function clearUserPermissionsCache(userId: string): void;
/**
 * Clear entire permissions cache
 * Call this when role definitions change
 */
export declare function clearAllPermissionsCache(): void;
//# sourceMappingURL=permissions.d.ts.map