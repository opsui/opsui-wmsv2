/**
 * Clean all data from database (keep schema)
 *
 * Removes all data but preserves table structure
 */
/**
 * Truncate all tables (removes data, keeps schema)
 */
export declare function cleanAllData(): Promise<void>;
declare function main(): Promise<void>;
export { main as cleanDataCli };
//# sourceMappingURL=clean-data.d.ts.map