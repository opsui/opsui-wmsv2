/**
 * WebSocket Broadcaster
 *
 * Provides typed methods for broadcasting events to connected WebSocket clients
 * Handles event validation and room-based targeting
 */
import { Server as SocketIOServer } from 'socket.io';
import type { ServerToClientEvents } from './index';
export interface OrderClaimedEvent {
    orderId: string;
    pickerId: string;
    pickerName: string;
    claimedAt: Date;
}
export interface OrderCompletedEvent {
    orderId: string;
    pickerId: string;
    completedAt: Date;
    itemCount: number;
}
export interface PickUpdatedEvent {
    orderId: string;
    orderItemId: string;
    sku: string;
    pickedQuantity: number;
    targetQuantity: number;
    pickerId: string;
}
export interface ZoneUpdatedEvent {
    zoneId: string;
    taskCount: number;
    pickerCount: number;
    lastUpdatedAt: Date;
}
export interface InventoryLowEvent {
    sku: string;
    binLocation: string;
    quantity: number;
    minThreshold: number;
    alertedAt: Date;
}
export interface NotificationEvent {
    notificationId: string;
    userId: string;
    title: string;
    message: string;
    type: 'INFO' | 'WARNING' | 'ERROR' | 'SUCCESS';
    createdAt: Date;
}
export declare class WebSocketBroadcaster {
    private io;
    constructor(io: SocketIOServer<ServerToClientEvents, any>);
    /**
     * Broadcast to all connected clients
     */
    private broadcastAll;
    /**
     * Broadcast to a specific room
     */
    private broadcastToRoom;
    /**
     * Broadcast to a specific user
     */
    private broadcastToUser;
    /**
     * Broadcast when an order is claimed by a picker
     */
    broadcastOrderClaimed(data: OrderClaimedEvent): void;
    /**
     * Broadcast when an order is completed
     */
    broadcastOrderCompleted(data: OrderCompletedEvent): void;
    /**
     * Broadcast when an order is cancelled
     */
    broadcastOrderCancelled(data: {
        orderId: string;
        reason: string;
    }): void;
    /**
     * Broadcast when a pick is updated
     */
    broadcastPickUpdated(data: PickUpdatedEvent): void;
    /**
     * Broadcast when a pick is completed
     */
    broadcastPickCompleted(data: {
        orderId: string;
        orderItemId: string;
        pickerId: string;
    }): void;
    /**
     * Broadcast zone updates to users subscribed to that zone
     */
    broadcastZoneUpdated(data: ZoneUpdatedEvent): void;
    /**
     * Broadcast picker assignment/unassignment from zone
     */
    broadcastZoneAssignment(data: {
        zoneId: string;
        pickerId: string;
        assigned: boolean;
    }): void;
    /**
     * Broadcast inventory updates
     */
    broadcastInventoryUpdated(data: {
        sku: string;
        binLocation: string;
        quantity: number;
    }): void;
    /**
     * Broadcast low stock alerts
     */
    broadcastInventoryLow(data: InventoryLowEvent): void;
    /**
     * Broadcast a notification to a specific user
     */
    broadcastNotification(data: NotificationEvent): void;
    /**
     * Broadcast a notification to all users
     */
    broadcastGlobalNotification(data: Omit<NotificationEvent, 'userId'>): void;
    /**
     * Broadcast user activity updates
     */
    broadcastUserActivity(data: {
        userId: string;
        status: string;
        currentView?: string;
        currentTask?: string;
    }): void;
    /**
     * Get number of connected clients
     */
    getConnectedCount(): number;
    /**
     * Get number of clients in a specific room
     */
    getRoomCount(room: string): number;
    /**
     * Get all room names and their client counts
     */
    getAllRoomCounts(): Map<string, number>;
}
/**
 * Broadcast an event without accessing the broadcaster instance
 * This is useful for calling from services that don't have direct access to the WebSocket server
 */
export declare function broadcastEvent<E extends keyof ServerToClientEvents>(_event: E, _data: Parameters<ServerToClientEvents[E]>[0], _room?: string): void;
//# sourceMappingURL=broadcaster.d.ts.map