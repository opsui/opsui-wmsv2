"use strict";
/**
 * NZC (NZ Couriers) API Service
 *
 * Handles integration with the NZC Sweetspot API for shipping rates,
 * shipment creation, and label generation.
 *
 * API Documentation: https://api.gosweetspot.com
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.nzcService = exports.NZCService = exports.NZCLabelFormat = void 0;
const logger_1 = require("../config/logger");
const config_1 = __importDefault(require("../config"));
/**
 * NZC Label Format options
 */
var NZCLabelFormat;
(function (NZCLabelFormat) {
    NZCLabelFormat["PNG_100X175"] = "LABEL_PNG_100X175";
    NZCLabelFormat["PNG_100X150"] = "LABEL_PNG_100X150";
    NZCLabelFormat["PDF_100X175"] = "LABEL_PDF_100X175";
    NZCLabelFormat["PDF"] = "LABEL_PDF";
})(NZCLabelFormat || (exports.NZCLabelFormat = NZCLabelFormat = {}));
// ============================================================================
// NZC SERVICE
// ============================================================================
class NZCService {
    baseUrl;
    apiKey;
    siteId;
    supportEmail;
    constructor() {
        this.baseUrl = config_1.default.nzc?.baseUrl || 'https://api.gosweetspot.com';
        this.apiKey = config_1.default.nzc?.apiKey || '';
        this.siteId = config_1.default.nzc?.siteId || '';
        this.supportEmail = config_1.default.nzc?.supportEmail || '';
        if (!this.apiKey || !this.siteId) {
            logger_1.logger.warn('NZC API credentials not configured. NZC integration will not work.');
        }
    }
    /**
     * Get request headers for NZC API
     */
    getHeaders() {
        return {
            'Content-Type': 'application/json',
            access_key: this.apiKey,
            site_id: this.siteId,
            supportemail: this.supportEmail,
        };
    }
    /**
     * Convert WMS Address to NZC Destination format
     * Note: Unused private method kept for API completeness
     */
    // @ts-ignore - Unused private method kept for API completeness
    _addressToNZCDestination(address) {
        return {
            Name: address.company || address.name || 'Customer',
            NameDisplay: address.company
                ? `${address.company} - ${address.city}`
                : `${address.name} - ${address.city}`,
            Address: {
                StreetAddress: address.addressLine1,
                Suburb: address.city,
                Postcode: address.postalCode,
                Country: address.country === 'NZ' ? 'NEW ZEALAND' : address.country,
                State: address.state || '',
            },
            ContactPerson: address.name,
            PhoneNumber: address.phone || '',
            Email: address.email || '',
        };
    }
    /**
     * Convert weight from lbs to kg (NZC uses kg)
     * Note: Unused private method kept for API completeness
     */
    // @ts-ignore - Unused private method kept for API completeness
    _lbsToKg(lbs) {
        return Math.round(lbs * 0.453592 * 100) / 100;
    }
    /**
     * Convert dimensions from inches to cm (NZC uses cm)
     * Note: Unused private method kept for API completeness
     */
    // @ts-ignore - Unused private method kept for API completeness
    _inchesToCm(inches) {
        return Math.round(inches * 2.54 * 10) / 10;
    }
    /**
     * Get shipping rates from NZC
     */
    async getRates(destination, packages) {
        try {
            const requestBody = {
                Destination: destination,
                Packages: packages,
            };
            logger_1.logger.info('[NZC] Fetching rates', {
                destination: destination.Name,
                packageCount: packages.length,
            });
            const response = await fetch(`${this.baseUrl}/api/rates`, {
                method: 'POST',
                headers: this.getHeaders(),
                body: JSON.stringify(requestBody),
            });
            if (!response.ok) {
                const errorText = await response.text();
                logger_1.logger.error('[NZC] Rate request failed', {
                    status: response.status,
                    error: errorText,
                });
                throw new Error(`NZC API error: ${response.status} ${response.statusText}`);
            }
            const data = (await response.json());
            // Log validation errors if any
            if (data.ValidationErrors && Object.keys(data.ValidationErrors).length > 0) {
                logger_1.logger.warn('[NZC] Rate validation errors', data.ValidationErrors);
            }
            // Log rejected quotes if any
            if (data.Rejected && data.Rejected.length > 0) {
                logger_1.logger.warn('[NZC] Rejected quotes', data.Rejected);
            }
            logger_1.logger.info('[NZC] Rates fetched successfully', {
                quoteCount: data.Quotes.length,
                rejectedCount: data.Rejected.length,
            });
            return data;
        }
        catch (error) {
            logger_1.logger.error('[NZC] Error fetching rates', error);
            throw error;
        }
    }
    /**
     * Create a shipment with NZC
     */
    async createShipment(destination, packages, quoteId) {
        try {
            const requestBody = {
                Destination: destination,
                Packages: packages,
                QuoteId: quoteId,
            };
            logger_1.logger.info('[NZC] Creating shipment', {
                destination: destination.Name,
                quoteId,
                packageCount: packages.length,
            });
            const response = await fetch(`${this.baseUrl}/api/shipments`, {
                method: 'POST',
                headers: this.getHeaders(),
                body: JSON.stringify(requestBody),
            });
            if (!response.ok) {
                const errorText = await response.text();
                logger_1.logger.error('[NZC] Shipment creation failed', {
                    status: response.status,
                    error: errorText,
                });
                throw new Error(`NZC API error: ${response.status} ${response.statusText}`);
            }
            const data = (await response.json());
            logger_1.logger.info('[NZC] Shipment created successfully', {
                consignmentNo: data.ConsignmentNo,
                consignmentId: data.ConsignmentId,
            });
            return data;
        }
        catch (error) {
            logger_1.logger.error('[NZC] Error creating shipment', error);
            throw error;
        }
    }
    /**
     * Get shipping label as base64 data
     */
    async getLabel(connote, format = NZCLabelFormat.PNG_100X175) {
        try {
            logger_1.logger.info('[NZC] Fetching label', { connote, format });
            const response = await fetch(`${this.baseUrl}/api/labels?format=${format}&connote=${encodeURIComponent(connote)}`, {
                method: 'GET',
                headers: this.getHeaders(),
            });
            if (!response.ok) {
                const errorText = await response.text();
                logger_1.logger.error('[NZC] Label fetch failed', {
                    status: response.status,
                    error: errorText,
                });
                throw new Error(`NZC API error: ${response.status} ${response.statusText}`);
            }
            const contentType = response.headers.get('content-type') || 'image/png';
            const buffer = await response.arrayBuffer();
            const base64 = Buffer.from(buffer).toString('base64');
            logger_1.logger.info('[NZC] Label fetched successfully', {
                connote,
                contentType,
                size: buffer.byteLength,
            });
            return {
                data: base64,
                contentType,
                format,
            };
        }
        catch (error) {
            logger_1.logger.error('[NZC] Error fetching label', error);
            throw error;
        }
    }
    /**
     * Requeue shipment for printing (simpler print method)
     */
    async reprintLabel(connote, copies = 1, printerName) {
        try {
            logger_1.logger.info('[NZC] Reprinting label', { connote, copies, printerName });
            const requestBody = printerName ? { copies, printtoprinter: printerName } : { copies };
            const response = await fetch(`${this.baseUrl}/api/labels?connote=${encodeURIComponent(connote)}`, {
                method: 'POST',
                headers: this.getHeaders(),
                body: JSON.stringify(requestBody),
            });
            if (!response.ok) {
                const errorText = await response.text();
                logger_1.logger.error('[NZC] Label reprint failed', {
                    status: response.status,
                    error: errorText,
                });
                throw new Error(`NZC API error: ${response.status} ${response.statusText}`);
            }
            logger_1.logger.info('[NZC] Label reprinted successfully', { connote, copies });
        }
        catch (error) {
            logger_1.logger.error('[NZC] Error reprinting label', error);
            throw error;
        }
    }
    /**
     * Get available printers from NZC
     */
    async getPrinters() {
        try {
            logger_1.logger.info('[NZC] Fetching available printers');
            const response = await fetch(`${this.baseUrl}/api/printers`, {
                method: 'GET',
                headers: this.getHeaders(),
            });
            if (!response.ok) {
                const errorText = await response.text();
                logger_1.logger.error('[NZC] Printers fetch failed', {
                    status: response.status,
                    error: errorText,
                });
                throw new Error(`NZC API error: ${response.status} ${response.statusText}`);
            }
            const data = (await response.json());
            logger_1.logger.info('[NZC] Printers fetched successfully', { count: data.length });
            return data;
        }
        catch (error) {
            logger_1.logger.error('[NZC] Error fetching printers', error);
            throw error;
        }
    }
    /**
     * Get available stock sizes from NZC
     */
    async getStockSizes() {
        try {
            logger_1.logger.info('[NZC] Fetching stock sizes');
            const response = await fetch(`${this.baseUrl}/api/stocksizes`, {
                method: 'GET',
                headers: this.getHeaders(),
            });
            if (!response.ok) {
                const errorText = await response.text();
                logger_1.logger.error('[NZC] Stock sizes fetch failed', {
                    status: response.status,
                    error: errorText,
                });
                throw new Error(`NZC API error: ${response.status} ${response.statusText}`);
            }
            const data = (await response.json());
            logger_1.logger.info('[NZC] Stock sizes fetched successfully', { count: data.length });
            return data;
        }
        catch (error) {
            logger_1.logger.error('[NZC] Error fetching stock sizes', error);
            throw error;
        }
    }
}
exports.NZCService = NZCService;
// Export singleton instance
exports.nzcService = new NZCService();
//# sourceMappingURL=NZCService.js.map