"use strict";
/**
 * Wave Picking Routes
 *
 * API endpoints for wave picking operations
 */
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const auth_1 = require("../middleware/auth");
const auth_2 = require("../middleware/auth");
const WavePickingService_1 = require("../services/WavePickingService");
const logger_1 = require("../config/logger");
const shared_1 = require("@opsui/shared");
const router = (0, express_1.Router)();
/**
 * POST /api/v1/waves/create
 * Create a new wave based on criteria
 */
router.post('/create', auth_1.authenticate, async (req, res) => {
    try {
        const criteria = req.body;
        // Validate required fields
        if (!criteria.strategy) {
            res.status(400).json({
                error: 'Missing required field',
                message: 'strategy is required',
            });
            return;
        }
        const context = {
            userId: req.user?.userId,
            userEmail: req.user?.email,
            userRole: req.user?.role,
            ipAddress: req.ip,
            userAgent: req.get('user-agent'),
            requestId: req.id,
        };
        const wave = await WavePickingService_1.wavePickingService.createWave(criteria, context);
        res.status(201).json({
            success: true,
            message: 'Wave created successfully',
            data: wave,
        });
    }
    catch (error) {
        logger_1.logger.error('Wave creation error', { error });
        res.status(500).json({
            error: 'Wave creation failed',
            message: error.message,
        });
    }
});
/**
 * POST /api/v1/waves/:waveId/release
 * Release a wave (make it active for picking)
 */
router.post('/:waveId/release', auth_1.authenticate, (0, auth_2.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR), async (req, res) => {
    try {
        const { waveId } = req.params;
        const context = {
            userId: req.user?.userId,
            userEmail: req.user?.email,
            userRole: req.user?.role,
            ipAddress: req.ip,
            userAgent: req.get('user-agent'),
            requestId: req.id,
        };
        const wave = await WavePickingService_1.wavePickingService.releaseWave(waveId, context);
        res.json({
            success: true,
            message: 'Wave released successfully',
            data: wave,
        });
    }
    catch (error) {
        logger_1.logger.error('Wave release error', { error });
        res.status(500).json({
            error: 'Wave release failed',
            message: error.message,
        });
    }
});
/**
 * GET /api/v1/waves/:waveId/status
 * Get wave status and progress
 */
router.get('/:waveId/status', auth_1.authenticate, async (req, res) => {
    try {
        const { waveId } = req.params;
        const status = await WavePickingService_1.wavePickingService.getWaveStatus(waveId);
        if (!status) {
            res.status(404).json({
                error: 'Wave not found',
                message: `Wave ${waveId} not found`,
            });
            return;
        }
        res.json({
            success: true,
            data: status,
        });
    }
    catch (error) {
        logger_1.logger.error('Wave status error', { error });
        res.status(500).json({
            error: 'Failed to get wave status',
            message: error.message,
        });
    }
});
/**
 * GET /api/v1/waves/picker/:pickerId
 * Get active waves for a picker
 */
router.get('/picker/:pickerId', auth_1.authenticate, async (req, res) => {
    try {
        const { pickerId } = req.params;
        const waves = await WavePickingService_1.wavePickingService.getActiveWavesForPicker(pickerId);
        res.json({
            success: true,
            data: waves,
        });
    }
    catch (error) {
        logger_1.logger.error('Get picker waves error', { error });
        res.status(500).json({
            error: 'Failed to get picker waves',
            message: error.message,
        });
    }
});
/**
 * POST /api/v1/waves/:waveId/complete
 * Mark a wave as completed
 */
router.post('/:waveId/complete', auth_1.authenticate, (0, auth_2.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR), async (req, res) => {
    try {
        const { waveId } = req.params;
        const context = {
            userId: req.user?.userId,
            userEmail: req.user?.email,
            userRole: req.user?.role,
            ipAddress: req.ip,
            userAgent: req.get('user-agent'),
            requestId: req.id,
        };
        await WavePickingService_1.wavePickingService.completeWave(waveId, context);
        res.json({
            success: true,
            message: 'Wave marked as completed',
        });
    }
    catch (error) {
        logger_1.logger.error('Wave completion error', { error });
        res.status(500).json({
            error: 'Wave completion failed',
            message: error.message,
        });
    }
});
/**
 * GET /api/v1/waves/strategies
 * Get available wave strategies
 */
router.get('/strategies', auth_1.authenticate, (_req, res) => {
    res.json({
        success: true,
        data: {
            strategies: [
                {
                    id: WavePickingService_1.WaveStrategy.CARRIER,
                    name: 'Carrier-based',
                    description: 'Group orders by shipping carrier to meet cutoff times',
                },
                {
                    id: WavePickingService_1.WaveStrategy.PRIORITY,
                    name: 'Priority-based',
                    description: 'Group orders by priority level',
                },
                {
                    id: WavePickingService_1.WaveStrategy.ZONE,
                    name: 'Zone-based',
                    description: 'Group orders by warehouse zone proximity',
                },
                {
                    id: WavePickingService_1.WaveStrategy.DEADLINE,
                    name: 'Deadline-based',
                    description: 'Group orders by delivery deadline',
                },
                {
                    id: WavePickingService_1.WaveStrategy.SKU_COMPATIBILITY,
                    name: 'SKU Compatibility',
                    description: 'Group orders with shared SKUs for efficient picking',
                },
                {
                    id: WavePickingService_1.WaveStrategy.BALANCED,
                    name: 'Balanced',
                    description: 'Balance multiple criteria for optimal efficiency',
                },
            ],
        },
    });
});
exports.default = router;
//# sourceMappingURL=waves.js.map