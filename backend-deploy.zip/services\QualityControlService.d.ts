/**
 * Quality Control Service
 *
 * Handles quality inspections, checklists, and return authorizations
 */
import { QualityInspection, InspectionChecklist, InspectionResult, ReturnAuthorization, CreateInspectionDTO, UpdateInspectionStatusDTO, CreateReturnAuthorizationDTO, InspectionStatus, InspectionType } from '@opsui/shared';
export declare class QualityControlService {
    /**
     * Create an inspection checklist
     */
    createInspectionChecklist(data: {
        checklistName: string;
        description?: string;
        inspectionType: InspectionType;
        sku?: string;
        category?: string;
        items: Array<{
            itemDescription: string;
            itemType: 'CHECKBOX' | 'TEXT' | 'NUMBER' | 'PHOTO' | 'PASS_FAIL';
            isRequired: boolean;
            displayOrder: number;
            options?: string[];
        }>;
        createdBy: string;
    }): Promise<InspectionChecklist>;
    /**
     * Get inspection checklist by ID
     */
    getInspectionChecklist(checklistId: string): Promise<InspectionChecklist>;
    /**
     * Get all inspection checklists
     */
    getAllInspectionChecklists(filters?: {
        inspectionType?: InspectionType;
        sku?: string;
        category?: string;
        activeOnly?: boolean;
    }): Promise<InspectionChecklist[]>;
    /**
     * Create a quality inspection
     */
    createInspection(dto: CreateInspectionDTO): Promise<QualityInspection>;
    /**
     * Get quality inspection by ID
     */
    getQualityInspection(inspectionId: string): Promise<QualityInspection>;
    /**
     * Get all quality inspections with optional filters
     */
    getAllQualityInspections(filters?: {
        status?: InspectionStatus;
        inspectionType?: InspectionType;
        referenceType?: string;
        referenceId?: string;
        sku?: string;
        inspectorId?: string;
        limit?: number;
        offset?: number;
    }): Promise<{
        inspections: QualityInspection[];
        total: number;
    }>;
    /**
     * Update inspection status (complete inspection)
     */
    updateInspectionStatus(dto: UpdateInspectionStatusDTO): Promise<QualityInspection>;
    /**
     * Start an inspection
     */
    startInspection(inspectionId: string): Promise<QualityInspection>;
    /**
     * Save inspection result (checklist item result)
     */
    saveInspectionResult(data: {
        inspectionId: string;
        checklistItemId: string;
        result: string;
        passed: boolean;
        notes?: string;
        imageUrl?: string;
    }): Promise<InspectionResult>;
    /**
     * Get inspection results for an inspection
     */
    getInspectionResults(inspectionId: string): Promise<InspectionResult[]>;
    /**
     * Create a return authorization
     */
    createReturnAuthorization(dto: CreateReturnAuthorizationDTO): Promise<ReturnAuthorization>;
    /**
     * Get return authorization by ID
     */
    getReturnAuthorization(returnId: string): Promise<ReturnAuthorization>;
    /**
     * Get all return authorizations with optional filters
     */
    getAllReturnAuthorizations(filters?: {
        status?: string;
        orderId?: string;
        customerId?: string;
        limit?: number;
        offset?: number;
    }): Promise<{
        returns: ReturnAuthorization[];
        total: number;
    }>;
    /**
     * Update return authorization status
     */
    updateReturnAuthorizationStatus(returnId: string, status: string, userId?: string): Promise<ReturnAuthorization>;
    private mapRowToChecklist;
    private mapRowToChecklistItem;
    private mapRowToInspection;
    private mapRowToInspectionResult;
    private mapRowToReturnAuthorization;
    private mapRowToReturnItem;
}
export declare const qualityControlService: QualityControlService;
//# sourceMappingURL=QualityControlService.d.ts.map