/**
 * Business Rules API Routes
 *
 * REST API for managing business rules, viewing execution logs,
 * and testing rule conditions.
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=businessRules.d.ts.map