/**
 * Production Management Routes
 *
 * API endpoints for production orders, BOMs, and manufacturing workflows
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=production.d.ts.map