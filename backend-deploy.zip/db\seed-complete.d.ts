/**
 * Complete Database Seed
 *
 * This script seeds all essential data:
 * 1. Users (pickers, packers, admins)
 * 2. SKUs
 * 3. Orders
 * 4. Order Items
 */
import 'dotenv/config';
//# sourceMappingURL=seed-complete.d.ts.map