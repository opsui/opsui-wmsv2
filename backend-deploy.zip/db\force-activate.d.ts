/**
 * Force activate all users using pg directly
 */
export {};
//# sourceMappingURL=force-activate.d.ts.map