/**
 * Run location capacity tables migration
 *
 * Creates the location_capacities, capacity_rules, and capacity_alerts tables
 */
declare function runLocationCapacityMigration(): Promise<void>;
export { runLocationCapacityMigration };
//# sourceMappingURL=run-location-capacity-migration.d.ts.map