/**
 * Jest Test Setup
 *
 * Configures the test environment for all test suites.
 */
declare global {
    namespace jest {
        interface Matchers<R> {
            toBeValidUUID(): R;
            toBeValidISODate(): R;
            toHaveErrorMessage(message: string): R;
        }
    }
}
export {};
//# sourceMappingURL=setup.d.ts.map