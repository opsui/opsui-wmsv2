/**
 * Test the getPickerOrders query
 */
export {};
//# sourceMappingURL=test-picker-orders-api.d.ts.map