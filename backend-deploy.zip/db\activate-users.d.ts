/**
 * Activate all users
 */
export {};
//# sourceMappingURL=activate-users.d.ts.map