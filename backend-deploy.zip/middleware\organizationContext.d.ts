/**
 * Organization Context Middleware
 *
 * Handles organization context for multi-tenant requests.
 * Extracts organization from header, token, or user's default.
 * Validates user has access to the organization.
 */
import { NextFunction, Response } from 'express';
import { AuthenticatedRequest } from './auth';
/**
 * Extract and validate organization context
 *
 * Organization can be specified via:
 * 1. X-Organization-ID header (explicit)
 * 2. JWT token organizationId field
 * 3. User's default organization (from database)
 *
 * Sets req.organizationId for use in downstream handlers
 */
export declare function organizationContext(req: AuthenticatedRequest, _res: Response, next: NextFunction): Promise<void>;
/**
 * Require organization context
 * Returns 400 if no organization is set
 */
export declare function requireOrganization(req: AuthenticatedRequest, res: Response, next: NextFunction): void;
/**
 * Validate user has access to the organization
 * Must be used after organizationContext
 */
export declare function validateOrganizationAccess(req: AuthenticatedRequest, _res: Response, next: NextFunction): Promise<void>;
/**
 * Require organization and validate access
 * Combines requireOrganization and validateOrganizationAccess
 */
export declare function requireOrganizationAccess(req: AuthenticatedRequest, _res: Response, next: NextFunction): Promise<void>;
/**
 * Organization role check middleware factory
 */
export declare function requireOrganizationRole(...allowedRoles: string[]): (req: AuthenticatedRequest, res: Response, next: NextFunction) => Promise<void>;
/**
 * Organization permission check middleware factory
 */
export declare function requireOrganizationPermission(permission: 'canManageUsers' | 'canManageBilling' | 'canManageSettings' | 'canInviteUsers'): (req: AuthenticatedRequest, res: Response, next: NextFunction) => Promise<void>;
/**
 * Get organization ID from request
 * Utility for use in route handlers
 */
export declare function getOrganizationId(req: AuthenticatedRequest): string | null;
/**
 * Get organization ID or throw
 * Use when organization is required
 */
export declare function getOrganizationIdOrThrow(req: AuthenticatedRequest): string;
//# sourceMappingURL=organizationContext.d.ts.map