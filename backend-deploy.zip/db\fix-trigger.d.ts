/**
 * Fix enum casting in trigger
 */
export {};
//# sourceMappingURL=fix-trigger.d.ts.map