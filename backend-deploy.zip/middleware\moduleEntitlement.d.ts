/**
 * Module Entitlement Middleware
 *
 * Checks if a module is enabled for the current entity before allowing access
 * Integrates with the existing auth middleware
 */
import { Response, NextFunction } from 'express';
import { AuthenticatedRequest } from './auth';
import { ModuleId } from '@opsui/shared';
export interface ModuleEntitlementRequest extends AuthenticatedRequest {
    enabledModules?: ModuleId[];
}
/**
 * Middleware to check if a specific module is enabled
 */
export declare function requireModule(moduleId: ModuleId): (req: ModuleEntitlementRequest, _res: Response, next: NextFunction) => Promise<void>;
/**
 * Middleware to check if any of the specified modules are enabled
 */
export declare function requireAnyModule(...moduleIds: ModuleId[]): (req: ModuleEntitlementRequest, _res: Response, next: NextFunction) => Promise<void>;
/**
 * Middleware to check if all specified modules are enabled
 */
export declare function requireAllModules(...moduleIds: ModuleId[]): (req: ModuleEntitlementRequest, _res: Response, next: NextFunction) => Promise<void>;
/**
 * Automatic module detection middleware
 * Checks if the module associated with the current route is enabled
 */
export declare function checkModuleEntitlement(req: ModuleEntitlementRequest, _res: Response, next: NextFunction): void;
/**
 * Middleware to attach enabled modules to request without blocking
 * Useful for conditional UI rendering
 */
export declare function attachEnabledModules(req: ModuleEntitlementRequest, _res: Response, next: NextFunction): Promise<void>;
/**
 * Helper function to check if a module is enabled (for use in routes)
 */
export declare function checkModuleAccess(entityId: string, moduleId: ModuleId): Promise<{
    enabled: boolean;
    moduleName: string;
}>;
/**
 * Express middleware factory for route-specific module checking
 * Use this when defining routes to automatically gate them by module
 */
export declare function moduleGate(moduleId: ModuleId): (req: ModuleEntitlementRequest, _res: Response, next: NextFunction) => Promise<void>;
/**
 * Get the module ID that should be checked for a given path
 * Useful for frontend route configuration
 */
export declare function getRequiredModuleForPath(path: string): ModuleId | null;
/**
 * Check which modules are required for a set of routes
 */
export declare function getRequiredModulesForRoutes(routes: string[]): ModuleId[];
//# sourceMappingURL=moduleEntitlement.d.ts.map