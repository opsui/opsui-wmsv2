"use strict";
/**
 * Add shipping_carrier and shipping_method to orders table
 * This is needed for wave picking functionality
 */
Object.defineProperty(exports, "__esModule", { value: true });
const client_1 = require("./client");
async function addShippingColumnsToOrders() {
    console.log('Adding shipping columns to orders table...');
    try {
        // Add shipping_carrier column
        await (0, client_1.query)(`
      ALTER TABLE orders
      ADD COLUMN IF NOT EXISTS shipping_carrier VARCHAR(50)
    `);
        console.log('✓ Added shipping_carrier column');
        // Add shipping_method column
        await (0, client_1.query)(`
      ALTER TABLE orders
      ADD COLUMN IF NOT EXISTS shipping_method VARCHAR(50) DEFAULT 'STANDARD'
    `);
        console.log('✓ Added shipping_method column');
        console.log('Migration completed successfully!');
    }
    catch (error) {
        console.error('✗ Migration failed:', error.message);
        throw error;
    }
}
addShippingColumnsToOrders()
    .then(() => {
    console.log('Done! Exiting...');
    process.exit(0);
})
    .catch(error => {
    console.error('Fatal error:', error);
    process.exit(1);
});
//# sourceMappingURL=add-shipping-columns-to-orders.js.map