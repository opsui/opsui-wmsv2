/**
 * Automation routes
 *
 * Endpoints for ASRS, robots, drones, and other automation systems integration
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=automation.d.ts.map