/**
 * Migration: Add is_active column to users table
 *
 * This column tracks whether a user is currently active (tab open/focused)
 * independent of current_view and current_view_updated_at
 */
export {};
//# sourceMappingURL=add-is-active-column.d.ts.map