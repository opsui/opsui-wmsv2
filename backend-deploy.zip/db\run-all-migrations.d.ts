/**
 * Comprehensive Migration Runner - Apply all pending migrations
 *
 * Uses pg library directly to run migrations without requiring psql CLI.
 *
 * Usage:
 *   npx tsx src/db/run-all-migrations.ts
 *   npx tsx src/db/run-all-migrations.ts --dry-run
 */
import 'dotenv/config';
//# sourceMappingURL=run-all-migrations.d.ts.map