/**
 * Audit Logs Routes
 *
 * Provides access to comprehensive audit logs for SOC2/ISO27001 compliance
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=audit.d.ts.map