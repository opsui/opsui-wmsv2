/**
 * Business Rules Repository
 *
 * Handles database operations for business rules, conditions, actions,
 * and execution logs.
 */
import { BusinessRule, RuleExecutionLog, RuleStatus, RuleType, RuleEventType } from '@opsui/shared';
export declare class BusinessRulesRepository {
    /**
     * Get all business rules with optional filtering
     */
    findAll(filters?: {
        status?: RuleStatus;
        ruleType?: RuleType;
        includeInactive?: boolean;
    }): Promise<BusinessRule[]>;
    /**
     * Find a business rule by ID
     */
    findById(ruleId: string): Promise<BusinessRule | null>;
    /**
     * Create a new business rule
     */
    create(rule: Omit<BusinessRule, 'ruleId' | 'createdAt' | 'executionCount' | 'version'>): Promise<BusinessRule>;
    /**
     * Update an existing business rule
     */
    update(ruleId: string, updates: Partial<BusinessRule>): Promise<BusinessRule | null>;
    /**
     * Delete a business rule
     */
    delete(ruleId: string): Promise<boolean>;
    /**
     * Find all conditions for a rule
     */
    private findConditionsByRuleId;
    /**
     * Find all actions for a rule
     */
    private findActionsByRuleId;
    /**
     * Log rule execution
     */
    createExecutionLog(log: Omit<RuleExecutionLog, 'logId'>): Promise<RuleExecutionLog>;
    /**
     * Get execution logs for a rule
     */
    findExecutionLogs(ruleId: string, limit?: number): Promise<RuleExecutionLog[]>;
    /**
     * Find active rules for a specific event type
     */
    findActiveRulesByEventType(eventType: RuleEventType): Promise<BusinessRule[]>;
}
export declare const businessRulesRepository: BusinessRulesRepository;
//# sourceMappingURL=BusinessRulesRepository.d.ts.map