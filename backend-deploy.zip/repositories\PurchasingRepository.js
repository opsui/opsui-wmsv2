"use strict";
/**
 * Purchasing Repository
 *
 * Data access layer for purchasing operations
 * Handles purchase requisitions, RFQs, purchase orders, receipts,
 * three-way matching, vendor catalogs, and vendor performance
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.vendorScorecardRepository = exports.vendorPerformanceEventRepository = exports.vendorPerformanceSummaryRepository = exports.threeWayMatchRepository = exports.purchaseReceiptLineRepository = exports.purchaseReceiptRepository = exports.purchaseOrderLineRepository = exports.purchaseOrderHeaderRepository = exports.vendorItemCatalogRepository = exports.rfqResponseLineRepository = exports.rfqVendorResponseRepository = exports.rfqVendorRepository = exports.rfqLineRepository = exports.rfqHeaderRepository = exports.requisitionApprovalRepository = exports.purchaseRequisitionLineRepository = exports.purchaseRequisitionRepository = exports.VendorScorecardRepository = exports.VendorPerformanceEventRepository = exports.VendorPerformanceSummaryRepository = exports.ThreeWayMatchRepository = exports.PurchaseReceiptLineRepository = exports.PurchaseReceiptRepository = exports.PurchaseOrderLineRepository = exports.PurchaseOrderHeaderRepository = exports.VendorItemCatalogRepository = exports.RFQResponseLineRepository = exports.RFQVendorResponseRepository = exports.RFQVendorRepository = exports.RFQLineRepository = exports.RFQHeaderRepository = exports.RequisitionApprovalRepository = exports.PurchaseRequisitionLineRepository = exports.PurchaseRequisitionRepository = void 0;
const client_1 = require("../db/client");
const BaseRepository_1 = require("./BaseRepository");
// ============================================================================
// PURCHASE REQUISITION REPOSITORY
// ============================================================================
class PurchaseRequisitionRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super('purchase_requisitions', 'requisition_id');
    }
    // Find by number
    async findByNumber(requisitionNumber) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE requisition_number = $1`, [requisitionNumber]);
        return result.rows[0] || null;
    }
    // Find with details
    async findByIdWithDetails(requisitionId) {
        const requisition = await this.findById(requisitionId);
        if (!requisition)
            return null;
        const [requester, lines, approvals] = await Promise.all([
            (0, client_1.query)('SELECT user_id, email, first_name, last_name FROM users WHERE user_id = $1', [
                requisition.requested_by,
            ]),
            (0, client_1.query)('SELECT * FROM purchase_requisition_lines WHERE requisition_id = $1 ORDER BY line_number', [requisitionId]),
            (0, client_1.query)('SELECT * FROM requisition_approvals WHERE requisition_id = $1 ORDER BY approval_level', [requisitionId]),
        ]);
        const totalEstimatedCost = lines.rows.reduce((sum, line) => sum + (line.estimated_total_cost || 0), 0);
        return {
            ...requisition,
            requester: requester.rows[0] || {
                user_id: requisition.requested_by,
                email: '',
                first_name: '',
                last_name: '',
            },
            lines: lines.rows,
            approvals: approvals.rows,
            total_estimated_cost: totalEstimatedCost,
        };
    }
    // Query with filters
    async queryWithFilters(filters) {
        const conditions = [];
        const params = [];
        let paramIndex = 1;
        if (filters.entity_id) {
            conditions.push(`entity_id = $${paramIndex++}`);
            params.push(filters.entity_id);
        }
        if (filters.requested_by) {
            conditions.push(`requested_by = $${paramIndex++}`);
            params.push(filters.requested_by);
        }
        if (filters.department) {
            conditions.push(`department = $${paramIndex++}`);
            params.push(filters.department);
        }
        if (filters.approval_status) {
            conditions.push(`approval_status = $${paramIndex++}`);
            params.push(filters.approval_status);
        }
        if (filters.date_from) {
            conditions.push(`request_date >= $${paramIndex++}`);
            params.push(filters.date_from);
        }
        if (filters.date_to) {
            conditions.push(`request_date <= $${paramIndex++}`);
            params.push(filters.date_to);
        }
        if (filters.required_by_from) {
            conditions.push(`required_by >= $${paramIndex++}`);
            params.push(filters.required_by_from);
        }
        if (filters.required_by_to) {
            conditions.push(`required_by <= $${paramIndex++}`);
            params.push(filters.required_by_to);
        }
        if (filters.job_number) {
            conditions.push(`job_number = $${paramIndex++}`);
            params.push(filters.job_number);
        }
        if (filters.search) {
            conditions.push(`(requisition_number ILIKE $${paramIndex++} OR justification ILIKE $${paramIndex++})`);
            params.push(`%${filters.search}%`, `%${filters.search}%`);
        }
        const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';
        const sql = `SELECT * FROM ${this.tableName} ${whereClause} ORDER BY request_date DESC`;
        const result = await (0, client_1.query)(sql, params);
        return result.rows;
    }
    // Find pending approvals
    async findPendingApprovals() {
        const result = await (0, client_1.query)(`SELECT pr.* FROM ${this.tableName} pr
       JOIN users u ON u.user_id = pr.requested_by
       WHERE pr.approval_status IN ('SUBMITTED', 'PENDING_APPROVAL')
       ORDER BY pr.required_by ASC`);
        const requisitions = await Promise.all(result.rows.map(async (row) => this.findByIdWithDetails(row.requisition_id)));
        return requisitions.filter((r) => r !== null);
    }
    // Find by job number
    async findByJobNumber(jobNumber) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE job_number = $1 ORDER BY request_date DESC`, [jobNumber]);
        return result.rows;
    }
    // Count by status
    async countByStatus() {
        const result = await (0, client_1.query)(`SELECT approval_status, COUNT(*) as count FROM ${this.tableName} GROUP BY approval_status`);
        return result.rows.reduce((acc, row) => {
            acc[row.approval_status] = parseInt(row.count, 10);
            return acc;
        }, {});
    }
}
exports.PurchaseRequisitionRepository = PurchaseRequisitionRepository;
// ============================================================================
// PURCHASE REQUISITION LINE REPOSITORY
// ============================================================================
class PurchaseRequisitionLineRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super('purchase_requisition_lines', 'line_id');
    }
    // Find by requisition
    async findByRequisition(requisitionId) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE requisition_id = $1 ORDER BY line_number`, [requisitionId]);
        return result.rows;
    }
    // Get next line number
    async getNextLineNumber(requisitionId) {
        const result = await (0, client_1.query)(`SELECT COALESCE(MAX(line_number), 0) + 1 as max_line_number FROM ${this.tableName} WHERE requisition_id = $1`, [requisitionId]);
        return parseInt(result.rows[0].max_line_number, 10);
    }
    // Delete by requisition
    async deleteByRequisition(requisitionId) {
        const result = await (0, client_1.query)(`DELETE FROM ${this.tableName} WHERE requisition_id = $1`, [
            requisitionId,
        ]);
        return result.rowCount || 0;
    }
}
exports.PurchaseRequisitionLineRepository = PurchaseRequisitionLineRepository;
// ============================================================================
// REQUISITION APPROVAL REPOSITORY
// ============================================================================
class RequisitionApprovalRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super('requisition_approvals', 'approval_id');
    }
    // Find by requisition
    async findByRequisition(requisitionId) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE requisition_id = $1 ORDER BY approval_level`, [requisitionId]);
        return result.rows;
    }
    // Find pending approvals for user
    async findPendingForUser(userId) {
        const result = await (0, client_1.query)(`SELECT ra.* FROM ${this.tableName} ra
       JOIN purchase_requisitions pr ON pr.requisition_id = ra.requisition_id
       WHERE ra.approver_id = $1
       AND ra.approval_status = 'PENDING'
       AND pr.approval_status IN ('SUBMITTED', 'PENDING_APPROVAL')
       ORDER BY pr.required_by ASC`, [userId]);
        return result.rows;
    }
    // Check if all approvals completed
    async allApprovalsCompleted(requisitionId) {
        const result = await (0, client_1.query)(`SELECT CASE
         WHEN COUNT(*) = 0 OR COUNT(*) FILTER (WHERE approval_status = 'PENDING') > 0
         THEN 'false'
         ELSE 'true'
       END as completed
       FROM ${this.tableName}
       WHERE requisition_id = $1`, [requisitionId]);
        return result.rows[0].completed === 'true';
    }
}
exports.RequisitionApprovalRepository = RequisitionApprovalRepository;
// ============================================================================
// RFQ HEADER REPOSITORY
// ============================================================================
class RFQHeaderRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super('rfq_headers', 'rfq_id');
    }
    // Find by number
    async findByNumber(rfqNumber) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE rfq_number = $1`, [
            rfqNumber,
        ]);
        return result.rows[0] || null;
    }
    // Find with details
    async findByIdWithDetails(rfqId) {
        const rfq = await this.findById(rfqId);
        if (!rfq)
            return null;
        const [lines, vendors] = await Promise.all([
            (0, client_1.query)(`SELECT * FROM rfq_lines WHERE rfq_id = $1 ORDER BY line_number`, [rfqId]),
            (0, client_1.query)(`SELECT rv.*,
         COALESCE(vr.response_id, rv.status) as has_response
         FROM rfq_vendors rv
         LEFT JOIN rfq_vendor_responses vr ON vr.rfq_vendor_id = rv.rfq_vendor_id
         WHERE rv.rfq_id = $1`, [rfqId]),
        ]);
        // Count responses and find lowest bid
        const responseCount = await (0, client_1.query)(`SELECT COUNT(DISTINCT response_id) as count FROM rfq_vendor_responses WHERE rfq_id = $1`, [rfqId]);
        const lowestBid = await (0, client_1.query)(`SELECT MIN(grand_total) as grand_total FROM rfq_vendor_responses WHERE rfq_id = $1`, [rfqId]);
        return {
            ...rfq,
            lines: lines.rows,
            vendors: vendors.rows,
            response_count: parseInt(responseCount.rows[0]?.count || '0', 10),
            lowest_bid_amount: lowestBid.rows[0]?.grand_total
                ? parseFloat(lowestBid.rows[0].grand_total)
                : null,
        };
    }
    // Find by source
    async findBySource(sourceType, sourceId) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE source_type = $1 AND source_id = $2 ORDER BY created_date DESC`, [sourceType, sourceId]);
        return result.rows;
    }
    // Find pending response
    async findPendingResponse() {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE rfq_status IN ('SENT', 'RESPONSES_PENDING') ORDER BY quote_due_date ASC`);
        const rfqs = await Promise.all(result.rows.map(async (row) => this.findByIdWithDetails(row.rfq_id)));
        return rfqs.filter((r) => r !== null);
    }
    // Update status
    async updateStatus(rfqId, status) {
        return this.update(rfqId, { rfq_status: status });
    }
}
exports.RFQHeaderRepository = RFQHeaderRepository;
// ============================================================================
// RFQ LINE REPOSITORY
// ============================================================================
class RFQLineRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super('rfq_lines', 'line_id');
    }
    // Find by RFQ
    async findByRFQ(rfqId) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE rfq_id = $1 ORDER BY line_number`, [rfqId]);
        return result.rows;
    }
    // Get next line number
    async getNextLineNumber(rfqId) {
        const result = await (0, client_1.query)(`SELECT COALESCE(MAX(line_number), 0) + 1 as max_line_number FROM ${this.tableName} WHERE rfq_id = $1`, [rfqId]);
        return parseInt(result.rows[0].max_line_number, 10);
    }
}
exports.RFQLineRepository = RFQLineRepository;
// ============================================================================
// RFQ VENDOR REPOSITORY
// ============================================================================
class RFQVendorRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super('rfq_vendors', 'rfq_vendor_id');
    }
    // Find by RFQ
    async findByRFQ(rfqId) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE rfq_id = $1`, [
            rfqId,
        ]);
        return result.rows;
    }
    // Find pending responses
    async findPendingResponses() {
        const result = await (0, client_1.query)(`SELECT rv.* FROM ${this.tableName} rv
       JOIN rfq_headers rh ON rh.rfq_id = rv.rfq_id
       WHERE rv.status = 'PENDING'
       AND rh.rfq_status IN ('SENT', 'RESPONSES_PENDING')
       AND rh.quote_due_date >= CURRENT_DATE`);
        return result.rows;
    }
    // Update status
    async updateStatus(rfqVendorId, status) {
        return this.update(rfqVendorId, { status });
    }
}
exports.RFQVendorRepository = RFQVendorRepository;
// ============================================================================
// RFQ VENDOR RESPONSE REPOSITORY
// ============================================================================
class RFQVendorResponseRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super('rfq_vendor_responses', 'response_id');
    }
    // Find by RFQ
    async findByRFQ(rfqId) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE rfq_id = $1 ORDER BY response_date`, [rfqId]);
        return result.rows;
    }
    // Find by vendor
    async findByVendor(vendorId) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE vendor_id = $1 ORDER BY response_date DESC`, [vendorId]);
        return result.rows;
    }
    // Find with lines
    async findByIdWithLines(responseId) {
        const response = await this.findById(responseId);
        if (!response)
            return null;
        const lines = await (0, client_1.query)(`SELECT * FROM rfq_response_lines WHERE response_id = $1 ORDER BY line_number`, [responseId]);
        return {
            ...response,
            lines: lines.rows,
        };
    }
    // Find lowest bid for RFQ
    async findLowestBidForRFQ(rfqId) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName}
       WHERE rfq_id = $1
       ORDER BY grand_total ASC
       LIMIT 1`, [rfqId]);
        return result.rows[0] || null;
    }
}
exports.RFQVendorResponseRepository = RFQVendorResponseRepository;
// ============================================================================
// RFQ RESPONSE LINE REPOSITORY
// ============================================================================
class RFQResponseLineRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super('rfq_response_lines', 'response_line_id');
    }
    // Find by response
    async findByResponse(responseId) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE response_id = $1 ORDER BY line_number`, [responseId]);
        return result.rows;
    }
}
exports.RFQResponseLineRepository = RFQResponseLineRepository;
// ============================================================================
// VENDOR ITEM CATALOG REPOSITORY
// ============================================================================
class VendorItemCatalogRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super('vendor_item_catalogs', 'catalog_id');
    }
    // Find by vendor
    async findByVendor(vendorId, activeOnly = true) {
        const condition = activeOnly ? 'AND is_active = true' : '';
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE vendor_id = $1 ${condition} ORDER BY item_name`, [vendorId]);
        return result.rows;
    }
    // Find by internal SKU
    async findByInternalSKU(sku) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE internal_sku = $1 AND is_active = true`, [sku]);
        return result.rows;
    }
    // Find by vendor and vendor SKU
    async findByVendorSKU(vendorId, vendorSku) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE vendor_id = $1 AND vendor_sku = $2`, [vendorId, vendorSku]);
        return result.rows[0] || null;
    }
    // Find preferred vendors for SKU
    async findPreferredForSKU(sku) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE internal_sku = $1 AND is_preferred = true AND is_active = true`, [sku]);
        return result.rows;
    }
    // Find by entity
    async findByEntity(entityId) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE entity_id = $1 AND is_active = true`, [entityId]);
        return result.rows;
    }
}
exports.VendorItemCatalogRepository = VendorItemCatalogRepository;
// ============================================================================
// PURCHASE ORDER HEADER REPOSITORY
// ============================================================================
class PurchaseOrderHeaderRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super('purchase_order_headers', 'po_id');
    }
    // Find by number
    async findByNumber(poNumber) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE po_number = $1`, [poNumber]);
        return result.rows[0] || null;
    }
    // Find with details
    async findByIdWithDetails(poId) {
        const po = await this.findById(poId);
        if (!po)
            return null;
        const lines = await (0, client_1.query)(`SELECT * FROM purchase_order_lines WHERE po_id = $1 ORDER BY line_number`, [poId]);
        return {
            ...po,
            lines: lines.rows,
        };
    }
    // Find by vendor
    async findByVendor(vendorId) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE vendor_id = $1 ORDER BY order_date DESC`, [vendorId]);
        return result.rows;
    }
    // Find by source
    async findBySource(sourceType, sourceId) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE source_type = $1 AND source_id = $2 ORDER BY order_date DESC`, [sourceType, sourceId]);
        return result.rows;
    }
    // Find open orders
    async findOpenOrders() {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE po_status IN ('DRAFT', 'SUBMITTED', 'ACKNOWLEDGED', 'PARTIAL') ORDER BY order_date ASC`);
        return result.rows;
    }
    // Find orders with match exceptions
    async findWithMatchExceptions() {
        const result = await (0, client_1.query)(`SELECT DISTINCT poh.* FROM ${this.tableName} poh
       JOIN three_way_match_details twm ON twm.po_id = poh.po_id
       WHERE twm.is_match_ok = false
       OR ABS(twm.variance_percent) > twm.tolerance_percent
       ORDER BY poh.order_date DESC`);
        return result.rows;
    }
    // Update status
    async updateStatus(poId, status) {
        return this.update(poId, { po_status: status });
    }
    // Update three-way match status
    async updateThreeWayMatchStatus(poId, status) {
        return this.update(poId, { three_way_match_status: status });
    }
}
exports.PurchaseOrderHeaderRepository = PurchaseOrderHeaderRepository;
// ============================================================================
// PURCHASE ORDER LINE REPOSITORY
// ============================================================================
class PurchaseOrderLineRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super('purchase_order_lines', 'pol_id');
    }
    // Find by PO
    async findByPO(poId) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE po_id = $1 ORDER BY line_number`, [poId]);
        return result.rows;
    }
    // Find by SKU
    async findBySKU(sku) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE sku = $1`, [sku]);
        return result.rows;
    }
    // Get next line number
    async getNextLineNumber(poId) {
        const result = await (0, client_1.query)(`SELECT COALESCE(MAX(line_number), 0) + 1 as max_line_number FROM ${this.tableName} WHERE po_id = $1`, [poId]);
        return parseInt(result.rows[0].max_line_number, 10);
    }
    // Update received quantity
    async updateReceivedQuantity(polId, quantityReceived) {
        const result = await (0, client_1.query)(`UPDATE ${this.tableName}
       SET quantity_received = $1,
           updated_at = NOW()
       WHERE pol_id = $2
       RETURNING *`, [quantityReceived, polId]);
        return result.rows[0] || null;
    }
    // Update three-way match status
    async updateThreeWayMatchStatus(polId, status) {
        const result = await (0, client_1.query)(`UPDATE ${this.tableName}
       SET three_way_match_status = $1,
           updated_at = NOW()
       WHERE pol_id = $2
       RETURNING *`, [status, polId]);
        return result.rows[0] || null;
    }
}
exports.PurchaseOrderLineRepository = PurchaseOrderLineRepository;
// ============================================================================
// PURCHASE RECEIPT REPOSITORY
// ============================================================================
class PurchaseReceiptRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super('purchase_receipts', 'receipt_id');
    }
    // Find by number
    async findByNumber(receiptNumber) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE receipt_number = $1`, [receiptNumber]);
        return result.rows[0] || null;
    }
    // Find with details
    async findByIdWithDetails(receiptId) {
        const receipt = await this.findById(receiptId);
        if (!receipt)
            return null;
        const lines = await (0, client_1.query)(`SELECT * FROM purchase_receipt_lines WHERE receipt_id = $1 ORDER BY line_number`, [receiptId]);
        return {
            ...receipt,
            lines: lines.rows,
        };
    }
    // Find by PO
    async findByPO(poId) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE po_id = $1 ORDER BY receipt_date DESC`, [poId]);
        return result.rows;
    }
    // Find by vendor
    async findByVendor(vendorId) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE vendor_id = $1 ORDER BY receipt_date DESC`, [vendorId]);
        return result.rows;
    }
    // Find by date range
    async findByDateRange(startDate, endDate) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE receipt_date BETWEEN $1 AND $2 ORDER BY receipt_date DESC`, [startDate, endDate]);
        return result.rows;
    }
    // Find open receipts (not fully put away)
    async findOpenReceipts() {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE receipt_status IN ('OPEN', 'PARTIALLY_PUTAWAY') ORDER BY receipt_date ASC`);
        return result.rows;
    }
}
exports.PurchaseReceiptRepository = PurchaseReceiptRepository;
// ============================================================================
// PURCHASE RECEIPT LINE REPOSITORY
// ============================================================================
class PurchaseReceiptLineRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super('purchase_receipt_lines', 'receipt_line_id');
    }
    // Find by receipt
    async findByReceipt(receiptId) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE receipt_id = $1 ORDER BY line_number`, [receiptId]);
        return result.rows;
    }
    // Find by PO line
    async findByPOLine(poLineId) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE po_line_id = $1 ORDER BY receipt_date DESC`, [poLineId]);
        return result.rows;
    }
    // Find by SKU
    async findBySKU(sku) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE sku = $1`, [sku]);
        return result.rows;
    }
    // Find by lot number
    async findByLotNumber(lotNumber) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE lot_number = $1`, [lotNumber]);
        return result.rows;
    }
    // Get next line number
    async getNextLineNumber(receiptId) {
        const result = await (0, client_1.query)(`SELECT COALESCE(MAX(line_number), 0) + 1 as max_line_number FROM ${this.tableName} WHERE receipt_id = $1`, [receiptId]);
        return parseInt(result.rows[0].max_line_number, 10);
    }
}
exports.PurchaseReceiptLineRepository = PurchaseReceiptLineRepository;
// ============================================================================
// THREE-WAY MATCH REPOSITORY
// ============================================================================
class ThreeWayMatchRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super('three_way_match_details', 'match_id');
    }
    // Find by PO
    async findByPO(poId) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE po_id = $1 ORDER BY created_at DESC`, [poId]);
        return result.rows;
    }
    // Find by PO line
    async findByPOLine(poLineId) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE po_line_id = $1 ORDER BY created_at DESC`, [poLineId]);
        return result.rows;
    }
    // Find by receipt
    async findByReceipt(receiptId) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE receipt_id = $1 ORDER BY created_at DESC`, [receiptId]);
        return result.rows;
    }
    // Find by invoice
    async findByInvoice(invoiceId) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE invoice_id = $1 ORDER BY created_at DESC`, [invoiceId]);
        return result.rows;
    }
    // Find exceptions
    async findExceptions() {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName}
       WHERE is_match_ok = false
       OR ABS(variance_percent) > tolerance_percent
       ORDER BY ABS(variance_percent) DESC`);
        return result.rows;
    }
    // Find pending invoice match
    async findPendingInvoiceMatch() {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName}
       WHERE match_status IN ('FULLY_RECEIVED', 'PENDING_INVOICE')
       ORDER BY created_at ASC`);
        return result.rows;
    }
    // Update match status
    async updateMatchStatus(matchId, status) {
        const result = await (0, client_1.query)(`UPDATE ${this.tableName}
       SET match_status = $1,
           updated_at = NOW()
       WHERE match_id = $2
       RETURNING *`, [status, matchId]);
        return result.rows[0] || null;
    }
    // Resolve variance
    async resolveVariance(matchId, resolved, resolutionNotes) {
        const result = await (0, client_1.query)(`UPDATE ${this.tableName}
       SET variance_resolved = $1,
           resolution_notes = $2,
           updated_at = NOW()
       WHERE match_id = $3
       RETURNING *`, [resolved, resolutionNotes || null, matchId]);
        return result.rows[0] || null;
    }
}
exports.ThreeWayMatchRepository = ThreeWayMatchRepository;
// ============================================================================
// VENDOR PERFORMANCE SUMMARY REPOSITORY
// ============================================================================
class VendorPerformanceSummaryRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super('vendor_performance_summary', 'performance_id');
    }
    // Find by vendor
    async findByVendor(vendorId) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE vendor_id = $1 ORDER BY period_start DESC`, [vendorId]);
        return result.rows;
    }
    // Find current period
    async findCurrentPeriod(vendorId) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName}
       WHERE vendor_id = $1
       AND period_start <= CURRENT_DATE
       AND period_end >= CURRENT_DATE
       LIMIT 1`, [vendorId]);
        return result.rows[0] || null;
    }
    // Find top performers
    async findTopPerformers(limit = 10, minRating = 4.0) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName}
       WHERE overall_rating >= $1
       ORDER BY overall_rating DESC, total_spend DESC
       LIMIT $2`, [minRating, limit]);
        return result.rows;
    }
    // Find vendors at risk
    async findVendorsAtRisk(maxRating = 2.5) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName}
       WHERE overall_rating <= $1
       OR overall_rank = 'CRITICAL'
       ORDER BY overall_rating ASC`, [maxRating]);
        return result.rows;
    }
    // Find by entity
    async findByEntity(entityId) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE entity_id = $1 ORDER BY overall_rating DESC`, [entityId]);
        return result.rows;
    }
    // Get vendor ranking
    async getVendorRanking(limit = 50) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName}
       WHERE overall_rating IS NOT NULL
       ORDER BY overall_rating DESC
       LIMIT $1`, [limit]);
        return result.rows;
    }
}
exports.VendorPerformanceSummaryRepository = VendorPerformanceSummaryRepository;
// ============================================================================
// VENDOR PERFORMANCE EVENT REPOSITORY
// ============================================================================
class VendorPerformanceEventRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super('vendor_performance_events', 'event_id');
    }
    // Find by vendor
    async findByVendor(vendorId, limit = 100) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE vendor_id = $1 ORDER BY event_date DESC LIMIT $2`, [vendorId, limit]);
        return result.rows;
    }
    // Find by category
    async findByCategory(vendorId, category) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName}
       WHERE vendor_id = $1 AND event_category = $2
       ORDER BY event_date DESC`, [vendorId, category]);
        return result.rows;
    }
    // Find unresolved
    async findUnresolved(vendorId) {
        const condition = vendorId ? 'AND vendor_id = $1' : '';
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE resolved = false ${condition} ORDER BY severity DESC, event_date ASC`, vendorId ? [vendorId] : []);
        return result.rows;
    }
    // Find by reference
    async findByReference(referenceType, referenceId) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName}
       WHERE reference_type = $1 AND reference_id = $2
       ORDER BY event_date DESC`, [referenceType, referenceId]);
        return result.rows;
    }
    // Update resolution
    async updateResolution(eventId, resolved, resolvedBy, resolutionNotes) {
        const result = await (0, client_1.query)(`UPDATE ${this.tableName}
       SET resolved = $1,
           resolved_by = $2,
           resolved_at = NOW(),
           resolution_notes = $3,
           updated_at = NOW()
       WHERE event_id = $4
       RETURNING *`, [resolved, resolvedBy, resolutionNotes || null, eventId]);
        return result.rows[0] || null;
    }
}
exports.VendorPerformanceEventRepository = VendorPerformanceEventRepository;
// ============================================================================
// VENDOR SCORECARD REPOSITORY
// ============================================================================
class VendorScorecardRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super('vendor_scorecards', 'scorecard_id');
    }
    // Find by vendor
    async findByVendor(vendorId) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE vendor_id = $1 ORDER BY review_period_end DESC`, [vendorId]);
        return result.rows;
    }
    // Find latest
    async findLatest(vendorId) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName}
       WHERE vendor_id = $1
       ORDER BY review_period_end DESC
       LIMIT 1`, [vendorId]);
        return result.rows[0] || null;
    }
    // Find pending approval
    async findPendingApproval() {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE status = 'SUBMITTED' ORDER BY review_date ASC`);
        return result.rows;
    }
    // Find by reviewer
    async findByReviewer(reviewerId) {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName} WHERE reviewed_by = $1 ORDER BY review_date DESC`, [reviewerId]);
        return result.rows;
    }
    // Update status
    async updateStatus(scorecardId, status) {
        return this.update(scorecardId, { status });
    }
    // Approve
    async approve(scorecardId, approvedBy) {
        const result = await (0, client_1.query)(`UPDATE ${this.tableName}
       SET status = 'APPROVED',
           approved_by = $1,
           approved_at = NOW(),
           updated_at = NOW()
       WHERE scorecard_id = $2
       RETURNING *`, [approvedBy, scorecardId]);
        return result.rows[0] || null;
    }
    // Find requiring development
    async findRequiringDevelopment() {
        const result = await (0, client_1.query)(`SELECT * FROM ${this.tableName}
       WHERE requires_development_plan = true
       AND (development_plan_approved IS NULL OR development_plan_approved = false)
       ORDER BY review_date DESC`);
        return result.rows;
    }
}
exports.VendorScorecardRepository = VendorScorecardRepository;
// ============================================================================
// REPOSITORY INSTANCES
// ============================================================================
exports.purchaseRequisitionRepository = new PurchaseRequisitionRepository();
exports.purchaseRequisitionLineRepository = new PurchaseRequisitionLineRepository();
exports.requisitionApprovalRepository = new RequisitionApprovalRepository();
exports.rfqHeaderRepository = new RFQHeaderRepository();
exports.rfqLineRepository = new RFQLineRepository();
exports.rfqVendorRepository = new RFQVendorRepository();
exports.rfqVendorResponseRepository = new RFQVendorResponseRepository();
exports.rfqResponseLineRepository = new RFQResponseLineRepository();
exports.vendorItemCatalogRepository = new VendorItemCatalogRepository();
exports.purchaseOrderHeaderRepository = new PurchaseOrderHeaderRepository();
exports.purchaseOrderLineRepository = new PurchaseOrderLineRepository();
exports.purchaseReceiptRepository = new PurchaseReceiptRepository();
exports.purchaseReceiptLineRepository = new PurchaseReceiptLineRepository();
exports.threeWayMatchRepository = new ThreeWayMatchRepository();
exports.vendorPerformanceSummaryRepository = new VendorPerformanceSummaryRepository();
exports.vendorPerformanceEventRepository = new VendorPerformanceEventRepository();
exports.vendorScorecardRepository = new VendorScorecardRepository();
//# sourceMappingURL=PurchasingRepository.js.map