/**
 * Maintenance & Assets Service
 *
 * Business logic for asset management and maintenance workflows
 */
import { Asset, MaintenanceSchedule, MaintenanceWorkOrder, ServiceLog, MeterReading, CreateAssetDTO, CreateMaintenanceScheduleDTO, CreateWorkOrderDTO, CompleteWorkOrderDTO, AddMeterReadingDTO, AssetStatus, MaintenanceStatus } from '@opsui/shared';
export declare class MaintenanceService {
    createAsset(dto: CreateAssetDTO, createdBy: string): Promise<Asset>;
    getAssetById(assetId: string): Promise<Asset>;
    getAllAssets(filters?: {
        status?: AssetStatus;
        type?: string;
        limit?: number;
        offset?: number;
    }): Promise<{
        assets: Asset[];
        total: number;
    }>;
    updateAsset(assetId: string, dto: Partial<Asset>, userId: string): Promise<Asset>;
    retireAsset(assetId: string, userId: string): Promise<Asset>;
    createSchedule(dto: CreateMaintenanceScheduleDTO, createdBy: string): Promise<MaintenanceSchedule>;
    getSchedulesByAsset(assetId: string): Promise<MaintenanceSchedule[]>;
    getUpcomingMaintenance(daysAhead?: number): Promise<MaintenanceSchedule[]>;
    createWorkOrder(dto: CreateWorkOrderDTO, createdBy: string): Promise<MaintenanceWorkOrder>;
    getWorkOrderById(workOrderId: string): Promise<MaintenanceWorkOrder>;
    getAllWorkOrders(filters?: {
        status?: MaintenanceStatus;
        assignedTo?: string;
        limit?: number;
        offset?: number;
    }): Promise<{
        workOrders: MaintenanceWorkOrder[];
        total: number;
    }>;
    startWorkOrder(workOrderId: string, userId: string): Promise<MaintenanceWorkOrder>;
    completeWorkOrder(workOrderId: string, dto: CompleteWorkOrderDTO, userId: string): Promise<MaintenanceWorkOrder>;
    getAssetServiceHistory(assetId: string, limit?: number): Promise<ServiceLog[]>;
    addServiceLog(log: Omit<ServiceLog, 'logId' | 'createdAt'>): Promise<ServiceLog>;
    addMeterReading(dto: AddMeterReadingDTO, userId: string): Promise<MeterReading>;
    getMeterReadingsByAsset(assetId: string, limit?: number): Promise<MeterReading[]>;
    getDashboardMetrics(): Promise<{
        openRequests: number;
        inProgress: number;
        completedToday: number;
        urgent: number;
        equipmentDown: number;
        equipmentNeedsService: number;
    }>;
    private checkMeterReadingForMaintenance;
}
export declare const maintenanceService: MaintenanceService;
//# sourceMappingURL=MaintenanceService.d.ts.map