"use strict";
/**
 * SKU catalog routes
 */
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const InventoryService_1 = require("../services/InventoryService");
const middleware_1 = require("../middleware");
const shared_1 = require("@opsui/shared");
const router = (0, express_1.Router)();
// All SKU routes require authentication
router.use(middleware_1.authenticate);
/**
 * GET /api/skus
 * Get all or search SKUs with pagination
 */
router.get('/', (0, middleware_1.asyncHandler)(async (req, res) => {
    const searchTerm = req.query.q;
    const page = parseInt(req.query.page) || 1;
    const pageSize = Math.min(parseInt(req.query.pageSize) || 20, 100);
    const sortBy = req.query.sortBy || 'sku';
    const sortOrder = req.query.sortOrder || 'asc';
    const category = req.query.category;
    const stockStatus = req.query.stockStatus;
    // Get all SKUs first
    let allSKUs = searchTerm
        ? await InventoryService_1.inventoryService.searchSKUs(searchTerm)
        : await InventoryService_1.inventoryService.getAllSKUs(1000);
    // Apply category filter
    if (category && category !== 'all') {
        allSKUs = allSKUs.filter((sku) => sku.category === category);
    }
    // Apply stock status filter
    if (stockStatus && stockStatus !== 'all') {
        allSKUs = allSKUs.filter((sku) => {
            const qty = sku.totalQuantity || 0;
            switch (stockStatus) {
                case 'in-stock':
                    return qty > 10;
                case 'low-stock':
                    return qty > 0 && qty <= 10;
                case 'out-of-stock':
                    return qty === 0;
                default:
                    return true;
            }
        });
    }
    // Apply sorting
    allSKUs.sort((a, b) => {
        let aVal = a[sortBy] ?? '';
        let bVal = b[sortBy] ?? '';
        if (typeof aVal === 'string')
            aVal = aVal.toLowerCase();
        if (typeof bVal === 'string')
            bVal = bVal.toLowerCase();
        if (aVal < bVal)
            return sortOrder === 'asc' ? -1 : 1;
        if (aVal > bVal)
            return sortOrder === 'asc' ? 1 : -1;
        return 0;
    });
    // Get unique categories for filter
    const categories = [...new Set(allSKUs.map((sku) => sku.category).filter(Boolean))];
    // Apply pagination
    const totalItems = allSKUs.length;
    const totalPages = Math.ceil(totalItems / pageSize);
    const startIndex = (page - 1) * pageSize;
    const paginatedData = allSKUs.slice(startIndex, startIndex + pageSize);
    res.json({
        data: paginatedData,
        pagination: {
            page,
            pageSize,
            totalItems,
            totalPages,
        },
        filters: {
            categories,
        },
    });
}));
/**
 * GET /api/skus/categories
 * Get all SKU categories
 */
router.get('/categories', (0, middleware_1.asyncHandler)(async (_req, res) => {
    const categories = await InventoryService_1.inventoryService.getCategories();
    res.json(categories);
}));
/**
 * GET /api/skus/:sku
 * Get SKU details with inventory
 */
router.get('/:sku', (0, middleware_1.asyncHandler)(async (req, res) => {
    (0, shared_1.validateSKU)(req.params.sku);
    const sku = await InventoryService_1.inventoryService.getSKUWithInventory(req.params.sku);
    res.json(sku);
}));
/**
 * POST /api/skus/:sku/reserve
 * Reserve inventory for an order (internal use, usually called automatically)
 */
router.post('/:sku/reserve', (0, middleware_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR), (0, middleware_1.asyncHandler)(async (req, res) => {
    if (!req.user) {
        res.status(401).json({ error: 'Not authenticated' });
        return;
    }
    (0, shared_1.validateSKU)(req.params.sku);
    const { binLocation, quantity, orderId } = req.body;
    if (!binLocation || !quantity || !orderId) {
        res.status(400).json({
            error: 'binLocation, quantity, and orderId are required',
            code: 'MISSING_FIELDS',
        });
        return;
    }
    const inventory = await InventoryService_1.inventoryService.reserveInventory(req.params.sku, binLocation, quantity, orderId);
    res.json(inventory);
}));
/**
 * POST /api/skus/:sku/release
 * Release inventory reservation
 */
router.post('/:sku/release', (0, middleware_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR), (0, middleware_1.asyncHandler)(async (req, res) => {
    if (!req.user) {
        res.status(401).json({ error: 'Not authenticated' });
        return;
    }
    (0, shared_1.validateSKU)(req.params.sku);
    const { binLocation, quantity, orderId } = req.body;
    if (!binLocation || !quantity || !orderId) {
        res.status(400).json({
            error: 'binLocation, quantity, and orderId are required',
            code: 'MISSING_FIELDS',
        });
        return;
    }
    const inventory = await InventoryService_1.inventoryService.releaseReservation(req.params.sku, binLocation, quantity, orderId);
    res.json(inventory);
}));
exports.default = router;
//# sourceMappingURL=skus.js.map