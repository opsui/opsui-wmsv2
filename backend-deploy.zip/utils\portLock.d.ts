/**
 * Port Locking Utility
 * Prevents duplicate server instances by acquiring exclusive port locks
 *
 * This ensures only ONE instance of each service can run on its designated port,
 * preventing conflicts, data races, and duplicate processes.
 */
interface PortLockFile {
    port: number;
    pid: number;
    host: string;
    acquiredAt: string;
    serviceName: string;
}
interface PortLockResult {
    acquired: boolean;
    port: number;
    reason?: string;
}
/**
 * Acquire a lock on a port
 */
export declare function acquirePortLock(port: number, serviceName: string, host?: string): Promise<PortLockResult>;
/**
 * Release a port lock
 */
export declare function releasePortLock(port: number): Promise<void>;
/**
 * Release all port locks for this process
 */
export declare function releaseAllPortLocks(): Promise<void>;
/**
 * Setup port lock cleanup on process exit
 */
export declare function setupPortLockCleanup(port: number): void;
/**
 * Check if a port is available before attempting to use it
 */
export declare function checkPortAvailable(port: number): Promise<boolean>;
/**
 * Get list of all locked ports
 */
export declare function getLockedPorts(): Promise<PortLockFile[]>;
/**
 * Kill process holding a port lock (DANGEROUS - use with caution)
 */
export declare function forceReleasePortLock(port: number): Promise<boolean>;
/**
 * Port registry - all service ports in one place
 * This is the SINGLE SOURCE OF TRUTH for port assignments
 */
export declare const SERVICE_PORTS: {
    readonly BACKEND_API: 3001;
    readonly FRONTEND_DEV: 5173;
    readonly WEBSOCKET: 3002;
    readonly ML_API: 8001;
    readonly MLFLOW: 5000;
    readonly POSTGRESQL: 5432;
    readonly REDIS: 6379;
    readonly PROMETHEUS: 9090;
    readonly GRAFANA: 3000;
    readonly JAEGER: 16686;
    readonly STORYBOOK: 6006;
    readonly CYPRESS: 8080;
};
export type ServicePort = keyof typeof SERVICE_PORTS;
export {};
//# sourceMappingURL=portLock.d.ts.map