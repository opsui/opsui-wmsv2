/**
 * Run user role assignments migration
 */
export {};
//# sourceMappingURL=run-role-migration.d.ts.map