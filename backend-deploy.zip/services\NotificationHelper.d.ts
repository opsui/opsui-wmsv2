/**
 * NotificationHelper Service
 * Provides notification functionality for various warehouse operations
 */
export declare enum NotificationType {
    INFO = "info",
    WARNING = "warning",
    ERROR = "error",
    SUCCESS = "success",
    EXCEPTION_REPORTED = "exception_reported",
    QUALITY_FAILED = "quality_failed",
    QUALITY_APPROVED = "quality_approved",
    ORDER_SHIPPED = "order_shipped",
    WAVE_CREATED = "wave_created",
    WAVE_COMPLETED = "wave_completed",
    ZONE_ASSIGNED = "zone_assigned"
}
export declare enum NotificationPriority {
    LOW = "low",
    NORMAL = "normal",
    MEDIUM = "medium",
    HIGH = "high",
    URGENT = "urgent"
}
export interface NotificationMessage {
    type: NotificationType | string;
    priority: NotificationPriority | string;
    title: string;
    message: string;
    timestamp?: Date;
    userId?: string;
    data?: unknown;
    exceptionId?: string;
    orderId?: string;
    description?: string;
}
/**
 * Send a notification to a specific user
 */
export declare function notifyUser(notification: NotificationMessage & {
    userId: string;
}): Promise<void>;
/**
 * Send a notification to all relevant users
 */
export declare function notifyAll(notification: NotificationMessage): Promise<void>;
/**
 * Broadcast an event to all connected clients
 */
export declare function broadcastEvent(event: string, _data: unknown): Promise<void>;
/**
 * Send exception notification
 */
export declare function notifyExceptionReported(notification: any): Promise<void>;
//# sourceMappingURL=NotificationHelper.d.ts.map