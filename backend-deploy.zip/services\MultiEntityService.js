"use strict";
/**
 * Multi-Entity Service
 *
 * Business logic for multi-company, multi-subsidiary ERP operations
 * Handles entity management, inter-company transactions, consolidation, and entity user assignments
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.multiEntityService = void 0;
const MultiEntityRepository_1 = require("../repositories/MultiEntityRepository");
const shared_1 = require("@opsui/shared");
// ============================================================================
// ID GENERATOR
// ============================================================================
function generateEntityId() {
    const timestamp = Date.now().toString(36).toUpperCase();
    const random = Math.random().toString(36).substring(2, 6).toUpperCase();
    return `ENT-${timestamp}-${random}`;
}
function generateTransactionId() {
    const timestamp = Date.now().toString(36).toUpperCase();
    const random = Math.random().toString(36).substring(2, 6).toUpperCase();
    return `ICT-${timestamp}-${random}`;
}
function generateRelationshipId() {
    const timestamp = Date.now().toString(36).toUpperCase();
    const random = Math.random().toString(36).substring(2, 6).toUpperCase();
    return `REL-${timestamp}-${random}`;
}
function generateEntityUserId() {
    const timestamp = Date.now().toString(36).toUpperCase();
    const random = Math.random().toString(36).substring(2, 6).toUpperCase();
    return `EUS-${timestamp}-${random}`;
}
function generateRuleId() {
    const timestamp = Date.now().toString(36).toUpperCase();
    const random = Math.random().toString(36).substring(2, 6).toUpperCase();
    return `CRULE-${timestamp}-${random}`;
}
function generateRateId() {
    const timestamp = Date.now().toString(36).toUpperCase();
    const random = Math.random().toString(36).substring(2, 6).toUpperCase();
    return `EER-${timestamp}-${random}`;
}
function generateAuditId() {
    const timestamp = Date.now().toString(36).toUpperCase();
    const random = Math.random().toString(36).substring(2, 6).toUpperCase();
    return `EADT-${timestamp}-${random}`;
}
// ============================================================================
// MULTI-ENTITY SERVICE
// ============================================================================
class MultiEntityService {
    // ==========================================================================
    // ENTITY MANAGEMENT
    // ==========================================================================
    /**
     * Get all entities with optional filters
     */
    async getEntities(filters = {}) {
        return await MultiEntityRepository_1.multiEntityRepository.entities.queryWithFilters(filters);
    }
    /**
     * Get entity by ID
     */
    async getEntityById(entityId) {
        const entity = await MultiEntityRepository_1.multiEntityRepository.entities.findByIdWithParent(entityId);
        if (!entity) {
            throw new shared_1.NotFoundError('Entity', entityId);
        }
        return entity;
    }
    /**
     * Get entity with hierarchy
     */
    async getEntityWithHierarchy(entityId) {
        const entity = await MultiEntityRepository_1.multiEntityRepository.entities.findByIdWithHierarchy(entityId);
        if (!entity) {
            throw new shared_1.NotFoundError('Entity', entityId);
        }
        return entity;
    }
    /**
     * Get entity hierarchy tree
     */
    async getEntityHierarchy(rootEntityId) {
        return await MultiEntityRepository_1.multiEntityRepository.entities.getHierarchyTree(rootEntityId);
    }
    /**
     * Create new entity
     */
    async createEntity(dto, createdBy) {
        // Check if code already exists
        const existing = await MultiEntityRepository_1.multiEntityRepository.entities.findByCode(dto.entity_code);
        if (existing) {
            throw new Error(`Entity code ${dto.entity_code} already exists`);
        }
        // Validate parent entity if provided
        if (dto.parent_entity_id) {
            const parent = await MultiEntityRepository_1.multiEntityRepository.entities.findById(dto.parent_entity_id);
            if (!parent) {
                throw new shared_1.NotFoundError('Parent Entity', dto.parent_entity_id);
            }
        }
        const entity_id = generateEntityId();
        const now = new Date();
        const entity = {
            entity_id,
            entity_code: dto.entity_code,
            entity_name: dto.entity_name,
            parent_entity_id: dto.parent_entity_id || null,
            entity_type: dto.entity_type,
            entity_status: shared_1.EntityStatus.ACTIVE,
            legal_name: dto.legal_name || null,
            tax_id: dto.tax_id || null,
            registration_number: dto.registration_number || null,
            base_currency: dto.base_currency || 'USD',
            address_line1: dto.address_line1 || null,
            address_line2: dto.address_line2 || null,
            city: dto.city || null,
            state_province: dto.state_province || null,
            postal_code: dto.postal_code || null,
            country_code: dto.country_code || null,
            phone: dto.phone || null,
            email: dto.email || null,
            website: dto.website || null,
            fiscal_year_start_month: dto.fiscal_year_start_month || 1,
            hierarchy_level: 0,
            sort_order: 0,
            is_active: true,
            created_at: now,
            updated_at: now,
            created_by: createdBy,
        };
        // Calculate hierarchy level based on parent
        if (entity.parent_entity_id) {
            const parent = await MultiEntityRepository_1.multiEntityRepository.entities.findById(entity.parent_entity_id);
            entity.hierarchy_level = (parent?.hierarchy_level || 0) + 1;
        }
        const created = await MultiEntityRepository_1.multiEntityRepository.entities.insert(entity);
        // Log audit
        await MultiEntityRepository_1.multiEntityRepository.auditLog.log(entity_id, 'ENTITY_CREATED', null, entity, createdBy);
        return created;
    }
    /**
     * Update entity
     */
    async updateEntity(entityId, dto, updatedBy) {
        const existing = await MultiEntityRepository_1.multiEntityRepository.entities.findByIdOrThrow(entityId);
        // Store old values for audit
        const oldValues = { ...existing };
        // Validate parent if changing
        if (dto.parent_entity_id !== undefined && dto.parent_entity_id !== entityId) {
            if (dto.parent_entity_id) {
                const parent = await MultiEntityRepository_1.multiEntityRepository.entities.findById(dto.parent_entity_id);
                if (!parent) {
                    throw new shared_1.NotFoundError('Parent Entity', dto.parent_entity_id);
                }
            }
        }
        const updated = (await MultiEntityRepository_1.multiEntityRepository.entities.update(entityId, {
            ...dto,
            updated_at: new Date(),
        }));
        // Log audit
        await MultiEntityRepository_1.multiEntityRepository.auditLog.log(entityId, 'ENTITY_UPDATED', oldValues, updated, updatedBy);
        return updated;
    }
    /**
     * Delete entity (soft delete)
     */
    async deleteEntity(entityId, deletedBy) {
        const entity = await MultiEntityRepository_1.multiEntityRepository.entities.findByIdOrThrow(entityId);
        // Check if entity has children
        const children = await MultiEntityRepository_1.multiEntityRepository.entities.findChildren(entityId);
        if (children.length > 0) {
            throw new Error('Cannot delete entity with child entities. Please reassign or delete children first.');
        }
        // Check if entity has active consolidation rules
        const rules = await MultiEntityRepository_1.multiEntityRepository.consolidation.findBySubsidiaryId(entityId);
        if (rules.length > 0) {
            throw new Error('Cannot delete entity with active consolidation rules.');
        }
        const result = await MultiEntityRepository_1.multiEntityRepository.entities.softDelete(entityId);
        if (result) {
            await MultiEntityRepository_1.multiEntityRepository.auditLog.log(entityId, 'ENTITY_DELETED', entity, null, deletedBy);
        }
        return result;
    }
    /**
     * Get entity subsidiaries
     */
    async getEntitySubsidiaries(entityId, includeChildren = true) {
        const entity = await MultiEntityRepository_1.multiEntityRepository.entities.findByIdOrThrow(entityId);
        return await MultiEntityRepository_1.multiEntityRepository.entities.findSubsidiaries(entityId, includeChildren);
    }
    // ==========================================================================
    // INTER-COMPANY TRANSACTIONS
    // ==========================================================================
    /**
     * Get inter-company transactions with filters
     */
    async getIntercompanyTransactions(filters = {}) {
        return await MultiEntityRepository_1.multiEntityRepository.intercompanyTransactions.queryWithFilters(filters);
    }
    /**
     * Get inter-company transaction by ID with details
     */
    async getIntercompanyTransactionById(transactionId) {
        const transaction = await MultiEntityRepository_1.multiEntityRepository.intercompanyTransactions.findByIdWithDetails(transactionId);
        if (!transaction) {
            throw new shared_1.NotFoundError('Inter-company Transaction', transactionId);
        }
        return transaction;
    }
    /**
     * Create inter-company transaction
     */
    async createIntercompanyTransaction(dto, createdBy) {
        // Validate entities
        const [fromEntity, toEntity] = await Promise.all([
            MultiEntityRepository_1.multiEntityRepository.entities.findByIdOrThrow(dto.from_entity_id),
            MultiEntityRepository_1.multiEntityRepository.entities.findByIdOrThrow(dto.to_entity_id),
        ]);
        // Calculate base currency amount if currencies differ
        let baseCurrencyAmount = dto.amount;
        let exchangeRate = 1.0;
        if (fromEntity.base_currency !== toEntity.base_currency) {
            // Get exchange rate or use 1.0 as default
            // In production, this would call a currency service
            exchangeRate = 1.0; // Placeholder
            baseCurrencyAmount = dto.amount * exchangeRate;
        }
        // Generate transaction number
        const transactionNumber = `ICT-${Date.now()}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`;
        const transaction_id = generateTransactionId();
        const now = new Date();
        const transaction = {
            transaction_id,
            transaction_number: transactionNumber,
            from_entity_id: dto.from_entity_id,
            to_entity_id: dto.to_entity_id,
            transaction_date: dto.transaction_date,
            transaction_type: dto.transaction_type,
            transaction_status: shared_1.IntercompanyTransactionStatus.PENDING,
            amount: dto.amount,
            currency: dto.currency || fromEntity.base_currency,
            exchange_rate: exchangeRate,
            base_currency_amount: baseCurrencyAmount,
            description: dto.description || null,
            reference_number: dto.reference_number || null,
            from_journal_entry_id: null,
            to_journal_entry_id: null,
            elimination_journal_id: null,
            approved_by: null,
            approved_at: null,
            notes: dto.notes || null,
            created_at: now,
            updated_at: now,
            created_by: createdBy,
        };
        return await MultiEntityRepository_1.multiEntityRepository.intercompanyTransactions.insert(transaction);
    }
    /**
     * Update inter-company transaction
     */
    async updateIntercompanyTransaction(transactionId, dto, updatedBy) {
        const existing = await MultiEntityRepository_1.multiEntityRepository.intercompanyTransactions.findByIdOrThrow(transactionId);
        // Check if transaction can be updated (only pending transactions)
        if (existing.transaction_status !== shared_1.IntercompanyTransactionStatus.PENDING) {
            throw new Error('Can only update pending transactions');
        }
        return (await MultiEntityRepository_1.multiEntityRepository.intercompanyTransactions.update(transactionId, {
            ...dto,
            updated_at: new Date(),
        }));
    }
    /**
     * Approve inter-company transaction
     */
    async approveIntercompanyTransaction(transactionId, approvedBy) {
        const transaction = await MultiEntityRepository_1.multiEntityRepository.intercompanyTransactions.findByIdOrThrow(transactionId);
        if (transaction.transaction_status !== shared_1.IntercompanyTransactionStatus.PENDING) {
            throw new Error('Transaction is not in pending status');
        }
        await MultiEntityRepository_1.multiEntityRepository.intercompanyTransactions.updateStatus(transactionId, shared_1.IntercompanyTransactionStatus.POSTED, approvedBy);
        return await MultiEntityRepository_1.multiEntityRepository.intercompanyTransactions.findByIdOrThrow(transactionId);
    }
    /**
     * Get inter-company transaction summary
     */
    async getIntercompanyTransactionSummary(filters = {}) {
        const transactions = await this.getIntercompanyTransactions(filters);
        const summary = {
            total_transactions: transactions.length,
            total_amount: transactions.reduce((sum, t) => sum + Number(t.amount), 0),
            by_type: {},
            by_status: {},
            pending_count: 0,
            pending_amount: 0,
        };
        // Initialize by_type and by_status
        for (const t of transactions) {
            summary.by_type[t.transaction_type] =
                (summary.by_type[t.transaction_type] || 0) + Number(t.amount);
            summary.by_status[t.transaction_status] = (summary.by_status[t.transaction_status] || 0) + 1;
            if (t.transaction_status === 'PENDING') {
                summary.pending_count++;
                summary.pending_amount += Number(t.amount);
            }
        }
        return summary;
    }
    // ==========================================================================
    // ENTITY RELATIONSHIPS
    // ==========================================================================
    /**
     * Get relationships for an entity
     */
    async getEntityRelationships(entityId) {
        const relationships = await MultiEntityRepository_1.multiEntityRepository.relationships.findByEntityId(entityId);
        const details = [];
        for (const rel of relationships) {
            const withDetails = await MultiEntityRepository_1.multiEntityRepository.relationships.findByIdWithDetails(rel.relationship_id);
            if (withDetails) {
                details.push(withDetails);
            }
        }
        return details;
    }
    /**
     * Create entity relationship
     */
    async createEntityRelationship(dto, createdBy) {
        // Check if relationship already exists
        const existing = await MultiEntityRepository_1.multiEntityRepository.relationships.findByEntities(dto.entity_id, dto.related_entity_id);
        if (existing) {
            throw new Error('Relationship already exists between these entities');
        }
        // Validate entities
        await Promise.all([
            MultiEntityRepository_1.multiEntityRepository.entities.findByIdOrThrow(dto.entity_id),
            MultiEntityRepository_1.multiEntityRepository.entities.findByIdOrThrow(dto.related_entity_id),
        ]);
        const relationship_id = generateRelationshipId();
        const now = new Date();
        const relationship = {
            relationship_id,
            entity_id: dto.entity_id,
            related_entity_id: dto.related_entity_id,
            relationship_type: dto.relationship_type,
            ownership_percentage: dto.ownership_percentage || null,
            is_primary_contact: dto.is_primary_contact || false,
            effective_date: dto.effective_date || null,
            expiry_date: dto.expiry_date || null,
            notes: dto.notes || null,
            created_at: now,
            created_by: createdBy,
        };
        return await MultiEntityRepository_1.multiEntityRepository.relationships.insert(relationship);
    }
    /**
     * Delete entity relationship
     */
    async deleteEntityRelationship(relationshipId) {
        return await MultiEntityRepository_1.multiEntityRepository.relationships.delete(relationshipId);
    }
    // ==========================================================================
    // ENTITY SETTINGS
    // ==========================================================================
    /**
     * Get all settings for an entity
     */
    async getEntitySettings(entityId) {
        return await MultiEntityRepository_1.multiEntityRepository.settings.getSettingsMap(entityId);
    }
    /**
     * Get a specific setting value
     */
    async getEntitySetting(entityId, key, defaultValue) {
        return await MultiEntityRepository_1.multiEntityRepository.settings.getValue(entityId, key, defaultValue);
    }
    /**
     * Set entity setting
     */
    async setEntitySetting(entityId, key, value, type, updatedBy) {
        await MultiEntityRepository_1.multiEntityRepository.entities.findByIdOrThrow(entityId);
        await MultiEntityRepository_1.multiEntityRepository.settings.upsertSetting(entityId, key, value, type, updatedBy);
        return await MultiEntityRepository_1.multiEntityRepository.entities.findByIdOrThrow(entityId);
    }
    // ==========================================================================
    // ENTITY USERS
    // ==========================================================================
    /**
     * Get users assigned to an entity
     */
    async getEntityUsers(entityId) {
        const entityUsers = await MultiEntityRepository_1.multiEntityRepository.users.findByEntityId(entityId);
        const details = [];
        for (const eu of entityUsers) {
            const withDetails = await MultiEntityRepository_1.multiEntityRepository.users.findByIdWithDetails(eu.entity_user_id);
            if (withDetails) {
                details.push(withDetails);
            }
        }
        return details;
    }
    /**
     * Get entities for a user
     */
    async getUserEntities(userId) {
        return await MultiEntityRepository_1.multiEntityRepository.users.findByUserId(userId);
    }
    /**
     * Get user's default entity
     */
    async getUserDefaultEntity(userId) {
        return await MultiEntityRepository_1.multiEntityRepository.users.getUserDefaultEntity(userId);
    }
    /**
     * Assign user to entity
     */
    async assignUserToEntity(dto, createdBy) {
        // Validate entity and user
        await MultiEntityRepository_1.multiEntityRepository.entities.findByIdOrThrow(dto.entity_id);
        // User validation would go here
        // Check if assignment already exists
        const existing = await MultiEntityRepository_1.multiEntityRepository.users.findByEntityAndUser(dto.entity_id, dto.user_id);
        if (existing) {
            throw new Error('User is already assigned to this entity');
        }
        const entity_user_id = generateEntityUserId();
        const now = new Date();
        const entityUser = {
            entity_user_id,
            entity_id: dto.entity_id,
            user_id: dto.user_id,
            entity_user_role: dto.entity_user_role,
            is_default_entity: dto.is_default_entity || false,
            can_view_financials: dto.can_view_financials || false,
            can_edit_financials: dto.can_edit_financials || false,
            can_approve_transactions: dto.can_approve_transactions || false,
            permissions: dto.permissions || null,
            effective_date: dto.effective_date || now,
            expiry_date: dto.expiry_date || null,
            is_active: true,
            created_at: now,
            created_by: createdBy,
        };
        // If setting as default, remove default from other entities
        if (entityUser.is_default_entity) {
            await MultiEntityRepository_1.multiEntityRepository.users.setDefaultEntity(dto.user_id, dto.entity_id);
        }
        return await MultiEntityRepository_1.multiEntityRepository.users.insert(entityUser);
    }
    /**
     * Update entity user assignment
     */
    async updateEntityUserAssignment(entityUserId, dto) {
        const existing = await MultiEntityRepository_1.multiEntityRepository.users.findByIdOrThrow(entityUserId);
        return (await MultiEntityRepository_1.multiEntityRepository.users.update(entityUserId, dto));
    }
    /**
     * Remove user from entity
     */
    async removeUserFromEntity(entityUserId) {
        return await MultiEntityRepository_1.multiEntityRepository.users.delete(entityUserId);
    }
    /**
     * Set default entity for user
     */
    async setUserDefaultEntity(userId, entityId) {
        return await MultiEntityRepository_1.multiEntityRepository.users.setDefaultEntity(userId, entityId);
    }
    /**
     * Check if user has permission on entity
     */
    async checkEntityPermission(userId, entityId, permission) {
        return await MultiEntityRepository_1.multiEntityRepository.users.hasPermission(userId, entityId, permission);
    }
    // ==========================================================================
    // CONSOLIDATION RULES
    // ==========================================================================
    /**
     * Get consolidation rules
     */
    async getConsolidationRules(parentId) {
        const rules = await MultiEntityRepository_1.multiEntityRepository.consolidation.findActive(parentId);
        const details = [];
        for (const rule of rules) {
            const withDetails = await MultiEntityRepository_1.multiEntityRepository.consolidation.findByIdWithDetails(rule.rule_id);
            if (withDetails) {
                details.push(withDetails);
            }
        }
        return details;
    }
    /**
     * Get consolidation rule by ID
     */
    async getConsolidationRuleById(ruleId) {
        const rule = await MultiEntityRepository_1.multiEntityRepository.consolidation.findByIdWithDetails(ruleId);
        if (!rule) {
            throw new shared_1.NotFoundError('Consolidation Rule', ruleId);
        }
        return rule;
    }
    /**
     * Create consolidation rule
     */
    async createConsolidationRule(dto, createdBy) {
        // Validate entities
        await Promise.all([
            MultiEntityRepository_1.multiEntityRepository.entities.findByIdOrThrow(dto.parent_entity_id),
            MultiEntityRepository_1.multiEntityRepository.entities.findByIdOrThrow(dto.subsidiary_entity_id),
        ]);
        // Check if rule already exists
        const existing = await MultiEntityRepository_1.multiEntityRepository.consolidation.findByParentAndSubsidiary(dto.parent_entity_id, dto.subsidiary_entity_id);
        if (existing) {
            throw new Error('Consolidation rule already exists for this parent-subsidiary pair');
        }
        const rule_id = generateRuleId();
        const now = new Date();
        const rule = {
            rule_id,
            parent_entity_id: dto.parent_entity_id,
            subsidiary_entity_id: dto.subsidiary_entity_id,
            consolidation_method: dto.consolidation_method,
            ownership_percentage: dto.ownership_percentage,
            control_percentage: dto.control_percentage || 100.0,
            voting_percentage: dto.voting_percentage || 100.0,
            eliminate_intercompany: dto.eliminate_intercompany !== false,
            eliminate_unrealized_gains: dto.eliminate_unrealized_gains !== false,
            consolidation_account_id: dto.consolidation_account_id || null,
            minority_interest_account_id: dto.minority_interest_account_id || null,
            effective_date: dto.effective_date || now,
            expiry_date: dto.expiry_date || null,
            notes: dto.notes || null,
            is_active: true,
            created_at: now,
            updated_at: now,
            created_by: createdBy,
        };
        return await MultiEntityRepository_1.multiEntityRepository.consolidation.insert(rule);
    }
    /**
     * Update consolidation rule
     */
    async updateConsolidationRule(ruleId, dto) {
        const existing = await MultiEntityRepository_1.multiEntityRepository.consolidation.findByIdOrThrow(ruleId);
        return (await MultiEntityRepository_1.multiEntityRepository.consolidation.update(ruleId, {
            ...dto,
            updated_at: new Date(),
        }));
    }
    /**
     * Delete consolidation rule
     */
    async deleteConsolidationRule(ruleId) {
        return await MultiEntityRepository_1.multiEntityRepository.consolidation.delete(ruleId);
    }
    // ==========================================================================
    // ENTITY EXCHANGE RATES
    // ==========================================================================
    /**
     * Get exchange rates for an entity
     */
    async getEntityExchangeRates(entityId) {
        return await MultiEntityRepository_1.multiEntityRepository.exchangeRates.findByEntityId(entityId);
    }
    /**
     * Get latest exchange rate
     */
    async getLatestExchangeRate(entityId, fromCurrency, toCurrency) {
        return await MultiEntityRepository_1.multiEntityRepository.exchangeRates.findLatestRate(entityId, fromCurrency, toCurrency);
    }
    /**
     * Set exchange rate
     */
    async setExchangeRate(dto, createdBy) {
        await MultiEntityRepository_1.multiEntityRepository.entities.findByIdOrThrow(dto.entity_id);
        return await MultiEntityRepository_1.multiEntityRepository.exchangeRates.upsertRate(dto.entity_id, dto.from_currency, dto.to_currency, dto.rate_date, dto.exchange_rate, createdBy, dto.is_override || false);
    }
    // ==========================================================================
    // ENTITY AUDIT LOG
    // ==========================================================================
    /**
     * Get audit log for an entity
     */
    async getEntityAuditLog(entityId, limit = 100) {
        return await MultiEntityRepository_1.multiEntityRepository.auditLog.findByEntityId(entityId, limit);
    }
    // ==========================================================================
    // CONSOLIDATION
    // ==========================================================================
    /**
     * Generate consolidated financial statements
     * This is a placeholder for the full consolidation logic
     */
    async generateConsolidatedFinancials(period, parentEntityId) {
        // Get all consolidation rules for parent
        const rules = await MultiEntityRepository_1.multiEntityRepository.consolidation.findByParentId(parentEntityId);
        // This would involve:
        // 1. Getting financial statements from parent entity
        // 2. Getting financial statements from all subsidiaries
        // 3. Applying consolidation rules (full, proportional, equity method)
        // 4. Eliminating inter-company transactions
        // 5. Calculating minority interest
        // 6. Generating consolidated statements
        // Placeholder response
        return {
            period,
            parent_entity_id: parentEntityId,
            entity_ids: [parentEntityId, ...rules.map(r => r.subsidiary_entity_id)],
            balance_sheet: {
                assets: 0,
                liabilities: 0,
                equity: 0,
                minority_interest: 0,
                consolidated_equity: 0,
            },
            profit_loss: {
                revenue: 0,
                expenses: 0,
                net_income: 0,
                minority_interest_share: 0,
                consolidated_net_income: 0,
            },
            cash_flow: {
                operating_cash_flow: 0,
                investing_cash_flow: 0,
                financing_cash_flow: 0,
                net_cash_flow: 0,
            },
            elimination_entries: [],
            intercompany_eliminations: {
                total_revenue_eliminated: 0,
                total_expense_eliminated: 0,
                total_receivables_eliminated: 0,
                total_payables_eliminated: 0,
            },
        };
    }
}
// ============================================================================
// EXPORT SINGLETON
// ============================================================================
exports.multiEntityService = new MultiEntityService();
//# sourceMappingURL=MultiEntityService.js.map