/**
 * Test Data Factories
 *
 * Provides factory functions for creating test data.
 * Uses faker.js for generating realistic test data.
 */
import { Order, OrderItem, User, PickTask, InventoryUnit } from '@opsui/shared';
/**
 * Factory for creating test users
 */
export declare const userFactory: {
    create(overrides?: Partial<User>): User;
    createPicker(overrides?: Partial<User>): User;
    createPacker(overrides?: Partial<User>): User;
    createAdmin(overrides?: Partial<User>): User;
    createSupervisor(overrides?: Partial<User>): User;
};
/**
 * Factory for creating test orders
 */
export declare const orderFactory: {
    create(overrides?: Partial<Order>): Order;
    createPicking(overrides?: Partial<Order>): Order;
    createPicked(overrides?: Partial<Order>): Order;
    createPacking(overrides?: Partial<Order>): Order;
    createShipped(overrides?: Partial<Order>): Order;
    createWithItems(itemCount: number, overrides?: Partial<Order>): Order;
};
/**
 * Factory for creating test order items
 */
export declare const orderItemFactory: {
    create(overrides?: Partial<OrderItem>): OrderItem;
    createList(count: number, overrides?: Partial<OrderItem>): OrderItem[];
    createPicked(overrides?: Partial<OrderItem>): OrderItem;
};
/**
 * Factory for creating test pick tasks
 */
export declare const pickTaskFactory: {
    create(overrides?: Partial<PickTask>): PickTask;
    createInProgress(overrides?: Partial<PickTask>): PickTask;
    createCompleted(overrides?: Partial<PickTask>): PickTask;
    createList(count: number, overrides?: Partial<PickTask>): PickTask[];
};
/**
 * Factory for creating test inventory
 */
export declare const inventoryFactory: {
    create(overrides?: Partial<InventoryUnit>): InventoryUnit;
    createLowStock(overrides?: Partial<InventoryUnit>): InventoryUnit;
    createOutOfStock(overrides?: Partial<InventoryUnit>): InventoryUnit;
    createList(count: number, overrides?: Partial<InventoryUnit>): InventoryUnit[];
};
/**
 * Test database helpers
 */
export declare const testDbHelpers: {
    /**
     * Clean all test data from database
     */
    cleanDatabase(db: any): Promise<void>;
    /**
     * Seed test database with sample data
     */
    seedTestData(db: any): Promise<void>;
    /**
     * Create test transaction
     */
    createTestTransaction(db: any): Promise<any>;
};
/**
 * API test helpers
 */
export declare const apiTestHelpers: {
    /**
     * Get authentication token for test user
     */
    getAuthToken(request: any, email: string, password: string): Promise<string>;
    /**
     * Create authenticated request
     */
    authenticatedRequest(token: string): {
        headers: {
            Authorization: string;
        };
    };
    /**
     * Expect error response
     */
    expectErrorResponse(response: any, statusCode: number, errorCode: string): void;
};
/**
 * Performance test helpers
 */
export declare const perfTestHelpers: {
    /**
     * Measure execution time
     */
    measureTime<T>(fn: () => Promise<T>): Promise<{
        result: T;
        duration: number;
    }>;
    /**
     * Generate load test data
     */
    generateLoadTestData(orderCount: number): {
        users: User[];
        orders: Order[];
        inventory: InventoryUnit[];
    };
};
//# sourceMappingURL=factories.d.ts.map