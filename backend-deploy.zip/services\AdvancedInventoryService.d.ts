/**
 * Advanced Inventory Service
 *
 * Business logic for advanced inventory management features
 * Landed cost, ABC analysis, demand planning, safety stock, cycle count optimization
 */
import { LandedCostComponent, InventoryLayer, ABCAnalysis, ABCAnalysisDetail, DemandForecast, DemandForecastDetail, CycleCountOptimization, CycleCountSchedule, SafetyStockLevel, SlowMovingInventory, SafetyStockAlert, CreateLandedCostComponentDTO, CreateABCAnalysisDTO, CreateDemandForecastDTO, CalculateSafetyStockDTO, CreateCycleCountOptimizationDTO, InventoryLayerSummary } from '@opsui/shared';
export declare class AdvancedInventoryService {
    /**
     * Add landed cost component to a receipt line
     */
    addLandedCostComponent(dto: CreateLandedCostComponentDTO): Promise<LandedCostComponent>;
    /**
     * Calculate landed cost for a receipt line
     */
    calculateLandedCost(receiptLineId: string): Promise<number>;
    /**
     * Get inventory layers summary for a SKU
     */
    getInventoryLayersSummary(sku: string): Promise<InventoryLayerSummary | null>;
    /**
     * Get all inventory layers for a SKU
     */
    getInventoryLayers(sku: string, includeExhausted?: boolean): Promise<InventoryLayer[]>;
    /**
     * Run ABC analysis on inventory
     */
    runABCAnalysis(dto: CreateABCAnalysisDTO): Promise<ABCAnalysis>;
    /**
     * Get ABC analysis with details
     */
    getABCAnalysis(analysisId: string): Promise<{
        analysis: ABCAnalysis;
        details: ABCAnalysisDetail[];
    } | null>;
    /**
     * Get latest ABC analysis
     */
    getLatestABCAnalysis(): Promise<ABCAnalysis | null>;
    /**
     * Create demand forecast
     */
    createDemandForecast(dto: CreateDemandForecastDTO): Promise<DemandForecast>;
    /**
     * Generate forecast details using historical data
     */
    private generateForecastDetails;
    /**
     * Get demand forecast with details
     */
    getDemandForecast(forecastId: string): Promise<{
        forecast: DemandForecast;
        details: DemandForecastDetail[];
    } | null>;
    /**
     * Calculate and set safety stock for an SKU
     */
    calculateSafetyStock(dto: CalculateSafetyStockDTO): Promise<SafetyStockLevel>;
    /**
     * Get Z-score for service level (simplified)
     */
    private getZScore;
    /**
     * Get safety stock alerts
     */
    getSafetyStockAlerts(): Promise<SafetyStockAlert[]>;
    /**
     * Create cycle count optimization plan
     */
    createCycleCountOptimization(dto: CreateCycleCountOptimizationDTO): Promise<CycleCountOptimization>;
    /**
     * Generate cycle count schedule based on strategy
     */
    private generateCycleCountSchedule;
    /**
     * Get cycle count schedule for a date range
     */
    getCycleCountSchedule(startDate: Date, endDate: Date): Promise<CycleCountSchedule[]>;
    /**
     * Get slow moving inventory report
     */
    getSlowMovingInventory(thresholdDays?: number): Promise<SlowMovingInventory[]>;
    /**
     * Get inventory investment analysis
     */
    getInventoryInvestmentAnalysis(periodStart: Date, periodEnd: Date): Promise<{
        total_investment: number;
        fast_moving_investment: number;
        slow_moving_investment: number;
        obsolete_investment: number;
    }>;
}
export declare const advancedInventoryService: AdvancedInventoryService;
//# sourceMappingURL=AdvancedInventoryService.d.ts.map