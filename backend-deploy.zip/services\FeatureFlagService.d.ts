/**
 * Feature Flag Service
 *
 * Manages feature flags for enabling/disabling application features
 */
export interface FeatureFlag {
    flag_id: string;
    flag_key: string;
    name: string;
    description: string | null;
    is_enabled: boolean;
    category: 'picking' | 'packing' | 'inventory' | 'shipping' | 'experimental';
    created_at: Date;
    updated_at: Date;
}
export interface CreateFlagDTO {
    flag_key: string;
    name: string;
    description?: string;
    category: 'picking' | 'packing' | 'inventory' | 'shipping' | 'experimental';
    is_enabled?: boolean;
}
/**
 * Invalidate cache (call after database updates)
 */
export declare function invalidateFlagCache(): void;
/**
 * Get a single feature flag by key
 */
export declare function getFlag(key: string): Promise<FeatureFlag | null>;
/**
 * Check if a feature flag is enabled
 */
export declare function isFlagEnabled(key: string): Promise<boolean>;
/**
 * Get all feature flags
 */
export declare function getAllFlags(): Promise<FeatureFlag[]>;
/**
 * Get feature flags by category
 */
export declare function getFlagsByCategory(category: string): Promise<FeatureFlag[]>;
/**
 * Set a feature flag's enabled state
 */
export declare function setFlag(key: string, enabled: boolean): Promise<FeatureFlag>;
/**
 * Create a new feature flag
 */
export declare function createFlag(data: CreateFlagDTO): Promise<FeatureFlag>;
/**
 * Delete a feature flag
 */
export declare function deleteFlag(key: string): Promise<void>;
/**
 * Get flag categories with counts
 */
export declare function getCategorySummary(): Promise<Array<{
    category: string;
    count: number;
    enabled: number;
}>>;
//# sourceMappingURL=FeatureFlagService.d.ts.map