"use strict";
/**
 * Clean all data from database (keep schema)
 *
 * Removes all data but preserves table structure
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.cleanAllData = cleanAllData;
exports.cleanDataCli = main;
const client_1 = require("./client");
const logger_1 = require("../config/logger");
/**
 * Truncate all tables (removes data, keeps schema)
 */
async function cleanAllData() {
    try {
        logger_1.logger.info('Cleaning all data from database...');
        // Truncate in correct order due to foreign key constraints
        await (0, client_1.query)(`
      TRUNCATE TABLE
        order_state_changes CASCADE,
        inventory_transactions CASCADE,
        pick_tasks CASCADE,
        order_items CASCADE,
        orders CASCADE,
        inventory_units CASCADE,
        bin_locations CASCADE,
        skus CASCADE,
        users CASCADE
    `);
        logger_1.logger.info('All data cleaned successfully');
    }
    catch (error) {
        logger_1.logger.error('Failed to clean data', {
            error: error instanceof Error ? error.message : String(error),
        });
        throw error;
    }
}
// CLI Entry Point
async function main() {
    try {
        await cleanAllData();
        await (0, client_1.closePool)();
        console.log('✅ Data cleaned successfully');
        process.exit(0);
    }
    catch (error) {
        console.error('❌ Failed to clean data');
        await (0, client_1.closePool)();
        process.exit(1);
    }
}
if (require.main === module) {
    main();
}
//# sourceMappingURL=clean-data.js.map