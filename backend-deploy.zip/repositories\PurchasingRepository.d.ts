/**
 * Purchasing Repository
 *
 * Data access layer for purchasing operations
 * Handles purchase requisitions, RFQs, purchase orders, receipts,
 * three-way matching, vendor catalogs, and vendor performance
 */
import { BaseRepository } from './BaseRepository';
import type { PurchaseRequisition, PurchaseRequisitionWithDetails, PurchaseRequisitionLine, RequisitionApproval, RequisitionQueryFilters, RFQHeader, RFQHeaderWithDetails, RFQLine, RFQVendor, RFQVendorResponse, RFQResponseLine, RFQStatus, VendorResponseStatus, VendorItemCatalog, PurchaseOrderHeader, PurchaseOrderWithDetails, PurchaseOrderLine, PurchaseOrderStatus, PurchaseReceipt, PurchaseReceiptWithDetails, PurchaseReceiptLine, ThreeWayMatchDetails, ThreeWayMatchStatus, VendorPerformanceSummary, VendorPerformanceEvent, VendorScorecard, ScorecardStatus } from '@opsui/shared';
export declare class PurchaseRequisitionRepository extends BaseRepository<PurchaseRequisition> {
    constructor();
    findByNumber(requisitionNumber: string): Promise<PurchaseRequisition | null>;
    findByIdWithDetails(requisitionId: string): Promise<PurchaseRequisitionWithDetails | null>;
    queryWithFilters(filters: RequisitionQueryFilters): Promise<PurchaseRequisition[]>;
    findPendingApprovals(): Promise<PurchaseRequisitionWithDetails[]>;
    findByJobNumber(jobNumber: string): Promise<PurchaseRequisition[]>;
    countByStatus(): Promise<Record<string, number>>;
}
export declare class PurchaseRequisitionLineRepository extends BaseRepository<PurchaseRequisitionLine> {
    constructor();
    findByRequisition(requisitionId: string): Promise<PurchaseRequisitionLine[]>;
    getNextLineNumber(requisitionId: string): Promise<number>;
    deleteByRequisition(requisitionId: string): Promise<number>;
}
export declare class RequisitionApprovalRepository extends BaseRepository<RequisitionApproval> {
    constructor();
    findByRequisition(requisitionId: string): Promise<RequisitionApproval[]>;
    findPendingForUser(userId: string): Promise<RequisitionApproval[]>;
    allApprovalsCompleted(requisitionId: string): Promise<boolean>;
}
export declare class RFQHeaderRepository extends BaseRepository<RFQHeader> {
    constructor();
    findByNumber(rfqNumber: string): Promise<RFQHeader | null>;
    findByIdWithDetails(rfqId: string): Promise<RFQHeaderWithDetails | null>;
    findBySource(sourceType: string, sourceId: string): Promise<RFQHeader[]>;
    findPendingResponse(): Promise<RFQHeaderWithDetails[]>;
    updateStatus(rfqId: string, status: RFQStatus): Promise<RFQHeader | null>;
}
export declare class RFQLineRepository extends BaseRepository<RFQLine> {
    constructor();
    findByRFQ(rfqId: string): Promise<RFQLine[]>;
    getNextLineNumber(rfqId: string): Promise<number>;
}
export declare class RFQVendorRepository extends BaseRepository<RFQVendor> {
    constructor();
    findByRFQ(rfqId: string): Promise<RFQVendor[]>;
    findPendingResponses(): Promise<RFQVendor[]>;
    updateStatus(rfqVendorId: string, status: VendorResponseStatus): Promise<RFQVendor | null>;
}
export declare class RFQVendorResponseRepository extends BaseRepository<RFQVendorResponse> {
    constructor();
    findByRFQ(rfqId: string): Promise<RFQVendorResponse[]>;
    findByVendor(vendorId: string): Promise<RFQVendorResponse[]>;
    findByIdWithLines(responseId: string): Promise<RFQVendorResponse | null>;
    findLowestBidForRFQ(rfqId: string): Promise<RFQVendorResponse | null>;
}
export declare class RFQResponseLineRepository extends BaseRepository<RFQResponseLine> {
    constructor();
    findByResponse(responseId: string): Promise<RFQResponseLine[]>;
}
export declare class VendorItemCatalogRepository extends BaseRepository<VendorItemCatalog> {
    constructor();
    findByVendor(vendorId: string, activeOnly?: boolean): Promise<VendorItemCatalog[]>;
    findByInternalSKU(sku: string): Promise<VendorItemCatalog[]>;
    findByVendorSKU(vendorId: string, vendorSku: string): Promise<VendorItemCatalog | null>;
    findPreferredForSKU(sku: string): Promise<VendorItemCatalog[]>;
    findByEntity(entityId: string): Promise<VendorItemCatalog[]>;
}
export declare class PurchaseOrderHeaderRepository extends BaseRepository<PurchaseOrderHeader> {
    constructor();
    findByNumber(poNumber: string): Promise<PurchaseOrderHeader | null>;
    findByIdWithDetails(poId: string): Promise<PurchaseOrderWithDetails | null>;
    findByVendor(vendorId: string): Promise<PurchaseOrderHeader[]>;
    findBySource(sourceType: string, sourceId: string): Promise<PurchaseOrderHeader[]>;
    findOpenOrders(): Promise<PurchaseOrderHeader[]>;
    findWithMatchExceptions(): Promise<PurchaseOrderHeader[]>;
    updateStatus(poId: string, status: PurchaseOrderStatus): Promise<PurchaseOrderHeader | null>;
    updateThreeWayMatchStatus(poId: string, status: ThreeWayMatchStatus): Promise<PurchaseOrderHeader | null>;
}
export declare class PurchaseOrderLineRepository extends BaseRepository<PurchaseOrderLine> {
    constructor();
    findByPO(poId: string): Promise<PurchaseOrderLine[]>;
    findBySKU(sku: string): Promise<PurchaseOrderLine[]>;
    getNextLineNumber(poId: string): Promise<number>;
    updateReceivedQuantity(polId: string, quantityReceived: number): Promise<PurchaseOrderLine | null>;
    updateThreeWayMatchStatus(polId: string, status: ThreeWayMatchStatus): Promise<PurchaseOrderLine | null>;
}
export declare class PurchaseReceiptRepository extends BaseRepository<PurchaseReceipt> {
    constructor();
    findByNumber(receiptNumber: string): Promise<PurchaseReceipt | null>;
    findByIdWithDetails(receiptId: string): Promise<PurchaseReceiptWithDetails | null>;
    findByPO(poId: string): Promise<PurchaseReceipt[]>;
    findByVendor(vendorId: string): Promise<PurchaseReceipt[]>;
    findByDateRange(startDate: Date, endDate: Date): Promise<PurchaseReceipt[]>;
    findOpenReceipts(): Promise<PurchaseReceipt[]>;
}
export declare class PurchaseReceiptLineRepository extends BaseRepository<PurchaseReceiptLine> {
    constructor();
    findByReceipt(receiptId: string): Promise<PurchaseReceiptLine[]>;
    findByPOLine(poLineId: string): Promise<PurchaseReceiptLine[]>;
    findBySKU(sku: string): Promise<PurchaseReceiptLine[]>;
    findByLotNumber(lotNumber: string): Promise<PurchaseReceiptLine[]>;
    getNextLineNumber(receiptId: string): Promise<number>;
}
export declare class ThreeWayMatchRepository extends BaseRepository<ThreeWayMatchDetails> {
    constructor();
    findByPO(poId: string): Promise<ThreeWayMatchDetails[]>;
    findByPOLine(poLineId: string): Promise<ThreeWayMatchDetails[]>;
    findByReceipt(receiptId: string): Promise<ThreeWayMatchDetails[]>;
    findByInvoice(invoiceId: string): Promise<ThreeWayMatchDetails[]>;
    findExceptions(): Promise<ThreeWayMatchDetails[]>;
    findPendingInvoiceMatch(): Promise<ThreeWayMatchDetails[]>;
    updateMatchStatus(matchId: string, status: ThreeWayMatchStatus): Promise<ThreeWayMatchDetails | null>;
    resolveVariance(matchId: string, resolved: boolean, resolutionNotes?: string): Promise<ThreeWayMatchDetails | null>;
}
export declare class VendorPerformanceSummaryRepository extends BaseRepository<VendorPerformanceSummary> {
    constructor();
    findByVendor(vendorId: string): Promise<VendorPerformanceSummary[]>;
    findCurrentPeriod(vendorId: string): Promise<VendorPerformanceSummary | null>;
    findTopPerformers(limit?: number, minRating?: number): Promise<VendorPerformanceSummary[]>;
    findVendorsAtRisk(maxRating?: number): Promise<VendorPerformanceSummary[]>;
    findByEntity(entityId: string): Promise<VendorPerformanceSummary[]>;
    getVendorRanking(limit?: number): Promise<VendorPerformanceSummary[]>;
}
export declare class VendorPerformanceEventRepository extends BaseRepository<VendorPerformanceEvent> {
    constructor();
    findByVendor(vendorId: string, limit?: number): Promise<VendorPerformanceEvent[]>;
    findByCategory(vendorId: string, category: string): Promise<VendorPerformanceEvent[]>;
    findUnresolved(vendorId?: string): Promise<VendorPerformanceEvent[]>;
    findByReference(referenceType: string, referenceId: string): Promise<VendorPerformanceEvent[]>;
    updateResolution(eventId: string, resolved: boolean, resolvedBy: string, resolutionNotes?: string): Promise<VendorPerformanceEvent | null>;
}
export declare class VendorScorecardRepository extends BaseRepository<VendorScorecard> {
    constructor();
    findByVendor(vendorId: string): Promise<VendorScorecard[]>;
    findLatest(vendorId: string): Promise<VendorScorecard | null>;
    findPendingApproval(): Promise<VendorScorecard[]>;
    findByReviewer(reviewerId: string): Promise<VendorScorecard[]>;
    updateStatus(scorecardId: string, status: ScorecardStatus): Promise<VendorScorecard | null>;
    approve(scorecardId: string, approvedBy: string): Promise<VendorScorecard | null>;
    findRequiringDevelopment(): Promise<VendorScorecard[]>;
}
export declare const purchaseRequisitionRepository: PurchaseRequisitionRepository;
export declare const purchaseRequisitionLineRepository: PurchaseRequisitionLineRepository;
export declare const requisitionApprovalRepository: RequisitionApprovalRepository;
export declare const rfqHeaderRepository: RFQHeaderRepository;
export declare const rfqLineRepository: RFQLineRepository;
export declare const rfqVendorRepository: RFQVendorRepository;
export declare const rfqVendorResponseRepository: RFQVendorResponseRepository;
export declare const rfqResponseLineRepository: RFQResponseLineRepository;
export declare const vendorItemCatalogRepository: VendorItemCatalogRepository;
export declare const purchaseOrderHeaderRepository: PurchaseOrderHeaderRepository;
export declare const purchaseOrderLineRepository: PurchaseOrderLineRepository;
export declare const purchaseReceiptRepository: PurchaseReceiptRepository;
export declare const purchaseReceiptLineRepository: PurchaseReceiptLineRepository;
export declare const threeWayMatchRepository: ThreeWayMatchRepository;
export declare const vendorPerformanceSummaryRepository: VendorPerformanceSummaryRepository;
export declare const vendorPerformanceEventRepository: VendorPerformanceEventRepository;
export declare const vendorScorecardRepository: VendorScorecardRepository;
//# sourceMappingURL=PurchasingRepository.d.ts.map