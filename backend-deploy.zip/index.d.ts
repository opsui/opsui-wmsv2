/**
 * WMS Backend - Server Entry Point
 *
 * Warehouse Management System API Server
 * Production-ready with proper error handling, logging, and database transactions
 * Port-locked to prevent duplicate instances
 */
import 'dotenv/config';
import { isShuttingDown as checkIfShuttingDown } from './utils/gracefulShutdown';
export declare const isShuttingDown: typeof checkIfShuttingDown;
//# sourceMappingURL=index.d.ts.map