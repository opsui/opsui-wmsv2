/**
 * Zone Picking Routes
 *
 * API endpoints for zone-based picking operations
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=zones.d.ts.map