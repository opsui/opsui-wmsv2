/**
 * Integrations Routes
 *
 * REST API endpoints for managing external integrations (ERP, e-commerce, carriers)
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=integrations.d.ts.map