"use strict";
/**
 * Module Subscription Routes
 *
 * REST API endpoints for managing module subscriptions and billing
 * Access: ADMIN only for modifications, SUPERVISOR for read access
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const auth_1 = require("../middleware/auth");
const shared_1 = require("@opsui/shared");
const ModuleService = __importStar(require("../services/ModuleSubscriptionService"));
const client_1 = require("../db/client");
const router = (0, express_1.Router)();
// ============================================================================
// MIDDLEWARE
// ============================================================================
// Apply authentication to all routes
router.use(auth_1.authenticate);
// ============================================================================
// MODULE STATUS & DISCOVERY
// ============================================================================
/**
 * GET /api/modules/definitions
 * Get all available module definitions with pricing
 * Access: All authenticated users
 */
router.get('/definitions', async (_req, res, next) => {
    try {
        const definitions = Object.values(shared_1.MODULE_DEFINITIONS).map(module => ({
            id: module.id,
            name: module.name,
            description: module.description,
            category: module.category,
            pricing: module.pricing,
            features: module.features,
            dependencies: module.dependencies,
            icon: module.icon,
        }));
        res.json({
            modules: definitions,
            categories: [
                { id: 'core-warehouse', name: 'Core Warehouse Operations' },
                { id: 'advanced-warehouse', name: 'Advanced Warehouse Features' },
                { id: 'logistics', name: 'Logistics & Route Optimization' },
                { id: 'quality-compliance', name: 'Quality & Compliance' },
                { id: 'business-automation', name: 'Business Automation' },
                { id: 'analytics-intelligence', name: 'Analytics & Intelligence' },
                { id: 'enterprise-management', name: 'Enterprise Management' },
            ],
        });
    }
    catch (error) {
        next(error);
    }
});
/**
 * GET /api/modules/tiers
 * Get all available user tiers with pricing
 * Access: All authenticated users
 */
router.get('/tiers', async (_req, res, next) => {
    try {
        const tiers = Object.values(shared_1.USER_TIERS);
        res.json({ tiers });
    }
    catch (error) {
        next(error);
    }
});
/**
 * GET /api/modules/status
 * Get module status for current entity
 * Access: All authenticated users
 */
router.get('/status', async (req, res, next) => {
    try {
        // Get entity ID from header or default
        const entityId = req.headers['x-entity-id'] || 'ENT-00001';
        const modulesWithStatus = await ModuleService.getModulesWithStatus(entityId);
        const enabledModules = modulesWithStatus.filter(m => m.isEnabled).map(m => m.id);
        res.json({
            entityId,
            enabledModules,
            modulesWithStatus: modulesWithStatus.map(m => ({
                id: m.id,
                name: m.name,
                description: m.description,
                category: m.category,
                pricing: m.pricing,
                isEnabled: m.isEnabled,
                subscription: m.subscription
                    ? {
                        moduleId: m.subscription.module_id,
                        moduleName: m.name,
                        pricePerPeriod: m.subscription.price_per_period,
                        billingCycle: m.subscription.billing_cycle,
                        status: m.subscription.subscription_status,
                    }
                    : undefined,
            })),
        });
    }
    catch (error) {
        next(error);
    }
});
/**
 * GET /api/modules/enabled
 * Get list of enabled module IDs for current entity
 * Access: All authenticated users
 */
router.get('/enabled', async (req, res, next) => {
    try {
        const entityId = req.headers['x-entity-id'] || 'ENT-00001';
        const enabledModules = await ModuleService.getEnabledModules(entityId);
        res.json({ enabledModules });
    }
    catch (error) {
        next(error);
    }
});
/**
 * GET /api/modules/check/:moduleId
 * Check if a specific module is enabled
 * Access: All authenticated users
 */
router.get('/check/:moduleId', async (req, res, next) => {
    try {
        const entityId = req.headers['x-entity-id'] || 'ENT-00001';
        const moduleId = req.params.moduleId;
        const isEnabled = await ModuleService.isModuleEnabled(entityId, moduleId);
        res.json({ moduleId, isEnabled });
    }
    catch (error) {
        next(error);
    }
});
// ============================================================================
// BILLING
// ============================================================================
/**
 * GET /api/modules/billing
 * Get billing summary for current entity
 * Access: ADMIN, SUPERVISOR
 */
router.get('/billing', (0, auth_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR), async (req, res, next) => {
    try {
        const entityId = req.headers['x-entity-id'] || 'ENT-00001';
        const summary = await ModuleService.getEntityBillingSummary(entityId);
        res.json(summary);
    }
    catch (error) {
        next(error);
    }
});
// ============================================================================
// MODULE MANAGEMENT
// ============================================================================
/**
 * POST /api/modules/enable
 * Enable a module for current entity
 * Access: ADMIN only
 */
router.post('/enable', (0, auth_1.authorize)(shared_1.UserRole.ADMIN), async (req, res, next) => {
    try {
        const entityId = req.headers['x-entity-id'] || 'ENT-00001';
        const { moduleId, billingCycle, customPrice, discountPercentage, startDate, endDate, notes } = req.body;
        if (!moduleId) {
            res.status(400).json({ error: 'moduleId is required' });
            return;
        }
        if (!['MONTHLY', 'ANNUAL'].includes(billingCycle)) {
            res.status(400).json({ error: 'billingCycle must be MONTHLY or ANNUAL' });
            return;
        }
        const userId = req.user?.userId;
        const subscription = await ModuleService.enableModule({
            entityId,
            moduleId: moduleId,
            billingCycle,
            customPrice,
            discountPercentage,
            startDate: startDate ? new Date(startDate) : undefined,
            endDate: endDate ? new Date(endDate) : undefined,
            notes,
            createdBy: userId,
        });
        res.status(201).json(subscription);
    }
    catch (error) {
        if (error.message.includes('dependencies')) {
            res.status(400).json({ error: error.message });
            return;
        }
        next(error);
    }
});
/**
 * POST /api/modules/disable
 * Disable a module for current entity
 * Access: ADMIN only
 */
router.post('/disable', (0, auth_1.authorize)(shared_1.UserRole.ADMIN), async (req, res, next) => {
    try {
        const entityId = req.headers['x-entity-id'] || 'ENT-00001';
        const { moduleId, reason } = req.body;
        if (!moduleId) {
            res.status(400).json({ error: 'moduleId is required' });
            return;
        }
        const userId = req.user?.userId;
        await ModuleService.disableModule(entityId, moduleId, userId, reason);
        res.json({ success: true, message: `Module ${moduleId} disabled` });
    }
    catch (error) {
        if (error.message.includes('depend on it')) {
            res.status(400).json({ error: error.message });
            return;
        }
        next(error);
    }
});
/**
 * POST /api/modules/enable-bundle
 * Enable multiple modules at once (for bundles)
 * Access: ADMIN only
 */
router.post('/enable-bundle', (0, auth_1.authorize)(shared_1.UserRole.ADMIN), async (req, res, next) => {
    try {
        const entityId = req.headers['x-entity-id'] || 'ENT-00001';
        const { moduleIds, billingCycle } = req.body;
        if (!moduleIds || !Array.isArray(moduleIds) || moduleIds.length === 0) {
            res.status(400).json({ error: 'moduleIds array is required' });
            return;
        }
        if (!['MONTHLY', 'ANNUAL'].includes(billingCycle)) {
            res.status(400).json({ error: 'billingCycle must be MONTHLY or ANNUAL' });
            return;
        }
        const userId = req.user?.userId;
        const subscriptions = await ModuleService.enableModules({
            entityId,
            moduleIds: moduleIds,
            billingCycle,
            createdBy: userId,
        });
        res.status(201).json({ subscriptions, count: subscriptions.length });
    }
    catch (error) {
        if (error.message.includes('dependencies')) {
            res.status(400).json({ error: error.message });
            return;
        }
        next(error);
    }
});
/**
 * PATCH /api/modules/:moduleId
 * Update a module subscription
 * Access: ADMIN only
 */
router.patch('/:moduleId', (0, auth_1.authorize)(shared_1.UserRole.ADMIN), async (req, res, next) => {
    try {
        const entityId = req.headers['x-entity-id'] || 'ENT-00001';
        const moduleId = req.params.moduleId;
        const updates = req.body;
        const userId = req.user?.userId;
        const subscription = await ModuleService.updateModuleSubscription(entityId, moduleId, updates, userId);
        res.json(subscription);
    }
    catch (error) {
        next(error);
    }
});
// ============================================================================
// USER TIER MANAGEMENT
// ============================================================================
/**
 * GET /api/modules/tier
 * Get current user tier for entity
 * Access: All authenticated users
 */
router.get('/tier', async (req, res, next) => {
    try {
        const entityId = req.headers['x-entity-id'] || 'ENT-00001';
        const tier = await ModuleService.getEntityUserTier(entityId);
        if (!tier) {
            res.json({
                tierId: 'tier-1-5',
                tierName: '1-5 Users',
                monthlyFee: 0,
                currentUserCount: 0,
                maxUserCount: 5,
            });
            return;
        }
        const tierInfo = shared_1.USER_TIERS[tier.tier_id];
        res.json({
            tierId: tier.tier_id,
            tierName: tierInfo?.name ?? tier.tier_id,
            monthlyFee: tier.monthly_fee,
            currentUserCount: tier.current_user_count,
            maxUserCount: tierInfo?.maxUsers ?? null,
        });
    }
    catch (error) {
        next(error);
    }
});
/**
 * POST /api/modules/tier
 * Set user tier for entity
 * Access: ADMIN only
 */
router.post('/tier', (0, auth_1.authorize)(shared_1.UserRole.ADMIN), async (req, res, next) => {
    try {
        const entityId = req.headers['x-entity-id'] || 'ENT-00001';
        const { tierId } = req.body;
        if (!tierId) {
            res.status(400).json({ error: 'tierId is required' });
            return;
        }
        const userId = req.user?.userId;
        const tier = await ModuleService.setEntityUserTier(entityId, tierId, userId);
        const tierInfo = shared_1.USER_TIERS[tier.tier_id];
        res.json({
            tierId: tier.tier_id,
            tierName: tierInfo?.name ?? tier.tier_id,
            monthlyFee: tier.monthly_fee,
        });
    }
    catch (error) {
        if (error.message.includes('Invalid tier')) {
            res.status(400).json({ error: error.message });
            return;
        }
        next(error);
    }
});
/**
 * POST /api/modules/tier/update-count
 * Update user count for current entity
 * Access: ADMIN only
 */
router.post('/tier/update-count', (0, auth_1.authorize)(shared_1.UserRole.ADMIN), async (req, res, next) => {
    try {
        const entityId = req.headers['x-entity-id'] || 'ENT-00001';
        const userCount = await ModuleService.updateUserCount(entityId);
        res.json({ userCount });
    }
    catch (error) {
        next(error);
    }
});
// ============================================================================
// ADD-ON MANAGEMENT
// ============================================================================
/**
 * GET /api/modules/addons
 * Get active add-ons for entity
 * Access: ADMIN, SUPERVISOR
 */
router.get('/addons', (0, auth_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR), async (req, res, next) => {
    try {
        const entityId = req.headers['x-entity-id'] || 'ENT-00001';
        const pool = (0, client_1.getPool)();
        const result = await pool.query(`SELECT * FROM addon_subscriptions WHERE entity_id = $1`, [
            entityId,
        ]);
        res.json({ addons: result.rows });
    }
    catch (error) {
        next(error);
    }
});
/**
 * POST /api/modules/addons/enable
 * Enable an add-on for entity
 * Access: ADMIN only
 */
router.post('/addons/enable', (0, auth_1.authorize)(shared_1.UserRole.ADMIN), async (req, res, next) => {
    try {
        const entityId = req.headers['x-entity-id'] || 'ENT-00001';
        const { addonId } = req.body;
        if (!addonId) {
            res.status(400).json({ error: 'addonId is required' });
            return;
        }
        const userId = req.user?.userId;
        const subscription = await ModuleService.enableAddon(entityId, addonId, userId);
        res.status(201).json(subscription);
    }
    catch (error) {
        next(error);
    }
});
/**
 * POST /api/modules/addons/disable
 * Disable an add-on for entity
 * Access: ADMIN only
 */
router.post('/addons/disable', (0, auth_1.authorize)(shared_1.UserRole.ADMIN), async (req, res, next) => {
    try {
        const entityId = req.headers['x-entity-id'] || 'ENT-00001';
        const { addonId } = req.body;
        if (!addonId) {
            res.status(400).json({ error: 'addonId is required' });
            return;
        }
        await ModuleService.disableAddon(entityId, addonId);
        res.json({ success: true, message: `Add-on ${addonId} disabled` });
    }
    catch (error) {
        next(error);
    }
});
// ============================================================================
// AUDIT LOG
// ============================================================================
/**
 * GET /api/modules/audit
 * Get module audit log for entity
 * Access: ADMIN only
 */
router.get('/audit', (0, auth_1.authorize)(shared_1.UserRole.ADMIN), async (req, res, next) => {
    try {
        const entityId = req.headers['x-entity-id'] || 'ENT-00001';
        const limit = parseInt(req.query.limit) || 50;
        const auditLog = await ModuleService.getModuleAuditLog(entityId, limit);
        res.json({ auditLog });
    }
    catch (error) {
        next(error);
    }
});
exports.default = router;
//# sourceMappingURL=modules.js.map