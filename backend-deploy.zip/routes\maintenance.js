"use strict";
/**
 * Maintenance & Assets Routes
 *
 * API endpoints for asset management and maintenance workflows
 */
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const MaintenanceService_1 = require("../services/MaintenanceService");
const middleware_1 = require("../middleware");
const shared_1 = require("@opsui/shared");
const router = (0, express_1.Router)();
// All maintenance routes require authentication
router.use(middleware_1.authenticate);
// ============================================================================
// DASHBOARD
// ============================================================================
/**
 * GET /api/maintenance/dashboard
 * Get maintenance dashboard metrics
 * Access: All authenticated users
 */
router.get('/dashboard', (0, middleware_1.asyncHandler)(async (_req, res) => {
    const metrics = await MaintenanceService_1.maintenanceService.getDashboardMetrics();
    res.json(metrics);
}));
// ============================================================================
// ASSETS
// ============================================================================
/**
 * POST /api/maintenance/assets
 * Create a new asset
 * Access: ADMIN, SUPERVISOR, MAINTENANCE
 */
router.post('/assets', (0, middleware_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR, shared_1.UserRole.MAINTENANCE), (0, middleware_1.asyncHandler)(async (req, res) => {
    const asset = await MaintenanceService_1.maintenanceService.createAsset(req.body, req.user.userId);
    res.status(201).json(asset);
}));
/**
 * GET /api/maintenance/assets
 * Get all assets with optional filtering
 * Access: All authenticated users
 */
router.get('/assets', (0, middleware_1.asyncHandler)(async (req, res) => {
    const { status, type, limit, offset } = req.query;
    const result = await MaintenanceService_1.maintenanceService.getAllAssets({
        status: status,
        type: type,
        limit: limit ? parseInt(limit) : undefined,
        offset: offset ? parseInt(offset) : undefined,
    });
    res.json(result);
}));
/**
 * GET /api/maintenance/assets/:assetId
 * Get a specific asset by ID
 * Access: All authenticated users
 */
router.get('/assets/:assetId', (0, middleware_1.asyncHandler)(async (req, res) => {
    const { assetId } = req.params;
    const asset = await MaintenanceService_1.maintenanceService.getAssetById(assetId);
    res.json(asset);
}));
/**
 * PUT /api/maintenance/assets/:assetId
 * Update an asset
 * Access: ADMIN, SUPERVISOR, MAINTENANCE
 */
router.put('/assets/:assetId', (0, middleware_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR, shared_1.UserRole.MAINTENANCE), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { assetId } = req.params;
    const asset = await MaintenanceService_1.maintenanceService.updateAsset(assetId, req.body, req.user.userId);
    res.json(asset);
}));
/**
 * POST /api/maintenance/assets/:assetId/retire
 * Retire an asset
 * Access: ADMIN, SUPERVISOR
 */
router.post('/assets/:assetId/retire', (0, middleware_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { assetId } = req.params;
    const asset = await MaintenanceService_1.maintenanceService.retireAsset(assetId, req.user.userId);
    res.json(asset);
}));
// ============================================================================
// MAINTENANCE SCHEDULES
// ============================================================================
/**
 * POST /api/maintenance/schedules
 * Create a new maintenance schedule
 * Access: ADMIN, SUPERVISOR, MAINTENANCE
 */
router.post('/schedules', (0, middleware_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR, shared_1.UserRole.MAINTENANCE), (0, middleware_1.asyncHandler)(async (req, res) => {
    const schedule = await MaintenanceService_1.maintenanceService.createSchedule(req.body, req.user.userId);
    res.status(201).json(schedule);
}));
/**
 * GET /api/maintenance/schedules
 * Get all maintenance schedules
 * Access: All authenticated users
 */
router.get('/schedules', (0, middleware_1.asyncHandler)(async (_req, res) => {
    const schedules = await MaintenanceService_1.maintenanceService.getUpcomingMaintenance(30);
    res.json({ schedules, count: schedules.length });
}));
/**
 * GET /api/maintenance/assets/:assetId/schedules
 * Get maintenance schedules for an asset
 * Access: All authenticated users
 */
router.get('/assets/:assetId/schedules', (0, middleware_1.asyncHandler)(async (req, res) => {
    const { assetId } = req.params;
    const schedules = await MaintenanceService_1.maintenanceService.getSchedulesByAsset(assetId);
    res.json({ schedules, count: schedules.length });
}));
/**
 * GET /api/maintenance/schedules/due
 * Get upcoming maintenance schedules
 * Access: All authenticated users
 */
router.get('/schedules/due', (0, middleware_1.asyncHandler)(async (req, res) => {
    const { days } = req.query;
    const schedules = await MaintenanceService_1.maintenanceService.getUpcomingMaintenance(days ? parseInt(days) : 7);
    res.json({ schedules, count: schedules.length });
}));
// ============================================================================
// WORK ORDERS
// ============================================================================
/**
 * POST /api/maintenance/work-orders
 * Create a new work order
 * Access: ADMIN, SUPERVISOR, MAINTENANCE
 */
router.post('/work-orders', (0, middleware_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR, shared_1.UserRole.MAINTENANCE), (0, middleware_1.asyncHandler)(async (req, res) => {
    const workOrder = await MaintenanceService_1.maintenanceService.createWorkOrder(req.body, req.user.userId);
    res.status(201).json(workOrder);
}));
/**
 * GET /api/maintenance/work-orders
 * Get all work orders with optional filtering
 * Access: All authenticated users
 */
router.get('/work-orders', (0, middleware_1.asyncHandler)(async (req, res) => {
    const { status, assignedTo, limit, offset } = req.query;
    const result = await MaintenanceService_1.maintenanceService.getAllWorkOrders({
        status: status,
        assignedTo: assignedTo,
        limit: limit ? parseInt(limit) : undefined,
        offset: offset ? parseInt(offset) : undefined,
    });
    res.json(result);
}));
/**
 * GET /api/maintenance/work-orders/:workOrderId
 * Get a specific work order by ID
 * Access: All authenticated users
 */
router.get('/work-orders/:workOrderId', (0, middleware_1.asyncHandler)(async (req, res) => {
    const { workOrderId } = req.params;
    const workOrder = await MaintenanceService_1.maintenanceService.getWorkOrderById(workOrderId);
    res.json(workOrder);
}));
/**
 * POST /api/maintenance/work-orders/:workOrderId/start
 * Start a work order
 * Access: ADMIN, SUPERVISOR, MAINTENANCE
 */
router.post('/work-orders/:workOrderId/start', (0, middleware_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR, shared_1.UserRole.MAINTENANCE), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { workOrderId } = req.params;
    const workOrder = await MaintenanceService_1.maintenanceService.startWorkOrder(workOrderId, req.user.userId);
    res.json(workOrder);
}));
/**
 * POST /api/maintenance/work-orders/:workOrderId/complete
 * Complete a work order
 * Access: ADMIN, SUPERVISOR, MAINTENANCE
 */
router.post('/work-orders/:workOrderId/complete', (0, middleware_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR, shared_1.UserRole.MAINTENANCE), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { workOrderId } = req.params;
    const workOrder = await MaintenanceService_1.maintenanceService.completeWorkOrder(workOrderId, req.body, req.user.userId);
    res.json(workOrder);
}));
// ============================================================================
// SERVICE HISTORY
// ============================================================================
/**
 * GET /api/maintenance/assets/:assetId/service-history
 * Get service history for an asset
 * Access: All authenticated users
 */
router.get('/assets/:assetId/service-history', (0, middleware_1.asyncHandler)(async (req, res) => {
    const { assetId } = req.params;
    const { limit } = req.query;
    const serviceLogs = await MaintenanceService_1.maintenanceService.getAssetServiceHistory(assetId, limit ? parseInt(limit) : 50);
    res.json({ serviceLogs, count: serviceLogs.length });
}));
/**
 * POST /api/maintenance/service-logs
 * Add a service log entry
 * Access: ADMIN, SUPERVISOR, MAINTENANCE
 */
router.post('/service-logs', (0, middleware_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR, shared_1.UserRole.MAINTENANCE), (0, middleware_1.asyncHandler)(async (req, res) => {
    const serviceLog = await MaintenanceService_1.maintenanceService.addServiceLog({
        ...req.body,
        createdAt: new Date(),
    });
    res.status(201).json(serviceLog);
}));
// ============================================================================
// METER READINGS
// ============================================================================
/**
 * POST /api/maintenance/meter-readings
 * Add a meter reading
 * Access: ADMIN, SUPERVISOR, MAINTENANCE
 */
router.post('/meter-readings', (0, middleware_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR, shared_1.UserRole.MAINTENANCE), (0, middleware_1.asyncHandler)(async (req, res) => {
    const reading = await MaintenanceService_1.maintenanceService.addMeterReading(req.body, req.user.userId);
    res.status(201).json(reading);
}));
/**
 * GET /api/maintenance/assets/:assetId/meter-readings
 * Get meter readings for an asset
 * Access: All authenticated users
 */
router.get('/assets/:assetId/meter-readings', (0, middleware_1.asyncHandler)(async (req, res) => {
    const { assetId } = req.params;
    const { limit } = req.query;
    const readings = await MaintenanceService_1.maintenanceService.getMeterReadingsByAsset(assetId, limit ? parseInt(limit) : 100);
    res.json({ readings, count: readings.length });
}));
exports.default = router;
//# sourceMappingURL=maintenance.js.map