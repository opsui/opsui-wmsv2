/**
 * Integrations Service
 *
 * Business logic for managing external system integrations (ERP, e-commerce, carriers)
 * Handles sync jobs, webhook processing, and carrier account management
 */
import { IntegrationsRepository } from '../repositories/IntegrationsRepository';
import { Integration, SyncJob, WebhookEvent, WebhookEventType, CarrierAccount } from '@opsui/shared';
export declare class IntegrationsService {
    private repository;
    constructor(repository: IntegrationsRepository);
    createIntegration(integration: Omit<Integration, 'integrationId' | 'createdAt' | 'updatedAt'>): Promise<Integration>;
    updateIntegration(integrationId: string, updates: Partial<Integration>): Promise<Integration | null>;
    deleteIntegration(integrationId: string): Promise<boolean>;
    testConnection(integrationId: string): Promise<{
        success: boolean;
        message: string;
        latency?: number;
    }>;
    createSyncJob(integrationId: string, syncType: 'FULL' | 'INCREMENTAL', triggeredBy: string): Promise<SyncJob>;
    private executeSyncJob;
    private performSync;
    private syncErpSystem;
    private syncEcommercePlatform;
    private syncCarrierSystem;
    handleWebhook(integrationId: string, eventType: WebhookEventType, payload: any): Promise<WebhookEvent>;
    private processWebhookEvent;
    private executeWebhookAction;
    private handleOrderCreated;
    private handleOrderUpdated;
    private handleOrderCancelled;
    private handleProductUpdated;
    private handleInventoryUpdated;
    private handleShipmentStatusUpdate;
    private findWebhookEvent;
    createCarrierAccount(integrationId: string, account: Omit<CarrierAccount, 'accountId' | 'createdAt'>): Promise<CarrierAccount>;
    updateCarrierAccount(carrierAccountId: string, updates: Partial<CarrierAccount>): Promise<CarrierAccount | null>;
    deleteCarrierAccount(carrierAccountId: string): Promise<boolean>;
    private validateConfiguration;
    private getRequiredFieldsForProvider;
    private performProviderConnectionTest;
}
//# sourceMappingURL=IntegrationsService.d.ts.map