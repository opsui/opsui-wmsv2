"use strict";
/**
 * Run the feature_flags migration (010)
 */
Object.defineProperty(exports, "__esModule", { value: true });
const fs_1 = require("fs");
const path_1 = require("path");
const client_1 = require("./client");
async function runMigration() {
    let pool;
    try {
        console.log('Running feature_flags migration (010)...');
        // Read migration file
        const migrationPath = (0, path_1.join)(__dirname, 'migrations/010_feature_flags.sql');
        const migrationSQL = (0, fs_1.readFileSync)(migrationPath, 'utf-8');
        // Get pool and execute migration directly
        pool = (0, client_1.getPool)();
        console.log('Executing migration...');
        await pool.query(migrationSQL);
        console.log('Migration completed successfully!');
        await (0, client_1.closePool)();
        process.exit(0);
    }
    catch (error) {
        console.error('Migration failed:', error);
        await (0, client_1.closePool)();
        process.exit(1);
    }
}
runMigration();
//# sourceMappingURL=run-feature-flags-migration.js.map