/**
 * Seed Data Service
 *
 * Manages seed scenarios for quick database state restoration
 */
export interface SeedScenario {
    scenario_id: string;
    name: string;
    description: string | null;
    data: any;
    created_at: Date;
    created_by: string | null;
}
export interface ExportData {
    timestamp: Date;
    tables: Record<string, any[]>;
}
/**
 * Save current database state as a scenario
 */
export declare function saveScenario(name: string, description: string, createdBy: string): Promise<SeedScenario>;
/**
 * Get all saved scenarios
 */
export declare function getScenarios(): Promise<SeedScenario[]>;
/**
 * Get a single scenario by ID
 */
export declare function getScenario(scenarioId: string): Promise<SeedScenario | null>;
/**
 * Apply a scenario (restore database state)
 */
export declare function applyScenario(scenarioId: string): Promise<void>;
/**
 * Delete a scenario
 */
export declare function deleteScenario(scenarioId: string): Promise<void>;
/**
 * Export current database state
 */
export declare function exportCurrentState(): Promise<ExportData>;
/**
 * Import data from exported state
 */
export declare function importData(importData: ExportData): Promise<void>;
/**
 * List available migrations
 */
export declare function getMigrations(): Promise<any[]>;
/**
 * Run a database reset (clear all data and reseed)
 */
export declare function runDatabaseReset(resetType: 'fresh' | 'with-orders' | 'full'): Promise<void>;
//# sourceMappingURL=SeedDataService.d.ts.map