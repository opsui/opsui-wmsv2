"use strict";
/**
 * Authentication routes
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const AuthService_1 = require("../services/AuthService");
const middleware_1 = require("../middleware");
const validation_1 = require("../middleware/validation");
const router = (0, express_1.Router)();
/**
 * POST /api/auth/login
 * Login with email and password
 */
router.post('/login', validation_1.validate.login, (0, middleware_1.asyncHandler)(async (req, res) => {
    const tokens = await AuthService_1.authService.login(req.body);
    res.json(tokens);
}));
/**
 * POST /api/auth/refresh
 * Refresh access token using refresh token
 */
router.post('/refresh', (0, middleware_1.asyncHandler)(async (req, res) => {
    const { refreshToken } = req.body;
    if (!refreshToken) {
        res.status(400).json({
            error: 'Refresh token is required',
            code: 'MISSING_REFRESH_TOKEN',
        });
        return;
    }
    const tokens = await AuthService_1.authService.refreshToken(refreshToken);
    res.json(tokens);
}));
/**
 * POST /api/auth/logout
 * Logout current user and blacklist their token
 */
router.post('/logout', middleware_1.authenticate, (0, middleware_1.asyncHandler)(async (req, res) => {
    if (req.user) {
        // Create token ID and pass expiration for blacklisting
        const tokenId = `${req.user.userId}:${req.user.iat}`;
        const expiresAt = req.user.exp ? req.user.exp * 1000 : Date.now() + 8 * 60 * 60 * 1000; // Default 8h
        await AuthService_1.authService.logout(req.user.userId, tokenId, expiresAt);
    }
    res.json({ message: 'Logged out successfully' });
}));
/**
 * GET /api/auth/me
 * Get current user info
 */
router.get('/me', middleware_1.authenticate, (0, middleware_1.asyncHandler)(async (req, res) => {
    if (!req.user) {
        res.status(401).json({
            error: 'Not authenticated',
            code: 'NOT_AUTHENTICATED',
        });
        return;
    }
    const user = await AuthService_1.authService.getUserById(req.user.userId);
    res.json(user);
}));
/**
 * POST /api/auth/change-password
 * Change current user's password
 */
router.post('/change-password', middleware_1.authenticate, (0, middleware_1.asyncHandler)(async (req, res) => {
    if (!req.user) {
        res.status(401).json({
            error: 'Not authenticated',
            code: 'NOT_AUTHENTICATED',
        });
        return;
    }
    const { currentPassword, newPassword } = req.body;
    if (!currentPassword || !newPassword) {
        res.status(400).json({
            error: 'Current password and new password are required',
            code: 'MISSING_PASSWORDS',
        });
        return;
    }
    await AuthService_1.authService.changePassword(req.user.userId, currentPassword, newPassword);
    res.json({ message: 'Password changed successfully' });
}));
/**
 * POST /api/auth/current-view
 * Update the current page/view the user is on
 */
router.post('/current-view', middleware_1.authenticate, (0, middleware_1.asyncHandler)(async (req, res) => {
    if (!req.user) {
        res.status(401).json({
            error: 'Not authenticated',
            code: 'NOT_AUTHENTICATED',
        });
        return;
    }
    const { view } = req.body;
    // Allow empty string to clear the current view
    if (view === undefined) {
        res.status(400).json({
            error: 'View is required',
            code: 'MISSING_VIEW',
        });
        return;
    }
    await AuthService_1.authService.updateCurrentView(req.user.userId, view);
    res.json({ message: 'Current view updated successfully' });
}));
/**
 * POST /api/auth/set-idle
 * Set picker to IDLE status immediately (when tab becomes hidden)
 */
router.post('/set-idle', middleware_1.authenticate, (0, middleware_1.asyncHandler)(async (req, res) => {
    if (!req.user) {
        res.status(401).json({
            error: 'Not authenticated',
            code: 'NOT_AUTHENTICATED',
        });
        return;
    }
    await AuthService_1.authService.setIdle(req.user.userId);
    res.json({ message: 'Picker status set to IDLE' });
}));
/**
 * POST /api/auth/set-active-role
 * Set active role for multi-role users (e.g., admin acting as picker/packer/stock-controller)
 */
router.post('/set-active-role', middleware_1.authenticate, (0, middleware_1.asyncHandler)(async (req, res) => {
    if (!req.user) {
        res.status(401).json({
            error: 'Not authenticated',
            code: 'NOT_AUTHENTICATED',
        });
        return;
    }
    const { role } = req.body;
    if (!role) {
        res.status(400).json({
            error: 'Role is required',
            code: 'MISSING_ROLE',
        });
        return;
    }
    // Validate role (including new roles)
    const validRoles = [
        'PICKER',
        'PACKER',
        'STOCK_CONTROLLER',
        'ADMIN',
        'SUPERVISOR',
        'PRODUCTION',
        'INWARDS',
        'DISPATCH',
        'SALES',
        'MAINTENANCE',
        'RMA',
        'ACCOUNTING',
    ];
    if (!validRoles.includes(role)) {
        res.status(400).json({
            error: 'Invalid role',
            code: 'INVALID_ROLE',
        });
        return;
    }
    const user = await AuthService_1.authService.setActiveRole(req.user.userId, role);
    res.json({ user, activeRole: role });
}));
/**
 * POST /api/auth/active-role
 * Alias for /set-active-role (for backwards compatibility)
 * Accepts both activeRole (camelCase) and active_role (snake_case)
 */
router.post('/active-role', middleware_1.authenticate, (0, middleware_1.asyncHandler)(async (req, res) => {
    if (!req.user) {
        res.status(401).json({
            error: 'Not authenticated',
            code: 'NOT_AUTHENTICATED',
        });
        return;
    }
    // Accept both camelCase and snake_case (frontend converts to snake_case)
    const { activeRole, active_role } = req.body;
    const role = activeRole || active_role;
    if (!role) {
        res.status(400).json({
            error: 'Active role is required',
            code: 'MISSING_ROLE',
        });
        return;
    }
    // Validate role (including new roles)
    const validRoles = [
        'PICKER',
        'PACKER',
        'STOCK_CONTROLLER',
        'ADMIN',
        'SUPERVISOR',
        'PRODUCTION',
        'INWARDS',
        'DISPATCH',
        'SALES',
        'MAINTENANCE',
        'RMA',
        'ACCOUNTING',
    ];
    if (!validRoles.includes(role)) {
        res.status(400).json({
            error: 'Invalid role',
            code: 'INVALID_ROLE',
        });
        return;
    }
    const user = await AuthService_1.authService.setActiveRole(req.user.userId, role);
    // Generate new access token with updated activeRole
    const { generateToken } = await Promise.resolve().then(() => __importStar(require('../middleware/auth')));
    const newAccessToken = generateToken({
        userId: user.userId,
        email: user.email,
        role: user.role,
        activeRole: role,
    });
    res.json({ user, activeRole: role, accessToken: newAccessToken });
}));
exports.default = router;
//# sourceMappingURL=auth.js.map