"use strict";
/**
 * Reports API Routes
 *
 * REST API for managing reports, executions, dashboards, and exports.
 */
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const ReportsRepository_1 = require("../repositories/ReportsRepository");
const ReportsService_1 = require("../services/ReportsService");
const middleware_1 = require("../middleware");
const shared_1 = require("@opsui/shared");
const router = (0, express_1.Router)();
// All reports routes require authentication
router.use(middleware_1.authenticate);
// ============================================================================
// REPORTS CRUD
// ============================================================================
/**
 * GET /api/reports
 * Get all reports with optional filtering
 */
router.get('/', (0, middleware_1.asyncHandler)(async (req, res) => {
    const { reportType, status, isPublic } = req.query;
    const userId = req.user?.userId;
    const reports = await ReportsRepository_1.reportsRepository.findAll({
        reportType: reportType,
        status: status,
        isPublic: isPublic === 'true' ? true : undefined,
        createdBy: userId,
    });
    res.json({
        success: true,
        data: {
            reports,
            count: reports.length,
        },
    });
}));
// ============================================================================
// DASHBOARDS
// ============================================================================
// NOTE: Dashboard routes must be defined BEFORE /:reportId to avoid route conflicts
// (otherwise /dashboards would match /:reportId with reportId="dashboards")
/**
 * GET /api/dashboards
 * Get all dashboards
 */
router.get('/dashboards', (0, middleware_1.asyncHandler)(async (req, res) => {
    const userId = req.user?.userId;
    const userRole = req.user?.role;
    // Users can see their own dashboards plus public ones
    const dashboards = await ReportsRepository_1.reportsRepository.findDashboards({
        owner: userRole === shared_1.UserRole.ADMIN ? undefined : userId,
        isPublic: userRole === shared_1.UserRole.ADMIN ? undefined : true,
    });
    res.json({
        success: true,
        data: {
            dashboards,
            count: dashboards.length,
        },
    });
}));
/**
 * GET /api/dashboards/:dashboardId
 * Get a specific dashboard
 */
router.get('/dashboards/:dashboardId', (0, middleware_1.asyncHandler)(async (req, res) => {
    const { dashboardId } = req.params;
    const dashboard = await ReportsRepository_1.reportsRepository.findDashboardById(dashboardId);
    if (!dashboard) {
        res.status(404).json({
            success: false,
            error: 'Dashboard not found',
        });
        return;
    }
    res.json({
        success: true,
        data: { dashboard },
    });
}));
/**
 * POST /api/dashboards
 * Create a new dashboard
 */
router.post('/dashboards', (0, middleware_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR), (0, middleware_1.asyncHandler)(async (req, res) => {
    const dashboardData = req.body;
    const userId = req.user?.userId;
    const dashboard = await ReportsRepository_1.reportsRepository.createDashboard({
        ...dashboardData,
        owner: userId,
        createdBy: userId,
        createdAt: new Date(),
    });
    res.status(201).json({
        success: true,
        data: { dashboard },
    });
}));
// ============================================================================
// EXPORT JOBS
// ============================================================================
// NOTE: Export routes must be defined BEFORE /:reportId to avoid route conflicts
/**
 * GET /api/reports/exports
 * Get all export jobs
 */
router.get('/exports', (0, middleware_1.asyncHandler)(async (req, res) => {
    const userId = req.user?.userId;
    const userRole = req.user?.role;
    // Get export jobs - admins see all, others see their own
    const jobs = await ReportsRepository_1.reportsRepository.findAllExportJobs(userRole === shared_1.UserRole.ADMIN ? undefined : userId);
    res.json({
        success: true,
        data: {
            jobs,
            count: jobs.length,
        },
    });
}));
/**
 * POST /api/reports/export
 * Create and start an export job
 */
router.post('/export', (0, middleware_1.asyncHandler)(async (req, res) => {
    const { entityType, format = shared_1.ReportFormat.CSV, fields, filters = [] } = req.body;
    const userId = req.user?.userId;
    if (!entityType || !fields || !Array.isArray(fields)) {
        res.status(400).json({
            success: false,
            error: 'Missing required fields: entityType, fields (array)',
        });
        return;
    }
    const job = await ReportsService_1.reportsService.createExportJob(entityType, format, fields, filters, userId);
    res.status(201).json({
        success: true,
        data: { job },
    });
}));
/**
 * GET /api/reports/export/:jobId
 * Get export job status
 */
router.get('/export/:jobId', (0, middleware_1.asyncHandler)(async (req, res) => {
    const { jobId } = req.params;
    const job = await ReportsRepository_1.reportsRepository.getExportJob(jobId);
    if (!job) {
        res.status(404).json({
            success: false,
            error: 'Export job not found',
        });
        return;
    }
    res.json({
        success: true,
        data: { job },
    });
}));
// ============================================================================
// REPORTS BY ID
// ============================================================================
/**
 * GET /api/reports/:reportId
 * Get a specific report by ID
 */
router.get('/:reportId', (0, middleware_1.asyncHandler)(async (req, res) => {
    const { reportId } = req.params;
    const report = await ReportsRepository_1.reportsRepository.findById(reportId);
    if (!report) {
        res.status(404).json({
            success: false,
            error: 'Report not found',
        });
        return;
    }
    res.json({
        success: true,
        data: { report },
    });
}));
/**
 * POST /api/reports
 * Create a new report (ADMIN/SUPERVISOR only)
 */
router.post('/', (0, middleware_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR), (0, middleware_1.asyncHandler)(async (req, res) => {
    const reportData = req.body;
    const userId = req.user?.userId;
    const report = await ReportsRepository_1.reportsRepository.create({
        ...reportData,
        createdBy: userId,
        createdAt: new Date(),
    });
    res.status(201).json({
        success: true,
        data: { report },
    });
}));
/**
 * PUT /api/reports/:reportId
 * Update a report (ADMIN/SUPERVISOR only)
 */
router.put('/:reportId', (0, middleware_1.authorize)(shared_1.UserRole.ADMIN, shared_1.UserRole.SUPERVISOR), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { reportId } = req.params;
    const updates = req.body;
    const userId = req.user?.userId;
    const report = await ReportsRepository_1.reportsRepository.update(reportId, {
        ...updates,
        updatedBy: userId,
    });
    if (!report) {
        res.status(404).json({
            success: false,
            error: 'Report not found',
        });
        return;
    }
    res.json({
        success: true,
        data: { report },
    });
}));
/**
 * DELETE /api/reports/:reportId
 * Delete a report (ADMIN only)
 */
router.delete('/:reportId', (0, middleware_1.authorize)(shared_1.UserRole.ADMIN), (0, middleware_1.asyncHandler)(async (req, res) => {
    const { reportId } = req.params;
    const deleted = await ReportsRepository_1.reportsRepository.delete(reportId);
    if (!deleted) {
        res.status(404).json({
            success: false,
            error: 'Report not found',
        });
        return;
    }
    res.json({
        success: true,
        message: 'Report deleted successfully',
    });
}));
// ============================================================================
// REPORT EXECUTION
// ============================================================================
/**
 * POST /api/reports/:reportId/execute
 * Execute a report and return results
 */
router.post('/:reportId/execute', (0, middleware_1.asyncHandler)(async (req, res) => {
    const { reportId } = req.params;
    const { format = shared_1.ReportFormat.JSON, parameters = {} } = req.body;
    const userId = req.user?.userId;
    try {
        const result = await ReportsService_1.reportsService.executeReport(reportId, format, parameters, userId);
        res.json({
            success: true,
            data: {
                execution: result.execution,
                results: result.data,
            },
        });
    }
    catch (error) {
        res.status(500).json({
            success: false,
            error: error.message,
        });
    }
}));
/**
 * GET /api/reports/:reportId/executions
 * Get execution history for a report
 */
router.get('/:reportId/executions', (0, middleware_1.asyncHandler)(async (req, res) => {
    const { reportId } = req.params;
    const limit = parseInt(req.query.limit) || 50;
    const executions = await ReportsRepository_1.reportsRepository.findExecutionsByReportId(reportId, limit);
    res.json({
        success: true,
        data: {
            executions,
            count: executions.length,
        },
    });
}));
exports.default = router;
//# sourceMappingURL=reports.js.map