"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const client_1 = require("./client");
async function checkTable() {
    const pool = (0, client_1.getPool)();
    try {
        const result = await pool.query("SELECT EXISTS (SELECT FROM pg_tables WHERE schemaname = 'public' AND tablename = 'order_state_changes')");
        console.log('order_state_changes table exists:', result.rows[0].exists);
    }
    catch (error) {
        console.error('Error:', error.message);
    }
    finally {
        await pool.end();
    }
}
checkTable();
//# sourceMappingURL=check-table.js.map