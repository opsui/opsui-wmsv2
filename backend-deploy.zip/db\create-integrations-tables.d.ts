/**
 * Create integrations tables
 */
export {};
//# sourceMappingURL=create-integrations-tables.d.ts.map