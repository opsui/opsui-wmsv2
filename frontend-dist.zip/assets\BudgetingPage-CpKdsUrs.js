import{j as e}from"./query-vendor-Blg1vgCh.js";import{u as H,r as i}from"./react-vendor-DNNwn-hs.js";import{ai as J,a0 as B,B as g,cT as W,cN as X}from"./index-BO_lgoz9.js";import{B as q}from"./Breadcrumb-Alv723Oy.js";import{F as K}from"./ArrowDownTrayIcon-CtOnrh5q.js";import{F as Z}from"./PrinterIcon-txxgFOGm.js";import{F}from"./PlusIcon--zCEhPQO.js";import{F as Y}from"./SparklesIcon-DCmT7Ac9.js";import{F as I}from"./ArrowTrendingUpIcon-DG7YDPi9.js";import{F as N}from"./ArrowTrendingDownIcon-DtcjfNKL.js";import{F as _}from"./CalendarIcon-H4mbpSrI.js";import"./ChevronRightIcon-B5iKoqAu.js";const ee=`
  /* Staggered entrance animation */
  @keyframes budget-stagger-in {
    from {
      opacity: 0;
      transform: translateY(28px) scale(0.97);
    }
    to {
      opacity: 1;
      transform: translateY(0) scale(1);
    }
  }

  /* Number reveal animation */
  @keyframes number-reveal {
    from {
      opacity: 0;
      transform: translateY(12px);
    }
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }

  /* Variance bar animation */
  @keyframes variance-bar-fill {
    from {
      transform: scaleX(0);
    }
    to {
      transform: scaleX(1);
    }
  }

  /* Decorative line reveal */
  @keyframes observatory-line-reveal {
    from {
      width: 0;
      opacity: 0;
    }
    to {
      width: 100%;
      opacity: 1;
    }
  }

  /* Subtle pulse for live data */
  @keyframes observatory-pulse {
    0%, 100% {
      box-shadow: 0 0 0 0 rgba(251, 191, 36, 0.3);
    }
    50% {
      box-shadow: 0 0 0 8px rgba(251, 191, 36, 0);
    }
  }

  /* Floating data point */
  @keyframes data-float {
    0%, 100% {
      transform: translateY(0) scale(1);
      opacity: 0.6;
    }
    50% {
      transform: translateY(-10px) scale(1.1);
      opacity: 1;
    }
  }

  /* Budget card styling */
  .budget-card {
    animation: budget-stagger-in 0.6s cubic-bezier(0.16, 1, 0.3, 1) backwards;
  }

  .budget-card:nth-child(1) { animation-delay: 0.05s; }
  .budget-card:nth-child(2) { animation-delay: 0.1s; }
  .budget-card:nth-child(3) { animation-delay: 0.15s; }
  .budget-card:nth-child(4) { animation-delay: 0.2s; }
  .budget-card:nth-child(5) { animation-delay: 0.25s; }
  .budget-card:nth-child(6) { animation-delay: 0.3s; }

  /* Metric card with gold accent */
  .metric-card-observatory {
    position: relative;
  }

  .metric-card-observatory::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 3px;
    background: linear-gradient(90deg, transparent, rgba(251, 191, 36, 0.6), transparent);
    animation: observatory-line-reveal 0.8s ease-out 0.4s backwards;
  }

  .metric-card-observatory.gold::before {
    background: linear-gradient(90deg, transparent, rgba(251, 191, 36, 0.7), transparent);
  }

  .metric-card-observatory.cyan::before {
    background: linear-gradient(90deg, transparent, rgba(6, 182, 212, 0.7), transparent);
  }

  .metric-card-observatory.emerald::before {
    background: linear-gradient(90deg, transparent, rgba(16, 185, 129, 0.7), transparent);
  }

  .metric-card-observatory.rose::before {
    background: linear-gradient(90deg, transparent, rgba(244, 63, 94, 0.7), transparent);
  }

  /* Live indicator pulse */
  .live-indicator {
    animation: observatory-pulse 2s ease-in-out infinite;
  }

  /* Number reveal */
  .number-reveal {
    animation: number-reveal 0.6s cubic-bezier(0.16, 1, 0.3, 1) backwards;
  }

  .number-reveal:nth-child(1) { animation-delay: 0.15s; }
  .number-reveal:nth-child(2) { animation-delay: 0.2s; }
  .number-reveal:nth-child(3) { animation-delay: 0.25s; }
  .number-reveal:nth-child(4) { animation-delay: 0.3s; }

  /* Variance bar */
  .variance-bar {
    transform-origin: left center;
    animation: variance-bar-fill 0.8s cubic-bezier(0.16, 1, 0.3, 1) backwards;
  }

  /* Account code styling - monospace */
  .account-code {
    font-family: 'JetBrains Mono', monospace;
    letter-spacing: 0.05em;
  }

  /* Category label - bold tracking */
  .category-label {
    font-family: 'Archivo', sans-serif;
    font-weight: 700;
    letter-spacing: 0.12em;
    text-transform: uppercase;
    font-size: 0.65rem;
  }

  /* Page title - editorial serif */
  .page-title-observatory {
    font-family: 'DM Serif Display', Georgia, serif;
    letter-spacing: -0.02em;
  }

  /* Atmospheric background */
  .observatory-atmosphere {
    position: fixed;
    inset: 0;
    pointer-events: none;
    z-index: 0;
  }

  .observatory-atmosphere::before {
    content: '';
    position: absolute;
    top: 0%;
    right: 5%;
    width: 50%;
    height: 50%;
    background: radial-gradient(ellipse at center, rgba(251, 191, 36, 0.08) 0%, transparent 60%);
    filter: blur(60px);
    animation: data-float 15s ease-in-out infinite;
  }

  .observatory-atmosphere::after {
    content: '';
    position: absolute;
    bottom: 10%;
    left: 0%;
    width: 40%;
    height: 40%;
    background: radial-gradient(ellipse at center, rgba(6, 182, 212, 0.06) 0%, transparent 60%);
    filter: blur(50px);
    animation: data-float 18s ease-in-out infinite reverse;
  }

  /* Light mode adjustments */
  html.light .observatory-atmosphere::before {
    background: radial-gradient(ellipse at center, rgba(251, 191, 36, 0.12) 0%, transparent 60%);
  }

  html.light .observatory-atmosphere::after {
    background: radial-gradient(ellipse at center, rgba(6, 182, 212, 0.08) 0%, transparent 60%);
  }

  /* Floating data points - decorative */
  .data-point {
    position: absolute;
    width: 4px;
    height: 4px;
    border-radius: 50%;
    background: rgba(251, 191, 36, 0.4);
    animation: data-float 8s ease-in-out infinite;
  }

  /* Observatory corner accents */
  .observatory-corner {
    position: relative;
  }

  .observatory-corner::before,
  .observatory-corner::after {
    content: '';
    position: absolute;
    width: 20px;
    height: 20px;
    border-color: rgba(251, 191, 36, 0.4);
    border-style: solid;
    transition: all 0.3s ease;
  }

  .observatory-corner::before {
    top: -1px;
    left: -1px;
    border-width: 2px 0 0 2px;
    border-radius: 6px 0 0 0;
  }

  .observatory-corner::after {
    bottom: -1px;
    right: -1px;
    border-width: 0 2px 2px 0;
    border-radius: 0 0 6px 0;
  }

  .observatory-corner:hover::before,
  .observatory-corner:hover::after {
    border-color: rgba(251, 191, 36, 0.7);
    width: 28px;
    height: 28px;
  }

  /* Table row hover effect */
  .budget-row {
    transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1);
  }

  .budget-row:hover {
    background: linear-gradient(90deg, 
      transparent 0%, 
      rgba(251, 191, 36, 0.04) 20%, 
      rgba(251, 191, 36, 0.06) 50%, 
      rgba(251, 191, 36, 0.04) 80%, 
      transparent 100%
    );
    transform: translateX(4px);
  }

  /* Floating action button */
  .fab-observatory {
    position: relative;
  }

  .fab-observatory::before {
    content: '';
    position: absolute;
    inset: -4px;
    border-radius: 16px;
    background: linear-gradient(135deg, rgba(251, 191, 36, 0.3), rgba(6, 182, 212, 0.3));
    opacity: 0;
    transition: opacity 0.3s ease;
    filter: blur(8px);
  }

  .fab-observatory:hover::before {
    opacity: 1;
  }

  /* Modal overlay with gradient */
  .modal-observatory {
    background: linear-gradient(135deg, rgba(0, 0, 0, 0.85) 0%, rgba(15, 23, 42, 0.95) 100%);
    backdrop-filter: blur(8px);
  }

  /* Grain texture overlay */
  .grain-overlay-budget {
    position: fixed;
    inset: 0;
    pointer-events: none;
    z-index: 1;
    opacity: 0.02;
    background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)'/%3E%3C/svg%3E");
  }

  html.light .grain-overlay-budget {
    opacity: 0.015;
  }

  /* Variance indicator badge */
  .variance-badge {
    font-family: 'JetBrains Mono', monospace;
    font-weight: 600;
    letter-spacing: 0.02em;
  }

  /* Hero metric display */
  .hero-metric-budget {
    font-family: 'JetBrains Mono', monospace;
    font-weight: 700;
    letter-spacing: -0.02em;
  }

  /* Budget selector styling */
  .budget-selector {
    background: linear-gradient(135deg, rgba(255, 255, 255, 0.05) 0%, rgba(255, 255, 255, 0.02) 100%);
    border: 1px solid rgba(251, 191, 36, 0.2);
    transition: all 0.3s ease;
  }

  .budget-selector:hover {
    border-color: rgba(251, 191, 36, 0.4);
  }

  .budget-selector:focus {
    border-color: rgba(251, 191, 36, 0.6);
    box-shadow: 0 0 0 3px rgba(251, 191, 36, 0.15);
  }
`;function ge(){H();const[d,j]=i.useState(""),[S,ae]=i.useState(!1),[$,x]=i.useState(!1),[h,R]=i.useState(!1),[w,P]=i.useState([{budgetId:"BG-2024-001",budgetName:"FY 2024 Operating Budget",fiscalYear:2024,budgetType:"ANNUAL",status:"ACTIVE"},{budgetId:"BG-2024-002",budgetName:"FY 2024 Q1 Forecast",fiscalYear:2024,budgetType:"QUARTERLY",status:"ACTIVE"},{budgetId:"BG-2024-003",budgetName:"FY 2024 Q2 Forecast",fiscalYear:2024,budgetType:"QUARTERLY",status:"DRAFT"}]),[r,f]=i.useState({budgetName:"",fiscalYear:2025,budgetType:"Annual",description:""}),[o,m]=i.useState({}),[v,A]=i.useState(!1),[E,k]=i.useState(!1);i.useEffect(()=>{R(!0)},[]);const V=[{budgetId:"BG-2024-001",budgetName:"FY 2024 Operating Budget",fiscalYear:2024,budgetType:"ANNUAL",status:"ACTIVE"},{budgetId:"BG-2024-002",budgetName:"FY 2024 Q1 Forecast",fiscalYear:2024,budgetType:"QUARTERLY",status:"ACTIVE"},{budgetId:"BG-2024-003",budgetName:"FY 2024 Q2 Forecast",fiscalYear:2024,budgetType:"QUARTERLY",status:"DRAFT"}],u=[{accountId:"ACT-4100",accountName:"Sales Revenue",accountCode:"4100",period:"2024-01",budgetedAmount:5e5,actualAmount:525e3,variance:-25e3,variancePercent:-5},{accountId:"ACT-4150",accountName:"Service Revenue",accountCode:"4150",period:"2024-01",budgetedAmount:15e4,actualAmount:162e3,variance:-12e3,variancePercent:-8},{accountId:"ACT-4200",accountName:"Interest Income",accountCode:"4200",period:"2024-01",budgetedAmount:5e3,actualAmount:5200,variance:-200,variancePercent:-4},{accountId:"ACT-5100",accountName:"Cost of Goods Sold",accountCode:"5100",period:"2024-01",budgetedAmount:3e5,actualAmount:29e4,variance:1e4,variancePercent:3.33},{accountId:"ACT-5120",accountName:"Material Costs",accountCode:"5120",period:"2024-01",budgetedAmount:18e4,actualAmount:175e3,variance:5e3,variancePercent:2.78},{accountId:"ACT-5200",accountName:"Operating Expenses",accountCode:"5200",period:"2024-01",budgetedAmount:8e4,actualAmount:85e3,variance:-5e3,variancePercent:-6.25},{accountId:"ACT-5210",accountName:"Salaries & Wages",accountCode:"5210",period:"2024-01",budgetedAmount:5e4,actualAmount:52e3,variance:-2e3,variancePercent:-4},{accountId:"ACT-5220",accountName:"Rent & Utilities",accountCode:"5220",period:"2024-01",budgetedAmount:15e3,actualAmount:14800,variance:200,variancePercent:1.33},{accountId:"ACT-5230",accountName:"Marketing Expenses",accountCode:"5230",period:"2024-01",budgetedAmount:12e3,actualAmount:14500,variance:-2500,variancePercent:-20.83},{accountId:"ACT-5240",accountName:"Insurance",accountCode:"5240",period:"2024-01",budgetedAmount:8e3,actualAmount:8e3,variance:0,variancePercent:0},{accountId:"ACT-5250",accountName:"Depreciation",accountCode:"5250",period:"2024-01",budgetedAmount:6500,actualAmount:6500,variance:0,variancePercent:0},{accountId:"ACT-5260",accountName:"Travel & Entertainment",accountCode:"5260",period:"2024-01",budgetedAmount:4500,actualAmount:5200,variance:-700,variancePercent:-15.56},{accountId:"ACT-5270",accountName:"Office Supplies",accountCode:"5270",period:"2024-01",budgetedAmount:2500,actualAmount:2100,variance:400,variancePercent:16},{accountId:"ACT-5280",accountName:"Professional Fees",accountCode:"5280",period:"2024-01",budgetedAmount:1e4,actualAmount:9500,variance:500,variancePercent:5}],l=a=>new Intl.NumberFormat("en-US",{style:"currency",currency:"USD",minimumFractionDigits:0,maximumFractionDigits:0}).format(a),D=u.reduce((a,t)=>a+t.budgetedAmount,0),L=u.reduce((a,t)=>a+t.actualAmount,0),s=u.reduce((a,t)=>a+t.variance,0),U=()=>{var T;if(!d)return;const a=V.find(c=>c.budgetId===d),t=[];t.push(`BUDGET VS ACTUAL REPORT - ${a==null?void 0:a.budgetName}`),t.push(`Fiscal Year: ${a==null?void 0:a.fiscalYear}`),t.push(""),t.push("Account,Account Code,Budgeted,Actual,Variance,Variance %"),u.forEach(c=>{t.push(`${c.accountName},${c.accountCode},${c.budgetedAmount},${c.actualAmount},${c.variance},${c.variancePercent.toFixed(2)}%`)});const n=t.join(`
`),y=new Blob([n],{type:"text/csv"}),C=URL.createObjectURL(y),b=document.createElement("a");b.href=C,b.download=`budget-${(T=a==null?void 0:a.budgetName)==null?void 0:T.toLowerCase().replace(/\s+/g,"-")}.csv`,document.body.appendChild(b),b.click(),document.body.removeChild(b),URL.revokeObjectURL(C)},z=()=>{window.print()},M=a=>{const t=Math.abs(a);return t<=5?{label:"On Track",color:"bg-emerald-500/15 text-emerald-400 border-emerald-500/30",icon:I}:t<=10?{label:"Watch",color:"bg-amber-500/15 text-amber-400 border-amber-500/30",icon:N}:{label:"Alert",color:"bg-rose-500/15 text-rose-400 border-rose-500/30",icon:N}},O=()=>{const a={};return r.budgetName.trim()?r.budgetName.trim().length<3?a.budgetName="Budget name must be at least 3 characters":r.budgetName.trim().length>100&&(a.budgetName="Budget name must be less than 100 characters"):a.budgetName="Budget name is required",(!r.fiscalYear||r.fiscalYear<2020||r.fiscalYear>2100)&&(a.fiscalYear="Please select a valid fiscal year"),r.budgetType||(a.budgetType="Please select a budget type"),m(a),Object.keys(a).length===0},p=(a,t)=>{f(n=>({...n,[a]:t})),o[a]&&m(n=>({...n,[a]:void 0}))},G=async()=>{if(O()){A(!0);try{await new Promise(n=>setTimeout(n,500));const a=`BG-${r.fiscalYear}-${String(w.length+1).padStart(3,"0")}`,t={budgetId:a,budgetName:r.budgetName.trim(),fiscalYear:r.fiscalYear,budgetType:r.budgetType.toUpperCase(),status:"DRAFT",description:r.description.trim()||void 0};P(n=>[...n,t]),f({budgetName:"",fiscalYear:2025,budgetType:"Annual",description:""}),m({}),k(!0),setTimeout(()=>k(!1),3e3),x(!1),j(a)}catch(a){console.error("Failed to create budget:",a),m({budgetName:"Failed to create budget. Please try again."})}finally{A(!1)}}},Q=()=>{f({budgetName:"",fiscalYear:2025,budgetType:"Annual",description:""}),m({}),x(!0)};return e.jsxs("div",{className:"min-h-screen relative",children:[e.jsx("style",{children:ee}),e.jsx("div",{className:"observatory-atmosphere","aria-hidden":"true"}),e.jsx("div",{className:"grain-overlay-budget","aria-hidden":"true"}),e.jsx(J,{}),e.jsxs("main",{className:"relative z-10 w-full px-4 sm:px-6 lg:px-8 py-8",children:[e.jsx(q,{}),e.jsx("header",{className:"mb-10",children:e.jsxs("div",{className:"flex flex-col lg:flex-row lg:items-end lg:justify-between gap-6",children:[e.jsxs("div",{className:`transition-all duration-700 ${h?"opacity-100 translate-y-0":"opacity-0 translate-y-4"}`,children:[e.jsxs("div",{className:"flex items-center gap-4 mb-3",children:[e.jsxs("div",{className:"relative",children:[e.jsx("div",{className:"p-3 bg-gradient-to-br from-amber-500/20 to-cyan-500/20 rounded-xl border border-amber-500/30",children:e.jsx(B,{className:"h-7 w-7 text-amber-400"})}),e.jsx("div",{className:"absolute -top-1 -right-1 w-3 h-3 bg-amber-500 rounded-full live-indicator"})]}),e.jsx("div",{children:e.jsx("span",{className:"category-label text-amber-400 tracking-widest",children:"Financial Planning"})})]}),e.jsx("h1",{className:"page-title-observatory text-4xl lg:text-5xl text-white dark:text-white tracking-tight",children:"Budgeting & Forecasting"}),e.jsx("p",{className:"mt-3 text-lg text-gray-400 dark:text-gray-400 max-w-2xl",children:"Analyze budget performance, track variances, and forecast financial outcomes"})]}),e.jsxs("div",{className:`flex flex-wrap items-center gap-3 transition-all duration-700 delay-200 ${h?"opacity-100 translate-y-0":"opacity-0 translate-y-4"}`,children:[e.jsxs(g,{variant:"secondary",onClick:U,className:"flex items-center gap-2 bg-white/5 hover:bg-white/10 border-white/10 hover:border-amber-500/30 transition-all duration-300",children:[e.jsx(K,{className:"h-4 w-4"}),e.jsx("span",{className:"hidden sm:inline",children:"Export"})]}),e.jsxs(g,{variant:"secondary",onClick:z,className:"flex items-center gap-2 bg-white/5 hover:bg-white/10 border-white/10 hover:border-amber-500/30 transition-all duration-300",children:[e.jsx(Z,{className:"h-4 w-4"}),e.jsx("span",{className:"hidden sm:inline",children:"Print"})]}),e.jsx("div",{className:"fab-observatory",children:e.jsxs(g,{variant:"primary",onClick:Q,className:"flex items-center gap-2 bg-gradient-to-r from-amber-600 to-cyan-600 hover:from-amber-500 hover:to-cyan-500 border-0 shadow-lg shadow-amber-500/25 hover:shadow-amber-500/40 transition-all duration-300",children:[e.jsx(F,{className:"h-4 w-4"}),e.jsx("span",{children:"New Budget"})]})})]})]})}),e.jsx("section",{className:"budget-card mb-8 transition-all duration-500 ",children:e.jsx("div",{className:"bg-gradient-to-br from-slate-900/80 to-slate-800/60 backdrop-blur-xl rounded-xl border border-white/10 p-5 lg:p-6",children:e.jsxs("div",{className:"flex flex-col sm:flex-row sm:items-center gap-4",children:[e.jsxs("div",{className:"flex items-center gap-3",children:[e.jsx("div",{className:"p-2 bg-amber-500/10 rounded-lg",children:e.jsx(W,{className:"h-5 w-5 text-amber-400"})}),e.jsxs("div",{children:[e.jsx("span",{className:"category-label text-gray-400",children:"Select Dataset"}),e.jsx("p",{className:"text-xs text-gray-500 mt-0.5",children:"Choose a budget to analyze"})]})]}),e.jsx("div",{className:"flex-1 sm:max-w-md",children:e.jsxs("select",{id:"budget-select",value:d,onChange:a=>j(a.target.value),className:"budget-selector w-full px-4 py-3 rounded-xl text-sm text-white focus:outline-none cursor-pointer",children:[e.jsx("option",{value:"",className:"bg-slate-900 text-gray-400",children:"Select a budget..."}),w.map(a=>e.jsxs("option",{value:a.budgetId,className:"bg-slate-900 text-white",children:[a.budgetName," (",a.fiscalYear,")"]},a.budgetId))]})})]})})}),d&&!S&&e.jsxs("div",{className:"space-y-6",children:[e.jsxs("section",{className:"grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6",children:[e.jsxs("div",{className:"budget-card metric-card-observatory cyan bg-gradient-to-br from-slate-900/80 to-slate-800/60 backdrop-blur-xl rounded-xl border border-white/10 p-5 lg:p-6 hover:border-cyan-500/30 transition-all duration-500",children:[e.jsxs("div",{className:"flex items-center gap-3 mb-4",children:[e.jsx("div",{className:"p-2 bg-cyan-500/10 rounded-lg",children:e.jsx(X,{className:"h-5 w-5 text-cyan-400"})}),e.jsx("span",{className:"text-sm font-medium text-gray-400 uppercase tracking-wider",children:"Total Budgeted"})]}),e.jsx("p",{className:"number-reveal hero-metric-budget text-3xl lg:text-4xl font-bold text-cyan-400",children:l(D)})]}),e.jsxs("div",{className:"budget-card metric-card-observatory gold bg-gradient-to-br from-slate-900/80 to-slate-800/60 backdrop-blur-xl rounded-xl border border-white/10 p-5 lg:p-6 hover:border-amber-500/30 transition-all duration-500",children:[e.jsxs("div",{className:"flex items-center gap-3 mb-4",children:[e.jsx("div",{className:"p-2 bg-amber-500/10 rounded-lg",children:e.jsx(Y,{className:"h-5 w-5 text-amber-400"})}),e.jsx("span",{className:"text-sm font-medium text-gray-400 uppercase tracking-wider",children:"Total Actual"})]}),e.jsx("p",{className:"number-reveal hero-metric-budget text-3xl lg:text-4xl font-bold text-amber-400",children:l(L)})]}),e.jsxs("div",{className:`budget-card metric-card-observatory ${s>=0?"emerald":"rose"} bg-gradient-to-br from-slate-900/80 to-slate-800/60 backdrop-blur-xl rounded-xl border border-white/10 p-5 lg:p-6 hover:border-${s>=0?"emerald":"rose"}-500/30 transition-all duration-500`,children:[e.jsxs("div",{className:"flex items-center gap-3 mb-4",children:[e.jsx("div",{className:`p-2 ${s>=0?"bg-emerald-500/10":"bg-rose-500/10"} rounded-lg`,children:s>=0?e.jsx(I,{className:"h-5 w-5 text-emerald-400"}):e.jsx(N,{className:"h-5 w-5 text-rose-400"})}),e.jsx("span",{className:"text-sm font-medium text-gray-400 uppercase tracking-wider",children:"Net Variance"})]}),e.jsxs("p",{className:`number-reveal hero-metric-budget text-3xl lg:text-4xl font-bold ${s>=0?"text-emerald-400":"text-rose-400"}`,children:[s>=0?"+":"",l(s)]})]}),e.jsxs("div",{className:`budget-card metric-card-observatory ${s>=0?"emerald":"rose"} bg-gradient-to-br from-slate-900/80 to-slate-800/60 backdrop-blur-xl rounded-xl border border-white/10 p-5 lg:p-6 hover:border-${s>=0?"emerald":"rose"}-500/30 transition-all duration-500`,children:[e.jsxs("div",{className:"flex items-center gap-3 mb-4",children:[e.jsx("div",{className:`p-2 ${s>=0?"bg-emerald-500/10":"bg-rose-500/10"} rounded-lg`,children:e.jsx(_,{className:`h-5 w-5 ${s>=0?"text-emerald-400":"text-rose-400"}`})}),e.jsx("span",{className:"text-sm font-medium text-gray-400 uppercase tracking-wider",children:"Budget Status"})]}),e.jsx("p",{className:`number-reveal hero-metric-budget text-3xl lg:text-4xl font-bold ${s>=0?"text-emerald-400":"text-rose-400"}`,children:s>=0?"Under":"Over"})]})]}),e.jsxs("div",{className:"budget-card observatory-corner bg-gradient-to-br from-slate-900/80 to-slate-800/60 backdrop-blur-xl rounded-xl border border-white/10 overflow-hidden",children:[e.jsxs("div",{className:"px-6 py-5 border-b border-white/10 bg-white/[0.02]",children:[e.jsx("h2",{className:"text-lg font-semibold text-white tracking-tight",children:"Budget vs Actual Analysis"}),e.jsx("p",{className:"text-sm text-gray-400 mt-1",children:"Variance breakdown by account category"})]}),e.jsx("div",{className:"overflow-x-auto",children:e.jsxs("table",{className:"w-full",role:"table",children:[e.jsx("thead",{children:e.jsxs("tr",{className:"border-b border-white/10 bg-white/[0.02]",children:[e.jsx("th",{className:"text-left py-4 px-6 text-xs font-bold text-gray-400 uppercase tracking-wider",children:"Account"}),e.jsx("th",{className:"text-left py-4 px-6 text-xs font-bold text-gray-400 uppercase tracking-wider",children:"Code"}),e.jsx("th",{className:"text-right py-4 px-6 text-xs font-bold text-gray-400 uppercase tracking-wider",children:"Budgeted"}),e.jsx("th",{className:"text-right py-4 px-6 text-xs font-bold text-gray-400 uppercase tracking-wider",children:"Actual"}),e.jsx("th",{className:"text-right py-4 px-6 text-xs font-bold text-gray-400 uppercase tracking-wider",children:"Variance"}),e.jsx("th",{className:"text-right py-4 px-6 text-xs font-bold text-gray-400 uppercase tracking-wider",children:"%"}),e.jsx("th",{className:"text-center py-4 px-6 text-xs font-bold text-gray-400 uppercase tracking-wider",children:"Status"})]})}),e.jsx("tbody",{className:"divide-y divide-white/5",children:u.map((a,t)=>{const n=M(a.variancePercent),y=n.icon;return e.jsxs("tr",{className:"budget-row",style:{animationDelay:`${.1+t*.03}s`},children:[e.jsx("td",{className:"py-4 px-6",children:e.jsx("span",{className:"text-sm text-white font-medium",children:a.accountName})}),e.jsx("td",{className:"py-4 px-6",children:e.jsx("span",{className:"account-code text-sm text-gray-500",children:a.accountCode})}),e.jsx("td",{className:"py-4 px-6 text-right",children:e.jsx("span",{className:"text-sm text-cyan-400 font-mono",children:l(a.budgetedAmount)})}),e.jsx("td",{className:"py-4 px-6 text-right",children:e.jsx("span",{className:"text-sm text-amber-400 font-mono",children:l(a.actualAmount)})}),e.jsx("td",{className:"py-4 px-6 text-right",children:e.jsxs("span",{className:`text-sm font-medium font-mono ${a.variance>=0?"text-emerald-400":"text-rose-400"}`,children:[a.variance>=0?"+":"",l(a.variance)]})}),e.jsx("td",{className:"py-4 px-6 text-right",children:e.jsxs("span",{className:`variance-badge text-sm ${a.variancePercent>=0?"text-emerald-400":"text-rose-400"}`,children:[a.variancePercent>=0?"+":"",a.variancePercent.toFixed(1),"%"]})}),e.jsx("td",{className:"py-4 px-6",children:e.jsx("div",{className:"flex items-center justify-center",children:e.jsxs("span",{className:`variance-badge inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md border ${n.color}`,children:[e.jsx(y,{className:"h-3 w-3"}),e.jsx("span",{className:"text-xs",children:n.label})]})})})]},t)})})]})})]})]}),!d&&e.jsx("div",{className:"budget-card bg-gradient-to-br from-slate-900/80 to-slate-800/60 backdrop-blur-xl rounded-xl border border-white/10 overflow-hidden",children:e.jsxs("div",{className:"p-16 text-center",children:[e.jsxs("div",{className:"relative inline-block mb-6",children:[e.jsx("div",{className:"p-4 bg-amber-500/10 rounded-2xl",children:e.jsx(B,{className:"h-12 w-12 text-amber-400/60"})}),e.jsx("div",{className:"absolute -top-2 -right-2 w-4 h-4 bg-amber-500/30 rounded-full animate-pulse"})]}),e.jsx("h3",{className:"text-lg font-semibold text-white mb-2",children:"Select a Budget to Analyze"}),e.jsx("p",{className:"text-gray-400 max-w-md mx-auto",children:"Choose a budget from the dropdown above to view detailed variance analysis and financial performance metrics"})]})}),$&&e.jsxs("div",{className:"fixed inset-0 z-50 flex items-center justify-center p-4",children:[e.jsx("div",{className:"modal-observatory absolute inset-0",onClick:()=>x(!1),"aria-hidden":"true"}),e.jsxs("div",{className:"relative w-full max-w-lg bg-gradient-to-br from-slate-900 to-slate-800 rounded-2xl border border-white/10 shadow-2xl shadow-black/50 overflow-hidden animate-in fade-in zoom-in-95 duration-300",children:[e.jsx("div",{className:"px-6 py-5 border-b border-white/10 bg-white/[0.02]",children:e.jsxs("div",{className:"flex items-center gap-3",children:[e.jsx("div",{className:"p-2 bg-amber-500/10 rounded-lg",children:e.jsx(F,{className:"h-5 w-5 text-amber-400"})}),e.jsxs("div",{children:[e.jsx("h3",{className:"text-lg font-semibold text-white",children:"Create New Budget"}),e.jsx("p",{className:"text-sm text-gray-400 mt-0.5",children:"Define a new financial planning period"})]})]})}),E&&e.jsxs("div",{className:"mx-6 mt-4 p-3 bg-emerald-500/10 border border-emerald-500/30 rounded-xl flex items-center gap-2",children:[e.jsx(Y,{className:"h-5 w-5 text-emerald-400"}),e.jsx("span",{className:"text-emerald-400 text-sm",children:"Budget created successfully!"})]}),e.jsxs("div",{className:"p-6 space-y-4",children:[e.jsxs("div",{children:[e.jsxs("label",{className:"block text-sm font-medium text-gray-300 mb-2",children:["Budget Name ",e.jsx("span",{className:"text-rose-400",children:"*"})]}),e.jsx("input",{type:"text",value:r.budgetName,onChange:a=>p("budgetName",a.target.value),placeholder:"e.g., FY 2025 Operating Budget",className:`budget-selector w-full px-4 py-3 rounded-xl text-white placeholder-gray-500 focus:outline-none transition-all ${o.budgetName?"border-rose-500":""}`}),o.budgetName&&e.jsx("p",{className:"mt-1 text-sm text-rose-400",children:o.budgetName})]}),e.jsxs("div",{className:"grid grid-cols-2 gap-4",children:[e.jsxs("div",{children:[e.jsxs("label",{className:"block text-sm font-medium text-gray-300 mb-2",children:["Fiscal Year ",e.jsx("span",{className:"text-rose-400",children:"*"})]}),e.jsxs("select",{value:r.fiscalYear,onChange:a=>p("fiscalYear",parseInt(a.target.value)),className:`budget-selector w-full px-4 py-3 rounded-xl text-white focus:outline-none transition-all cursor-pointer ${o.fiscalYear?"border-rose-500":""}`,children:[e.jsx("option",{value:2024,className:"bg-slate-900",children:"2024"}),e.jsx("option",{value:2025,className:"bg-slate-900",children:"2025"}),e.jsx("option",{value:2026,className:"bg-slate-900",children:"2026"})]}),o.fiscalYear&&e.jsx("p",{className:"mt-1 text-sm text-rose-400",children:o.fiscalYear})]}),e.jsxs("div",{children:[e.jsxs("label",{className:"block text-sm font-medium text-gray-300 mb-2",children:["Budget Type ",e.jsx("span",{className:"text-rose-400",children:"*"})]}),e.jsxs("select",{value:r.budgetType,onChange:a=>p("budgetType",a.target.value),className:`budget-selector w-full px-4 py-3 rounded-xl text-white focus:outline-none transition-all cursor-pointer ${o.budgetType?"border-rose-500":""}`,children:[e.jsx("option",{value:"Annual",className:"bg-slate-900",children:"Annual"}),e.jsx("option",{value:"Quarterly",className:"bg-slate-900",children:"Quarterly"}),e.jsx("option",{value:"Monthly",className:"bg-slate-900",children:"Monthly"})]}),o.budgetType&&e.jsx("p",{className:"mt-1 text-sm text-rose-400",children:o.budgetType})]})]}),e.jsxs("div",{children:[e.jsx("label",{className:"block text-sm font-medium text-gray-300 mb-2",children:"Description (Optional)"}),e.jsx("textarea",{value:r.description,onChange:a=>p("description",a.target.value),placeholder:"Brief description of this budget...",rows:3,className:"budget-selector w-full px-4 py-3 rounded-xl text-white placeholder-gray-500 focus:outline-none transition-all resize-none"})]})]}),e.jsxs("div",{className:"px-6 py-4 border-t border-white/10 bg-white/[0.02] flex justify-end gap-3",children:[e.jsx(g,{variant:"secondary",onClick:()=>x(!1),disabled:v,className:"bg-white/5 hover:bg-white/10 border-white/10",children:"Cancel"}),e.jsx(g,{variant:"primary",onClick:G,disabled:v,className:"bg-gradient-to-r from-amber-600 to-cyan-600 hover:from-amber-500 hover:to-cyan-500 border-0 disabled:opacity-50 disabled:cursor-not-allowed",children:v?e.jsxs("span",{className:"flex items-center gap-2",children:[e.jsxs("svg",{className:"animate-spin h-4 w-4",viewBox:"0 0 24 24",children:[e.jsx("circle",{className:"opacity-25",cx:"12",cy:"12",r:"10",stroke:"currentColor",strokeWidth:"4",fill:"none"}),e.jsx("path",{className:"opacity-75",fill:"currentColor",d:"M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"})]}),"Creating..."]}):"Create Budget"})]})]})]})]})]})}export{ge as default};
//# sourceMappingURL=BudgetingPage-CpKdsUrs.js.map
