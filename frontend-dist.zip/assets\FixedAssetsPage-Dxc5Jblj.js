import{j as e}from"./query-vendor-Blg1vgCh.js";import{u as Q,r as i}from"./react-vendor-DNNwn-hs.js";import{u as W,ai as J,x as K,au as m,l as Z,bT as V,B as n,a0 as ee,cD as te,S as se,c as I}from"./index-BO_lgoz9.js";import{B as ae}from"./Breadcrumb-Alv723Oy.js";import{F as re}from"./ArrowDownTrayIcon-CtOnrh5q.js";import{F as le}from"./PrinterIcon-txxgFOGm.js";import{F as B}from"./PlusIcon--zCEhPQO.js";import{F as ie}from"./CalendarIcon-H4mbpSrI.js";import{F as oe}from"./SparklesIcon-DCmT7Ac9.js";import{F as ne}from"./PencilIcon-CLoZEvGk.js";import{F as R}from"./TrashIcon-BykFWxe6.js";import"./ChevronRightIcon-B5iKoqAu.js";const ce=`
  /* Staggered entrance animation */
  @keyframes asset-stagger-in {
    from {
      opacity: 0;
      transform: translateY(32px) scale(0.97);
    }
    to {
      opacity: 1;
      transform: translateY(0) scale(1);
    }
  }

  /* Number slide up with elegant easing */
  @keyframes number-slide-up {
    from {
      opacity: 0;
      transform: translateY(16px);
    }
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }

  /* Decorative line reveal */
  @keyframes deco-line-reveal {
    from {
      width: 0;
      opacity: 0;
    }
    to {
      width: 100%;
      opacity: 1;
    }
  }

  /* Subtle float for decorative elements */
  @keyframes asset-float {
    0%, 100% {
      transform: translateY(0) rotate(0deg);
    }
    50% {
      transform: translateY(-6px) rotate(1deg);
    }
  }

  /* Metric pulse for live indicators */
  @keyframes metric-pulse {
    0%, 100% {
      box-shadow: 0 0 0 0 rgba(16, 185, 129, 0.4);
    }
    50% {
      box-shadow: 0 0 0 8px rgba(16, 185, 129, 0);
    }
  }

  /* Row hover highlight */
  @keyframes row-highlight {
    from {
      background-position: -100% 0;
    }
    to {
      background-position: 200% 0;
    }
  }

  /* Asset card styling */
  .asset-card {
    animation: asset-stagger-in 0.6s cubic-bezier(0.16, 1, 0.3, 1) backwards;
  }

  .asset-card:nth-child(1) { animation-delay: 0.05s; }
  .asset-card:nth-child(2) { animation-delay: 0.1s; }
  .asset-card:nth-child(3) { animation-delay: 0.15s; }
  .asset-card:nth-child(4) { animation-delay: 0.2s; }
  .asset-card:nth-child(5) { animation-delay: 0.25s; }
  .asset-card:nth-child(6) { animation-delay: 0.3s; }

  /* Metric card with pulse */
  .metric-card {
    position: relative;
  }

  .metric-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 3px;
    background: linear-gradient(90deg, transparent, rgba(16, 185, 129, 0.6), transparent);
    animation: deco-line-reveal 0.8s ease-out 0.4s backwards;
  }

  .metric-card.live::after {
    content: '';
    position: absolute;
    top: 12px;
    right: 12px;
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: #10b981;
    animation: metric-pulse 2s ease-in-out infinite;
  }

  /* Hero number styling */
  .hero-number {
    animation: number-slide-up 0.7s cubic-bezier(0.16, 1, 0.3, 1) backwards;
  }

  .hero-number:nth-child(1) { animation-delay: 0.2s; }
  .hero-number:nth-child(2) { animation-delay: 0.3s; }
  .hero-number:nth-child(3) { animation-delay: 0.4s; }
  .hero-number:nth-child(4) { animation-delay: 0.5s; }

  /* Art Deco corner accents */
  .deco-corner {
    position: relative;
  }

  .deco-corner::before,
  .deco-corner::after {
    content: '';
    position: absolute;
    width: 24px;
    height: 24px;
    border-color: rgba(16, 185, 129, 0.4);
    border-style: solid;
    transition: all 0.3s ease;
  }

  .deco-corner::before {
    top: -1px;
    left: -1px;
    border-width: 2px 0 0 2px;
    border-radius: 6px 0 0 0;
  }

  .deco-corner::after {
    bottom: -1px;
    right: -1px;
    border-width: 0 2px 2px 0;
    border-radius: 0 0 6px 0;
  }

  .deco-corner:hover::before,
  .deco-corner:hover::after {
    border-color: rgba(16, 185, 129, 0.7);
    width: 32px;
    height: 32px;
  }

  /* Table row hover effect */
  .asset-row {
    transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1);
  }

  .asset-row:hover {
    background: linear-gradient(90deg, 
      transparent 0%, 
      rgba(16, 185, 129, 0.05) 20%, 
      rgba(16, 185, 129, 0.08) 50%, 
      rgba(16, 185, 129, 0.05) 80%, 
      transparent 100%
    );
    transform: translateX(4px);
  }

  /* Asset number styling - distinctive monospace */
  .asset-number {
    font-family: 'JetBrains Mono', monospace;
    letter-spacing: 0.08em;
  }

  /* Category badge - art deco style */
  .category-badge {
    font-family: 'Archivo', sans-serif;
    font-weight: 700;
    letter-spacing: 0.1em;
    text-transform: uppercase;
    font-size: 0.65rem;
  }

  /* Page title - editorial serif */
  .page-title {
    font-family: 'DM Serif Display', Georgia, serif;
    letter-spacing: -0.02em;
  }

  /* Atmospheric background */
  .asset-atmosphere {
    position: fixed;
    inset: 0;
    pointer-events: none;
    z-index: 0;
  }

  .asset-atmosphere::before {
    content: '';
    position: absolute;
    top: 5%;
    right: 10%;
    width: 45%;
    height: 45%;
    background: radial-gradient(ellipse at center, rgba(16, 185, 129, 0.1) 0%, transparent 60%);
    filter: blur(60px);
    animation: asset-float 12s ease-in-out infinite;
  }

  .asset-atmosphere::after {
    content: '';
    position: absolute;
    bottom: 15%;
    left: 5%;
    width: 35%;
    height: 35%;
    background: radial-gradient(ellipse at center, rgba(6, 182, 212, 0.08) 0%, transparent 60%);
    filter: blur(50px);
    animation: asset-float 15s ease-in-out infinite reverse;
  }

  /* Light mode adjustments */
  html.light .asset-atmosphere::before {
    background: radial-gradient(ellipse at center, rgba(16, 185, 129, 0.15) 0%, transparent 60%);
  }

  html.light .asset-atmosphere::after {
    background: radial-gradient(ellipse at center, rgba(6, 182, 212, 0.1) 0%, transparent 60%);
  }

  /* Floating action button */
  .fab-container {
    position: relative;
  }

  .fab-container::before {
    content: '';
    position: absolute;
    inset: -4px;
    border-radius: 16px;
    background: linear-gradient(135deg, rgba(16, 185, 129, 0.3), rgba(6, 182, 212, 0.3));
    opacity: 0;
    transition: opacity 0.3s ease;
    filter: blur(8px);
  }

  .fab-container:hover::before {
    opacity: 1;
  }

  /* Modal overlay with gradient */
  .modal-overlay {
    background: linear-gradient(135deg, rgba(0, 0, 0, 0.8) 0%, rgba(15, 23, 42, 0.9) 100%);
    backdrop-filter: blur(8px);
  }

  /* Grain texture overlay */
  .grain-overlay {
    position: fixed;
    inset: 0;
    pointer-events: none;
    z-index: 1;
    opacity: 0.025;
    background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)'/%3E%3C/svg%3E");
  }

  html.light .grain-overlay {
    opacity: 0.02;
  }

  /* Toast notification */
  .toast {
    animation: slide-in-right 0.3s ease-out;
  }

  @keyframes slide-in-right {
    from {
      transform: translateX(100%);
      opacity: 0;
    }
    to {
      transform: translateX(0);
      opacity: 1;
    }
  }

  /* Input error state */
  .input-error {
    border-color: rgba(239, 68, 68, 0.5) !important;
    background-color: rgba(239, 68, 68, 0.05) !important;
  }
`;async function de(){return(await I.get("/accounting/fixed-assets")).data.assets||[]}async function me(s){return(await I.post("/accounting/fixed-assets",{assetNumber:s.assetNumber,assetName:s.assetName,assetCategory:s.category,purchaseDate:s.purchaseDate,purchaseCost:parseFloat(s.purchaseCost),salvageValue:parseFloat(s.salvageValue||"0"),usefulLife:parseInt(s.usefulLife),depreciationMethod:"STRAIGHT_LINE"})).data}async function ue(s){await I.delete(`/accounting/fixed-assets/${s}`)}const S={assetName:"",assetNumber:"",category:"",purchaseCost:"",purchaseDate:new Date().toISOString().split("T")[0],usefulLife:"",salvageValue:"0"};function Ce(){Q(),W(t=>t.accessToken);const[s,h]=i.useState([]),[M,$]=i.useState(!0),[z,p]=i.useState(!1),[k,O]=i.useState(!1),[l,N]=i.useState(S),[a,y]=i.useState({}),[u,j]=i.useState(!1),[w,C]=i.useState(null),[g,v]=i.useState({show:!1,assetId:"",assetName:""}),E=i.useCallback(async()=>{try{$(!0);const t=await de();h(t)}catch(t){console.error("Failed to load assets:",t),x("error","Failed to load assets. Using sample data."),h(_())}finally{$(!1)}},[]);i.useEffect(()=>{O(!0),E()},[E]);const _=()=>[{assetId:"FA-001",assetNumber:"EQ-2024-001",assetName:"Forklift - Toyota 8-Series",assetCategory:"Equipment",purchaseDate:new Date("2024-01-15"),purchaseCost:45e3,salvageValue:5e3,usefulLife:10,depreciationMethod:"STRAIGHT_LINE",currentBookValue:41e3,accumulatedDepreciation:4e3,status:"ACTIVE"},{assetId:"FA-002",assetNumber:"VE-2024-001",assetName:"Delivery Truck - Ford Transit",assetCategory:"Vehicles",purchaseDate:new Date("2024-03-01"),purchaseCost:35e3,salvageValue:3e3,usefulLife:8,depreciationMethod:"DOUBLE_DECLINING",currentBookValue:32e3,accumulatedDepreciation:3e3,status:"ACTIVE"},{assetId:"FA-003",assetNumber:"BL-2023-001",assetName:"Warehouse Racking System",assetCategory:"Building Improvements",purchaseDate:new Date("2023-06-01"),purchaseCost:12e4,salvageValue:0,usefulLife:20,depreciationMethod:"STRAIGHT_LINE",currentBookValue:114e3,accumulatedDepreciation:6e3,status:"ACTIVE"},{assetId:"FA-004",assetNumber:"OF-2022-001",assetName:"Office Furniture",assetCategory:"Furniture & Fixtures",purchaseDate:new Date("2022-01-15"),purchaseCost:15e3,salvageValue:0,usefulLife:7,depreciationMethod:"STRAIGHT_LINE",currentBookValue:10714,accumulatedDepreciation:4286,status:"ACTIVE"}],x=(t,r)=>{C({type:t,message:r}),setTimeout(()=>C(null),5e3)},q=()=>{const t={};return l.assetName.trim()||(t.assetName="Asset name is required"),l.assetNumber.trim()||(t.assetNumber="Asset number is required"),l.category||(t.category="Category is required"),(!l.purchaseCost||parseFloat(l.purchaseCost)<=0)&&(t.purchaseCost="Purchase cost must be greater than 0"),l.purchaseDate||(t.purchaseDate="Purchase date is required"),(!l.usefulLife||parseInt(l.usefulLife)<=0)&&(t.usefulLife="Useful life must be greater than 0"),y(t),Object.keys(t).length===0},c=(t,r)=>{N(b=>({...b,[t]:r})),a[t]&&y(b=>({...b,[t]:void 0}))},U=async()=>{if(q()){j(!0);try{const t=await me(l);h(r=>[...r,t]),p(!1),N(S),y({}),x("success",`Asset "${t.assetName}" created successfully!`)}catch(t){console.error("Failed to create asset:",t),x("error",t instanceof Error?t.message:"Failed to create asset")}finally{j(!1)}}},P=async()=>{if(g.assetId){j(!0);try{await ue(g.assetId),h(t=>t.filter(r=>r.assetId!==g.assetId)),v({show:!1,assetId:"",assetName:""}),x("success","Asset deleted successfully!")}catch(t){console.error("Failed to delete asset:",t),x("error",t instanceof Error?t.message:"Failed to delete asset")}finally{j(!1)}}},T=()=>{p(!1),N(S),y({})},o=t=>new Intl.NumberFormat("en-US",{style:"currency",currency:"USD",minimumFractionDigits:0,maximumFractionDigits:0}).format(t),F=s.reduce((t,r)=>t+(Number(r.purchaseCost)||0),0),D=s.reduce((t,r)=>t+(Number(r.accumulatedDepreciation)||0),0),A=s.reduce((t,r)=>t+(Number(r.currentBookValue)||0),0),G=()=>{const t=[];t.push("FIXED ASSET REGISTER"),t.push(`Generated on ${new Date().toLocaleDateString()}`),t.push(""),t.push("Asset Number,Asset Name,Category,Purchase Date,Cost,Accum. Depreciation,Net Book Value"),s.forEach(d=>{t.push(`${d.assetNumber},${d.assetName},${d.assetCategory||""},${new Date(d.purchaseDate).toLocaleDateString()},${d.purchaseCost},${d.accumulatedDepreciation},${d.currentBookValue}`)}),t.push(""),t.push(`TOTALS,,,$${F},$${D},$${A}`);const r=t.join(`
`),b=new Blob([r],{type:"text/csv"}),L=URL.createObjectURL(b),f=document.createElement("a");f.href=L,f.download=`fixed-assets-${new Date().toISOString().split("T")[0]}.csv`,document.body.appendChild(f),f.click(),document.body.removeChild(f),URL.revokeObjectURL(L),x("success","Asset register exported successfully!")},Y=()=>{window.print()},H=t=>({Equipment:"bg-emerald-500/15 text-emerald-400 border-emerald-500/30",Vehicles:"bg-blue-500/15 text-blue-400 border-blue-500/30",Building_Improve:"bg-purple-500/15 text-purple-400 border-purple-500/30",Furniture_Fixt:"bg-amber-500/15 text-amber-400 border-amber-500/30","Building Improvements":"bg-purple-500/15 text-purple-400 border-purple-500/30","Furniture & Fixtures":"bg-amber-500/15 text-amber-400 border-amber-500/30"})[t||""]||"bg-slate-500/15 text-slate-400 border-slate-500/30",X=t=>({Equipment:"Equipment",Vehicles:"Vehicles",Building_Improve:"Building Improvements",Furniture_Fixt:"Furniture & Fixtures"})[t||""]||t||"-";return e.jsxs("div",{className:"min-h-screen relative",children:[e.jsx("style",{children:ce}),e.jsx("div",{className:"asset-atmosphere","aria-hidden":"true"}),e.jsx("div",{className:"grain-overlay","aria-hidden":"true"}),e.jsx(J,{}),w&&e.jsx("div",{className:"fixed top-4 right-4 z-[100] toast",children:e.jsxs("div",{className:`flex items-center gap-3 px-4 py-3 rounded-lg border ${w.type==="success"?"bg-emerald-500/10 border-emerald-500/30 text-emerald-400":"bg-red-500/10 border-red-500/30 text-red-400"}`,children:[w.type==="success"?e.jsx(K,{className:"h-5 w-5"}):e.jsx(m,{className:"h-5 w-5"}),e.jsx("span",{className:"text-sm font-medium",children:w.message}),e.jsx("button",{onClick:()=>C(null),className:"ml-2 hover:opacity-70 transition-opacity",children:e.jsx(Z,{className:"h-4 w-4"})})]})}),e.jsxs("main",{className:"relative z-10 w-full px-4 sm:px-6 lg:px-8 py-8",children:[e.jsx(ae,{}),e.jsx("header",{className:"mb-10",children:e.jsxs("div",{className:"flex flex-col lg:flex-row lg:items-end lg:justify-between gap-6",children:[e.jsxs("div",{className:`transition-all duration-700 ${k?"opacity-100 translate-y-0":"opacity-0 translate-y-4"}`,children:[e.jsxs("div",{className:"flex items-center gap-4 mb-3",children:[e.jsxs("div",{className:"relative",children:[e.jsx("div",{className:"p-3 bg-gradient-to-br from-purple-500/20 to-violet-500/20 rounded-xl border border-purple-500/30",children:e.jsx(V,{className:"h-7 w-7 text-purple-400"})}),e.jsx("div",{className:"absolute -top-1 -right-1 w-3 h-3 bg-purple-500 rounded-full animate-pulse"})]}),e.jsx("div",{children:e.jsx("span",{className:"category-badge text-purple-400 tracking-widest",children:"Asset Management"})})]}),e.jsx("h1",{className:"page-title text-4xl lg:text-5xl text-white dark:text-white tracking-tight",children:"Fixed Assets"}),e.jsx("p",{className:"mt-3 text-lg text-gray-400 dark:text-gray-400 max-w-2xl",children:"Track depreciation, manage disposals, and generate asset registers with precision"})]}),e.jsxs("div",{className:`flex flex-wrap items-center gap-3 transition-all duration-700 delay-200 ${k?"opacity-100 translate-y-0":"opacity-0 translate-y-4"}`,children:[e.jsxs(n,{variant:"secondary",onClick:G,className:"flex items-center gap-2 bg-white/5 hover:bg-white/10 border-white/10 hover:border-emerald-500/30 transition-all duration-300",children:[e.jsx(re,{className:"h-4 w-4"}),e.jsx("span",{className:"hidden sm:inline",children:"Export"})]}),e.jsxs(n,{variant:"secondary",onClick:Y,className:"flex items-center gap-2 bg-white/5 hover:bg-white/10 border-white/10 hover:border-emerald-500/30 transition-all duration-300",children:[e.jsx(le,{className:"h-4 w-4"}),e.jsx("span",{className:"hidden sm:inline",children:"Print"})]}),e.jsx("div",{className:"fab-container",children:e.jsxs(n,{variant:"primary",onClick:()=>p(!0),className:"flex items-center gap-2 bg-gradient-to-r from-emerald-600 to-cyan-600 hover:from-emerald-500 hover:to-cyan-500 border-0 shadow-lg shadow-emerald-500/25 hover:shadow-emerald-500/40 transition-all duration-300",children:[e.jsx(B,{className:"h-4 w-4"}),e.jsx("span",{children:"Add Asset"})]})})]})]})}),e.jsxs("section",{className:"grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6 mb-8",children:[e.jsxs("div",{className:"asset-card metric-card bg-gradient-to-br from-slate-900/80 to-slate-800/60 backdrop-blur-xl rounded-xl border border-white/10 p-5 lg:p-6 hover:border-emerald-500/30 transition-all duration-500 ",children:[e.jsxs("div",{className:"flex items-center gap-3 mb-4",children:[e.jsx("div",{className:"p-2 bg-emerald-500/10 rounded-lg",children:e.jsx(ee,{className:"h-5 w-5 text-emerald-400"})}),e.jsx("span",{className:"text-sm font-medium text-gray-400 uppercase tracking-wider",children:"Total Assets"})]}),e.jsx("p",{className:"hero-number text-3xl lg:text-4xl font-bold text-white font-mono",children:s.length})]}),e.jsxs("div",{className:"asset-card metric-card bg-gradient-to-br from-slate-900/80 to-slate-800/60 backdrop-blur-xl rounded-xl border border-white/10 p-5 lg:p-6 hover:border-blue-500/30 transition-all duration-500",children:[e.jsxs("div",{className:"flex items-center gap-3 mb-4",children:[e.jsx("div",{className:"p-2 bg-blue-500/10 rounded-lg",children:e.jsx(te,{className:"h-5 w-5 text-blue-400"})}),e.jsx("span",{className:"text-sm font-medium text-gray-400 uppercase tracking-wider",children:"Original Cost"})]}),e.jsx("p",{className:"hero-number text-3xl lg:text-4xl font-bold text-blue-400 font-mono",children:o(F)})]}),e.jsxs("div",{className:"asset-card metric-card bg-gradient-to-br from-slate-900/80 to-slate-800/60 backdrop-blur-xl rounded-xl border border-white/10 p-5 lg:p-6 hover:border-amber-500/30 transition-all duration-500",children:[e.jsxs("div",{className:"flex items-center gap-3 mb-4",children:[e.jsx("div",{className:"p-2 bg-amber-500/10 rounded-lg",children:e.jsx(ie,{className:"h-5 w-5 text-amber-400"})}),e.jsx("span",{className:"text-sm font-medium text-gray-400 uppercase tracking-wider",children:"Accum. Dep."})]}),e.jsx("p",{className:"hero-number text-3xl lg:text-4xl font-bold text-amber-400 font-mono",children:o(D)})]}),e.jsxs("div",{className:"asset-card metric-card live bg-gradient-to-br from-slate-900/80 to-slate-800/60 backdrop-blur-xl rounded-xl border border-white/10 p-5 lg:p-6 hover:border-emerald-500/30 transition-all duration-500",children:[e.jsxs("div",{className:"flex items-center gap-3 mb-4",children:[e.jsx("div",{className:"p-2 bg-emerald-500/10 rounded-lg",children:e.jsx(oe,{className:"h-5 w-5 text-emerald-400"})}),e.jsx("span",{className:"text-sm font-medium text-gray-400 uppercase tracking-wider",children:"Net Book Value"})]}),e.jsx("p",{className:"hero-number text-3xl lg:text-4xl font-bold text-emerald-400 font-mono",children:o(A)})]})]}),M?e.jsx("div",{className:"space-y-4",children:e.jsx(se,{variant:"rounded",className:"h-64"})}):e.jsxs("div",{className:"asset-card deco-corner bg-gradient-to-br from-slate-900/80 to-slate-800/60 backdrop-blur-xl rounded-xl border border-white/10 overflow-hidden",children:[e.jsxs("div",{className:"px-6 py-5 border-b border-white/10 bg-white/[0.02]",children:[e.jsx("h2",{className:"text-lg font-semibold text-white tracking-tight",children:"Asset Register"}),e.jsx("p",{className:"text-sm text-gray-400 mt-1",children:"Complete listing of all registered fixed assets"})]}),e.jsx("div",{className:"overflow-x-auto",children:e.jsxs("table",{className:"w-full",role:"table",children:[e.jsx("thead",{children:e.jsxs("tr",{className:"border-b border-white/10 bg-white/[0.02]",children:[e.jsx("th",{className:"text-left py-4 px-6 text-xs font-bold text-gray-400 uppercase tracking-wider",children:"Asset #"}),e.jsx("th",{className:"text-left py-4 px-6 text-xs font-bold text-gray-400 uppercase tracking-wider",children:"Name"}),e.jsx("th",{className:"text-left py-4 px-6 text-xs font-bold text-gray-400 uppercase tracking-wider",children:"Category"}),e.jsx("th",{className:"text-left py-4 px-6 text-xs font-bold text-gray-400 uppercase tracking-wider",children:"Purchase Date"}),e.jsx("th",{className:"text-right py-4 px-6 text-xs font-bold text-gray-400 uppercase tracking-wider",children:"Cost"}),e.jsx("th",{className:"text-right py-4 px-6 text-xs font-bold text-gray-400 uppercase tracking-wider",children:"Accum. Dep."}),e.jsx("th",{className:"text-right py-4 px-6 text-xs font-bold text-gray-400 uppercase tracking-wider",children:"Net Book Value"}),e.jsx("th",{className:"text-center py-4 px-6 text-xs font-bold text-gray-400 uppercase tracking-wider",children:"Method"}),e.jsx("th",{className:"text-center py-4 px-6 text-xs font-bold text-gray-400 uppercase tracking-wider",children:"Actions"})]})}),e.jsx("tbody",{className:"divide-y divide-white/5",children:s.length===0?e.jsx("tr",{children:e.jsx("td",{colSpan:9,className:"py-12 text-center text-gray-400",children:e.jsxs("div",{className:"flex flex-col items-center gap-3",children:[e.jsx(V,{className:"h-12 w-12 text-gray-600"}),e.jsx("p",{children:"No assets registered yet"}),e.jsx(n,{variant:"primary",onClick:()=>p(!0),className:"mt-2",children:"Add Your First Asset"})]})})}):s.map((t,r)=>e.jsxs("tr",{className:"asset-row",style:{animationDelay:`${.1+r*.05}s`},children:[e.jsx("td",{className:"py-4 px-6",children:e.jsx("span",{className:"asset-number text-sm text-emerald-400 font-medium",children:t.assetNumber})}),e.jsx("td",{className:"py-4 px-6",children:e.jsx("span",{className:"text-sm text-white font-medium",children:t.assetName})}),e.jsx("td",{className:"py-4 px-6",children:e.jsx("span",{className:`category-badge inline-flex px-2.5 py-1 rounded-md border ${H(t.assetCategory)}`,children:X(t.assetCategory)})}),e.jsx("td",{className:"py-4 px-6",children:e.jsx("span",{className:"text-sm text-gray-400",children:new Date(t.purchaseDate).toLocaleDateString("en-US",{month:"short",day:"numeric",year:"numeric"})})}),e.jsx("td",{className:"py-4 px-6 text-right",children:e.jsx("span",{className:"text-sm font-medium text-blue-400 font-mono",children:o(t.purchaseCost)})}),e.jsx("td",{className:"py-4 px-6 text-right",children:e.jsx("span",{className:"text-sm text-amber-400 font-mono",children:o(t.accumulatedDepreciation)})}),e.jsx("td",{className:"py-4 px-6 text-right",children:e.jsx("span",{className:"text-sm font-bold text-emerald-400 font-mono",children:o(t.currentBookValue)})}),e.jsx("td",{className:"py-4 px-6 text-center",children:e.jsx("span",{className:"text-xs text-gray-500 uppercase tracking-wide",children:t.depreciationMethod.replace("_"," ")})}),e.jsx("td",{className:"py-4 px-6",children:e.jsxs("div",{className:"flex items-center justify-center gap-1",children:[e.jsx("button",{onClick:()=>{N({assetName:t.assetName,assetNumber:t.assetNumber,category:t.assetCategory||"",purchaseCost:t.purchaseCost.toString(),purchaseDate:new Date(t.purchaseDate).toISOString().split("T")[0],usefulLife:t.usefulLife.toString(),salvageValue:t.salvageValue.toString()}),p(!0)},className:"p-2 hover:bg-white/5 rounded-lg transition-colors group",title:"Edit asset",children:e.jsx(ne,{className:"h-4 w-4 text-gray-500 group-hover:text-emerald-400 transition-colors"})}),e.jsx("button",{onClick:()=>v({show:!0,assetId:t.assetId,assetName:t.assetName}),className:"p-2 hover:bg-white/5 rounded-lg transition-colors group",title:"Delete asset",children:e.jsx(R,{className:"h-4 w-4 text-gray-500 group-hover:text-rose-400 transition-colors"})})]})})]},t.assetId))}),s.length>0&&e.jsx("tfoot",{children:e.jsxs("tr",{className:"border-t-2 border-emerald-500/20 bg-emerald-500/5",children:[e.jsx("td",{colSpan:4,className:"py-4 px-6 text-sm font-bold text-gray-300 text-right uppercase tracking-wider",children:"Totals"}),e.jsx("td",{className:"py-4 px-6 text-right",children:e.jsx("span",{className:"text-sm font-bold text-blue-400 font-mono",children:o(F)})}),e.jsx("td",{className:"py-4 px-6 text-right",children:e.jsx("span",{className:"text-sm font-bold text-amber-400 font-mono",children:o(D)})}),e.jsx("td",{className:"py-4 px-6 text-right",children:e.jsx("span",{className:"text-base font-bold text-emerald-400 font-mono",children:o(A)})}),e.jsx("td",{colSpan:2})]})})]})})]}),z&&e.jsxs("div",{className:"fixed inset-0 z-50 flex items-center justify-center p-4",children:[e.jsx("div",{className:"modal-overlay absolute inset-0",onClick:T,"aria-hidden":"true"}),e.jsxs("div",{className:"relative w-full max-w-2xl bg-gradient-to-br from-slate-900 to-slate-800 rounded-2xl border border-white/10 shadow-2xl shadow-black/50 overflow-hidden animate-in fade-in zoom-in-95 duration-300",children:[e.jsx("div",{className:"px-6 py-5 border-b border-white/10 bg-white/[0.02]",children:e.jsxs("div",{className:"flex items-center gap-3",children:[e.jsx("div",{className:"p-2 bg-emerald-500/10 rounded-lg",children:e.jsx(B,{className:"h-5 w-5 text-emerald-400"})}),e.jsxs("div",{children:[e.jsx("h3",{className:"text-lg font-semibold text-white",children:"Add New Fixed Asset"}),e.jsx("p",{className:"text-sm text-gray-400 mt-0.5",children:"Register a new asset for depreciation tracking"})]})]})}),e.jsx("div",{className:"p-6",children:e.jsxs("div",{className:"grid grid-cols-2 gap-4",children:[e.jsxs("div",{className:"col-span-2",children:[e.jsxs("label",{className:"block text-sm font-medium text-gray-300 mb-2",children:["Asset Name ",e.jsx("span",{className:"text-red-400",children:"*"})]}),e.jsx("input",{type:"text",placeholder:"e.g., Forklift - Toyota 8-Series",value:l.assetName,onChange:t=>c("assetName",t.target.value),className:`w-full px-4 py-3 bg-white/5 border rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-emerald-500/50 focus:ring-1 focus:ring-emerald-500/50 transition-all ${a.assetName?"input-error":"border-white/10"}`}),a.assetName&&e.jsxs("p",{className:"mt-1 text-sm text-red-400 flex items-center gap-1",children:[e.jsx(m,{className:"h-4 w-4"}),a.assetName]})]}),e.jsxs("div",{children:[e.jsxs("label",{className:"block text-sm font-medium text-gray-300 mb-2",children:["Asset Number ",e.jsx("span",{className:"text-red-400",children:"*"})]}),e.jsx("input",{type:"text",placeholder:"e.g., EQ-2024-001",value:l.assetNumber,onChange:t=>c("assetNumber",t.target.value),className:`w-full px-4 py-3 bg-white/5 border rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-emerald-500/50 focus:ring-1 focus:ring-emerald-500/50 transition-all font-mono ${a.assetNumber?"input-error":"border-white/10"}`}),a.assetNumber&&e.jsxs("p",{className:"mt-1 text-sm text-red-400 flex items-center gap-1",children:[e.jsx(m,{className:"h-4 w-4"}),a.assetNumber]})]}),e.jsxs("div",{children:[e.jsxs("label",{className:"block text-sm font-medium text-gray-300 mb-2",children:["Category ",e.jsx("span",{className:"text-red-400",children:"*"})]}),e.jsxs("select",{value:l.category,onChange:t=>c("category",t.target.value),className:`w-full px-4 py-3 bg-white/5 border rounded-lg text-white focus:outline-none focus:border-emerald-500/50 focus:ring-1 focus:ring-emerald-500/50 transition-all ${a.category?"input-error":"border-white/10"}`,children:[e.jsx("option",{value:"",children:"Select category"}),e.jsx("option",{value:"Equipment",children:"Equipment"}),e.jsx("option",{value:"Vehicles",children:"Vehicles"}),e.jsx("option",{value:"Building_Improve",children:"Building Improvements"}),e.jsx("option",{value:"Furniture_Fixt",children:"Furniture & Fixtures"})]}),a.category&&e.jsxs("p",{className:"mt-1 text-sm text-red-400 flex items-center gap-1",children:[e.jsx(m,{className:"h-4 w-4"}),a.category]})]}),e.jsxs("div",{children:[e.jsxs("label",{className:"block text-sm font-medium text-gray-300 mb-2",children:["Purchase Cost ",e.jsx("span",{className:"text-red-400",children:"*"})]}),e.jsxs("div",{className:"relative",children:[e.jsx("span",{className:"absolute left-4 top-1/2 -translate-y-1/2 text-gray-500",children:"$"}),e.jsx("input",{type:"number",placeholder:"0.00",value:l.purchaseCost,onChange:t=>c("purchaseCost",t.target.value),className:`w-full pl-8 pr-4 py-3 bg-white/5 border rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-emerald-500/50 focus:ring-1 focus:ring-emerald-500/50 transition-all font-mono ${a.purchaseCost?"input-error":"border-white/10"}`})]}),a.purchaseCost&&e.jsxs("p",{className:"mt-1 text-sm text-red-400 flex items-center gap-1",children:[e.jsx(m,{className:"h-4 w-4"}),a.purchaseCost]})]}),e.jsxs("div",{children:[e.jsxs("label",{className:"block text-sm font-medium text-gray-300 mb-2",children:["Purchase Date ",e.jsx("span",{className:"text-red-400",children:"*"})]}),e.jsx("input",{type:"date",value:l.purchaseDate,onChange:t=>c("purchaseDate",t.target.value),className:`w-full px-4 py-3 bg-white/5 border rounded-lg text-white focus:outline-none focus:border-emerald-500/50 focus:ring-1 focus:ring-emerald-500/50 transition-all ${a.purchaseDate?"input-error":"border-white/10"}`}),a.purchaseDate&&e.jsxs("p",{className:"mt-1 text-sm text-red-400 flex items-center gap-1",children:[e.jsx(m,{className:"h-4 w-4"}),a.purchaseDate]})]}),e.jsxs("div",{children:[e.jsxs("label",{className:"block text-sm font-medium text-gray-300 mb-2",children:["Useful Life (Years) ",e.jsx("span",{className:"text-red-400",children:"*"})]}),e.jsx("input",{type:"number",placeholder:"10",value:l.usefulLife,onChange:t=>c("usefulLife",t.target.value),className:`w-full px-4 py-3 bg-white/5 border rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-emerald-500/50 focus:ring-1 focus:ring-emerald-500/50 transition-all font-mono ${a.usefulLife?"input-error":"border-white/10"}`}),a.usefulLife&&e.jsxs("p",{className:"mt-1 text-sm text-red-400 flex items-center gap-1",children:[e.jsx(m,{className:"h-4 w-4"}),a.usefulLife]})]}),e.jsxs("div",{children:[e.jsx("label",{className:"block text-sm font-medium text-gray-300 mb-2",children:"Salvage Value"}),e.jsxs("div",{className:"relative",children:[e.jsx("span",{className:"absolute left-4 top-1/2 -translate-y-1/2 text-gray-500",children:"$"}),e.jsx("input",{type:"number",placeholder:"0.00",value:l.salvageValue,onChange:t=>c("salvageValue",t.target.value),className:"w-full pl-8 pr-4 py-3 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-emerald-500/50 focus:ring-1 focus:ring-emerald-500/50 transition-all font-mono"})]})]})]})}),e.jsxs("div",{className:"px-6 py-4 border-t border-white/10 bg-white/[0.02] flex justify-end gap-3",children:[e.jsx(n,{variant:"secondary",onClick:T,disabled:u,className:"bg-white/5 hover:bg-white/10 border-white/10",children:"Cancel"}),e.jsx(n,{variant:"primary",onClick:U,disabled:u,className:"bg-gradient-to-r from-emerald-600 to-cyan-600 hover:from-emerald-500 hover:to-cyan-500 border-0",children:u?e.jsxs("span",{className:"flex items-center gap-2",children:[e.jsxs("svg",{className:"animate-spin h-4 w-4",viewBox:"0 0 24 24",children:[e.jsx("circle",{className:"opacity-25",cx:"12",cy:"12",r:"10",stroke:"currentColor",strokeWidth:"4",fill:"none"}),e.jsx("path",{className:"opacity-75",fill:"currentColor",d:"M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"})]}),"Saving..."]}):"Save Asset"})]})]})]}),g.show&&e.jsxs("div",{className:"fixed inset-0 z-50 flex items-center justify-center p-4",children:[e.jsx("div",{className:"modal-overlay absolute inset-0",onClick:()=>v({show:!1,assetId:"",assetName:""})}),e.jsxs("div",{className:"relative w-full max-w-md bg-gradient-to-br from-slate-900 to-slate-800 rounded-2xl border border-white/10 shadow-2xl p-6",children:[e.jsxs("div",{className:"flex items-center gap-4 mb-4",children:[e.jsx("div",{className:"p-3 bg-red-500/10 rounded-lg",children:e.jsx(R,{className:"h-6 w-6 text-red-400"})}),e.jsxs("div",{children:[e.jsx("h3",{className:"text-lg font-semibold text-white",children:"Delete Asset"}),e.jsxs("p",{className:"text-sm text-gray-400",children:['Are you sure you want to delete "',g.assetName,'"?']})]})]}),e.jsx("p",{className:"text-sm text-gray-400 mb-6",children:"This action cannot be undone. The asset will be permanently removed from the register."}),e.jsxs("div",{className:"flex justify-end gap-3",children:[e.jsx(n,{variant:"secondary",onClick:()=>v({show:!1,assetId:"",assetName:""}),disabled:u,className:"bg-white/5 hover:bg-white/10 border-white/10",children:"Cancel"}),e.jsx(n,{variant:"primary",onClick:P,disabled:u,className:"bg-red-600 hover:bg-red-500 border-0",children:u?"Deleting...":"Delete"})]})]})]})]})]})}export{Ce as default};
//# sourceMappingURL=FixedAssetsPage-Dxc5Jblj.js.map
