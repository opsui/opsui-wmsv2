import{j as e}from"./query-vendor-Blg1vgCh.js";import{r as d}from"./react-vendor-DNNwn-hs.js";import{u as ce,d6 as s,d7 as de,d8 as xe,d9 as me,da as pe,C as h,p as g,a2 as u,db as r,ai as ue,B as N,x as D,d5 as R,i as J,j as X,n as he,l as ae,ao as i,au as G}from"./index-BO_lgoz9.js";import{B as ge}from"./Breadcrumb-Alv723Oy.js";import{P as be}from"./Pagination-DEU4fgvr.js";import{F as ie}from"./ClockIcon-lDDVf0Sd.js";import{F as Z}from"./ChevronRightIcon-B5iKoqAu.js";import{F as fe}from"./ArrowUturnLeftIcon-7AFYGIky.js";const ee=`
  :root {
    --exception-bg-primary: #0c0f1a;
    --exception-bg-secondary: #111827;
    --exception-accent-urgent: #ef4444;
    --exception-accent-warning: #f59e0b;
    --exception-accent-success: #22c55e;
    --exception-accent-info: #3b82f6;
    --exception-glow-urgent: 0 0 30px rgba(239, 68, 68, 0.4);
    --exception-glow-warning: 0 0 30px rgba(245, 158, 11, 0.4);
    --exception-glow-success: 0 0 30px rgba(34, 197, 94, 0.4);
    --exception-border-subtle: rgba(255, 255, 255, 0.06);
    --exception-border-accent: rgba(168, 85, 247, 0.3);
    --safe-bottom: env(safe-area-inset-bottom, 0px);
    --safe-top: env(safe-area-inset-top, 0px);
  }

  /* Staggered entrance animations - 300ms max for mobile */
  @keyframes exception-stagger-in {
    0% {
      opacity: 0;
      transform: translateY(12px) scale(0.98);
    }
    100% {
      opacity: 1;
      transform: translateY(0) scale(1);
    }
  }

  @keyframes exception-scale-in {
    0% {
      opacity: 0;
      transform: scale(0.95);
    }
    100% {
      opacity: 1;
      transform: scale(1);
    }
  }

  @keyframes pulse-glow-urgent {
    0%, 100% {
      box-shadow: 0 0 5px rgba(239, 68, 68, 0.4), 0 0 20px rgba(239, 68, 68, 0.2);
    }
    50% {
      box-shadow: 0 0 15px rgba(239, 68, 68, 0.6), 0 0 40px rgba(239, 68, 68, 0.3);
    }
  }

  @keyframes pulse-dot {
    0%, 100% {
      transform: scale(1);
      opacity: 1;
    }
    50% {
      transform: scale(1.5);
      opacity: 0.7;
    }
  }

  @keyframes hero-stat-glow {
    0%, 100% {
      filter: drop-shadow(0 0 20px rgba(239, 68, 68, 0.3));
    }
    50% {
      filter: drop-shadow(0 0 40px rgba(239, 68, 68, 0.5));
    }
  }

  @keyframes scan-line {
    0% {
      transform: translateY(-100%);
    }
    100% {
      transform: translateY(100vh);
    }
  }

  @keyframes grain-shift {
    0%, 100% { transform: translate(0, 0); }
    10% { transform: translate(-5%, -10%); }
    20% { transform: translate(-15%, 5%); }
    30% { transform: translate(7%, -25%); }
    40% { transform: translate(-5%, 25%); }
    50% { transform: translate(-15%, 10%); }
    60% { transform: translate(15%, 0%); }
    70% { transform: translate(0%, 15%); }
    80% { transform: translate(3%, 35%); }
    90% { transform: translate(-10%, 10%); }
  }

  @keyframes shimmer {
    0% { background-position: 200% 0; }
    100% { background-position: -200% 0; }
  }

  /* Skeleton loaders */
  .skeleton {
    background: linear-gradient(
      90deg,
      rgba(255, 255, 255, 0.05) 25%,
      rgba(255, 255, 255, 0.1) 50%,
      rgba(255, 255, 255, 0.05) 75%
    );
    background-size: 200% 100%;
    animation: shimmer 1.5s infinite;
    border-radius: 8px;
  }

  .skeleton-text { height: 1em; width: 70%; margin-bottom: 8px; }
  .skeleton-heading { height: 2em; width: 50%; margin-bottom: 12px; }
  .skeleton-card { height: 120px; width: 100%; }
  .skeleton-stat { height: 100px; width: 100%; }

  /* Reduced motion support */
  @media (prefers-reduced-motion: reduce) {
    .exception-stagger-item,
    .exception-card-animate,
    .pulse-glow-urgent,
    .pulse-dot,
    .hero-stat-glow,
    .exception-scan-line,
    .skeleton {
      animation: none !important;
      opacity: 1 !important;
      transform: none !important;
    }
  }

  .exception-stagger-item {
    animation: exception-stagger-in 0.3s ease-out forwards;
    opacity: 0;
  }

  .exception-stagger-item:nth-child(1) { animation-delay: 0ms; }
  .exception-stagger-item:nth-child(2) { animation-delay: 30ms; }
  .exception-stagger-item:nth-child(3) { animation-delay: 60ms; }
  .exception-stagger-item:nth-child(4) { animation-delay: 90ms; }
  .exception-stagger-item:nth-child(5) { animation-delay: 120ms; }
  .exception-stagger-item:nth-child(6) { animation-delay: 150ms; }
  .exception-stagger-item:nth-child(7) { animation-delay: 180ms; }
  .exception-stagger-item:nth-child(8) { animation-delay: 210ms; }
  .exception-stagger-item:nth-child(9) { animation-delay: 240ms; }
  .exception-stagger-item:nth-child(10) { animation-delay: 270ms; }

  .exception-card-animate {
    animation: exception-scale-in 0.25s ease-out forwards;
    opacity: 0;
  }

  .pulse-glow-urgent {
    animation: pulse-glow-urgent 2s ease-in-out infinite;
  }

  .pulse-dot {
    animation: pulse-dot 1.5s ease-in-out infinite;
  }

  .hero-stat-glow {
    animation: hero-stat-glow 3s ease-in-out infinite;
  }

  /* Industrial typography */
  .exception-display-font {
    font-family: 'Archivo', sans-serif;
    font-weight: 800;
    letter-spacing: -0.03em;
  }

  .exception-mono-font {
    font-family: 'JetBrains Mono', monospace;
    font-weight: 600;
    letter-spacing: 0.05em;
  }

  .exception-body-font {
    font-family: 'Plus Jakarta Sans', sans-serif;
    font-weight: 500;
  }

  /* Atmospheric background */
  .exception-atmosphere {
    position: relative;
  }

  .exception-atmosphere::before {
    content: '';
    position: fixed;
    inset: 0;
    background: 
      radial-gradient(ellipse at 20% 0%, rgba(239, 68, 68, 0.08) 0%, transparent 50%),
      radial-gradient(ellipse at 80% 100%, rgba(245, 158, 11, 0.06) 0%, transparent 50%),
      radial-gradient(ellipse at 50% 50%, rgba(168, 85, 247, 0.04) 0%, transparent 70%);
    pointer-events: none;
    z-index: 0;
  }

  /* Grain texture overlay */
  .exception-grain {
    position: relative;
  }

  .exception-grain::after {
    content: '';
    position: fixed;
    inset: 0;
    background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 400 400' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E");
    opacity: 0.03;
    pointer-events: none;
    z-index: 1;
    animation: grain-shift 8s steps(10) infinite;
  }

  /* Scan line effect */
  .exception-scan-line {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    height: 2px;
    background: linear-gradient(90deg, transparent 0%, rgba(239, 68, 68, 0.5) 50%, transparent 100%);
    animation: scan-line 8s linear infinite;
    pointer-events: none;
    z-index: 100;
    opacity: 0.5;
  }

  /* Industrial corner accents */
  .exception-card-industrial {
    position: relative;
    border: 1px solid var(--exception-border-subtle);
    background: linear-gradient(145deg, rgba(17, 24, 39, 0.95) 0%, rgba(12, 15, 26, 0.98) 100%);
  }

  .exception-card-industrial::before,
  .exception-card-industrial::after {
    content: '';
    position: absolute;
    width: 16px;
    height: 16px;
    border-style: solid;
    border-color: rgba(168, 85, 247, 0.4);
    transition: border-color 0.3s ease;
  }

  .exception-card-industrial::before {
    top: -1px;
    left: -1px;
    border-width: 2px 0 0 2px;
    border-radius: 4px 0 0 0;
  }

  .exception-card-industrial::after {
    bottom: -1px;
    right: -1px;
    border-width: 0 2px 2px 0;
    border-radius: 0 0 4px 0;
  }

  .exception-card-industrial:hover::before,
  .exception-card-industrial:hover::after {
    border-color: rgba(168, 85, 247, 0.7);
  }

  /* Hero stat card - breaks the grid */
  .exception-hero-stat {
    position: relative;
    background: linear-gradient(135deg, rgba(239, 68, 68, 0.15) 0%, rgba(17, 24, 39, 0.95) 100%);
    border: 2px solid rgba(239, 68, 68, 0.3);
    overflow: visible;
  }

  .exception-hero-stat::before {
    content: '';
    position: absolute;
    inset: -2px;
    background: linear-gradient(135deg, rgba(239, 68, 68, 0.4) 0%, transparent 50%, transparent 100%);
    border-radius: inherit;
    z-index: -1;
    opacity: 0;
    transition: opacity 0.3s ease;
  }

  .exception-hero-stat:hover::before {
    opacity: 1;
  }

  /* Urgent badge glow */
  .exception-badge-urgent {
    box-shadow: 0 0 10px rgba(239, 68, 68, 0.5), 0 0 20px rgba(239, 68, 68, 0.2);
  }

  /* Type-specific glow effects */
  .exception-type-glow-damage {
    text-shadow: 0 0 10px rgba(239, 68, 68, 0.5);
  }

  .exception-type-glow-warning {
    text-shadow: 0 0 10px rgba(245, 158, 11, 0.5);
  }

  /* Filter button active state */
  .exception-filter-active {
    position: relative;
    overflow: hidden;
  }

  .exception-filter-active::after {
    content: '';
    position: absolute;
    bottom: 0;
    left: 50%;
    transform: translateX(-50%);
    width: 60%;
    height: 2px;
    background: currentColor;
    border-radius: 1px;
  }

  /* Resolution option hover effect */
  .exception-resolution-option {
    transition: all 0.2s ease;
  }

  .exception-resolution-option:hover {
    transform: translateX(4px);
  }

  /* Mobile active press states */
  @media (hover: none) {
    .exception-card-industrial:active,
    .exception-resolution-option:active,
    .exception-touch-active:active {
      transform: scale(0.98);
      opacity: 0.95;
    }
    
    .btn-mobile-active:active {
      transform: scale(0.96);
    }
  }

  /* Modal backdrop industrial */
  .exception-modal-backdrop {
    background: rgba(0, 0, 0, 0.85);
    backdrop-filter: blur(4px);
  }

  /* Accent divider */
  .exception-divider {
    height: 1px;
    background: linear-gradient(90deg, transparent 0%, rgba(168, 85, 247, 0.3) 50%, transparent 100%);
  }

  /* Status indicator dot */
  .exception-status-dot {
    width: 8px;
    height: 8px;
    border-radius: 50%;
  }

  .exception-status-dot-open {
    background: #ef4444;
    box-shadow: 0 0 8px rgba(239, 68, 68, 0.6);
  }

  .exception-status-dot-resolved {
    background: #22c55e;
    box-shadow: 0 0 8px rgba(34, 197, 94, 0.6);
  }

  /* Mobile-first hero grid - single column on mobile */
  .exception-hero-grid {
    display: flex;
    flex-direction: column;
    gap: 1rem;
  }

  @media (min-width: 768px) {
    .exception-hero-grid {
      display: grid;
      grid-template-columns: 1.5fr 1fr 1fr 1fr;
      gap: 1.5rem;
    }
  }

  /* Quantity display mono */
  .exception-quantity {
    font-family: 'JetBrains Mono', monospace;
    font-weight: 700;
    font-variant-numeric: tabular-nums;
  }

  /* Mobile input styles - 16px prevents iOS zoom */
  .exception-mobile-input {
    font-size: 16px;
    min-height: 48px;
    padding: 14px 16px;
  }

  /* iPhone 14 Pro Max specific fixes */
  @media (max-width: 440px) {
    .exception-hero-grid {
      gap: 0.75rem;
    }

    .exception-resolution-option {
      padding: 0.75rem 1rem;
    }

    /* Better tap targets for exception cards */
    .exception-card-animate {
      padding: 1rem;
    }

    /* Smaller header text for narrow screens */
    .exception-display-font {
      letter-spacing: -0.04em;
    }
  }

  /* Mobile touch target - 44px minimum */
  .exception-touch-target {
    min-height: 44px;
    min-width: 44px;
  }

  /* Mobile button - 52px for primary CTA */
  .exception-mobile-btn {
    min-height: 52px;
    padding: 16px 24px;
    font-size: 16px;
  }

  /* Mobile bottom sheet for modal */
  .exception-mobile-modal {
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    max-height: 90vh;
    border-radius: 24px 24px 0 0;
    transform: translateY(100%);
    transition: transform 0.28s cubic-bezier(0.32, 0.72, 0, 1);
  }

  .exception-mobile-modal.open {
    transform: translateY(0);
  }

  @media (min-width: 640px) {
    .exception-mobile-modal {
      position: relative;
      bottom: auto;
      left: auto;
      right: auto;
      max-height: none;
      border-radius: 16px;
      transform: none;
    }
  }

  /* Light mode overrides */
  html.light .exception-atmosphere::before {
    background: 
      radial-gradient(ellipse at 20% 0%, rgba(239, 68, 68, 0.05) 0%, transparent 50%),
      radial-gradient(ellipse at 80% 100%, rgba(245, 158, 11, 0.04) 0%, transparent 50%);
  }

  html.light .exception-card-industrial {
    background: linear-gradient(145deg, rgba(255, 255, 255, 0.98) 0%, rgba(248, 250, 252, 0.98) 100%);
    border-color: rgba(0, 0, 0, 0.08);
  }

  html.light .exception-hero-stat {
    background: linear-gradient(135deg, rgba(239, 68, 68, 0.08) 0%, rgba(255, 255, 255, 0.98) 100%);
  }

  /* Focus visible styles */
  .exception-focus-visible:focus-visible {
    outline: 2px solid rgba(168, 85, 247, 0.8);
    outline-offset: 2px;
  }

  .exception-focus-visible:focus:not(:focus-visible) {
    outline: none;
  }

  /* Mobile sticky bottom CTA */
  .exception-mobile-cta {
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    padding: 16px;
    padding-bottom: calc(16px + var(--safe-bottom));
    background: linear-gradient(to top, rgba(12, 15, 26, 0.98), transparent);
    z-index: 50;
    backdrop-filter: blur(8px);
  }

  @media (min-width: 768px) {
    .exception-mobile-cta {
      position: relative;
      bottom: auto;
      left: auto;
      right: auto;
      padding: 0;
      padding-bottom: 0;
      background: none;
    }
  }
`;function we(){return e.jsx("div",{className:"relative border-2 border-red-500/30 rounded-xl overflow-hidden bg-gradient-to-br from-red-500/10 to-gray-900/95",children:e.jsxs("div",{className:"p-6 sm:p-8",children:[e.jsxs("div",{className:"flex items-center gap-2 mb-4",children:[e.jsx("div",{className:"skeleton w-2 h-2 rounded-full"}),e.jsx("div",{className:"skeleton w-24 h-3 rounded"})]}),e.jsx("div",{className:"skeleton w-20 h-16 sm:h-20 rounded-lg mb-2"}),e.jsx("div",{className:"skeleton w-40 h-4 rounded"}),e.jsx("div",{className:"mt-6 h-1.5 bg-gray-800 rounded-full overflow-hidden",children:e.jsx("div",{className:"skeleton w-1/2 h-full"})})]})})}function M(){return e.jsx("div",{className:"exception-card-industrial rounded-xl",children:e.jsxs("div",{className:"p-5 sm:p-6",children:[e.jsx("div",{className:"w-8 h-8 rounded-lg skeleton mb-3"}),e.jsx("div",{className:"skeleton w-16 h-10 rounded-lg"}),e.jsx("div",{className:"skeleton w-24 h-3 rounded mt-1"})]})})}function ve(){return e.jsxs("div",{className:"exception-card-industrial rounded-xl mb-3 relative",children:[e.jsx("div",{className:"absolute left-0 top-4 bottom-4 w-1 skeleton rounded-r-full"}),e.jsxs("div",{className:"p-4 sm:p-5 pl-4",children:[e.jsxs("div",{className:"flex flex-wrap items-center gap-2 mb-4 pl-3",children:[e.jsx("div",{className:"skeleton w-20 h-6 rounded"}),e.jsx("div",{className:"skeleton w-16 h-6 rounded"}),e.jsx("div",{className:"skeleton w-24 h-4 rounded ml-auto"})]}),e.jsxs("div",{className:"flex flex-col sm:grid sm:grid-cols-4 gap-3 sm:gap-4 pl-3",children:[e.jsxs("div",{children:[e.jsx("div",{className:"skeleton w-12 h-3 rounded mb-1"}),e.jsx("div",{className:"skeleton w-20 h-4 rounded"})]}),e.jsxs("div",{children:[e.jsx("div",{className:"skeleton w-8 h-3 rounded mb-1"}),e.jsx("div",{className:"skeleton w-16 h-4 rounded"})]}),e.jsxs("div",{children:[e.jsx("div",{className:"skeleton w-14 h-3 rounded mb-1"}),e.jsx("div",{className:"skeleton w-12 h-4 rounded"})]}),e.jsxs("div",{children:[e.jsx("div",{className:"skeleton w-16 h-3 rounded mb-1"}),e.jsx("div",{className:"skeleton w-20 h-4 rounded"})]})]})]})]})}function te({status:b}){const n={[r.OPEN]:{color:"bg-red-500/20 text-red-400 border border-red-500/40",label:"OPEN",glow:"exception-badge-urgent pulse-glow-urgent"},[r.REVIEWING]:{color:"bg-amber-500/20 text-amber-400 border border-amber-500/40",label:"REVIEWING",glow:"shadow-[0_0_15px_rgba(245,158,11,0.3)]"},[r.APPROVED]:{color:"bg-blue-500/20 text-blue-400 border border-blue-500/40",label:"APPROVED"},[r.REJECTED]:{color:"bg-gray-500/20 text-gray-400 border border-gray-500/40",label:"REJECTED"},[r.RESOLVED]:{color:"bg-emerald-500/20 text-emerald-400 border border-emerald-500/40",label:"RESOLVED"},[r.CANCELLED]:{color:"bg-gray-500/20 text-gray-400 border border-gray-500/40",label:"CANCELLED"}},l=n[b]||n[r.OPEN];return e.jsx("span",{className:`px-2.5 py-1.5 rounded-md text-xs sm:text-[0.65rem] font-bold uppercase tracking-wider exception-mono-font ${l.color} ${l.glow||""}`,children:l.label})}function se({type:b}){const n={[i.UNCLAIM]:{icon:ae,color:"text-gray-400",label:"Unclaimed"},[i.UNDO_PICK]:{icon:fe,color:"text-amber-400",label:"Undo Pick",glowClass:"exception-type-glow-warning"},[i.SHORT_PICK]:{icon:u,color:"text-red-400",label:"Short Pick",glowClass:"exception-type-glow-damage"},[i.SHORT_PICK_BACKORDER]:{icon:ie,color:"text-amber-400",label:"Backorder",glowClass:"exception-type-glow-warning"},[i.DAMAGE]:{icon:G,color:"text-red-400",label:"Damaged",glowClass:"exception-type-glow-damage"},[i.DEFECTIVE]:{icon:G,color:"text-red-400",label:"Defective",glowClass:"exception-type-glow-damage"},[i.WRONG_ITEM]:{icon:u,color:"text-red-400",label:"Wrong Item",glowClass:"exception-type-glow-damage"},[i.SUBSTITUTION]:{icon:R,color:"text-blue-400",label:"Substitution"},[i.OUT_OF_STOCK]:{icon:u,color:"text-red-400",label:"Out of Stock",glowClass:"exception-type-glow-damage"},[i.BIN_MISMATCH]:{icon:u,color:"text-amber-400",label:"Bin Mismatch",glowClass:"exception-type-glow-warning"},[i.BARCODE_MISMATCH]:{icon:u,color:"text-amber-400",label:"Barcode Issue",glowClass:"exception-type-glow-warning"},[i.EXPIRED]:{icon:u,color:"text-red-400",label:"Expired",glowClass:"exception-type-glow-damage"},[i.OTHER]:{icon:R,color:"text-gray-400",label:"Other"}},l=n[b]||n[i.OTHER],c=l.icon;return e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx("div",{className:`p-1.5 sm:p-1 rounded-md bg-white/5 ${l.color}`,children:e.jsx(c,{className:"h-4 w-4 sm:h-3.5 sm:w-3.5"})}),e.jsx("span",{className:`text-xs sm:text-xs font-semibold uppercase tracking-wide exception-mono-font ${l.color} ${l.glowClass||""}`,children:l.label})]})}function Oe(){const b=ce(t=>t.canSupervise),[n,l]=d.useState(null),[c,S]=d.useState("all"),[B,f]=d.useState(!1),[x,T]=d.useState(s.BACKORDER),[P,j]=d.useState(""),[L,y]=d.useState(""),[F,k]=d.useState(0),[K,E]=d.useState(""),[O,$]=d.useState(1),[v,oe]=d.useState(""),{data:p,refetch:I,isLoading:ne}=de(c==="all"?{limit:20,offset:(O-1)*20}:{status:c,limit:20,offset:(O-1)*20});d.useEffect(()=>{$(1),I(),U()},[c,v]);const{data:A,refetch:U}=xe(),{data:o,refetch:q,isLoading:z}=me(),_=pe();if(!b())return e.jsxs("div",{className:"flex items-center justify-center min-h-screen exception-atmosphere exception-grain",children:[e.jsx("style",{children:ee}),e.jsx(h,{className:"max-w-md exception-card-industrial mx-4",children:e.jsxs(g,{className:"p-8 text-center",children:[e.jsx("div",{className:"w-16 h-16 mx-auto mb-6 rounded-2xl bg-red-500/10 flex items-center justify-center pulse-glow-urgent",children:e.jsx(u,{className:"h-8 w-8 text-red-400"})}),e.jsx("h2",{className:"text-2xl font-bold text-white mb-3 exception-display-font",children:"Access Denied"}),e.jsx("p",{className:"text-gray-400 exception-body-font",children:"Supervisor or admin privileges required to access the Exception Control Center."})]})})]});const re=async()=>{if(n)try{await _.mutateAsync({exceptionId:n.exceptionId,dto:{exceptionId:n.exceptionId,resolution:x,notes:P,resolvedBy:"current-user",substituteSku:x===s.SUBSTITUTE?L:void 0,newQuantity:x===s.ADJUST_QUANTITY?F:void 0,newBinLocation:x===s.TRANSFER_BIN?K:void 0}}),I(),U(),q(),f(!1),l(null),j(""),y(""),k(0),E("")}catch(t){console.error("Failed to resolve exception:",t)}},le=t=>{const a=[{value:s.CANCEL_ITEM,label:"Cancel Item",description:"Remove this item from the order"},{value:s.CANCEL_ORDER,label:"Cancel Order",description:"Cancel the entire order"},{value:s.CONTACT_CUSTOMER,label:"Contact Customer",description:"Reach out to customer for guidance"},{value:s.MANUAL_OVERRIDE,label:"Manual Override",description:"Manually resolve without automated action"}];return{[i.UNCLAIM]:[{value:s.MANUAL_OVERRIDE,label:"Re-assign Order",description:"Assign order to a different picker/packer"},{value:s.CONTACT_CUSTOMER,label:"Investigate Issue",description:"Review the unclaim reason and follow up"},{value:s.CANCEL_ORDER,label:"Cancel Order",description:"Cancel the order if needed"},{value:s.MANUAL_OVERRIDE,label:"Archive",description:"Mark as reviewed and close"}],[i.SHORT_PICK]:[{value:s.BACKORDER,label:"Backorder",description:"Place item on backorder"},{value:s.SUBSTITUTE,label:"Substitute",description:"Offer substitute product"},{value:s.ADJUST_QUANTITY,label:"Adjust Quantity",description:"Update quantity to what is available"},...a],[i.SHORT_PICK_BACKORDER]:[{value:s.BACKORDER,label:"Backorder",description:"Confirm backorder for customer"},{value:s.SUBSTITUTE,label:"Substitute",description:"Offer substitute product instead"},{value:s.CANCEL_ITEM,label:"Cancel Item",description:"Remove this item from order"},...a.filter(w=>w.value!==s.CANCEL_ITEM)],[i.DAMAGE]:[{value:s.RETURN_TO_STOCK,label:"Return to Stock",description:"Return item if salvageable"},{value:s.WRITE_OFF,label:"Write Off",description:"Write off damaged item"},{value:s.SUBSTITUTE,label:"Substitute",description:"Send replacement item"},...a],[i.DEFECTIVE]:[{value:s.RETURN_TO_STOCK,label:"Return to Stock",description:"Return for RMA if applicable"},{value:s.WRITE_OFF,label:"Write Off",description:"Write off defective item"},{value:s.SUBSTITUTE,label:"Substitute",description:"Send replacement item"},...a],[i.WRONG_ITEM]:[{value:s.TRANSFER_BIN,label:"Transfer Bin",description:"Move item to correct bin location"},{value:s.RETURN_TO_STOCK,label:"Return to Stock",description:"Return item to inventory"},...a],[i.SUBSTITUTION]:[{value:s.SUBSTITUTE,label:"Confirm Substitution",description:"Process the substitution"},...a],[i.OUT_OF_STOCK]:[{value:s.BACKORDER,label:"Backorder",description:"Place on backorder"},{value:s.SUBSTITUTE,label:"Substitute",description:"Offer alternative product"},{value:s.CANCEL_ITEM,label:"Cancel Item",description:"Remove item from order"},...a.filter(w=>w.value!==s.CANCEL_ITEM)],[i.BIN_MISMATCH]:[{value:s.TRANSFER_BIN,label:"Transfer Bin",description:"Update to correct bin location"},{value:s.RETURN_TO_STOCK,label:"Return to Stock",description:"Return item for proper stocking"},...a],[i.BARCODE_MISMATCH]:[{value:s.MANUAL_OVERRIDE,label:"Manual Override",description:"Manually verify and correct"},...a],[i.EXPIRED]:[{value:s.WRITE_OFF,label:"Write Off",description:"Dispose of expired item"},{value:s.SUBSTITUTE,label:"Substitute",description:"Send fresh replacement"},...a],[i.UNDO_PICK]:[{value:s.MANUAL_OVERRIDE,label:"Acknowledge",description:"Acknowledge the undo pick action"},{value:s.RETURN_TO_STOCK,label:"Return to Stock",description:"Return item to inventory"},...a],[i.OTHER]:a}[t]||a},C=(c===r.OPEN?(A==null?void 0:A.exceptions)||[]:(p==null?void 0:p.exceptions)||[]).filter(t=>{var m,w,Q,W,Y;if(!v.trim())return!0;const a=v.toLowerCase();return((m=t.exceptionId)==null?void 0:m.toLowerCase().includes(a))||((w=t.orderId)==null?void 0:w.toLowerCase().includes(a))||((Q=t.sku)==null?void 0:Q.toLowerCase().includes(a))||((W=t.type)==null?void 0:W.toLowerCase().includes(a))||((Y=t.status)==null?void 0:Y.toLowerCase().includes(a))}),V=C.filter(t=>t.status===r.OPEN).length,H=C.find(t=>t.status===r.OPEN);return e.jsxs("div",{className:"min-h-screen exception-atmosphere exception-grain",children:[e.jsx("style",{children:ee}),e.jsx("div",{className:"exception-scan-line"}),e.jsx(ue,{}),e.jsxs("main",{className:"relative z-10 w-full px-4 sm:px-6 lg:px-8 py-6 sm:py-8 space-y-6 sm:space-y-8 pb-[calc(5rem+var(--safe-bottom))] sm:pb-8",children:[e.jsx(ge,{}),b()&&e.jsxs(e.Fragment,{children:[e.jsx("div",{className:"exception-stagger-item",children:e.jsxs("div",{className:"flex flex-col items-center sm:items-start sm:flex-row sm:items-end sm:justify-between gap-4 text-center sm:text-left",children:[e.jsxs("div",{className:"flex-1 min-w-0",children:[e.jsxs("div",{className:"flex items-center justify-center sm:justify-start gap-2 sm:gap-3 mb-2",children:[o&&o.open>0&&e.jsx("div",{className:"exception-status-dot exception-status-dot-open pulse-dot flex-shrink-0"}),e.jsxs("h1",{className:"text-xl sm:text-4xl md:text-5xl text-white exception-display-font leading-tight whitespace-normal break-normal min-w-0",children:["EXCEPTION",e.jsx("span",{className:"text-red-400",children:" "}),"CONTROL"]})]}),e.jsx("p",{className:"text-gray-400 exception-body-font text-sm sm:text-lg",children:"Monitor, Investigate, Resolve"})]}),e.jsx("div",{className:"flex items-center gap-3 w-full sm:w-auto justify-center sm:justify-end",children:e.jsxs(N,{variant:"secondary",size:"sm",onClick:()=>{I(),U(),q()},className:"exception-card-industrial !bg-transparent exception-touch-target btn-mobile-active min-w-[100px] sm:min-w-0",children:[e.jsx(ie,{className:"h-4 w-4 mr-2"}),e.jsx("span",{className:"hidden sm:inline",children:"Refresh"}),e.jsx("span",{className:"sm:hidden",children:"Refresh"})]})})]})}),z?e.jsxs("div",{className:"exception-hero-grid",children:[e.jsx(we,{}),e.jsx(M,{}),e.jsx(M,{}),e.jsx(M,{})]}):o&&e.jsxs("div",{className:"exception-hero-grid",children:[e.jsx(h,{className:"exception-hero-stat hero-stat-glow exception-stagger-item overflow-hidden",children:e.jsxs(g,{className:"p-6 sm:p-8 relative",children:[e.jsxs("div",{className:"absolute inset-0 opacity-10",children:[e.jsx("div",{className:"absolute top-0 right-0 w-32 h-32 bg-red-500 rounded-full blur-3xl"}),e.jsx("div",{className:"absolute bottom-0 left-0 w-24 h-24 bg-amber-500 rounded-full blur-3xl"})]}),e.jsxs("div",{className:"relative min-w-0",children:[e.jsxs("div",{className:"flex items-center gap-2 mb-4",children:[e.jsx("div",{className:"exception-status-dot exception-status-dot-open pulse-dot"}),e.jsx("p",{className:"text-xs font-bold uppercase tracking-wider sm:tracking-widest text-red-400 exception-mono-font truncate",children:"CRITICAL / OPEN"})]}),e.jsx("p",{className:"text-6xl sm:text-7xl md:text-8xl font-black text-white exception-display-font leading-tight mb-2 overflow-hidden text-ellipsis",children:o.open}),e.jsx("p",{className:"text-gray-500 exception-body-font",children:"Require immediate attention"}),e.jsx("div",{className:"mt-6 h-1.5 bg-gray-800 rounded-full overflow-hidden",children:e.jsx("div",{className:"h-full bg-gradient-to-r from-red-500 to-amber-500 rounded-full transition-all duration-500",style:{width:`${o.total>0?o.open/o.total*100:0}%`}})})]})]})}),e.jsx(h,{className:"exception-card-industrial exception-stagger-item",children:e.jsxs(g,{className:"p-5 sm:p-6",children:[e.jsx("div",{className:"flex items-center gap-2 mb-3",children:e.jsx("div",{className:"w-8 h-8 rounded-lg bg-gray-500/10 flex items-center justify-center",children:e.jsx(u,{className:"h-4 w-4 text-gray-400"})})}),e.jsx("p",{className:"text-3xl sm:text-4xl font-black text-white exception-display-font",children:o.total}),e.jsx("p",{className:"text-xs uppercase tracking-wider text-gray-500 exception-mono-font mt-1",children:"Total Exceptions"})]})}),e.jsx(h,{className:"exception-card-industrial exception-stagger-item",children:e.jsxs(g,{className:"p-5 sm:p-6",children:[e.jsx("div",{className:"flex items-center gap-2 mb-3",children:e.jsx("div",{className:"w-8 h-8 rounded-lg bg-emerald-500/10 flex items-center justify-center",children:e.jsx(D,{className:"h-4 w-4 text-emerald-400"})})}),e.jsx("p",{className:"text-3xl sm:text-4xl font-black text-emerald-400 exception-display-font",children:o.resolved}),e.jsx("p",{className:"text-xs uppercase tracking-wider text-gray-500 exception-mono-font mt-1",children:"Resolved"})]})}),e.jsx(h,{className:"exception-card-industrial exception-stagger-item",children:e.jsxs(g,{className:"p-5 sm:p-6",children:[e.jsx("div",{className:"flex items-center gap-2 mb-3",children:e.jsx("div",{className:"w-8 h-8 rounded-lg bg-purple-500/10 flex items-center justify-center",children:e.jsx(R,{className:"h-4 w-4 text-purple-400"})})}),e.jsxs("p",{className:"text-3xl sm:text-4xl font-black text-purple-400 exception-display-font",children:[o.total>0?Math.round(o.resolved/o.total*100):0,"%"]}),e.jsx("p",{className:"text-xs uppercase tracking-wider text-gray-500 exception-mono-font mt-1",children:"Resolution Rate"})]})})]}),!z&&o&&Object.keys(o.byType).length>0&&e.jsxs(h,{className:"exception-card-industrial exception-stagger-item",children:[e.jsx(J,{children:e.jsx(X,{className:"text-sm font-bold uppercase tracking-widest text-gray-400 exception-mono-font",children:"Exception Distribution by Type"})}),e.jsx(g,{children:e.jsx("div",{className:"grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-2 sm:gap-3",children:Object.entries(o.byType).map(([t,a],m)=>e.jsxs("div",{className:"exception-card-animate group p-4 rounded-xl bg-white/[0.02] border border-white/[0.05] hover:border-purple-500/30 hover:bg-purple-500/5 transition-all duration-300 cursor-default exception-touch-target exception-touch-active",style:{animationDelay:`${m*50}ms`},children:[e.jsx("p",{className:"text-2xl font-black text-white exception-display-font group-hover:text-purple-300 transition-colors",children:a}),e.jsx("p",{className:"text-xs sm:text-[0.65rem] uppercase tracking-wide text-gray-500 exception-mono-font mt-1 sm:truncate",children:t.replace(/_/g," ")})]},t))})})]}),e.jsxs("div",{className:"flex flex-wrap gap-2 sm:gap-3 exception-stagger-item",children:[e.jsxs("button",{onClick:()=>S("all"),className:`flex-1 sm:flex-none min-w-[90px] sm:min-w-0 px-3 sm:px-5 py-2.5 sm:py-2.5 rounded-lg text-[0.7rem] sm:text-xs font-bold uppercase tracking-wider exception-mono-font transition-all duration-200 exception-touch-target exception-focus-visible ${c==="all"?"bg-purple-500 text-white shadow-lg shadow-purple-500/25 exception-filter-active":"exception-card-industrial text-gray-400 hover:text-white hover:border-purple-500/30"}`,children:[e.jsx("span",{className:"hidden sm:inline",children:"All"}),e.jsx("span",{className:"sm:hidden",children:"All"}),e.jsxs("span",{className:"ml-1 sm:ml-2",children:["(",(o==null?void 0:o.total)||0,")"]})]}),e.jsx("button",{onClick:()=>S(r.OPEN),className:`flex-1 sm:flex-none min-w-[90px] sm:min-w-0 px-3 sm:px-5 py-2.5 sm:py-2.5 rounded-lg text-[0.7rem] sm:text-xs font-bold uppercase tracking-wider exception-mono-font transition-all duration-200 exception-touch-target exception-focus-visible ${c===r.OPEN?"bg-red-500 text-white shadow-lg shadow-red-500/25 exception-filter-active":"exception-card-industrial text-gray-400 hover:text-red-400 hover:border-red-500/30"}`,children:e.jsxs("span",{className:"flex items-center justify-center gap-1.5 sm:gap-2",children:[o&&o.open>0&&e.jsx("span",{className:"w-1.5 h-1.5 rounded-full bg-red-400 pulse-dot flex-shrink-0"}),e.jsx("span",{className:"hidden sm:inline",children:"Open"}),e.jsx("span",{className:"sm:hidden",children:"Open"}),e.jsxs("span",{children:["(",(o==null?void 0:o.open)||0,")"]})]})}),e.jsxs("button",{onClick:()=>S(r.RESOLVED),className:`flex-1 sm:flex-none min-w-[90px] sm:min-w-0 px-3 sm:px-5 py-2.5 sm:py-2.5 rounded-lg text-[0.7rem] sm:text-xs font-bold uppercase tracking-wider exception-mono-font transition-all duration-200 exception-touch-target exception-focus-visible ${c===r.RESOLVED?"bg-emerald-500 text-white shadow-lg shadow-emerald-500/25 exception-filter-active":"exception-card-industrial text-gray-400 hover:text-emerald-400 hover:border-emerald-500/30"}`,children:[e.jsx("span",{className:"hidden sm:inline",children:"Resolved"}),e.jsx("span",{className:"sm:hidden",children:"Done"}),e.jsxs("span",{className:"ml-1 sm:ml-2",children:["(",(o==null?void 0:o.resolved)||0,")"]})]})]}),e.jsxs(h,{className:"exception-card-industrial exception-stagger-item",children:[e.jsx(J,{children:e.jsxs("div",{className:"flex flex-col gap-3",children:[e.jsx(X,{className:"text-sm font-bold uppercase tracking-widest text-gray-400 exception-mono-font",children:c==="all"?"ALL EXCEPTIONS":c===r.OPEN?"OPEN EXCEPTIONS — ACTION REQUIRED":"RESOLVED EXCEPTIONS"}),e.jsxs("div",{className:"relative w-full sm:w-72",children:[e.jsx("label",{className:"block text-xs font-bold uppercase tracking-wider text-gray-500 exception-mono-font mb-2",children:"Search"}),e.jsxs("div",{className:"relative",children:[e.jsx(he,{className:"absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-500"}),e.jsx("input",{type:"text",inputMode:"search",placeholder:"ID, Order, SKU...",value:v,onChange:t=>oe(t.target.value),className:"w-full pl-10 pr-4 py-3 sm:py-2.5 bg-white/[0.02] border border-white/[0.08] rounded-lg text-base sm:text-sm text-white placeholder-gray-600 exception-mono-font focus:outline-none focus:border-purple-500/50 focus:bg-white/[0.04] transition-all exception-mobile-input exception-focus-visible"})]})]})]})}),e.jsx(g,{children:ne?e.jsx("div",{className:"space-y-3",children:[...Array(5)].map((t,a)=>e.jsx(ve,{},a))}):C.length>0?e.jsx("div",{className:"space-y-3",children:C.map((t,a)=>{const m=t.status===r.OPEN;return e.jsxs("div",{className:`exception-card-animate group relative p-4 sm:p-5 rounded-xl transition-all duration-300 exception-touch-active ${m?"exception-card-industrial pulse-glow-urgent hover:border-red-500/50":"exception-card-industrial hover:border-purple-500/30"}`,style:{animationDelay:`${a*75}ms`},children:[m&&e.jsx("div",{className:"absolute left-0 top-4 bottom-4 w-1 bg-gradient-to-b from-red-500 to-amber-500 rounded-r-full"}),e.jsxs("div",{className:"flex flex-wrap items-center gap-2 sm:gap-3 mb-4 pl-3",children:[e.jsx(se,{type:t.type}),e.jsx(te,{status:t.status}),e.jsxs("span",{className:"text-xs sm:text-[0.65rem] text-gray-500 exception-mono-font ml-auto",children:["#",t.exceptionId]})]}),e.jsxs("div",{className:"grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4 pl-3 min-w-0",children:[e.jsxs("div",{className:"min-w-0",children:[e.jsx("p",{className:"text-xs sm:text-[0.65rem] uppercase tracking-wide sm:tracking-wider text-gray-500 exception-mono-font mb-1.5 sm:mb-1",children:"Order"}),e.jsx("p",{className:"text-sm font-semibold text-white exception-mono-font truncate",children:t.orderId})]}),e.jsxs("div",{className:"min-w-0",children:[e.jsx("p",{className:"text-xs sm:text-[0.65rem] uppercase tracking-wide sm:tracking-wider text-gray-500 exception-mono-font mb-1.5 sm:mb-1",children:"SKU"}),e.jsx("p",{className:"text-sm font-semibold text-white exception-mono-font truncate",children:t.sku})]}),e.jsxs("div",{className:"min-w-0",children:[e.jsx("p",{className:"text-xs sm:text-[0.65rem] uppercase tracking-wide sm:tracking-wider text-gray-500 exception-mono-font mb-1.5 sm:mb-1",children:"Qty"}),e.jsxs("div",{className:"text-sm text-white exception-quantity",children:[e.jsxs("span",{className:"sm:hidden block",children:[e.jsx("span",{className:"text-red-400 font-bold",children:t.quantityActual}),e.jsx("span",{className:"text-gray-500",children:" / "}),e.jsx("span",{children:t.quantityExpected})]}),e.jsxs("span",{className:"hidden sm:inline",children:[e.jsx("span",{className:"text-red-400",children:t.quantityActual}),e.jsx("span",{className:"text-gray-600 mx-1",children:"/"}),e.jsx("span",{children:t.quantityExpected})]}),t.quantityShort>0&&e.jsxs("span",{className:"text-red-400 text-xs sm:text-sm block sm:inline sm:ml-1 mt-0.5 sm:mt-0",children:["-",t.quantityShort," short"]})]})]}),e.jsxs("div",{className:"min-w-0",children:[e.jsx("p",{className:"text-xs sm:text-[0.65rem] uppercase tracking-wide sm:tracking-wider text-gray-500 exception-mono-font mb-1.5 sm:mb-1",children:"Reported"}),e.jsx("p",{className:"text-sm text-gray-400 exception-mono-font truncate",children:new Date(t.reportedAt).toLocaleDateString()})]})]}),t.reason&&e.jsx("div",{className:"mt-4 ml-3 p-3 rounded-lg bg-white/[0.02] border-l-2 border-purple-500/50",children:e.jsxs("p",{className:"text-xs text-gray-400 exception-body-font italic",children:['"',t.reason,'"']})}),t.resolution&&e.jsxs("div",{className:"mt-4 ml-3 flex flex-wrap items-center gap-2 min-w-0",children:[e.jsx("span",{className:"text-[0.65rem] uppercase tracking-wide sm:tracking-wider text-gray-600 exception-mono-font",children:"Resolution:"}),e.jsx("span",{className:"text-xs font-semibold text-emerald-400 exception-mono-font truncate",children:t.resolution.replace(/_/g," ")})]}),t.resolutionNotes&&e.jsx("div",{className:"mt-3 ml-3 p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/20",children:e.jsx("p",{className:"text-xs text-emerald-300 exception-body-font",children:t.resolutionNotes})}),m&&e.jsx("div",{className:"mt-4 sm:mt-5 ml-3",children:e.jsxs(N,{variant:"primary",size:"sm",onClick:()=>{l(t),f(!0),T(s.BACKORDER),j(""),y(""),k(0),E("")},className:"w-full sm:w-auto bg-gradient-to-r from-red-500 to-amber-500 hover:from-red-400 hover:to-amber-400 text-white font-bold uppercase text-xs tracking-wider exception-mono-font shadow-lg shadow-red-500/25 exception-mobile-btn sm:!min-h-[36px] sm:!py-2 sm:!text-sm btn-mobile-active whitespace-nowrap",children:[e.jsx("span",{className:"whitespace-nowrap",children:"Resolve Exception"}),e.jsx(Z,{className:"h-4 w-4 ml-1 flex-shrink-0"})]})})]},t.exceptionId)})}):e.jsxs("div",{className:"flex flex-col items-center justify-center py-16 sm:py-20",children:[e.jsx("div",{className:"w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-emerald-500/10 flex items-center justify-center mb-6",children:e.jsx(D,{className:"h-8 w-8 sm:h-10 sm:w-10 text-emerald-400"})}),e.jsx("p",{className:"text-lg font-semibold text-white exception-display-font mb-2",children:"All Clear"}),e.jsx("p",{className:"text-sm text-gray-500 exception-body-font text-center px-4",children:v?"No exceptions match your search criteria":"No exceptions match this filter"})]})})]}),(p==null?void 0:p.total)&&p.total>0&&e.jsx(be,{currentPage:O,totalItems:p.total,pageSize:20,onPageChange:$,onPageSizeChange:()=>{},pageSizeOptions:[10,20,50,100]})]})]}),V>0&&H&&e.jsx("div",{className:"exception-mobile-cta sm:hidden px-4",children:e.jsxs(N,{variant:"primary",onClick:()=>{l(H),f(!0),T(s.BACKORDER),j(""),y(""),k(0),E("")},className:"w-full bg-gradient-to-r from-red-500 to-amber-500 hover:from-red-400 hover:to-amber-400 text-white font-bold uppercase text-xs sm:text-sm tracking-wider exception-mono-font shadow-lg shadow-red-500/25 exception-mobile-btn flex items-center justify-center gap-2 whitespace-nowrap overflow-hidden",children:[e.jsx("span",{className:"truncate",children:"Resolve Exception"}),e.jsxs("span",{className:"flex items-center gap-1 flex-shrink-0",children:[e.jsxs("span",{className:"bg-white/20 px-2 py-0.5 rounded text-xs whitespace-nowrap",children:["(",V,")"]}),e.jsx(Z,{className:"h-4 w-4 flex-shrink-0"})]})]})}),B&&n&&e.jsx("div",{className:"fixed inset-0 z-50 overflow-y-auto",children:e.jsxs("div",{className:"flex items-end sm:items-center justify-center min-h-screen px-0 sm:px-4 pt-4 pb-0 sm:pb-20 text-center sm:block sm:p-0",children:[e.jsx("div",{className:"fixed inset-0 exception-modal-backdrop transition-opacity",onClick:()=>f(!1)}),e.jsxs("div",{className:`exception-mobile-modal ${B?"open":""} inline-block align-bottom bg-gray-900 rounded-t-2xl sm:rounded-2xl text-left overflow-hidden shadow-2xl transform transition-all sm:my-8 sm:align-middle sm:max-w-2xl sm:w-full border-t sm:border border-white/[0.08] exception-card-animate w-full max-h-[90vh]`,children:[e.jsx("div",{className:"sm:hidden flex justify-center pt-3 pb-2",children:e.jsx("div",{className:"w-10 h-1 rounded-full bg-gray-700"})}),e.jsx("div",{className:"relative px-4 sm:px-6 py-4 sm:py-5 border-b border-white/[0.08] bg-gradient-to-r from-red-500/10 to-amber-500/10",children:e.jsxs("div",{className:"relative flex items-center justify-between",children:[e.jsxs("div",{children:[e.jsx("h3",{className:"text-lg sm:text-xl font-bold text-white exception-display-font",children:"Resolve Exception"}),e.jsxs("p",{className:"mt-1 text-xs text-gray-500 exception-mono-font",children:["ID: ",n.exceptionId]})]}),e.jsx("button",{onClick:()=>f(!1),className:"w-11 h-11 rounded-lg bg-white/5 flex items-center justify-center text-gray-400 hover:text-white hover:bg-white/10 transition-colors exception-touch-target exception-focus-visible","aria-label":"Close modal",children:e.jsx(ae,{className:"h-6 w-6"})})]})}),e.jsxs("div",{className:"px-4 sm:px-6 py-4 sm:py-6 max-h-[50vh] sm:max-h-[60vh] overflow-y-auto",children:[e.jsxs("div",{className:"mb-6",children:[e.jsxs("h4",{className:"text-xs font-bold uppercase tracking-widest text-gray-500 exception-mono-font mb-4 flex items-center gap-2",children:[e.jsx("div",{className:"w-4 h-4 rounded bg-purple-500/20 flex items-center justify-center",children:e.jsx(R,{className:"h-3 w-3 text-purple-400"})}),"Exception Details"]}),e.jsxs("div",{className:"p-4 rounded-xl bg-white/[0.02] border border-white/[0.08]",children:[e.jsxs("div",{className:"flex flex-wrap items-center gap-2 sm:gap-3 mb-4",children:[e.jsx(se,{type:n.type}),e.jsx(te,{status:n.status})]}),e.jsxs("div",{className:"grid grid-cols-2 sm:grid-cols-4 gap-3",children:[e.jsxs("div",{className:"p-3 rounded-lg bg-white/[0.02]",children:[e.jsx("p",{className:"text-xs sm:text-[0.65rem] uppercase tracking-wider text-gray-500 exception-mono-font mb-1.5 sm:mb-1",children:"Order"}),e.jsx("p",{className:"text-sm font-semibold text-white exception-mono-font truncate",children:n.orderId})]}),e.jsxs("div",{className:"p-3 rounded-lg bg-white/[0.02]",children:[e.jsx("p",{className:"text-xs sm:text-[0.65rem] uppercase tracking-wider text-gray-500 exception-mono-font mb-1.5 sm:mb-1",children:"SKU"}),e.jsx("p",{className:"text-sm font-semibold text-white exception-mono-font truncate",children:n.sku})]}),e.jsxs("div",{className:"p-3 rounded-lg bg-white/[0.02]",children:[e.jsx("p",{className:"text-xs sm:text-[0.65rem] uppercase tracking-wider text-gray-500 exception-mono-font mb-1.5 sm:mb-1",children:"Expected"}),e.jsx("p",{className:"text-sm font-semibold text-white exception-quantity",children:n.quantityExpected})]}),e.jsxs("div",{className:"p-3 rounded-lg bg-white/[0.02]",children:[e.jsx("p",{className:"text-xs sm:text-[0.65rem] uppercase tracking-wider text-gray-500 exception-mono-font mb-1.5 sm:mb-1",children:"Actual"}),e.jsx("p",{className:"text-sm font-semibold text-red-400 exception-quantity",children:n.quantityActual})]})]}),n.reason&&e.jsxs("div",{className:"mt-4 pt-4 border-t border-white/[0.05]",children:[e.jsx("p",{className:"text-xs sm:text-[0.65rem] uppercase tracking-wider text-gray-500 exception-mono-font mb-2",children:"Reason"}),e.jsxs("p",{className:"text-sm text-gray-300 exception-body-font italic",children:['"',n.reason,'"']})]})]})]}),e.jsxs("div",{className:"space-y-4",children:[e.jsxs("h4",{className:"text-xs font-bold uppercase tracking-widest text-gray-500 exception-mono-font flex items-center gap-2",children:[e.jsx("div",{className:"w-4 h-4 rounded bg-emerald-500/20 flex items-center justify-center",children:e.jsx(D,{className:"h-3 w-3 text-emerald-400"})}),"Select Resolution ",e.jsx("span",{className:"text-red-400",children:"*"})]}),e.jsx("div",{className:"flex flex-col sm:grid sm:grid-cols-2 gap-2",children:le(n.type).map((t,a)=>e.jsxs("button",{onClick:()=>T(t.value),className:`exception-resolution-option text-left p-4 rounded-xl border transition-all exception-touch-target exception-focus-visible ${x===t.value?"border-purple-500 bg-purple-500/10 shadow-lg shadow-purple-500/10":"border-white/[0.08] bg-white/[0.02] hover:border-white/[0.15] hover:bg-white/[0.04]"}`,style:{animationDelay:`${a*25}ms`},children:[e.jsxs("div",{className:"flex items-center gap-2 mb-1",children:[x===t.value&&e.jsx("div",{className:"w-2 h-2 rounded-full bg-purple-400"}),e.jsx("span",{className:"text-sm font-semibold text-white exception-mono-font",children:t.label})]}),e.jsx("p",{className:"text-xs text-gray-500 exception-body-font",children:t.description})]},t.value))}),e.jsxs("div",{className:"p-4 sm:p-5 rounded-xl bg-white/[0.02] border border-white/[0.08]",children:[e.jsx("h5",{className:"text-xs font-bold uppercase tracking-widest text-gray-500 exception-mono-font mb-4",children:"Resolution Details"}),x===s.SUBSTITUTE&&e.jsxs("div",{className:"mb-4",children:[e.jsx("label",{className:"block text-xs font-bold uppercase tracking-wider text-gray-400 exception-mono-font mb-2",children:"Substitute SKU"}),e.jsx("input",{type:"text",inputMode:"text",value:L,onChange:t=>y(t.target.value.toUpperCase()),className:"w-full px-4 py-3 sm:py-2.5 bg-white/[0.02] border border-white/[0.08] rounded-lg text-white exception-mono-font placeholder-gray-600 focus:outline-none focus:border-purple-500/50 focus:bg-white/[0.04] transition-all exception-mobile-input exception-focus-visible",placeholder:"Enter substitute SKU..."})]}),x===s.ADJUST_QUANTITY&&e.jsxs("div",{className:"mb-4",children:[e.jsx("label",{className:"block text-xs font-bold uppercase tracking-wider text-gray-400 exception-mono-font mb-2",children:"New Quantity"}),e.jsx("input",{type:"number",inputMode:"numeric",min:0,max:n.quantityExpected,value:F,onChange:t=>k(parseInt(t.target.value)||0),className:"w-full px-4 py-3 sm:py-2.5 bg-white/[0.02] border border-white/[0.08] rounded-lg text-white exception-mono-font placeholder-gray-600 focus:outline-none focus:border-purple-500/50 focus:bg-white/[0.04] transition-all exception-mobile-input exception-focus-visible",placeholder:"Enter new quantity..."})]}),x===s.TRANSFER_BIN&&e.jsxs("div",{className:"mb-4",children:[e.jsx("label",{className:"block text-xs font-bold uppercase tracking-wider text-gray-400 exception-mono-font mb-2",children:"New Bin Location"}),e.jsx("input",{type:"text",inputMode:"text",value:K,onChange:t=>E(t.target.value.toUpperCase()),className:"w-full px-4 py-3 sm:py-2.5 bg-white/[0.02] border border-white/[0.08] rounded-lg text-white exception-mono-font placeholder-gray-600 focus:outline-none focus:border-purple-500/50 focus:bg-white/[0.04] transition-all exception-mobile-input exception-focus-visible",placeholder:"Enter new bin location..."})]}),e.jsxs("div",{children:[e.jsx("label",{className:"block text-xs font-bold uppercase tracking-wider text-gray-400 exception-mono-font mb-2",children:"Notes (optional)"}),e.jsx("textarea",{value:P,onChange:t=>j(t.target.value),rows:3,className:"w-full px-4 py-3 sm:py-2.5 bg-white/[0.02] border border-white/[0.08] rounded-lg text-white exception-body-font placeholder-gray-600 focus:outline-none focus:border-purple-500/50 focus:bg-white/[0.04] transition-all resize-none exception-mobile-input exception-focus-visible",placeholder:"Add notes about this resolution..."})]})]})]})]}),e.jsxs("div",{className:"sticky bottom-0 px-4 sm:px-6 py-4 sm:py-5 border-t border-white/[0.08] bg-gray-900/95 backdrop-blur-sm flex flex-col sm:flex-row gap-3 pb-[calc(1rem+var(--safe-bottom))] sm:pb-5",children:[e.jsx(N,{variant:"secondary",onClick:()=>f(!1),className:"exception-card-industrial !bg-transparent exception-mobile-btn sm:!min-h-[44px] sm:!py-2.5 sm:!text-sm",children:"Cancel"}),e.jsx(N,{variant:"primary",onClick:re,disabled:_.isPending,className:"bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-white font-bold uppercase text-sm tracking-wider exception-mono-font shadow-lg shadow-emerald-500/25 exception-mobile-btn sm:!min-h-[44px] sm:!py-2.5 sm:!text-sm",children:_.isPending?"Resolving...":"Confirm Resolution"})]})]})]})})]})}export{Oe as ExceptionsPage};
//# sourceMappingURL=ExceptionsPage-B1ZxFJw4.js.map
